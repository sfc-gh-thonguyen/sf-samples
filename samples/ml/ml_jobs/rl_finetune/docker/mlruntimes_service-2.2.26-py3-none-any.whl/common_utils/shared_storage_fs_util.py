from shared_storage.constants import USER_STAGE_NAME
from shared_storage.named_stage_shared_filesystem import NamedStageSharedFileSystem
from shared_storage.user_stage_shared_filesystem import UserStageSharedFileSystem
from pyarrow.fs import PyFileSystem, FSSpecHandler


def get_py_filesystem_for_stage(stage_path=None) -> PyFileSystem:
    """
    Usage:
    from common_utils.shared_storage_fs_util import get_py_filesystem_for_stage
    st_path = "@ST_DB.ST_SCHEMA.ML_MULTI_NODE_FS"
    OR
    st_path = "@~/TEMPORARY_DIRECTORY"
    custom_fs = get_py_filesystem_for_stage(st_path)
    # Note - "storage_path" for RunConfig should NOT be empty
    run_config = RunConfig(storage_path="/", storage_filesystem=custom_fs)
    """
    if stage_path is None or stage_path.startswith(USER_STAGE_NAME):
        stage_fs = UserStageSharedFileSystem(
            stage_path=stage_path or USER_STAGE_NAME,
        )
    else:
        stage_fs = NamedStageSharedFileSystem(
            stage_path=stage_path,
        )
    return PyFileSystem(FSSpecHandler(stage_fs))
