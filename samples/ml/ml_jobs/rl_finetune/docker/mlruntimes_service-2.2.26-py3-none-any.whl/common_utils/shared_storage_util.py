from common_utils.common_util import get_num_ray_nodes
from common_utils.shared_storage_fs_util import get_py_filesystem_for_stage
from ray.train import RunConfig

from snowflake.runtime.utils.session_utils import get_session


def get_run_config_stage_name(num_workers) -> RunConfig:
    # Note - "storage_path" for RunConfig should NOT be empty
    if get_num_ray_nodes() > 1 and num_workers > 1:
        return RunConfig(
            storage_path="/",
            storage_filesystem=get_py_filesystem_for_stage(),
        )
    else:
        return RunConfig()


def convert_to_fully_qualified_stage(stage_name: str) -> str:
    session = get_session()
    if stage_name.startswith("@"):
        stage_name = stage_name[1:]

    parts = stage_name.split(".")
    parts_size = len(parts)
    if parts_size == 3:
        return stage_name
    elif parts_size == 1:
        return ".".join(
            [
                session.get_current_database().replace('"', ""),
                session.get_current_schema().replace('"', ""),
                stage_name,
            ]
        )
    else:
        raise ValueError(
            "Invalid stage name format. Please provide the stage name as one of the following:\n"
            "  - stage_name\n"
            "  - database.schema.stage_name\n"
        )
