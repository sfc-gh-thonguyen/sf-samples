import time
from typing import Dict, List, Any
import functools
import pandas as pd
import requests
import ray
from snowflake.runtime.utils.const import DEFAULT_RAY_METRICS_PORT
import torch
from ray.util.state import list_nodes


def timing(f):
    @functools.wraps(f)
    def wrap(*args, **kwargs):
        time1 = time.time()
        ret = f(*args, **kwargs)
        time2 = time.time()
        print(
            f"{f.__name__} function took {(time2 - time1)} sec with {args} & {kwargs} \n"
        )

        return ret

    return wrap


def get_active_ray_nodes() -> List[Dict[str, Any]]:
    if not ray.is_initialized():
        ray.init(
            address="auto",
            ignore_reinit_error=True,
            log_to_driver=False,
            logging_level="CRITICAL",
        )
    nodes = ray.nodes()
    alive_nodes = [n for n in nodes if n["Alive"]]
    return alive_nodes


def get_num_ray_nodes() -> int:
    return len(get_active_ray_nodes())


def in_multi_node_env() -> bool:
    return get_num_ray_nodes() > 1


def get_total_cluster_cpus() -> float:
    if not ray.is_initialized():
        ray.init(
            address="auto",
            ignore_reinit_error=True,
            log_to_driver=False,
            logging_level="CRITICAL",
        )
    cluster_resources = ray.cluster_resources()
    return cluster_resources.get("CPU", 0)


def get_total_node_resources() -> Dict[str, int]:
    if not ray.is_initialized():
        ray.init(
            address="auto",
            ignore_reinit_error=True,
            log_to_driver=False,
            logging_level="CRITICAL",
        )

    # Note: This assumes that we are operating on a homogeneous cluster.
    resources = list_nodes()[0].resources_total
    return resources


def get_ray_resource_metrics() -> pd.DataFrame:
    """Get resource metrics for every Ray node."""
    nodes = get_active_ray_nodes()
    metrics_used = [
        ("cpu_utilization", "%"),
        ("mem_available", "GB"),
    ]
    is_gpu_available = torch.cuda.is_available()
    if is_gpu_available:
        metrics_used.append(("gpus_utilization", "%"))
        metrics_used.append(("gram_available", "GB"))

    all_nodes_metrics: Dict[str, Dict[str, Any]] = {}

    for idx, node in enumerate(nodes):
        # Can also use NodeManagerAddress as it has the same value as NodeName
        ip_address = node["NodeName"]
        node_name = f"Node_{idx}"
        node_data = {}

        try:
            response = requests.get(
                f"http://{ip_address}:{DEFAULT_RAY_METRICS_PORT}/metrics", timeout=10
            )
            metrics = response.text.splitlines()
            for metric_line in metrics:
                # Metric line example (note: it is one line. Feed a new line to pass flake8)
                # ray_node_cpu_utilization{SessionName="session_2025-05-01_18-31-47_831850_44",
                # Version="2.36.1",ip="10.244.33.73"} 1.4

                # Hack to skip useless lines
                if not metric_line.startswith("ray_node_"):
                    continue
                for metric_name, unit in metrics_used:
                    prefix = f"ray_node_{metric_name}{{"
                    if not metric_line.startswith(prefix):
                        continue
                    try:
                        value = float(metric_line.split("} ")[1])
                    except (IndexError, ValueError):
                        continue

                    # Unit conversion
                    if metric_name == "mem_available":
                        value /= 1024**3  # Bytes → GB
                    elif metric_name == "gram_available":
                        value /= 1024  # MB → GB

                    formatted_value = f"{value:.2f}".rstrip("0").rstrip(".")

                    if is_gpu_available and "GpuIndex=" in metric_line:
                        gpu_idx = metric_line.split('GpuIndex="')[1].split('"')[0]
                        key = (
                            f"GPU {gpu_idx}"
                            if metric_name == "gpus_utilization"
                            else f"GRAM {gpu_idx} Free"
                        )
                    elif metric_name == "cpu_utilization":
                        key = "CPU"
                    elif metric_name == "mem_available":
                        key = "Memory Free"
                    else:
                        key = metric_name

                    node_data[key] = f"{formatted_value}{unit}"
                    break  # Stop checking other metrics for this line

            all_nodes_metrics[node_name] = node_data or {
                "status": "No metrics available"
            }

        except (requests.RequestException, IndexError, ValueError):
            # In case endpoint for accessing worker nodes is not available, we skip the node.
            pass

    # Rotate the dataframe 90 degrees (i.e. we want nodes to be rows and metrics to be columns)
    df = pd.DataFrame.from_dict(all_nodes_metrics, orient="index")
    return df
