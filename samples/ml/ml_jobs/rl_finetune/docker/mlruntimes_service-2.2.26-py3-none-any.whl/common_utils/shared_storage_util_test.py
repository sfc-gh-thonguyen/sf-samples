from unittest.mock import patch
import pytest
from common_utils.shared_storage_util import convert_to_fully_qualified_stage


@patch("common_utils.shared_storage_util.get_session")
def test_convert_to_fully_qualified_stage(mock_get_session):
    # Create a mock session object with proper return values
    mock_session = mock_get_session.return_value
    mock_session.get_current_database.return_value = '"my_db"'
    mock_session.get_current_schema.return_value = '"my_schema"'

    expected_fully_qualified_stage = "my_db.my_schema.my_stage"

    assert (
        convert_to_fully_qualified_stage("my_stage") == expected_fully_qualified_stage
    )
    assert (
        convert_to_fully_qualified_stage("@my_stage") == expected_fully_qualified_stage
    )
    assert (
        convert_to_fully_qualified_stage("@db.schema.my_stage") == "db.schema.my_stage"
    )
    assert (
        convert_to_fully_qualified_stage("db.schema.my_stage") == "db.schema.my_stage"
    )

    with pytest.raises(ValueError):
        convert_to_fully_qualified_stage("@schema.my_stage")
