import logging
import os
import subprocess
import signal
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Any, Optional, Dict

import ray
import requests
import sys
import time

from requests.adapters import HTTPAdapter, Retry
from snowflake.runtime.utils.config import HEALTH_CHECK_PORT, NODE_IP_ADDRESS

from snowflake.runtime.utils.const import (
    HEALTH_CHECK_HTTP_TIMEOUT_10,
    HEALTH_CHECK_HTTP_RETRY_COUNT,
    HEALTH_CHECK_FAILURE_COUNT,
    HEALTH_CHECK_REPEAT_SECS,
    HEALTH_CHECK_FAILURE_DELAY_SECS,
    RAY_STATUS,
    NOTEBOOK_STATUS,
    HEALTH_CHECK_INITIAL_DELAY_SECS,
)
from snowflake.runtime.utils.logger import configure_ray_logger
from snowflake.runtime.utils.metrics import start_prometheus_metrics_port

SNOWBOOK_START_PARAM = "snowbook.web.cli"
SNOWBOOK_STARTUP_DELAY: int = 5
TEMP_FILE_NAME = "need_restart_kernel"
WORKING_DIR = "/tmp"
LIVENESS_LOGGER_DIR = "/var/log/managedservices/system/liveness_process/"
LIVENESS_LOGGER_FILE_NAME = (
    "/var/log/managedservices/system/liveness_process/logs-liveness.log"
)
LOG_MAX_BYTES = 512_000_000
LIVENESS_LOGGING_FORMAT = (
    "%(asctime)s,%(msecs)03d - LIVENESS - %(levelname)s - %(message)s"
)
LIVENESS_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def run_health_check() -> Optional[Dict[str, Any]]:
    """
    Call health check endpoint localhost:5001/health to monitor service health for
    1. ML runtime service
    2. Ray init connection
    3. Notebook service
    """
    url = f"http://{NODE_IP_ADDRESS}:{HEALTH_CHECK_PORT}/health"
    try:
        health_check_session = requests.Session()
        # retry /health check call 2 times
        retries_config = Retry(
            total=HEALTH_CHECK_HTTP_RETRY_COUNT,
            backoff_factor=1,
        )
        health_check_session.mount("http://", HTTPAdapter(max_retries=retries_config))
        health_check_response = health_check_session.get(
            url, data={}, timeout=HEALTH_CHECK_HTTP_TIMEOUT_10
        )
        logging.debug(f"health_check_response: {health_check_response.text}")
        health_check_dict = health_check_response.json()
        return health_check_dict
    except requests.exceptions.RequestException as e:
        logging.error(f"request exception in run_health_check {str(e)}")
        return None


def recovery_action():
    """
    Default recovery action for any service health check failure is to crash the container.
    This will restart the container.
    """
    sys.exit(1)


class ProcessManager:
    def __init__(self):
        self.snowbook_child_process = None

    def start_snowbook(self):
        """
        Notebook process is started as a child process.

        This function will wait until the notebook is ready or the maximum wait time is reached.
        """
        try:
            cmd = ["python", "-m"]
            cmd.extend([SNOWBOOK_START_PARAM])
            logging.debug(f"Starting child process: {cmd}")
            self.snowbook_child_process = subprocess.Popen(cmd)
        finally:
            time.sleep(SNOWBOOK_STARTUP_DELAY)

        # wait until the notebook is ready
        notebook_wait_count = 0
        logging.debug("Waiting for notebook to become ready...")
        while True:
            health_check_resp = run_health_check()
            if health_check_resp is not None and health_check_resp[NOTEBOOK_STATUS]:
                logging.debug("Notebook is now ready!")
                break

            notebook_wait_count += 1
            logging.debug(
                f"Notebook not ready yet, waiting attempt {notebook_wait_count}..."
            )
            time.sleep(HEALTH_CHECK_FAILURE_DELAY_SECS)

            # If we've waited too long, just proceed anyway and let the main loop handle it
            if (
                notebook_wait_count * HEALTH_CHECK_FAILURE_DELAY_SECS
                >= HEALTH_CHECK_INITIAL_DELAY_SECS
            ):
                logging.warning(
                    "Notebook not ready after maximum wait attempts, proceeding anyway"
                )
                break

    def restart_snowbook_process(self):
        """
        After installing new packages notebook kernel restart can be triggered by the user.
        """
        if self.snowbook_child_process:
            self.snowbook_child_process.kill()
        logging.debug("restarting snowbook process")
        self.start_snowbook()

    def kill_snowbook(self):
        if self.snowbook_child_process:
            self.snowbook_child_process.kill()


def is_snowbook_restarted_on_command():
    for file in os.listdir(WORKING_DIR):
        if TEMP_FILE_NAME in file:
            logging.debug("temp file exists, this an intentional snowbook restart")
            return True
    return False


def should_restart_snowbook(health_check_response: Dict[str, Any]) -> bool:
    return (
        health_check_response[RAY_STATUS]
        and not health_check_response[NOTEBOOK_STATUS]
        and is_snowbook_restarted_on_command()
    )


def cleanup_temp_file():
    """
    Temporary file is created by notebook service to signal if it needs a kernel restart.
    """
    file_path = os.path.join(WORKING_DIR, TEMP_FILE_NAME)
    if os.path.exists(file_path):
        os.remove(file_path)
        logging.debug(f"Deleted temporary file: {file_path}")
    else:
        # this should not happen
        logging.debug(f"Failed to delete temporary file: {file_path}")


def setup_liveness_logger():
    # dump logs to LIVENESS_LOGGER_DIR for SPCS to export to Snowhouse
    if not os.path.exists(LIVENESS_LOGGER_DIR):
        os.makedirs(LIVENESS_LOGGER_DIR)
    liveness_logging_handler = RotatingFileHandler(
        filename=LIVENESS_LOGGER_FILE_NAME,
        mode="a",
        maxBytes=LOG_MAX_BYTES,
        backupCount=1,
    )
    liveness_logging_handler.setFormatter(
        logging.Formatter(
            fmt=LIVENESS_LOGGING_FORMAT,
            datefmt=LIVENESS_DATE_FORMAT,
        )
    )
    logging.getLogger().addHandler(liveness_logging_handler)
    logging.getLogger().setLevel(logging.DEBUG)


class SignalHandler:
    def __init__(self, sb_process_manager: ProcessManager):
        self._process_manager = sb_process_manager

        signal.signal(signal.SIGINT, self.kill_processes)
        signal.signal(signal.SIGTERM, self.kill_processes)

    def kill_processes(self, signum, frame):
        logging.debug(
            f"Received signal {signum} at {datetime.now()}, shutting down gracefully..."
        )
        if ray.is_initialized():
            ray.shutdown()

        self._process_manager.kill_snowbook()

        logging.debug(f"Shut down all processes at {datetime.now()}")
        sys.exit(0)


def main() -> None:
    process_manager = ProcessManager()
    SignalHandler(process_manager)

    failure_count = 0
    setup_liveness_logger()

    start_prometheus_metrics_port()
    configure_ray_logger()

    logging.debug("Starting notebook process.")
    process_manager.start_snowbook()

    try:
        while failure_count <= HEALTH_CHECK_FAILURE_COUNT:
            health_check_resp = run_health_check()

            if health_check_resp is None:
                failure_count += 1
                pass

            assert health_check_resp is not None

            if should_restart_snowbook(health_check_resp):
                # Check if temp file exists and restart notebook
                logging.debug("need to restart notebook!")
                cleanup_temp_file()
                process_manager.restart_snowbook_process()
                health_check_resp[NOTEBOOK_STATUS] = True

            if not (
                health_check_resp[NOTEBOOK_STATUS] and health_check_resp[RAY_STATUS]
            ):
                logging.error(
                    f"not healthy, "
                    f"notebook: {health_check_resp[NOTEBOOK_STATUS]}, "
                    f"ray: {health_check_resp[RAY_STATUS]}, "
                )
                if failure_count == HEALTH_CHECK_FAILURE_COUNT:
                    logging.error("failure count reached, exiting main process")
                    recovery_action()
                failure_count += 1
                time.sleep(HEALTH_CHECK_FAILURE_DELAY_SECS * failure_count)
            else:
                logging.debug("liveness_process finds everything healthy!")
                failure_count = 0
                time.sleep(HEALTH_CHECK_REPEAT_SECS)
    except TypeError:
        # should never happen
        recovery_action()

    # should never reach here
    if failure_count >= HEALTH_CHECK_FAILURE_COUNT:
        recovery_action()


if __name__ == "__main__":
    main()
