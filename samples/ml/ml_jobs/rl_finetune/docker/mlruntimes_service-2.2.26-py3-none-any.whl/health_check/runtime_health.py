import socket

import ray
import threading
import requests
import time
from flask import Flask, jsonify
from typing import Dict
from snowflake.runtime.utils.config import (
    IS_WORKER_NODE,
    ENV_SERVICE_NAME,
)
from snowflake.runtime.utils.const import RAY_STATUS, NOTEBOOK_STATUS

from snowflake.runtime.utils.const import (
    HEALTH_CHECK_HTTP_TIMEOUT_10,
    MLRS_METRICS_PORT,
    DEFAULT_RAY_METRICS_PORT,
)

app = Flask(__name__)


def check_ray_status(result_dict: Dict[str, bool], is_worker: int):
    """
    Head node check if cluster is active.
    Worker node connects to Ray cluster and checks if it is connected to head node.
        If not it will crash the container and restart, and will reconnect to head node.
    """
    try:
        result_dict[RAY_STATUS] = False
        if not ray.is_initialized():
            ray.init(
                address="auto",
                ignore_reinit_error=True,
                log_to_driver=False,
                logging_level="CRITICAL",
            )

        if is_worker == 1:
            is_current_node_active = False
            for node in ray.nodes():
                resources = node.get("Resources", {})
                if node.get("Alive", False) and resources.get(ENV_SERVICE_NAME, 0) == 1:
                    is_current_node_active = True
            if not is_current_node_active:
                result_dict[RAY_STATUS] = False
                return
        result_dict[RAY_STATUS] = True
    except ConnectionError:
        return False


def check_ray_health(is_worker: int = 0) -> bool:
    ray_result = dict([(RAY_STATUS, False)])
    # ray.init() takes 30 seconds to timeout, so run it in a thread and timeout after 3 seconds
    ray_init_thread = threading.Thread(
        target=check_ray_status,
        args=(
            ray_result,
            is_worker,
        ),
    )
    ray_init_thread.start()
    ray_init_thread.join(timeout=HEALTH_CHECK_HTTP_TIMEOUT_10)
    return ray_result[RAY_STATUS]


def check_notebook_health() -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        result = sock.connect_ex(("0.0.0.0", 9090))
        return result == 0
    finally:
        sock.close()


def _check_single_metrics_endpoint(endpoint_name, port, timeout=1):
    """
    Check if a single metrics endpoint is ready and serving metrics.

    Args:
        endpoint_name: Human-readable name for the endpoint (for logging)
        port: Port number to check
        timeout: Request timeout in seconds

    Returns:
        tuple: (is_ready: bool, status_message: str)
    """
    try:
        response = requests.get(f"http://localhost:{port}/metrics", timeout=timeout)
        if response.status_code == 200:
            has_metrics = len(response.text.strip()) > 0
            if has_metrics:
                return True, f"{endpoint_name} endpoint ready"
            else:
                return (
                    False,
                    f"{endpoint_name} endpoint responding but no metrics content",
                )
        else:
            return (
                False,
                f"{endpoint_name} endpoint returned status {response.status_code}",
            )

    except (requests.RequestException, requests.Timeout) as e:
        return False, f"{endpoint_name} endpoint connection failed: {e}"


def check_metrics_endpoints_ready(max_retries=20, retry_interval=3.0):
    """
    Check that both MLRS and Ray metrics endpoints are ready and serving metrics.

    Args:
        max_retries: Maximum number of retry attempts
        retry_interval: Time to wait between retries in seconds

    Returns:
        tuple: (is_ready: bool, error_message: str or None)
               If is_ready is True, error_message is None
               If is_ready is False, error_message contains details of failures
    """
    endpoints_to_check = [
        ("MLRS", MLRS_METRICS_PORT),
        ("Ray", DEFAULT_RAY_METRICS_PORT),
    ]

    last_error_messages = {}

    for attempt in range(max_retries):
        endpoint_statuses = {}
        all_ready = True

        for endpoint_name, port in endpoints_to_check:
            is_ready, status_message = _check_single_metrics_endpoint(
                endpoint_name, port
            )
            endpoint_statuses[endpoint_name] = is_ready

            if not is_ready:
                last_error_messages[endpoint_name] = status_message
                all_ready = False

        if all_ready:
            return True, None

        if attempt < max_retries - 1:  # Don't sleep on the last attempt
            time.sleep(retry_interval)

    # Return failure with detailed error message
    error_details = "; ".join(
        [f"{name}: {msg}" for name, msg in last_error_messages.items()]
    )
    error_message = f"Metrics endpoints failed to become ready after {max_retries} attempts. Errors: {error_details}"
    return False, error_message


def get_service_status(is_ray_healthy=False, is_notebook_healthy=False) -> dict:
    return {
        RAY_STATUS: is_ray_healthy,
        NOTEBOOK_STATUS: is_notebook_healthy,
    }


@app.route("/health", methods=["GET"])
def health():
    """
    Head node checks for all three services mlrs, ray and notebook.
    Worker node checks for connection to Ray head node/cluster.
    """
    try:
        if IS_WORKER_NODE == 1:
            is_ray_healthy = check_ray_health(IS_WORKER_NODE)
            is_notebook_healthy = True
        else:
            is_ray_healthy = check_ray_health()
            is_notebook_healthy = check_notebook_health()

        service_status = get_service_status(is_ray_healthy, is_notebook_healthy)
        if is_ray_healthy and is_notebook_healthy:
            return jsonify(service_status), 200
        else:
            return jsonify(service_status), 503
    except Exception as e:
        print(f"exception in health(): {str(e)}")
        return jsonify(get_service_status()), 503
