from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class SearchAlgorithm:
    """
    Base class for hyperparameter search algorithms.

    This is the abstract base class that all search algorithms inherit from.
    It defines the interface for search algorithm implementations.
    """

    pass


@dataclass
class BayesOpt(SearchAlgorithm):
    """
    Bayesian Optimization search algorithm.

    Uses Gaussian processes to model the objective function and intelligently
    select the next hyperparameter configuration to evaluate. This algorithm
    is particularly effective when evaluations are expensive and you want to
    minimize the number of trials needed to find good hyperparameters.

    Args:
        utility_kwargs (Optional[Dict[str, Any]]): Optional keyword arguments
            to pass to the acquisition function. Common options include:
            - kind: Type of acquisition function ('ucb', 'ei', 'poi')
            - kappa: Exploration parameter for UCB
            - xi: Exploration parameter for EI/POI

    Example:
        >>> from snowflake.ml.modeling.tune.search import BayesOpt
        >>>
        >>> # Use default settings
        >>> search_alg = BayesOpt()
        >>>
        >>> # Customize acquisition function
        >>> search_alg = BayesOpt(utility_kwargs={
        ...     'kind': 'ucb',
        ...     'kappa': 1.96  # Less exploration
        ... })
    """

    utility_kwargs: Optional[Dict[str, Any]] = None


@dataclass
class RandomSearch(SearchAlgorithm):
    """
    Random search algorithm.

    Randomly samples hyperparameter configurations from the defined search space.
    This is often a good baseline and can be surprisingly effective, especially
    in high-dimensional spaces where grid search becomes impractical.

    Args:
        random_state (Optional[int]): Random seed for reproducible results.
            If None, results will vary between runs.

    Example:
        >>> from snowflake.ml.modeling.tune.search import RandomSearch
        >>>
        >>> # Use random sampling
        >>> search_alg = RandomSearch()
        >>>
        >>> # Use fixed seed for reproducibility
        >>> search_alg = RandomSearch(random_state=42)
    """

    random_state: Optional[int] = None


@dataclass
class GridSearch(SearchAlgorithm):
    """
    Grid search algorithm.

    Exhaustively evaluates all possible combinations of hyperparameters
    in the search space. This guarantees finding the optimal configuration
    within the defined grid, but can be computationally expensive with
    many parameters or large parameter ranges.

    Example:
        >>> from snowflake.ml.modeling.tune.search import GridSearch
        >>>
        >>> search_alg = GridSearch()
        >>>
        >>> # Define search space as lists for grid search; Following will evaluate 3 × 3 × 2 = 18 combinations
        >>> search_space = {
        ...     'learning_rate': [0.01, 0.1, 0.2],
        ...     'max_depth': [3, 5, 7],
        ...     'n_estimators': [50, 100]
        ... }
    """

    pass
