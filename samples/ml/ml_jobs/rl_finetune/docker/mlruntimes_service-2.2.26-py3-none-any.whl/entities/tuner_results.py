from typing import Any
import pandas as pd


class TunerResults:
    """
    Results container for hyperparameter optimization runs.

    This class contains all the information from a completed tuning run,
    including detailed results for all trials, the best configuration found,
    and the trained model from the best trial.

    Attributes:
        results (pd.DataFrame): Complete results from all trials. Each row represents
            one trial with columns for hyperparameters (prefixed with 'config/') and
            reported metrics. Useful for analyzing optimization progress and comparing
            different configurations.

        best_result (pd.DataFrame): Single-row DataFrame containing the trial that
            achieved the best performance according to the optimization metric.
            Contains the same columns as 'results' but filtered to just the best trial.

        best_model (Any): The trained model object from the best performing trial.
            This is the actual model instance that was returned by tuner_context.report()
            in the training function. Can be used directly for predictions or further analysis.

    Example:
        >>> # After running tuner.run()
        >>> results = tuner.run(dataset_map=dataset_map)

        >>> # View all trial results
        >>> print(results.results.head())

        >>> # Access best configuration and performance
        >>> best_config = results.best_result

        >>> # Use the best model for predictions
        >>> best_model = results.best_model


    Note:
        The exact columns in 'results' and 'best_result' depend on:

        - The hyperparameters defined in your search_space (appear as 'config/<param_name>')
        - The metrics reported by your training function via tuner_context.report()
        - Additional metadata like trial execution time and iteration number
    """

    def __init__(
        self, results: pd.DataFrame, best_result: pd.DataFrame, best_model: Any
    ):
        self.results = results
        self.best_result = best_result
        self.best_model = best_model
