from dataclasses import dataclass
from typing import List, Union


@dataclass
class SamplingFunction:
    """
    Base class for hyperparameter sampling functions.

    Sampling functions define how hyperparameter values are sampled during
    the optimization process. Different sampling functions are appropriate
    for different types of parameters and search strategies.
    """

    pass


@dataclass
class Uniform(SamplingFunction):
    """
    Uniform distribution sampling for continuous parameters.

    Samples values uniformly from the specified range [lower, upper].
    This is appropriate for parameters where all values in the range
    are equally likely to be optimal.

    Args:
        lower (float): Lower bound of the sampling range (inclusive).
        upper (float): Upper bound of the sampling range (exclusive).

    Example:
        >>> from snowflake.ml.modeling.tune import uniform
        >>>
        >>> # Sample learning rate uniformly between 0.001 and 0.1
        >>> learning_rate = uniform(0.001, 0.1)
        >>>
        >>> search_space = {
        ...     'learning_rate': learning_rate,
        ...     'dropout_rate': uniform(0.0, 0.5)
        ... }
    """

    lower: float
    upper: float


@dataclass
class LogUniform(SamplingFunction):
    """
    Log-uniform distribution sampling for exponentially-scaled parameters.

    Samples values from a log-uniform distribution in the range [lower, upper].
    This is appropriate for parameters that vary exponentially, such as
    learning rates, where orders of magnitude differences are meaningful.

    Args:
        lower (float): Lower bound of the sampling range (inclusive).
        upper (float): Upper bound of the sampling range (exclusive).

    Example:
        >>> from snowflake.ml.modeling.tune import loguniform
        >>>
        >>> # Sample learning rate log-uniformly between 1e-5 and 1e-1
        >>> learning_rate = loguniform(1e-5, 1e-1)
        >>>
        >>> search_space = {
        ...     'learning_rate': learning_rate,
        ...     'weight_decay': loguniform(1e-6, 1e-2)
        ... }
    """

    lower: float
    upper: float


@dataclass
class RandInt(SamplingFunction):
    """
    Random integer sampling for discrete parameters.

    Samples integer values uniformly from the specified range [lower, upper].
    This is appropriate for discrete parameters like the number of layers,
    batch size, or other integer-valued hyperparameters.

    Args:
        lower (int): Lower bound of the sampling range (inclusive).
        upper (int): Upper bound of the sampling range (exclusive).

    Example:
        >>> from snowflake.ml.modeling.tune import randint
        >>>
        >>> search_space = {
        ...     'n_estimators': randint(50, 200),
        ...     'max_depth': randint(3, 10),
        ...     'batch_size': randint(16, 128)
        ... }
    """

    lower: int
    upper: int


@dataclass
class Choice(SamplingFunction):
    """
    Categorical sampling from a discrete set of options.

    Randomly selects from a predefined list of options. This is appropriate
    for categorical parameters like activation functions, optimizers, or
    any parameter with a discrete set of valid values.

    Args:
        options (List[Union[float, int, str]]): List of possible values to
            choose from. Can contain mixed types.

    Example:
        >>> from snowflake.ml.modeling.tune import choice
        >>>
        >>> search_space = {
        ...     'optimizer': choice(['adam', 'sgd', 'rmsprop']),
        ...     'activation': choice(['relu', 'tanh', 'sigmoid']),
        ...     'batch_size': choice([16, 32, 64, 128])
        ... }
    """

    options: List[Union[float, int, str]]
