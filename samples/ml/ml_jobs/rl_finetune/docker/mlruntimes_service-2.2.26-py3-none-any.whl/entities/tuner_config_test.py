import pytest

from entities.search_algorithm import GridSearch, RandomSearch, BayesOpt
from entities.tuner_config import TunerConfig


def test_grid_search_overrides_num_trials():
    config = TunerConfig(
        metric="accuracy",
        mode="max",
        search_alg=GridSearch(),
        num_trials=10,
        max_concurrent_trials=1,
    )
    assert (
        config.num_trials == 1
    ), "For grid search, num_trials should be overridden to 1."


def test_grid_search_default_num_trials():
    config = TunerConfig(
        metric="accuracy", mode="max", search_alg=GridSearch(), max_concurrent_trials=1
    )
    assert (
        config.num_trials == 1
    ), "For grid search, num_trials should be defaulted to 1."


def test_random_search_default_num_trials():
    config = TunerConfig(
        metric="accuracy",
        mode="max",
        search_alg=RandomSearch(),
        max_concurrent_trials=1,
    )
    assert config.num_trials == 5, "For random search, num_trials should defaulted to 5"


def test_random_search_overrides_num_trials():
    config = TunerConfig(
        metric="accuracy",
        mode="max",
        search_alg=RandomSearch(),
        num_trials=10,
        max_concurrent_trials=1,
    )
    assert config.num_trials == 10


def test_bayes_search_default_num_trials():
    config = TunerConfig(
        metric="accuracy", mode="max", search_alg=BayesOpt(), max_concurrent_trials=1
    )
    assert config.num_trials == 5, "For bayes search, num_trials should defaulted to 5"


def test_bayes_search_overrides_num_trials():
    config = TunerConfig(
        metric="accuracy",
        mode="max",
        search_alg=BayesOpt(),
        num_trials=100,
        max_concurrent_trials=1,
    )
    assert config.num_trials == 100


if __name__ == "__main__":
    pytest.main()
