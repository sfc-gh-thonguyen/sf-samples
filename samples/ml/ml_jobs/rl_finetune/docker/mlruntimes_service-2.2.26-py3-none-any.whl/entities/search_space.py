from typing import Dict, List, Union, Any
from entities.sampling_function import (
    Uniform,
    LogUniform,
    Choice,
    SamplingFunction,
    RandInt,
)

# For cleaner documentation signatures
HyperparameterValue = Union[SamplingFunction, Any, List[Any]]

# Full type definition (used internally)
SearchSpaceValue = Union[
    SamplingFunction, float, int, str, bool, List[Union[float, int, str, bool]]
]


def uniform(lower: float, upper: float) -> Uniform:
    return Uniform(lower=lower, upper=upper)


def loguniform(lower: float, upper: float) -> LogUniform:
    return LogUniform(lower=lower, upper=upper)


def randint(lower: int, upper: int) -> RandInt:
    return RandInt(lower=lower, upper=upper)


def choice(options=List[Union[float, int, str]]) -> Choice:
    return Choice(options=options)


class SearchSpace(Dict[str, SearchSpaceValue]):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
