import math
from dataclasses import dataclass, field
from typing import Optional
from entities.search_algorithm import SearchAlgorithm, RandomSearch, GridSearch

DEFAULT_NUM_TRIALS = 5


def default_search_alg() -> SearchAlgorithm:
    return RandomSearch()


@dataclass
class TunerConfig:
    """
    Configuration class for the tuning process.

    Attributes:
        metric (str): The name of the metric to optimize. This must match exactly
            what you report in your training function via tuner_context.report(metrics={...}).

            For example, if your training function calls:
            tuner_context.report(metrics={"accuracy": 0.95, "loss": 0.1})

            Then valid metric names would be "accuracy" or "loss".

            Common examples: "accuracy", "f1_score", "mse", "loss", "auc"

        mode (str): The optimization mode for the metric. Must be either "min"
            for minimization or "max" for maximization.

            Use "max" for metrics where higher is better (accuracy, f1_score, auc).
            Use "min" for metrics where lower is better (loss, error, mse).

        search_alg (SearchAlgorithm): The search algorithm to use for
            exploring the hyperparameter space. Defaults to random search.

        num_trials (int): The maximum number of parameter configurations to
            try. Defaults to 5.
            Note: In a grid search, the num_trials parameter is set to 1, such that each unique parameter combination
            in the grid is evaluated with exactly one trial.

        uses_snowflake_trainer (bool):  Specifies if the training function leverages a distributed Snowflake
            trainer (e.g., XGBEstimator, LightGBMEstimator, PyTorchTrainer).  Defaults to False.

            This flag is necessary because distributed trainers may require additional resources, and without this
            information, it's impossible to determine the correct resources per trial.

        max_concurrent_trials (Optional[int]): The maximum number of concurrently running trials per node.
            If not specified, it defaults to the total number of nodes in the cluster. This value must be a positive
            integer if provided.

        resource_per_trial (Optional[dict]): An optional dictionary specifying the resources allocated per trial.

            Examples:
            - {'CPU': 1} reserves 1 CPU core per trial
            - {'CPU': 2, 'GPU': 1} reserves 2 CPU cores and 1 GPU per trial

            **Important**: To enable GPU-based hyperparameter optimization, you must explicitly
            specify GPU resources (e.g., {'GPU': 1}). GPU resources are never automatically
            allocated - they must be explicitly requested.

            When this parameter is not provided, the resource allocation per trial
            is inferred based on the max_concurrent_trials setting and total cluster resources.

        persist_data_in_object_store (bool): If True, datasets will be materialized and
            stored in the Ray object store for reuse across trials. Defaults to True.

    Example:
        >>> from snowflake.ml.modeling.tune import  TunerConfig
        >>> config = TunerConfig(
        ...     metric="accuracy",
        ...     mode="max",
        ...     num_trials=5,
        ... )
    """

    metric: str
    mode: str
    search_alg: SearchAlgorithm = field(default_factory=default_search_alg)
    num_trials: int = DEFAULT_NUM_TRIALS
    uses_snowflake_trainer: bool = False
    max_concurrent_trials: Optional[int] = None
    resource_per_trial: Optional[dict] = None
    persist_data_in_object_store: bool = True

    def __post_init__(self):
        # override num_trials to 1 for GridSearch algorithm.
        if isinstance(self.search_alg, GridSearch):
            self.num_trials = 1


def configure_tuner_resources(
    tuner_config: TunerConfig, total_nodes: int, total_cluster_cpus: int
) -> None:
    """
    Updates the tuner configuration with Ray cluster-specific resource settings.
    This internal function is intended to run on the server side where access to
    a running Ray cluster is available. It infers the max_concurrent_trials and the resource_per_trial
    when they're not set by the client.
    Parameters:
        tuner_config (TunerConfig): The configuration object for the tuner. It may include:
            - max_concurrent_trials (int, optional): The maximum number of trials to run concurrently.
              Defaults to the total number of nodes in the cluster if not specified.
            - resource_per_trial (dict, optional): The resource allocation for each trial, including
              the number of CPUs. Defaults to total cluster cpus / 2 / number of nodes.
        total_nodes: Total number of nodes in the ray cluster.
        total_cluster_cpus: Total number of CPUs in the ray cluster.
    Raises:
        ValueError: If the cluster has no nodes or CPUs detected, or if `max_concurrent_trials` is less
        than or equal to 0.
    Notes:
        - The number of CPUs per trial is calculated to ensure that at least half of the cluster's
          CPUs remain available for other operations, such as Ray data ingestion.
        - Fractional CPU allocation is not supported for simplification; each trial is assigned at least one CPU.
    """
    # Validate cluster state
    if total_nodes <= 0 or total_cluster_cpus <= 0:
        raise ValueError("Invalid cluster configuration: No nodes or CPUs detected.")

    # Default to total_nodes if max_concurrent_trials is not specified
    tuner_config.max_concurrent_trials = (
        tuner_config.max_concurrent_trials or total_nodes
    )

    # assert tuner_config.max_concurrent_trials is not None
    if tuner_config.max_concurrent_trials <= 0:
        raise ValueError("max_concurrent_trials must be greater than 0.")

    if tuner_config.resource_per_trial is None:
        # Calculate CPUs per trial (at least 1 CPU per trial). No fractional cpu support for now.
        # We cannot blindly use all cpus for scheduling the callable function, as ray data ingestion will
        # create a separate PlacementGroup for example. Hence we reserve half to be safe.
        cpus_per_trial = max(
            1,
            math.floor(total_cluster_cpus / 2 / tuner_config.max_concurrent_trials),
        )
        tuner_config.resource_per_trial = {"CPU": cpus_per_trial}
