import os
from typing import Any

from snowflake.ml.data.data_ingestor import DataIngestor
from snowflake.ml.data.internal_data_connector import InternalDataConnector


class ShardedDataIngestor(DataIngestor):
    def get_shard_by_id(self, index: int) -> DataIngestor:
        """Retrieve a data shard by `index`."""
        ...

    def shard(self, num_shards: int, equal: bool) -> None:
        ...


class ShardedDataConnector(InternalDataConnector):
    def __init__(
        self, ingestor: ShardedDataIngestor, equal: bool, **kwargs: Any
    ) -> None:
        super().__init__(ingestor, **kwargs)
        self._ingestor = ingestor
        self.equal = equal

    def prepare_shards(self, num_shards: int) -> None:
        """Shards the data of the underlying ingestor into `num_shards`.

        Note that this command must be run ahead of time before executing `get_shard` on the connector,
        from within the same context as `get_shard` will be called.
        """
        return self._ingestor.shard(num_shards=num_shards, equal=self.equal)

    def get_shard(self) -> InternalDataConnector:
        """Retrieve a data shard."""
        rank = os.environ.get("RANK")
        if rank is None:
            raise NotImplementedError(
                "`get_shard` must be called from within the Snowflake training context."
            )

        return InternalDataConnector(self._ingestor.get_shard_by_id(index=int(rank)))
