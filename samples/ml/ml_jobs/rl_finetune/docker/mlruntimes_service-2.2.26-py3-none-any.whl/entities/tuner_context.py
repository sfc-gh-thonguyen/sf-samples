from snowflake.ml.data.data_connector import DataConnector
from typing import Dict, Any, Callable, Optional


class TunerContext:
    """
    A context class for managing configuration, reporting, and dataset information in hyperparameter tuning trials.

    This class provides a centralized way to access hyperparameters, report metrics, and access datasets
    within a training function during hyperparameter optimization. Users should not create instances of
    this class directly; instead, use get_tuner_context() within your training function.

    Example:
        >>> # Within your training function (see Tuner class for complete example)
        >>> tuner_context = get_tuner_context()
        >>>
        >>> # Get current trial's hyperparameters
        >>> config = tuner_context.get_hyper_params()  # {"learning_rate": 0.1, "n_estimators": 100}
        >>>
        >>> # Access datasets if provided to tuner.run()
        >>> datasets = tuner_context.get_dataset_map()  # {"train": connector, "test": connector}
        >>>
        >>> # Report metrics and optionally save model
        >>> tuner_context.report(metrics={"accuracy": 0.95}, model=trained_model)
    """

    def __init__(
        self,
        *,
        hyper_params: Dict[str, Any],
        progress_reporter: Callable[[Dict[str, Any], Optional[Any]], None],
        dataset_map: Optional[Dict[str, DataConnector]] = None
    ):
        # Internal constructor - users get TunerContext via get_tuner_context()
        self._hyper_params = hyper_params
        self._progress_reporter = progress_reporter
        self._dataset_map = dataset_map

    def get_hyper_params(self) -> Dict[str, Any]:
        """
        Retrieve the hyperparameter configuration for the current trial.

        Returns the specific hyperparameter values selected by the search algorithm
        for this trial. The keys correspond to parameter names defined in your
        search_space, and values are the sampled/selected values to use for training.

        Returns:
            Dict[str, Any]: The hyperparameter configuration dictionary for this trial.
                Keys are parameter names from your search_space.
                Values are the specific parameter values to use (e.g., learning_rate=0.1, n_estimators=150).

        Example:
            >>> config = tuner_context.get_hyper_params()
            >>> # Example output: {"learning_rate": 0.05, "n_estimators": 120, "max_depth": 6}
            >>> learning_rate = config["learning_rate"]
            >>> n_estimators = config["n_estimators"]
        """
        return self._hyper_params

    def report(self, metrics: Dict[str, Any], model: Optional[Any] = None) -> None:
        """
        Report trial results back to the hyperparameter optimization process.

        This method is used to report the performance metrics of your trained model
        and optionally the model itself. The metrics are used by the search algorithm
        to select the next set of hyperparameters to try. The model from the best-performing
        trial will be available in the final TunerResults.

        Args:
            metrics (Dict[str, Any]): A dictionary containing the performance metrics.
                Must include the metric specified in TunerConfig.metric (e.g., "accuracy", "loss").
                Can include additional metrics for analysis. Keys are metric names (strings),
                values should be numeric (float, int) for proper optimization.

            model (Optional[Any], optional): The trained model object to save with this trial.
                Currently, only picklable models are supported.
                The model from the best trial will be available as TunerResults.best_model.
                Defaults to None if you don't need to save the model.



        Example:
            >>> # Report just the required metric
            >>> tuner_context.report(metrics={"accuracy": 0.95})
            >>>
            >>> # Report multiple metrics with model
            >>> tuner_context.report(
            ...     metrics={"accuracy": 0.95, "f1_score": 0.93, "training_time": 45.2},
            ...     model=trained_model
            ... )

        Note:
            The optimization process uses only the metric specified in TunerConfig.metric
            and TunerConfig.mode to determine the "best" trial. Additional metrics are
            stored for analysis but don't affect the optimization process.
        """

        # Purposely not using keyword as it caused mypy exceptions for callables.
        self._progress_reporter(metrics, model)

    def get_dataset_map(self) -> Optional[Dict[str, DataConnector]]:
        """
        Retrieve the dataset mapping provided to tuner.run().

        Returns the DataConnector objects that were passed to the tuner's run() method
        via the dataset_map parameter. Use this to access your training, validation,
        and test datasets within your training function.

        Returns:
            Optional[Dict[str, DataConnector]]: A mapping of dataset names to DataConnector objects.
                Keys are the names you specified in dataset_map (e.g., "train", "test", "validation").
                Values are DataConnector objects that you can call .to_pandas() on to get the actual data.
                Returns None if no dataset_map was provided to tuner.run().

        Example:
            >>> datasets = tuner_context.get_dataset_map()
            >>> if datasets:
            ...     train_df = datasets["train"].to_pandas()
            ...     test_df = datasets["test"].to_pandas()
            ... else:
            ...     # Handle case where no datasets were provided
            ...     train_df = load_your_data_somehow()
        """
        return self._dataset_map


_context: Optional[TunerContext] = None


def get_tuner_context() -> TunerContext:
    """
    Retrieve the current TunerContext within a training function.

    This function provides access to the TunerContext object that contains
    hyperparameters, datasets, and reporting functionality for the current trial.
    Should only be called from within the training function passed to the Tuner.

    Returns:
        TunerContext: The current TunerContext instance containing:
            - Hyperparameters for this trial (via get_hyper_params())
            - Dataset connectors if provided (via get_dataset_map())
            - Reporting functionality (via report())

    Raises:
        RuntimeError: If called outside of a hyperparameter optimization trial
            (i.e., not within a training function being executed by the tuner).

    Example:
        >>> def train_func():
        ...     # This is the correct place to call get_tuner_context()
        ...     tuner_context = get_tuner_context()
        ...     config = tuner_context.get_hyper_params()
        ...     # ... use config to train your model ...
        ...     tuner_context.report(metrics={"accuracy": accuracy})
        >>>
        >>> # This would raise RuntimeError:
        >>> # tuner_context = get_tuner_context()  # Called outside training function

    Note:
        This function uses a global context that is automatically set by the
        tuning framework when your training function is executed. You should
        never need to manually set or manage this context.
    """
    global _context
    if _context is None:
        raise RuntimeError(
            "Context has not been set. This function should only be called within a Ray Tune trial."
        )
    return _context


def set_tuner_context(context: TunerContext) -> None:
    """
    Set the global TunerContext.

    This function should be called to initialize the TunerContext before starting a Ray Tune trial.

    Args:
        context (TunerContext): The TunerContext instance to set as the global context.

    Raises:
        ValueError: If the TunerContext has already been initialized.
    """
    global _context
    if _context:
        raise ValueError("Tuner context already initialized")
    _context = context
