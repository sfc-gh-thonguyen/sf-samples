import sys
import subprocess
import tempfile
import ray

env_cache: str = ""


def _get_env() -> str:
    """
    Get the current environment state.
    """
    curr_env = subprocess.check_output(
        [sys.executable, "-m", "pip", "list", "--format=freeze"]
    ).decode("utf-8")
    return curr_env


@ray.remote
def _update_env(requirements: str) -> None:
    """
    Install a list of packages from requirements.
    """
    curr_env = _get_env()
    if requirements == curr_env:
        return

    with tempfile.NamedTemporaryFile(
        mode="w", suffix="requirements.txt", delete=False
    ) as f:
        f.write(requirements)
        f.flush()
        subprocess.check_call(
            [sys.executable, "-m", "pip", "-q", "install", "--no-deps", "-r", f.name]
        )


def sync_env() -> None:
    """
    Synchronize the python environment with the given updates.
    """
    nodes = ray.nodes()

    resource_tags = []
    # Collect all the tags for non head nodes.
    for node in nodes:
        resources = node.get("Resources", {})
        if not node.get("Alive", False) or resources.get("node:__internal_head__", 0):
            # Ignore dead nodes and head node.
            continue

        for tag in resources.keys():
            # TODO: Make this prefix a system-wide constant.
            if tag.startswith("stplatnotebook"):
                resource_tags.append(tag)

    if not resource_tags:
        return
    new_env = _get_env()
    # Update the python environment on all the worker nodes.
    refs = []
    for tag in resource_tags:
        refs.append(_update_env.options(resources={tag: 1}).remote(new_env))  # type: ignore

    unfinished = refs
    while unfinished:
        # Returns the first ObjectRef that is ready.
        finished, unfinished = ray.wait(unfinished, num_returns=1)
        ray.get(finished[0])
