from implementations.ray_data_ingester import RayDataIngester
from snowflake.ml.data.data_ingestor import DataIngestor


def get_ingester_class() -> "DataIngestor":
    """
    Returns the default ingester class for runtime users.

    This function is currently used in snowml pacakge to switch
    the data ingester of DataConnector.
    """
    return RayDataIngester
