import asyncio
import uuid
from unittest import mock

from ray.dashboard.modules.job.common import JobStatus

from entities.search_space import SearchSpace, uniform
from entities.tuner_config import TunerConfig
from internal_entities.internal_tuner_results import InternalTunerResults
from snowflake.ml.modeling.distributors.pytorch import (
    PyTorchScalingConfig,
    WorkerResourceConfig,
)
from web.jobs.common import TrainV2Response
from web.ml_runtime_trainer import _should_use_ray_job
import os


class MockJobSubmissionClient:
    """Mock implementation of JobSubmissionClient with controlled async behavior."""

    def __init__(self):
        self.jobs = {}
        self._job_id = "test_id"

    def submit_job(self, submission_id, entrypoint, runtime_env):
        """Mock job submission - just returns a job ID."""
        self.jobs[self._job_id] = {
            "submission_id": submission_id,
            "entrypoint": entrypoint,
            "status": JobStatus.STOPPED,
        }
        return self._job_id


class TestMLRuntimeTrainer:
    """Tests for MLRuntimeTrainer class focusing on async behavior."""

    def test_train_async(self):
        """Test that logs from _async_stream_logs appear before job completion."""
        # Setup
        request_id = str(uuid.uuid4())
        log_messages = [
            "Starting training...",
            "Loading data...",
            "Training model...",
            "Evaluating model...",
        ]

        # We'll use this to track the order of operations
        mock_client = MockJobSubmissionClient()

        # Create module mocks
        # Mock _async_wait_for_job_completion to return response with model info
        response = TrainV2Response(
            model_location="/mock/model/path",
            checkpoint_location="/mock/checkpoint/path",
            metrics={"accuracy": 0.95},
        )

        mock_logger = mock.MagicMock()
        mock_logger.info = mock.MagicMock()
        mock_logger.error = mock.MagicMock()

        # List to track sequence of events
        event_sequence = []

        # Create mocked versions of key async methods to track timing
        async def mock_async_stream_logs(comm_queue):
            event_sequence.append("stream_logs_start")
            for msg in log_messages:
                await asyncio.sleep(0.05)  # Small delay between logs
                comm_queue.put_nowait({"request_id": request_id, "log_lines": msg})
                event_sequence.append(f"log: {msg}")
            event_sequence.append("stream_logs_end")
            return None

        async def mock_async_wait_for_job_completion(result_filename):
            # Wait for logs to finish and then add a small delay
            await asyncio.sleep(0.3)  # Wait longer than log streaming
            event_sequence.append("job_completion")
            return response

        with mock.patch(
            "web.request_handler.JobSubmissionClient", return_value=mock_client
        ), mock.patch(
            "web.request_handler.RayJobHandler._async_stream_logs",
            side_effect=mock_async_stream_logs,
        ), mock.patch(
            "snowflake.runtime.utils.logger.get_logger", return_value=mock_logger
        ), mock.patch(
            "web.request_handler.RayJobHandler._async_wait_for_job_completion",
            side_effect=mock_async_wait_for_job_completion,
        ):
            from web.ml_runtime_trainer import MLRuntimeTrainer

            # Create the trainer
            trainer = MLRuntimeTrainer()

            trainer.trainV2(
                train_func=lambda x: x,
                scaling_config=PyTorchScalingConfig(
                    num_nodes=1,
                    num_workers_per_node=1,
                    resource_requirements_per_worker=WorkerResourceConfig(),
                ),
            )

            # Verify the sequence of events
            print(f"Event sequence: {event_sequence}")

            # Find indices of key events
            stream_start_idx = event_sequence.index("stream_logs_start")
            stream_end_idx = event_sequence.index("stream_logs_end")
            job_completion_idx = event_sequence.index("job_completion")

            # Verify log streaming starts before job completion
            assert (
                stream_start_idx < job_completion_idx
            ), "Log streaming should start before job completion"

            # Verify log streaming ends before job completion
            assert (
                stream_end_idx < job_completion_idx
            ), "Log streaming should end before job completion"

    def test_tune_async(self):
        """Test that logs from tune appear before job completion."""
        # Setup
        request_id = str(uuid.uuid4())
        log_messages = [
            "Starting tuning...",
            "Preparing search space...",
            "Running trial 1...",
            "Running trial 2...",
            "Evaluating trials...",
        ]

        # We'll use this to track the order of operations
        mock_client = MockJobSubmissionClient()

        # Mock tune results
        tune_results = InternalTunerResults(
            results=mock.Mock(),
            best_result=mock.Mock(),
            best_model_path="test_path",
            shared_storage_stage_path=None,
            errors=[],
        )

        # Create module mocks
        mock_logger = mock.MagicMock()
        mock_logger.info = mock.MagicMock()
        mock_logger.error = mock.MagicMock()

        # List to track sequence of events
        event_sequence = []

        # Create mocked versions of key async methods to track timing
        async def mock_async_stream_logs(comm_queue):
            for msg in log_messages:
                await asyncio.sleep(0.05)  # Small delay between logs
                comm_queue.put({"request_id": request_id, "log_lines": msg})
                event_sequence.append(f"log: {msg}")
            return None

        async def mock_async_wait_for_job_completion(result_filename):
            # Wait for logs to finish and then add a small delay
            await asyncio.sleep(0.3)  # Wait longer than log streaming
            event_sequence.append("job_completion")
            return tune_results

        # Mock the validate_ray_scaling_config function
        mock_validate = mock.MagicMock()

        with mock.patch(
            "web.request_handler.JobSubmissionClient", return_value=mock_client
        ), mock.patch(
            "web.request_handler.RayJobHandler._async_stream_logs",
            side_effect=mock_async_stream_logs,
        ), mock.patch(
            "snowflake.runtime.utils.logger.get_logger", return_value=mock_logger
        ), mock.patch(
            "web.request_handler.RayJobHandler._async_wait_for_job_completion",
            side_effect=mock_async_wait_for_job_completion,
        ), mock.patch(
            "snowflake.ml.modeling.distributors.scaling_config_validator.validate_ray_scaling_config",
            side_effect=mock_validate,
        ):
            from web.ml_runtime_trainer import MLRuntimeTrainer

            # Create the trainer
            trainer = MLRuntimeTrainer()

            # Define mock search space and tuner config
            test_space = {
                "int_param": 100,
                "float_param": 3.14,
                "string_param": "test",
                "uniform_param": uniform(0, 1),
                "bool_param": True,
            }
            search_space = SearchSpace(test_space)

            tuner_config = TunerConfig(
                num_trials=5, metric="accuracy", mode="max", resource_per_trial=None
            )

            # Call the tune method
            result = trainer.tune(
                train_func=lambda x: x,
                search_space=search_space,
                tuner_config=tuner_config,
            )

            assert result == tune_results

            # Verify the sequence of events
            print(f"Tune event sequence: {event_sequence}")

            # Find indices of key events
            job_completion_idx = event_sequence.index("job_completion")

            # Get indices of all log events
            log_indices = [
                i for i, event in enumerate(event_sequence) if event.startswith("log:")
            ]

            # Verify all logs are emitted before job completion
            assert all(
                i < job_completion_idx for i in log_indices
            ), "All logs should be emitted before job completion"

    def test_should_use_ray_job(self):
        """Test that the should_use_ray_job function returns the correct value."""

        assert _should_use_ray_job(True) is True
        assert _should_use_ray_job(False) is False

        # Once flag is set, always use flag's value.
        os.environ["PYTORCH_DISABLE_RAY_JOB"] = "true"
        assert _should_use_ray_job(True) is False
        assert _should_use_ray_job(False) is False
