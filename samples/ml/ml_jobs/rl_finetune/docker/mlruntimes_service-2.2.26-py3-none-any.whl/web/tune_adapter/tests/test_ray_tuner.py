import pytest
from entities import tuner_config
from entities.search_algorithm import BayesOpt
from entities.sampling_function import Uniform, Choice, LogUniform, RandInt
from entities.search_space import SearchSpace, SamplingFunction
from web.jobs.tune import (
    _adapt_tuner,
    _adapt_sampling_function,
    _adapt_tune_results,
    _get_report_callback,
    _get_run_config,
)
from ray import tune
from ray.tune.search.bayesopt import BayesOptSearch
from ray.tune.search.basic_variant import BasicVariantGenerator
from unittest.mock import MagicMock
from unittest import mock
import pandas as pd
from ray.tune import ResultGrid, ExperimentAnalysis
from internal_entities.internal_tuner_results import InternalTunerResults


def test_adapt_with_default():
    def mock_train_func(config):
        return {"dummy": 0.9}

    search_space = SearchSpace({"learning_rate": Uniform(0.01, 0.1), "batch_size": 32})
    config = tuner_config.TunerConfig(
        metric="accuracy",
        mode="max",
        resource_per_trial={"CPU": 2},
        max_concurrent_trials=1,
    )

    result = _adapt_tuner(
        train_func=mock_train_func,
        search_space=search_space,
        use_shared_storage=False,
        num_trials=config.num_trials,
        request_id="test_request",
        tuner_config=config,
        dataset_map={},
    )

    assert isinstance(result, tune.Tuner)

    param_space = result._local_tuner.param_space
    assert "learning_rate" in param_space
    assert param_space["learning_rate"].lower == 0.01
    assert param_space["learning_rate"].upper == 0.1
    assert param_space["batch_size"] == 32

    # Check the tune config
    tune_config = result._local_tuner._tune_config
    assert tune_config.metric == "accuracy"
    assert tune_config.mode == "max"
    assert isinstance(tune_config.search_alg, BasicVariantGenerator)

    assert tune_config.max_concurrent_trials == 1
    assert tune_config.num_samples == tuner_config.DEFAULT_NUM_TRIALS

    # Verify that the trainable function is correctly wrapped
    trainable = result._local_tuner._trainable
    assert callable(trainable)


def test_adapt_with_non_default():
    def mock_train_func(config):
        return {"dummy": 0.9}

    search_space = SearchSpace({"learning_rate": Uniform(0.01, 0.1), "batch_size": 32})
    config = tuner_config.TunerConfig(
        metric="accuracy",
        mode="max",
        num_trials=10,
        search_alg=BayesOpt(),
        max_concurrent_trials=2,
        resource_per_trial={"CPU": 2},
    )

    result = _adapt_tuner(
        train_func=mock_train_func,
        search_space=search_space,
        use_shared_storage=False,
        num_trials=config.num_trials,
        request_id="test_request",
        tuner_config=config,
        dataset_map={},
    )

    assert isinstance(result, tune.Tuner)
    tune_config = result._local_tuner._tune_config
    assert tune_config.metric == "accuracy"
    assert tune_config.mode == "max"
    assert tune_config.num_samples == 10
    assert isinstance(tune_config.search_alg, BayesOptSearch)
    assert tune_config.max_concurrent_trials == 2


def test_adapt_sampling_function_uniform():
    uniform_func = Uniform(0.01, 0.1)
    adapted_func = _adapt_sampling_function(uniform_func)
    assert isinstance(adapted_func, tune.search.sample.Float)
    assert adapted_func.lower == 0.01
    assert adapted_func.upper == 0.1


def test_adapt_sampling_function_choice():
    choice_func = Choice([1, 2, 3])
    adapted_func = _adapt_sampling_function(choice_func)
    assert isinstance(adapted_func, tune.search.sample.Categorical)
    assert adapted_func.categories == [1, 2, 3]


def test_adapt_sampling_function_loguniform():
    loguniform_func = LogUniform(0.01, 0.1)
    adapted_func = _adapt_sampling_function(loguniform_func)
    assert isinstance(adapted_func, tune.search.sample.Float)
    assert adapted_func.lower == 0.01
    assert adapted_func.upper == 0.1


def test_adapt_sampling_function_randint():
    randint_func = RandInt(1, 10)
    adapted_func = _adapt_sampling_function(randint_func)
    assert isinstance(adapted_func, tune.search.sample.Integer)
    assert adapted_func.lower == 1
    assert adapted_func.upper == 10


def test_adapt_sampling_function_invalid():
    class InvalidSamplingFunction(SamplingFunction):
        pass

    invalid_func = InvalidSamplingFunction()
    with pytest.raises(TypeError):
        _adapt_sampling_function(invalid_func)


def test_adapt_tune_results_no_errors():
    # Mocking ResultGrid and ExperimentAnalysis
    mock_result_grid = MagicMock(spec=ResultGrid)
    mock_best_result = MagicMock(spec=ExperimentAnalysis)
    mock_result_grid.errors = []
    mock_result_grid.get_best_result.return_value = mock_best_result
    mock_result_grid.get_dataframe.return_value = pd.DataFrame(
        {"timestamp": [1, 2], "accuracy": [0.8, 0.9], "iterations": [10, 20]}
    )
    mock_best_result.metrics_dataframe = pd.DataFrame(
        {"timestamp": [1], "accuracy": [0.9], "iterations": [20]}
    )
    mock_best_result.checkpoint = MagicMock()
    expected_model_dir = "/mock/path"
    expected_model_path = f"{expected_model_dir}/model.pkl"
    mock_best_result.checkpoint.path = expected_model_dir

    result = _adapt_tune_results(
        results=mock_result_grid,
        metric="accuracy",
        mode="max",
        use_shared_storage=False,
    )

    assert isinstance(result, InternalTunerResults)
    assert result.errors == []
    # Assert `FILTERED` columns are removed
    assert "timestamp" not in result.results.columns
    assert "timestamp" not in result.best_result.columns
    assert result.best_model_path == expected_model_path


def test_adapt_tune_results_with_errors():
    # Mocking ResultGrid with errors
    mock_result_grid = MagicMock(spec=ResultGrid)
    mock_result_grid.errors = ["error1", "error2"]

    result = _adapt_tune_results(
        results=mock_result_grid,
        metric="accuracy",
        mode="max",
        use_shared_storage=False,
    )

    assert isinstance(result, InternalTunerResults)
    assert result.errors == ["error1", "error2"]
    assert result.results is None
    assert result.best_result is None
    assert result.best_model_path is None


def test_get_report_callback_no_model():
    metrics = {"accuracy": 0.9}
    with mock.patch("ray.tune.report") as mock_report:
        _get_report_callback(metrics)
        mock_report.assert_called_once_with(metrics)


def test_get_report_callback_with_model(tmp_path):
    metrics = {"accuracy": 0.9}
    model = MagicMock()

    with (
        mock.patch("ray.tune.report") as mock_report,
        mock.patch("tempfile.TemporaryDirectory", return_value=tmp_path),
        mock.patch("web.jobs.tune.Checkpoint") as mock_checkpoint,
    ):
        mock_checkpoint_instance = mock.Mock()
        mock_checkpoint.from_directory.return_value = mock_checkpoint_instance

        _get_report_callback(metrics, model)

        mock_checkpoint.from_directory.assert_called_once_with(tmp_path)
        mock_report.assert_called_once_with(
            metrics, checkpoint=mock_checkpoint_instance
        )


def test_get_run_config_with_share_storage():
    run_config = _get_run_config(
        use_shared_storage=True, num_trials=10, request_id="test_request"
    )
    assert run_config.storage_path == "/"
    assert run_config.storage_filesystem is not None


def test_get_run_config_without_share_storage():
    run_config = _get_run_config(
        use_shared_storage=False, num_trials=10, request_id="test_request"
    )
    assert run_config.storage_filesystem is None


if __name__ == "__main__":
    pytest.main()
