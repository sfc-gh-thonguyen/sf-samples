import asyncio
import queue
from os import path
from typing import Optional, Dict, Any, Union
from unittest import mock

from snowflake.runtime.utils.ray_utils import IN_RAY_TASK_ENV_VAR
from web.jobs.common import REQUEST_ID_ENV_VAR, WORKING_DIR_ENV_VAR
from web.request_handler import RayJobHandler


class LocalJobSubmissionClient:
    def __init__(
        self,
        address: Optional[str] = None,
        create_cluster_if_needed: bool = False,
        cookies: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        verify: Optional[Union[str, bool]] = True,
    ):
        ...

    async def tail_job_logs(self, job_id: str):
        for msg in ["msg1, msg2, msg3"]:
            yield msg


@mock.patch("web.request_handler.JobSubmissionClient")
@mock.patch("web.request_handler.ray", new=mock.MagicMock())
def test_ray_job_handler(ray_mock) -> None:
    job_handler = RayJobHandler(request_id="my_test_job")

    # Test that a working directory is created
    assert path.isdir(job_handler.working_dir)

    # Test expected environment variables are set
    for expected_env_key, expected_env_var in {
        REQUEST_ID_ENV_VAR: job_handler.request_id,
        WORKING_DIR_ENV_VAR: job_handler.working_dir,
        "RAY_DEDUP_LOGS": "0",
        IN_RAY_TASK_ENV_VAR: "1",
    }.items():
        assert job_handler.env_vars[expected_env_key] == expected_env_var

    assert ray_mock.init.is_called_once()


@mock.patch("web.request_handler.JobSubmissionClient", new=LocalJobSubmissionClient)
@mock.patch("web.request_handler.ray", new=mock.MagicMock())
def test_async_stream_logs() -> None:
    job_handler = RayJobHandler(request_id="my_test_job")

    comm_queue: queue.Queue = queue.Queue()
    asyncio.run(job_handler._async_stream_logs(comm_queue=comm_queue))

    last_message = comm_queue.queue.pop()

    assert last_message["log_lines"] == "msg1, msg2, msg3"
    assert last_message["request_id"] == "my_test_job"
