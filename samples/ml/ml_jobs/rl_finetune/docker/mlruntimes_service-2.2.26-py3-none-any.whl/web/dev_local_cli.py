import os
import signal
import time

import click

from snowflake.runtime.utils.logger import configure_ray_logger
from snowflake.runtime.utils.metrics import start_prometheus_metrics_port
from test_utils.utils import (
    set_up_prometheus_multiprocess_dir,
)
from snowflake.runtime.utils.const import DEFAULT_RAY_METRICS_PORT
from snowflake.runtime.utils.dev_env_python_path_utils import set_python_path_in_dev_env


os.environ["DEV_ENV"] = "1"

# Global flag to coordinate shutdown
shutdown_requested = False


def signal_handler(signum, frame):
    """Handle shutdown signals gracefully."""
    global shutdown_requested
    if shutdown_requested:
        print(f"ML Runtime Service already shutting down, ignoring signal {signum}")
        return
    print(f"ML Runtime Service received signal {signum}, initiating shutdown...")
    shutdown_requested = True


@click.command()
@click.option("--ray_port", default=7777, show_default=True)
@click.option("--ray_dashboard_port", default=12003, show_default=True)
@click.option("--ray_client_server_port", default=10001, show_default=True)
@click.option("--ray_metrics_port", default=DEFAULT_RAY_METRICS_PORT, show_default=True)
@click.option("--ray_min_worker_port", default=20002, show_default=True)
@click.option("--ray_max_worker_port", default=29999, show_default=True)
def start(
    ray_port,
    ray_dashboard_port,
    ray_client_server_port,
    ray_metrics_port,
    ray_min_worker_port,
    ray_max_worker_port,
):
    import subprocess

    global shutdown_requested

    # Set up signal handlers for graceful shutdown before starting anything
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    try:
        # Stop any existing Ray processes
        p = subprocess.Popen(["ray", "stop"])
        p.wait()

        # Start Ray cluster
        subprocess.Popen(
            [
                "ray",
                "start",
                "--node-ip-address",
                "127.0.0.1",
                "--head",
                '--resources={"node_tag:head":1}',
                "--temp-dir=/tmp/ray/",  # contains session logs and metrics
                "--port",
                f"{ray_port}",
                "--dashboard-host",
                "0.0.0.0",
                "--dashboard-port",
                f"{ray_dashboard_port}",
                "--ray-client-server-port",
                f"{ray_client_server_port}",
                "--metrics-export-port",
                f"{ray_metrics_port}",
                "--disable-usage-stats",
                "--min-worker-port",
                f"{ray_min_worker_port}",
                "--max-worker-port",
                f"{ray_max_worker_port}",
            ]
        )

        # Wait for Ray to be ready before starting metrics
        # Check if Ray is responsive instead of arbitrary delay
        ray_ready = False
        for attempt in range(10):  # Up to 10 seconds
            try:
                # Simple check to see if Ray is responsive
                result = subprocess.run(
                    ["ray", "status"], capture_output=True, timeout=1
                )
                if result.returncode == 0:
                    ray_ready = True
                    break
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                pass
            time.sleep(1)

        if not ray_ready:
            print(
                "Warning: Ray may not be fully ready, proceeding with metrics startup"
            )

        start_prometheus_metrics_port()
        configure_ray_logger()

        print("ML Runtime Service started successfully")

        # Keep the service alive until shutdown is requested
        try:
            while not shutdown_requested:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Received keyboard interrupt")
            shutdown_requested = True

    finally:
        # Clean shutdown sequence
        print("Shutting down ML Runtime Service...")

        # Stop Ray gracefully with retries
        try:
            # First, try to stop Ray normally
            stop_ray = subprocess.Popen(["ray", "stop"])
            stop_ray.wait(timeout=15)
            print("Ray stopped successfully")
        except subprocess.TimeoutExpired:
            print("Ray stop timed out, forcing termination...")
            try:
                # Force kill Ray processes if normal stop fails
                subprocess.run(["pkill", "-9", "-f", "ray::"], timeout=5)
                subprocess.run(["pkill", "-9", "-f", "raylet"], timeout=5)
                subprocess.run(["pkill", "-9", "-f", "gcs_server"], timeout=5)
            except Exception as force_kill_error:
                print(f"Error during force kill: {force_kill_error}")
        except Exception as e:
            print(f"Error stopping Ray: {e}")

        print("ML Runtime Service shutdown complete")


if __name__ == "__main__":
    set_python_path_in_dev_env()

    prometheus_dir = "/tmp/prometheus-multi-dir"
    set_up_prometheus_multiprocess_dir(prometheus_dir)
    start()
