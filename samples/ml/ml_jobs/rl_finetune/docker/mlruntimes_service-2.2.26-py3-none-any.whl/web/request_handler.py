from typing import List, Dict, Optional, Callable, Any, Union
import os
import asyncio
import queue
import time
import traceback
import re
import functools
from snowflake.runtime.utils.session_utils import get_session
import xgboost as xgb
import lightgbm as lgb
import pandas as pd
from dataclasses import dataclass
from scipy.sparse import csr_matrix
import numpy as np

try:
    import streamlit as st

    if not st.runtime.exists():
        st = None
    USE_STREAMLIT_WIDGETS = os.getenv("USE_STREAMLIT_WIDGETS", "1") == "1"
    if not USE_STREAMLIT_WIDGETS:
        st = None
except ImportError:
    st = None
from events.handlers import StreamlitEventHandler


def with_streamlit_progress(msg="Training"):
    """
    Decorator to handle streamlit progress indicators during processing.
    Starts an event handler before the function runs and stops it after completion.
    Only activates if streamlit (st) is available.
    For synchronous functions.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            request_id = args[0].request_id
            if not request_id:
                raise ValueError("request_id is required")
            assert isinstance(request_id, str)

            event_handler = None
            if st is not None:
                event_handler = StreamlitEventHandler(request_id=request_id, msg=msg)
                event_handler.start_processing()
            err_msg = None

            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                err_msg = str(e)
            finally:
                # Make sure we stop processing even if there's an exception
                if st is not None and event_handler is not None:
                    event_handler.stop_processing(err_msg=err_msg)

        return wrapper

    return decorator


def with_streamlit_progress_async(msg="Training"):
    """
    Decorator to handle streamlit progress indicators during async processing.
    Starts an event handler before the function runs and stops it after completion.
    Only activates if streamlit (st) is available.
    For asynchronous functions.
    """

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            request_id = args[0].request_id
            if not request_id:
                raise ValueError("request_id is required")
            assert isinstance(request_id, str)

            event_handler = None
            if st is not None:
                event_handler = StreamlitEventHandler(request_id=request_id, msg=msg)
                event_handler.start_processing()
            err_msg = None
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                err_msg = str(e)
            finally:
                # Make sure we stop processing even if there's an exception
                if st is not None and event_handler is not None:
                    event_handler.stop_processing(err_msg=err_msg)

        return wrapper

    return decorator


# IMPORTENT NOTE: The following HAS to be done before importing ray
# This is due to a "potential" bug in ray that causes the dedup logs function to not
# Ray has a few feature related log config that can be enabled via the environment variables.
# However, the environment variables are checked only once when the ray package is imported.
# So, we need to set the environment variable before importing ray
# Log config: https://docs.ray.io/en/latest/ray-observability/user-guides/configure-logging.html
SKIP_LOG_LINES_RE = re.compile(
    r"INFO worker\.py"  # noqa: W605
    r"|object_store_memory"
    r"|ray\.data"  # noqa: W605
    # TODO (snandamuri): Fix the data loader issue that is producing non writable tensors.
    r"|UserWarning: The given NumPy array is not writable, and PyTorch does not support non-writable tensors"
    # TODO (snandamuri): Fixing the above data loader issue will fix this too.
    r"|return torch.as_tensor\(data\)"  # noqa: W605
    r"|Executing DAG InputDataBuffer"
    r"|ReadResultSetDataSource to satisfy DataContext\.get_current\(\)\.min_parallelism"  # noqa: W605
    r"|Running 0:"
    # TODO (snandamuri): Fix the pyarrow version issue.
    r"|UserWarning: You are using pyarrow version 10\.0\.1 which is known to be insecure."  # noqa: W605
    # TODO (snandamuri): Fix below issues from renamer
    r"|``concurrency`` is set, but ``fn`` is not a callable class: <implementations\.ray_data_ingester"  # noqa: W605
    r"|ReadResultSetDataSource->MapBatches\(RenameHelper\)"  # noqa: W605
    r"|warnings\.warn\($"  # noqa: W605
    r"|SnowflakeLoginOptions"  # noqa: W605
    # TODO: For RayXGBoostTrainer related logs
    r"|[(]XGBoostTrainer pid="
    r"|[(]RayTrainWorker pid="
    r"|^│.*│$"
    r"|─────────────"
    r"|View detailed results here:"
    r"|To visualize your results with TensorBoard"
    # For HPO tuning
    r"|wrapper_func pid="
    r"|_execute_read_task_split"
    r"|tune.py:"
    r"|Logical resource usage:"
    r"|started with configuration:"
    r"|experiment_state.py:"
    r"|TUNE_WARN_EXCESSIVE_EXPERIMENT_CHECKPOINT_SYNC_THRESHOLD_S"
    r"|CheckpointConfig\(num_to_keep\)"  # noqa: W605
    r"|Starting execution of Dataset. Full logs are in"
    r"|Execution plan of Dataset: InputDataBuffer\[Input\] -> TaskPoolMapOperator\[ReadResultSetDataSource\]"
    r"|Runtime env is setting up"
)

os.environ["RAY_DEDUP_LOGS"] = "1"
os.environ["RAY_DEDUP_LOGS_SKIP_REGEX"] = SKIP_LOG_LINES_RE.pattern
os.environ["RAY_COLOR_PREFIX"] = "0"  # remove color prefix from ray logs
# Disable Ray Data progress bars at the environment level
os.environ["RAY_DATA_DISABLE_PROGRESS_BARS"] = "1"

import ray
from ray.job_submission import JobSubmissionClient, JobStatus
from ray.runtime_env import RuntimeEnv

import cloudpickle as cp
from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.modeling.distributors.scaling_config_validator import (
    validate_ray_scaling_config,
)
from entities.search_space import SearchSpace
from entities.tuner_config import TunerConfig
from implementations.distributed_trainers.ray_utils import (
    get_ray_scaling_config,
)
from snowflake.ml.runtime_cluster.cluster_manager import (
    get_cluster_size,
)
from internal_entities.internal_tuner_results import InternalTunerResults
from snowflake.runtime.utils.logger import get_logger, LogType
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
from snowflake.runtime.utils.ray_utils import (
    is_running_in_ray_task,
    IN_RAY_TASK_ENV_VAR,
    interruptible_ray_get,
    get_ray_dashboard_address,
)
from runtime_env import python_env
from web.jobs.common import (
    ARGUMENTS_FILE_NAME,
    ERROR_FILE_NAME,
    RESPONSE_FILE_NAME,
    TUNE_FILE_NAME,
    REQUEST_ID_ENV_VAR,
    WORKING_DIR_ENV_VAR,
    BaseArgs,
    TrainV2Args,
    XGBTrainArgs,
    LGBMTrainArgs,
    TuneArgs,
)

USER_ERROR_MESSAGE = "Unexpected error in the MLRS Worker."
JOB_TIMEOUT_SECONDS = 60 * 60 * 24 * 7  # 1 week

IS_DEV_ENV = os.getenv("DEV_ENV", None)
# TODO: Find a way to share global constants between server and client
MODELS_DIR = "/tmp/models"
WORKING_DIR_PREFIX = os.getenv("WORKING_DIR_PREFIX", "/tmp/ray-jobs")

logger = get_logger()


class RayJobHandler:
    """Util class for all the Ray job handling logic.
    This class is closable. close() method will stop all active ray jobs, async log streaming, and async result
    fetcher tasks. No new ray jobs can be submitted after close() call.
    """

    def __init__(self, request_id: str):
        self.request_id = request_id
        self.client = JobSubmissionClient(get_ray_dashboard_address())
        self.wait_for_active_ray_job_async_task: Optional[asyncio.Task] = None
        self.active_ray_job_id = None
        self.active_ray_task_ref = None
        self.active_ray_actor = None
        self.is_closed = False

        # Make working directory for serializing arguments and results
        self.working_dir = os.path.join(WORKING_DIR_PREFIX, self.request_id)
        os.makedirs(self.working_dir, exist_ok=True)
        self.env_vars = {
            REQUEST_ID_ENV_VAR: self.request_id,
            WORKING_DIR_ENV_VAR: self.working_dir,
            "RAY_DEDUP_LOGS": "0",
            "RAY_COLOR_PREFIX": "0",  # Disable ANSI color codes in submitted Ray jobs
            IN_RAY_TASK_ENV_VAR: "1",
        }

        if not ray.is_initialized():
            ray.init(
                ignore_reinit_error=True, log_to_driver=False, logging_level="CRITICAL"
            )

    def _submit_ray_job(self, *, script_path: str | None, arguments: BaseArgs):
        with open(os.path.join(self.working_dir, ARGUMENTS_FILE_NAME), "wb") as f:
            cp.dump(arguments, f)

        # Submit job
        logger.info(
            f"{self.request_id}: Submitting job...",
            extra={"log_types": [LogType.SYSTEM]},
        )

        logger.info(f"Env vars: {self.env_vars}", extra={"log_types": [LogType.SYSTEM]})
        job_id = self.client.submit_job(
            submission_id=self.request_id,
            entrypoint=f"python -m {script_path}",
            runtime_env=RuntimeEnv(env_vars=self.env_vars),
        )
        return job_id

    async def _async_stream_logs(self, comm_queue: queue.Queue):
        logger.info(f"{self.request_id}: ---------- Job logs -------------- ")
        async for lines in self.client.tail_job_logs(job_id=self.active_ray_job_id):
            logger.info(lines)
            ##
            # ray.init() call in the submitted job would produce following log lines
            # 2024-05-08 20:42:38,405   INFO worker.py:1432 -- Using address 0.0.0.0:7777 set in the environment
            #       variable RAY_ADDRESS
            # 2024-05-08 20:42:38,405   INFO worker.py:1567 -- Connecting to existing Ray cluster at address:
            #       0.0.0.0:7777...
            # 2024-05-08 20:42:38,411   INFO worker.py:1743 -- Connected to Ray cluster. View the dashboard at
            #       http://0.0.0.0:9999
            #
            # We need to skip those log lines. So, we skip log lines that contain "INFO worker.py" sub string
            # as a temp hack.
            ##
            processed_lines = "".join(
                [
                    ln
                    for ln in lines.splitlines(keepends=True)
                    if ln.strip(" \n\r") and SKIP_LOG_LINES_RE.search(ln) is None
                ]
            )
            if processed_lines:
                comm_queue.put_nowait(
                    {"request_id": self.request_id, "log_lines": processed_lines}
                )
        logger.info(f"{self.request_id}: ------------ End job logs -------- ")

    async def _async_wait_for_job_completion(self, result_filename: str | None):
        # Wait for job
        async def wait_until_status(
            job_id, status_to_wait_for, timeout_seconds=JOB_TIMEOUT_SECONDS
        ) -> None:
            start = time.time()
            while time.time() - start <= timeout_seconds:
                status = self.client.get_job_status(job_id)
                logger.info(
                    f"Awaiting job ({status})...",
                    extra={"log_types": [LogType.SYSTEM]},
                )
                if status in status_to_wait_for:
                    return
                await asyncio.sleep(1)

        await wait_until_status(
            self.active_ray_job_id,
            {JobStatus.SUCCEEDED, JobStatus.STOPPED, JobStatus.FAILED},
        )
        job_detail = self.client.get_job_info(self.active_ray_job_id)
        logger.info(
            f"Job complete: status={job_detail.status}, detail={job_detail}",
            extra={"log_types": [LogType.SYSTEM]},
        )
        if job_detail.status == JobStatus.SUCCEEDED:
            MLRSPrometheusMetrics.RAY_JOB_SUCCESS.value.inc()
        elif job_detail.status == JobStatus.FAILED or job_detail.driver_exit_code > 0:
            MLRSPrometheusMetrics.RAY_JOB_FAILURE.value.inc()
            logger.error(
                "Unable to deserialize worker error.",
                extra={"log_types": [LogType.SYSTEM]},
            )
            exp = None
            try:
                with open(
                    os.path.join(WORKING_DIR_PREFIX, self.request_id, ERROR_FILE_NAME),
                    "rb",
                ) as f:
                    exp = cp.load(f)
            except FileNotFoundError:
                # Error file not found. Ignore.
                exp = RuntimeError(f"Unknown error. RequestId: {self.request_id}")
            raise exp

        # Deserialize results
        if not result_filename:
            return None

        working_dir = f"{WORKING_DIR_PREFIX}/{self.request_id}"
        with open(f"{working_dir}/{result_filename}", "rb") as f:
            return cp.load(f)

    def _try_sync_env(self, comm_queue: Optional[queue.Queue] = None):
        try:
            python_env.sync_env()
        except Exception as e:
            ex_info = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            logger.error(
                f"Error while updating python environment: {ex_info}",
                extra={"log_types": [LogType.SYSTEM]},
            )
            # Don't re-raise the exception, just log it. Let the user know that the
            # environment update failed.

            if comm_queue is not None:
                comm_queue.put_nowait(
                    {
                        "request_id": self.request_id,
                        "log_lines": f"Error while updating python environment: {ex_info}",
                    }
                )

    async def async_submit_ray_job_and_stream_logs(
        self,
        *,
        script_path: str | None,
        arguments: BaseArgs,
        comm_queue: queue.Queue,
        result_filename: str | None = None,
    ):
        """Method to submit a ray job and start async tasks to stream job logs and wait for completion."""

        if self.is_closed:
            raise asyncio.CancelledError("Request handler is closed by server.")

        self._try_sync_env(comm_queue)

        self.active_ray_job_id = self._submit_ray_job(
            script_path=script_path, arguments=arguments
        )
        loop = asyncio.get_running_loop()
        log_stream_task = loop.create_task(
            self._async_stream_logs(comm_queue=comm_queue)
        )
        self.wait_for_active_ray_job_async_task = loop.create_task(
            self._async_wait_for_job_completion(result_filename=result_filename)
        )
        try:
            return await self.wait_for_active_ray_job_async_task
        finally:
            log_stream_task.cancel()

    def run_callable_as_a_ray_actor(self, *, func: Callable, **function_kwargs) -> Any:
        """
        Run a callable as a Ray actor with proper cleanup.

        Actors have better lifecycle management and cleanup than tasks.

        Here we're taking a defensive approach to cleanup the actor upfront. If for any reason it failed,
        we'll defer to Ray to cleanup the actor based on reference counting.
        """
        logger.info(
            f"Running callable as Ray actor for request_id: {self.request_id}",
            extra={"log_types": [LogType.SYSTEM]},
        )

        @ray.remote(runtime_env=RuntimeEnv(env_vars=self.env_vars))
        class RayActor:
            def __init__(self):
                self.func = func
                self.function_kwargs = function_kwargs

            def run(self):
                get_session()
                return self.func(**self.function_kwargs)

            def cleanup(self):
                """Explicit cleanup method for the actor"""
                try:
                    # Force garbage collection within the actor
                    import gc

                    gc.collect()
                    logger.info("Actor cleanup completed")
                except Exception as e:
                    logger.warning(f"Actor cleanup failed: {e}")

        actor = RayActor.remote()  # type: ignore
        self.active_ray_actor = actor

        logger.info(
            f"Created Ray actor for request_id: {self.request_id}",
            extra={"log_types": [LogType.SYSTEM]},
        )

        try:
            output = interruptible_ray_get(actor.run.remote())
            return output

        finally:
            try:
                interruptible_ray_get(actor.cleanup.remote())
                # Kill the actor explicitly
                ray.kill(actor)
            except Exception as e:
                logger.warning(f"Failed to cleanup actor: {e}")
            finally:
                self.active_ray_actor = None

    def close(self):
        self.is_closed = True
        try:
            if self.active_ray_job_id:
                self.client.stop_job(job_id=self.active_ray_job_id)
            elif self.active_ray_task_ref:
                ray.cancel(self.active_ray_task_ref)
            elif self.active_ray_actor:
                ray.kill(self.active_ray_actor)
        finally:
            if self.wait_for_active_ray_job_async_task:
                self.wait_for_active_ray_job_async_task.cancel()


class TrainV2Handler(RayJobHandler):
    def __init__(self, request_id: str):
        super().__init__(request_id=request_id)

    @with_streamlit_progress_async(msg="Pytorch Training")
    async def trainV2(
        self,
        train_func_file_path: str,
        num_nodes: int,
        num_workers_per_node: int,
        num_cpus_per_worker: int,
        num_gpus_per_worker: int,
        hyper_params: Dict[str, str],
        dataset_map: Dict[str, DataConnector],
        artifact_stage_location: Optional[str],
        comm_queue: queue.Queue,
    ):
        try:
            models_dir_for_request = os.path.join(MODELS_DIR, self.request_id)
            os.makedirs(models_dir_for_request, exist_ok=True)
            response = await self.async_submit_ray_job_and_stream_logs(
                script_path="web.jobs.train_v2",
                arguments=TrainV2Args(
                    train_func_file_path=train_func_file_path,
                    num_nodes=num_nodes,
                    num_workers_per_node=num_workers_per_node,
                    num_cpus_per_worker=num_cpus_per_worker,
                    num_gpus_per_worker=num_gpus_per_worker,
                    hyper_params=hyper_params,
                    dataset_map=dataset_map,
                    artifact_stage_location=artifact_stage_location
                    if artifact_stage_location
                    else "",
                    model_dir=models_dir_for_request,
                ),
                comm_queue=comm_queue,
                result_filename=RESPONSE_FILE_NAME,
            )

            comm_queue.put_nowait(
                {
                    "request_id": self.request_id,
                    "done": True,
                    "trained_model": models_dir_for_request,
                    "response": response,
                }
            )
        except Exception as e:
            print(f"Encoutered exception: {e}")
            traceback.print_exc()
            comm_queue.put_nowait(
                {"request_id": self.request_id, "done": True, "exception": e}
            )


class TrainV3Handler(RayJobHandler):
    def __init__(self, request_id: str):
        super().__init__(request_id=request_id)

    @with_streamlit_progress_async(msg="Pytorch Training")
    async def trainV3(
        self,
        train_func: Callable,
        num_nodes: int,
        num_workers_per_node: int,
        num_cpus_per_worker: int,
        num_gpus_per_worker: int,
        hyper_params: Dict[str, str],
        dataset_map: Dict[str, DataConnector],
        artifact_stage_location: Optional[str],
        comm_queue: queue.Queue,
    ):
        models_dir_for_request = os.path.join(MODELS_DIR, self.request_id)
        os.makedirs(models_dir_for_request, exist_ok=True)

        try:
            logger.info(
                "Running PyTorch training directly in driver node - no Ray job submission"
            )
            from implementations.pytorch.torch_trainer import TorchTrainer

            torch_trainer = TorchTrainer(
                train_func=train_func,
                num_nodes=num_nodes,
                num_workers_per_node=num_workers_per_node,
                num_cpus_per_worker=num_cpus_per_worker,
                num_gpus_per_worker=num_gpus_per_worker,
                model_dir=models_dir_for_request,
                hyper_params=hyper_params,
                dataset_map=dataset_map,
                artifact_stage_location=artifact_stage_location
                if artifact_stage_location != ""
                else None,
                request_id=self.request_id,
            )
            response = torch_trainer.training_loop()

            comm_queue.put_nowait(
                {
                    "request_id": self.request_id,
                    "done": True,
                    "trained_model": models_dir_for_request,
                    "response": response,
                }
            )
        except Exception as e:
            print(f"Encoutered exception: {e}")
            traceback.print_exc()
            comm_queue.put_nowait(
                {"request_id": self.request_id, "done": True, "exception": e}
            )
        finally:
            # Clean up Ray resources only for direct execution (torch_trainer is only set for direct execution)
            if torch_trainer is not None and hasattr(torch_trainer, "worker_group"):
                try:
                    logger.info(
                        "Cleaning up Ray resources (actors and placement groups)"
                    )
                    torch_trainer.worker_group.shutdown()
                except Exception as cleanup_error:
                    logger.error(f"Failed to clean up Ray resources: {cleanup_error}")


@dataclass
class TrainResult:
    request_id: str
    trained_model: Optional[xgb.Booster] = None
    eval_results: Optional[Dict[str, Any]] = None


class XGBTrainingHandler(RayJobHandler):
    def __init__(
        self,
        request_id: str,
        num_workers: int = -1,
        num_cpu_per_worker: int = -1,
        use_gpu: Optional[bool] = None,
    ):
        super().__init__(request_id=request_id)
        self.num_workers = num_workers
        self.num_cpu_per_worker = num_cpu_per_worker
        self.use_gpu = use_gpu

    @with_streamlit_progress(msg="XGBoost training")
    def train_with_in_memory_data(
        self,
        *,
        X: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        params: Optional[Dict[str, Any]] = None,
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[bool] = False,
        xgb_model: Optional[xgb.Booster] = None,
        callbacks: Optional[List[xgb.callback.TrainingCallback]] = None,
    ) -> TrainResult:
        from web.jobs.train_boosting_model import train_xgboost_with_in_memory_data

        booster, eval_results = self.run_callable_as_a_ray_actor(
            func=train_xgboost_with_in_memory_data,
            X=X,
            y=y,
            params=params,
            eval_set=eval_set,
            verbose_eval=verbose_eval,
            xgb_model=xgb_model,
            callbacks=callbacks,
            num_workers=self.num_workers,
            num_cpu_per_worker=self.num_cpu_per_worker,
            use_gpu=self.use_gpu,
            request_id=self.request_id,
        )

        return TrainResult(
            request_id=self.request_id,
            trained_model=booster,
            eval_results=eval_results,
        )

    @with_streamlit_progress_async(msg="XGBoost training")
    async def train(
        self,
        *,
        comm_queue: queue.Queue,
        dataset: DataConnector,
        input_cols: List[str],
        label_col: str,
        params: Optional[Dict[str, Any]] = None,
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[bool] = False,
        xgb_model: Optional[xgb.Booster] = None,
        callbacks: Optional[List[xgb.callback.TrainingCallback]] = None,
    ) -> None:
        try:
            output_model_path = f"{WORKING_DIR_PREFIX}/{self.request_id}.pkl"
            eval_results_path = (
                f"{WORKING_DIR_PREFIX}/{self.request_id}_eval_results.pkl"
            )
            ray_scaling_config = get_ray_scaling_config(
                input_num_workers=self.num_workers,
                input_num_cpu_per_worker=self.num_cpu_per_worker,
                use_gpu=self.use_gpu,
                num_alive_nodes=get_cluster_size(),
            )

            validate_ray_scaling_config(
                num_workers=ray_scaling_config.num_workers,
                num_cpu_per_worker=ray_scaling_config.resources_per_worker.get(
                    "CPU", 0
                ),
                num_gpu_per_worker=ray_scaling_config.resources_per_worker.get(
                    "GPU", 0
                ),
            )

            if is_running_in_ray_task():
                logger.info("Running inside a ray task")
                # directly running in a ray task
                from web.jobs.train_boosting_model import train_xgboost

                booster, eval_results = train_xgboost(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=params,
                    eval_set=eval_set,
                    verbose_eval=verbose_eval,
                    xgb_model=xgb_model,
                    callbacks=callbacks,
                    num_workers=self.num_workers,
                    num_cpu_per_worker=self.num_cpu_per_worker,
                    use_gpu=self.use_gpu,
                    request_id=self.request_id,
                )

                comm_queue.put_nowait(
                    {
                        "request_id": self.request_id,
                        "done": True,
                        "trained_model": booster,
                        "eval_results": eval_results,
                    }
                )
                return

            # Submit job as a remote job

            logger.info("Not running inside a ray task")
            await self.async_submit_ray_job_and_stream_logs(
                script_path="web.jobs.train_boosting_model",
                arguments=XGBTrainArgs(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=params,
                    eval_set=eval_set,
                    verbose_eval=verbose_eval,
                    model=xgb_model,
                    callbacks=callbacks,
                    num_workers=self.num_workers,
                    num_cpu_per_worker=self.num_cpu_per_worker,
                    use_gpu=self.use_gpu,
                    output_model_path=output_model_path,
                    eval_results_path=eval_results_path,
                ),
                comm_queue=comm_queue,
            )

            comm_queue.put_nowait(
                {
                    "request_id": self.request_id,
                    "done": True,
                    "trained_model": output_model_path,
                    "eval_results": eval_results_path,
                }
            )
        except Exception as e:
            comm_queue.put_nowait(
                {"request_id": self.request_id, "done": True, "exception": e}
            )
            raise


class LGBMTrainingHandler(RayJobHandler):
    def __init__(
        self,
        request_id: str,
        num_workers: int = -1,
        num_cpu_per_worker: int = -1,
        use_gpu: Optional[bool] = None,
    ):
        super().__init__(request_id=request_id)
        self.num_workers = num_workers
        self.num_cpu_per_worker = num_cpu_per_worker
        self.use_gpu = use_gpu

    @with_streamlit_progress(msg="LightGBM training")
    def train_with_in_memory_data(
        self,
        *,
        X: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        params: Optional[Dict[str, Any]] = None,
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
        callbacks: Optional[List[Callable[..., Any]]] = None,
    ) -> TrainResult:
        from web.jobs.train_boosting_model import train_lightgbm_with_in_memory_data

        booster, eval_results = self.run_callable_as_a_ray_actor(
            func=train_lightgbm_with_in_memory_data,
            X=X,
            y=y,
            params=params,
            eval_set=eval_set,
            init_model=init_model,
            callbacks=callbacks,
            num_workers=self.num_workers,
            num_cpu_per_worker=self.num_cpu_per_worker,
            use_gpu=self.use_gpu,
            request_id=self.request_id,
        )

        return TrainResult(
            request_id=self.request_id,
            trained_model=booster,
            eval_results=eval_results,
        )

    @with_streamlit_progress_async(msg="LightGBM training")
    async def train(
        self,
        *,
        comm_queue: queue.Queue,
        dataset: DataConnector,
        input_cols: List[str],
        label_col: str,
        params: Optional[Dict[str, Any]] = None,
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
        callbacks: Optional[List[Callable[..., Any]]] = None,
    ) -> None:
        output_model_path = f"{WORKING_DIR_PREFIX}/{self.request_id}.pkl"
        ray_scaling_config = get_ray_scaling_config(
            input_num_workers=self.num_workers,
            input_num_cpu_per_worker=self.num_cpu_per_worker,
            use_gpu=self.use_gpu,
            num_alive_nodes=get_cluster_size(),
        )

        validate_ray_scaling_config(
            num_workers=ray_scaling_config.num_workers,
            num_cpu_per_worker=ray_scaling_config.resources_per_worker.get("CPU", 0),
            num_gpu_per_worker=ray_scaling_config.resources_per_worker.get("GPU", 0),
        )

        eval_results_path = f"{WORKING_DIR_PREFIX}/{self.request_id}_eval_results.pkl"

        if is_running_in_ray_task():
            logger.info("Running inside a ray task")
            # directly running in a ray task
            from web.jobs.train_boosting_model import train_lightgbm

            try:
                booster, eval_results = train_lightgbm(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=params,
                    eval_set=eval_set,
                    init_model=init_model,
                    callbacks=callbacks,
                    num_workers=self.num_workers,
                    num_cpu_per_worker=self.num_cpu_per_worker,
                    use_gpu=self.use_gpu,
                    request_id=self.request_id,
                )

                comm_queue.put_nowait(
                    {
                        "request_id": self.request_id,
                        "done": True,
                        "trained_model": booster,
                        "eval_results": eval_results,
                    }
                )
            except Exception as e:
                comm_queue.put_nowait(
                    {"request_id": self.request_id, "done": True, "exception": e}
                )
            return

        # Submit job as a remote job
        try:
            logger.info("Not running inside a ray task")
            await self.async_submit_ray_job_and_stream_logs(
                script_path="web.jobs.train_boosting_model",
                arguments=LGBMTrainArgs(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=params,
                    eval_set=eval_set,
                    model=init_model,
                    callbacks=callbacks,
                    num_workers=self.num_workers,
                    num_cpu_per_worker=self.num_cpu_per_worker,
                    use_gpu=self.use_gpu,
                    output_model_path=output_model_path,
                    eval_results_path=eval_results_path,
                ),
                comm_queue=comm_queue,
            )

            comm_queue.put_nowait(
                {
                    "request_id": self.request_id,
                    "done": True,
                    "trained_model": output_model_path,
                    "eval_results": eval_results_path,
                }
            )
        except Exception as e:
            comm_queue.put_nowait(
                {"request_id": self.request_id, "done": True, "exception": e}
            )
            raise


class TuneHandler(RayJobHandler):
    def __init__(self, request_id: str):
        super().__init__(request_id=request_id)

    @with_streamlit_progress_async(msg="Tuning")
    async def tune(
        self,
        train_func_file_path: str,
        search_space: SearchSpace,
        tuner_config: TunerConfig,
        dataset_map: Dict[str, DataConnector],
        comm_queue: queue.Queue,
    ) -> None:
        try:
            validate_ray_scaling_config(
                num_workers=1,
                num_cpu_per_worker=tuner_config.resource_per_trial.get("CPU", 1),
                num_gpu_per_worker=tuner_config.resource_per_trial.get("GPU", 0),
                max_concurrent_trials=tuner_config.max_concurrent_trials,
            )

            tune_results: InternalTunerResults = (
                await self.async_submit_ray_job_and_stream_logs(
                    script_path="web.jobs.tune",
                    arguments=TuneArgs(
                        train_func_file_path=train_func_file_path,
                        search_space=search_space,
                        tuner_config=tuner_config,
                        dataset_map=dataset_map,
                    ),
                    comm_queue=comm_queue,
                    result_filename=TUNE_FILE_NAME,
                )
            )

            if tune_results is not None and len(tune_results.errors) > 0:
                if len(tune_results.errors) == 1:
                    error_msg = tune_results.errors[0]
                else:
                    formatted_errors = [
                        f"  Trial {i+1}: {err}"
                        for i, err in enumerate(tune_results.errors)
                    ]
                    error_msg = (
                        f"{len(tune_results.errors)} trials failed:\n"
                        + "\n".join(formatted_errors)
                    )
                raise RuntimeError(error_msg)

            comm_queue.put_nowait(
                {
                    "request_id": self.request_id,
                    "done": True,
                    "tune_results": tune_results,
                }
            )
        except Exception as e:
            comm_queue.put_nowait(
                {"request_id": self.request_id, "done": True, "exception": e}
            )
