import ray

from web.jobs.common import (
    load_arguments,
    get_request_id,
    write_response,
    job_function_decorator,
)
import cloudpickle as cp
from implementations.pytorch.torch_trainer import TorchTrainer
from snowflake.runtime.utils.logger import get_logger, LogType
from snowflake.runtime.utils.global_contextvars import set_context_worker

logger = get_logger()


@job_function_decorator
def train():
    request_id = get_request_id()
    set_context_worker(request_id)

    logger.info(
        f"{request_id}: Starting training job...", extra={"log_types": [LogType.SYSTEM]}
    )
    args = load_arguments()
    logger.info(
        f"{request_id}: Received raw arguments: {args}",
        extra={"log_types": [LogType.SYSTEM]},
    )

    with open(args.train_func_file_path, "r+b") as f:
        train_func = cp.load(f)

    logger.info(
        f"{request_id}: Creating training job...", extra={"log_types": [LogType.SYSTEM]}
    )
    torch_trainer = TorchTrainer(
        train_func=train_func,
        num_nodes=args.num_nodes,
        num_workers_per_node=args.num_workers_per_node,
        num_cpus_per_worker=args.num_cpus_per_worker,
        num_gpus_per_worker=args.num_gpus_per_worker,
        model_dir=args.model_dir,
        hyper_params=args.hyper_params,
        dataset_map=args.dataset_map,
        artifact_stage_location=args.artifact_stage_location
        if args.artifact_stage_location != ""
        else None,
    )
    response = torch_trainer.training_loop()
    write_response(response)

    logger.info(
        f"{request_id}: Training completed.", extra={"log_types": [LogType.SYSTEM]}
    )


if __name__ == "__main__":
    ray.init(ignore_reinit_error=True, log_to_driver=True, logging_level="CRITICAL")
    train()
