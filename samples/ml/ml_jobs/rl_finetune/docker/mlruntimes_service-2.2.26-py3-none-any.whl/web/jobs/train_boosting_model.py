# flake8: noqa
# THIS HAS TO BE THE FIRST LINE BEFORE IMPORITNG THE REST!
# Remove OMP_NUM_THREADS from the environment
# Ray Job API API will set this to 1, which will cause the any training that uses OpenMP to run single-threaded
import os

N_THREAD = os.getenv("OMP_NUM_THREADS", None)  # noqa
if N_THREAD is not None:  # noqa
    del os.environ["OMP_NUM_THREADS"]  # noqa

from implementations.distributed_trainers.oss_lgbm_implementation import OSSLGBMTrainer
from implementations.distributed_trainers.oss_xgboost_implementation import (
    OSSXGBoostTrainer,
)
from implementations.distributed_trainers.ray_lgbm_implementation import RayLGBMTrainer
from snowflake.ml.runtime_cluster.cluster_manager import (
    get_cluster_size,
    get_available_gpu,
)
from implementations.distributed_trainers.ray_xgboost_implementation import (
    RayXGBoostTrainer,
)
from internal_entities.distribution_params import DistributionParams
from events.producer import (
    RayTrainXGBoostCallback,
    RayTrainLGBMCallback,
    OSSTrainXGBoostCallback,
    OSSTrainLGBMCallback,
)

import ray
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
import cloudpickle as cp
from typing import Optional, Callable, Dict, Any, Tuple, List, Union

import xgboost as xgb
import lightgbm as lgb
from snowflake.ml.data.data_connector import DataConnector
from web.jobs.common import (
    load_arguments,
    get_request_id,
    BoostingModelTypes,
    LGBMTrainArgs,
    XGBTrainArgs,
    job_function_decorator,
)
from snowflake.runtime.utils.logger import (
    get_logger,
    LogType,
    print_user_log_warn,
)
from snowflake.runtime.utils.global_contextvars import set_context_worker

logger = get_logger()


def _train_using_gpu(user_use_gpu: Optional[bool]) -> bool:
    """
    Check if the training should be done using GPU. If user_use_gpu_choice is not None, it will be used to determine
    if GPU should be used.
    """
    gpu_available = get_available_gpu()
    if user_use_gpu is not None:
        if user_use_gpu and gpu_available == 0:
            raise ValueError(
                "GPU is not available in the environment but use_gpu is set to True"
            )
        return user_use_gpu

    # User didn't specify use_gpu, we will use GPU if there are available GPUs
    return gpu_available > 0


def _validate_xgboost_callbacks(callbacks: List[xgb.callback.TrainingCallback]) -> None:
    for callback in callbacks:
        if not isinstance(callback, xgb.callback.TrainingCallback):
            raise ValueError(
                f"All callbacks must be instances of xgboost.callback.TrainingCallback, but got {type(callback)}"
            )


def _validate_lightgbm_callbacks(callbacks: List[Callable[..., Any]]) -> None:
    for callback in callbacks:
        if not callable(callback):
            raise ValueError(
                f"All callbacks must be callable, but got {type(callback)}"
            )


@job_function_decorator
def train_xgboost(
    *,
    dataset: DataConnector,
    input_cols: List[str],
    label_col: str,
    params: Dict[str, Any],
    request_id: str,
    num_workers: int,
    num_cpu_per_worker: int,
    use_gpu: Optional[bool],
    eval_set: Optional[DataConnector] = None,
    verbose_eval: Optional[Union[bool, int]] = None,
    xgb_model: Optional[xgb.Booster] = None,
    callbacks: Optional[List[xgb.callback.TrainingCallback]] = None,
) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
    num_alive_nodes = get_cluster_size()
    sys_use_gpu = _train_using_gpu(use_gpu)

    # Get the number of boosting rounds
    num_boost_round = params.get("n_estimators", 100)
    if xgb_model:
        num_boost_round += xgb_model.num_boosted_rounds()

    if callbacks is None:
        callbacks = []
    _validate_xgboost_callbacks(callbacks)

    if num_alive_nodes == 1 and not sys_use_gpu:
        if num_workers != -1 or num_cpu_per_worker != -1:
            print_user_log_warn(
                logger,
                "Ignoring num_workers num_cpu_per_worker because GPU is not available",
                extra={"log_types": [LogType.USER]},
            )
        trainer = OSSXGBoostTrainer()
        callbacks.append(
            OSSTrainXGBoostCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )
    else:
        distribution_params = DistributionParams(
            num_workers=num_workers,
            cpus_per_worker=num_cpu_per_worker,
            use_gpus=sys_use_gpu,
            num_nodes=num_alive_nodes,
        )
        trainer = RayXGBoostTrainer(distribution_params=distribution_params)
        callbacks.append(
            RayTrainXGBoostCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )

    return trainer.fit(
        init_model=xgb_model,
        data_connector=dataset,
        input_cols=input_cols,
        label_cols=[label_col],
        params=params,
        eval_set=eval_set,
        verbose_eval=verbose_eval,
        callbacks=callbacks,
    )


@job_function_decorator
def train_lightgbm(
    *,
    dataset: DataConnector,
    input_cols: List[str],
    label_col: str,
    params: Dict[str, Any],
    request_id: str,
    num_workers: int,
    num_cpu_per_worker: int,
    use_gpu: Optional[bool],
    eval_set: Optional[DataConnector] = None,
    init_model: Optional[lgb.Booster] = None,
    callbacks: Optional[List[Callable[..., Any]]] = None,
) -> Tuple[lgb.Booster, Optional[Dict[str, Any]]]:
    num_alive_nodes = get_cluster_size()
    sys_use_gpu = _train_using_gpu(use_gpu)

    # Get the number of boosting rounds
    num_boost_round = params.get("n_estimators", 100)
    if init_model:
        num_boost_round += init_model.current_iteration()

    if callbacks is None:
        callbacks = []
    _validate_lightgbm_callbacks(callbacks)

    if num_alive_nodes == 1 and not sys_use_gpu:
        print_user_log_warn(
            logger,
            "Ignoring num_workers num_cpu_per_worker because GPU is not available",
            extra={"log_types": [LogType.USER]},
        )
        trainer = OSSLGBMTrainer()
        callbacks.append(
            OSSTrainLGBMCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )
    else:
        distribution_params = DistributionParams(
            num_workers=num_workers,
            cpus_per_worker=num_cpu_per_worker,
            use_gpus=sys_use_gpu,
            num_nodes=num_alive_nodes,
        )
        trainer = RayLGBMTrainer(distribution_params=distribution_params)
        callbacks.append(
            RayTrainLGBMCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )

    return trainer.fit(
        init_model=init_model,
        data_connector=dataset,
        input_cols=input_cols,
        label_cols=[label_col],
        params=params,
        eval_set=eval_set,
        verbose_eval=None,
        callbacks=callbacks,
    )


@job_function_decorator
def train_xgboost_with_in_memory_data(
    X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
    y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
    params: Dict[str, Any],
    request_id: str,
    eval_set: Optional[DataConnector] = None,
    verbose_eval: Optional[Union[bool, int]] = None,
    xgb_model: Optional[xgb.Booster] = None,
    callbacks: Optional[List[xgb.callback.TrainingCallback]] = None,
    num_workers: int = -1,
    num_cpu_per_worker: int = -1,
    use_gpu: Optional[bool] = None,
) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
    """
    Train XGBoost Booster with in-memory data. This is primary used for sklearn integration where data is already
    loaded in memory.
    """
    num_alive_nodes = get_cluster_size()
    sys_use_gpu = _train_using_gpu(use_gpu)

    # Get the number of boosting rounds
    num_boost_round = params.get("n_estimators", 100)
    if xgb_model:
        num_boost_round += xgb_model.num_boosted_rounds()

    if callbacks is None:
        callbacks = []
    _validate_xgboost_callbacks(callbacks)

    if num_alive_nodes == 1 and not sys_use_gpu:
        print_user_log_warn(
            logger,
            "Ignoring num_workers num_cpu_per_worker because GPU is not available",
            extra={"log_types": [LogType.USER]},
        )
        trainer = OSSXGBoostTrainer()
        callbacks.append(
            OSSTrainXGBoostCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )
    else:
        distribution_params = DistributionParams(
            num_workers=num_workers,
            cpus_per_worker=num_cpu_per_worker,
            use_gpus=sys_use_gpu,
            num_nodes=num_alive_nodes,
        )
        trainer = RayXGBoostTrainer(distribution_params=distribution_params)
        callbacks.append(
            RayTrainXGBoostCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )

    return trainer.fit_in_memory(
        init_model=xgb_model,
        X=X,
        y=y,
        params=params,
        eval_set=eval_set,
        verbose_eval=verbose_eval,
        callbacks=callbacks,
    )


@job_function_decorator
def train_lightgbm_with_in_memory_data(
    X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
    y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
    params: Dict[str, Any],
    request_id: str,
    eval_set: Optional[DataConnector] = None,
    init_model: Optional[lgb.Booster] = None,
    callbacks: Optional[List[Callable[..., Any]]] = None,
    num_workers: int = -1,
    num_cpu_per_worker: int = -1,
    use_gpu: Optional[bool] = None,
) -> Tuple[lgb.Booster, Optional[Dict[str, Any]]]:
    num_alive_nodes = get_cluster_size()
    sys_use_gpu = _train_using_gpu(use_gpu)

    # Get the number of boosting rounds
    num_boost_round = params.get("n_estimators", 100)
    if init_model:
        num_boost_round += init_model.current_iteration()

    if callbacks is None:
        callbacks = []
    _validate_lightgbm_callbacks(callbacks)

    if num_alive_nodes == 1 and not sys_use_gpu:
        print_user_log_warn(
            logger,
            "Ignoring num_workers num_cpu_per_worker because GPU is not available",
            extra={"log_types": [LogType.USER]},
        )
        trainer = OSSLGBMTrainer()
        callbacks.append(
            OSSTrainLGBMCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )
    else:
        distribution_params = DistributionParams(
            num_workers=num_workers,
            cpus_per_worker=num_cpu_per_worker,
            use_gpus=sys_use_gpu,
            num_nodes=num_alive_nodes,
        )
        trainer = RayLGBMTrainer(distribution_params=distribution_params)
        callbacks.append(
            RayTrainLGBMCallback(
                request_id=request_id, total_iterations=num_boost_round
            )
        )

    return trainer.fit_in_memory(
        init_model=init_model,
        X=X,
        y=y,
        params=params,
        eval_set=eval_set,
        callbacks=callbacks,
    )


def main() -> None:
    # load arguments
    request_id = get_request_id()
    set_context_worker(request_id)

    args: Union[XGBTrainArgs, LGBMTrainArgs] = load_arguments()
    logger.info(
        f"{request_id}: Received raw arguments: {args}",
        extra={"log_types": [LogType.SYSTEM]},
    )
    print(f"{request_id}: Received raw arguments: {args}")

    if args.model_type == BoostingModelTypes.XGBOOST:
        booster, eval_results = train_xgboost(
            dataset=args.dataset,
            input_cols=args.input_cols,
            label_col=args.label_col,
            params=args.params,
            eval_set=args.eval_set,
            verbose_eval=args.verbose_eval,
            xgb_model=args.model,
            callbacks=args.callbacks,
            use_gpu=args.use_gpu,
            request_id=request_id,
            num_workers=args.num_workers,
            num_cpu_per_worker=args.num_cpu_per_worker,
        )
    elif args.model_type == BoostingModelTypes.LIGHTGBM:
        booster, eval_results = train_lightgbm(
            dataset=args.dataset,
            input_cols=args.input_cols,
            label_col=args.label_col,
            params=args.params,
            eval_set=args.eval_set,
            init_model=args.model,
            callbacks=args.callbacks,
            use_gpu=args.use_gpu,
            request_id=request_id,
            num_workers=args.num_workers,
            num_cpu_per_worker=args.num_cpu_per_worker,
        )
    else:
        raise ValueError(f"Unsupported model type: {args.model_type}")

    booster.save_model(args.output_model_path)

    if eval_results:
        with open(args.eval_results_path, "wb") as f:
            cp.dump(eval_results, f)


if __name__ == "__main__":
    ray.init(ignore_reinit_error=True, log_to_driver=False, logging_level="CRITICAL")
    main()
