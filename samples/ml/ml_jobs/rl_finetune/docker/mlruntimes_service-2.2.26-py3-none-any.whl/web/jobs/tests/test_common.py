import pytest
from unittest.mock import patch, MagicMock
from web.jobs.common import job_function_decorator, ERROR_FILE_NAME, LogType
from web.jobs.common import load_data


@patch("web.jobs.common.get_request_id")
@patch("web.jobs.common.serialize_object")
@patch("web.jobs.common.logger")
def test_job_function_decorator_no_exception(
    mock_logger, mock_serialize_object, mock_get_request_id
):
    mock_get_request_id.return_value = "test_request_id"

    @job_function_decorator
    def sample_job_function():
        return "success"

    result = sample_job_function()
    assert result == "success"
    mock_logger.error.assert_not_called()
    mock_serialize_object.assert_not_called()


@patch("web.jobs.common.get_request_id")
@patch("web.jobs.common.serialize_object")
@patch("web.jobs.common.logger")
def test_job_function_decorator_with_exception(
    mock_logger, mock_serialize_object, mock_get_request_id
):
    mock_get_request_id.return_value = "test_request_id"
    test_exception = Exception("Test exception")

    @job_function_decorator
    def sample_job_function():
        raise test_exception

    with pytest.raises(Exception):
        sample_job_function()

    # assert str(context.exception) == "Test exception"
    mock_logger.error.assert_any_call(
        "test_request_id: Caught user exception in worker: Test exception",
        extra={"log_types": [LogType.SYSTEM]},
    )
    mock_logger.error.assert_any_call(
        f"test_request_id: Serializing error message to {ERROR_FILE_NAME}...",
        extra={"log_types": [LogType.SYSTEM]},
    )
    mock_logger.error.assert_any_call(
        "test_request_id: Re-raising the error...",
        extra={"log_types": [LogType.SYSTEM]},
    )
    mock_serialize_object.assert_called_once_with(test_exception, ERROR_FILE_NAME)


@patch("web.jobs.common.RayDataIngester")
@patch("web.jobs.common.DataConnector")
def test_load_data(mock_data_connector, mock_ray_data_ingester):
    query_id = "test_query_id"
    mock_ingester = MagicMock()
    mock_ray_data_ingester.return_value = mock_ingester
    mock_connector = MagicMock()
    mock_data_connector.return_value = mock_connector

    result = load_data(query_id)

    mock_data_connector.assert_called_once_with(mock_ingester)
    assert result == mock_connector
