import cloudpickle as cp
import dataclasses
import os
import enum
import functools

from typing import Callable, List, Dict, Any, Optional, Union
from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.data.data_source import DataFrameInfo
from implementations.ray_data_ingester import RayDataIngester
from entities.tuner_config import TunerConfig
from entities.search_space import SearchSpace

from snowflake.runtime.utils.logger import get_logger, LogType

import xgboost as xgb
import lightgbm as lgb

DEV_ENV_VAR = "DEV_ENV"
WORKING_DIR_ENV_VAR = "RAY_JOB_WORKING_DIR"
REQUEST_ID_ENV_VAR = "RAY_JOB_REQUEST_ID"
CUDA_VISIBLE_DEVICES_ENV_VAR = "CUDA_VISIBLE_DEVICES"

ARGUMENTS_FILE_NAME = "arguments.pk"
ERROR_FILE_NAME = "error.pk"
TUNE_FILE_NAME = "tune.pk"
HEAD_NODE_TAG = "node_tag:head"
RESPONSE_FILE_NAME = "response.pk"

# ray constants
RAY_PLACEMENT_SPREAD = "SPREAD"
RAY_PLACEMENT_PACK = "PACK"

NON_COMPUTE_PERCENT_CPU_NODE = 0.25
NON_COMPUTE_PERCENT_GPU_NODE = 0.6

RAY_LOGGER_NAME = "mlrs_worker"
RAY_LOG_FORMAT = "%(asctime)s\t%(levelname)s -- {REQUEST_ID}: %(message)s"
MLRS_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"  # e.g 2024-03-25 23:11:02

IS_DEV_ENV = os.getenv(DEV_ENV_VAR, "False").lower() in ("true", "1")

logger = get_logger()


def job_function_decorator(job_func):
    """Handles errors if they are raised in the Ray Job, serializing the error,
    reporting and raising the returning exception"""

    @functools.wraps(job_func)
    def wrapped_func(*args, **kwargs):
        try:
            return job_func(*args, **kwargs)
        except Exception as e:
            request_id = get_request_id()
            logger.error(
                f"{request_id}: Caught user exception in worker: {e}",
                extra={"log_types": [LogType.SYSTEM]},
            )
            logger.error(
                f"{request_id}: Serializing error message to {ERROR_FILE_NAME}...",
                extra={"log_types": [LogType.SYSTEM]},
            )
            # TODO check for job_func exception types here once we undestand them
            serialize_object(e, ERROR_FILE_NAME)
            logger.error(
                f"{request_id}: Re-raising the error...",
                extra={"log_types": [LogType.SYSTEM]},
            )
            raise e

    return wrapped_func


def get_request_id() -> str:
    env = os.environ
    return env[REQUEST_ID_ENV_VAR]


@dataclasses.dataclass
class BaseArgs:
    pass


@dataclasses.dataclass
class BaseResponse:
    pass


class BoostingModelTypes(str, enum.Enum):
    XGBOOST = "xgboost"
    LIGHTGBM = "lightgbm"


@dataclasses.dataclass(kw_only=True)
class BoostingModelTrainArgs(BaseArgs):
    model_type: BoostingModelTypes
    dataset: DataConnector
    input_cols: List[str]
    label_col: str
    params: Dict[str, str]
    eval_set: DataConnector | None
    num_workers: int
    num_cpu_per_worker: int
    use_gpu: bool | None
    output_model_path: str | None
    eval_results_path: str | None


@dataclasses.dataclass(kw_only=True)
class XGBTrainArgs(BoostingModelTrainArgs):
    verbose_eval: bool | None
    model: xgb.Booster | None
    callbacks: List[xgb.callback.TrainingCallback] | None
    model_type: BoostingModelTypes = BoostingModelTypes.XGBOOST


@dataclasses.dataclass(kw_only=True)
class LGBMTrainArgs(BoostingModelTrainArgs):
    model: lgb.Booster | None
    callbacks: List[Callable[..., Any]] | None
    model_type: BoostingModelTypes = BoostingModelTypes.LIGHTGBM


@dataclasses.dataclass
class TrainV2Args(BaseArgs):
    train_func_file_path: str
    num_nodes: int
    num_workers_per_node: int
    num_cpus_per_worker: int
    num_gpus_per_worker: int
    hyper_params: Dict[str, str]
    dataset_map: Dict[str, DataConnector]
    model_dir: str
    artifact_stage_location: str


@dataclasses.dataclass
class TrainV2Response(BaseResponse):
    metrics: Dict[str, Any]
    checkpoint_location: str
    model_location: str


@dataclasses.dataclass
class TuneArgs(BaseArgs):
    train_func_file_path: str
    search_space: SearchSpace
    tuner_config: TunerConfig
    dataset_map: Dict[str, DataConnector]


@dataclasses.dataclass
class BoosterArgs(BaseArgs):
    train_func_file_path: str
    num_nodes: int
    num_workers_per_node: int
    num_cpus_per_worker: int
    num_gpus_per_worker: int
    model_dir: str
    hyper_params: Dict[str, str]
    dataset_map: Optional[Dict[str, DataConnector]]


def load_arguments() -> Union[LGBMTrainArgs, XGBTrainArgs, BoosterArgs, TrainV2Args]:
    working_dir = os.environ[WORKING_DIR_ENV_VAR]
    with open(f"{working_dir}/{ARGUMENTS_FILE_NAME}", "rb") as f:
        arguments = cp.load(f)

    return arguments


def load_data(query_id: str) -> DataConnector:
    source = DataFrameInfo(None, query_id=query_id)
    ingester = RayDataIngester([source])
    return DataConnector(ingester)


def load_model(serialized_model_file_path: str) -> object:
    with open(serialized_model_file_path, mode="rb") as model_file:
        model = cp.load(model_file)

    return model


def serialize_object(obj: object, filename: str) -> None:
    working_dir = os.environ[WORKING_DIR_ENV_VAR]
    with open(f"{working_dir}/{filename}", "wb") as f:
        cp.dump(obj, f)


def write_response(response: BaseResponse) -> None:
    working_dir = os.environ[WORKING_DIR_ENV_VAR]
    with open(f"{working_dir}/{RESPONSE_FILE_NAME}", "wb") as f:
        cp.dump(response, f)
