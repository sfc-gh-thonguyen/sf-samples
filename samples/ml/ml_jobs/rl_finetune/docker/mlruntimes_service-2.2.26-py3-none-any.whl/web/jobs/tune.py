# Standard library imports
import math
import os
import tempfile
from typing import Any, Callable, Dict, Optional, Type

# Third-party imports
import cloudpickle as cp
import ray
from ray import tune as ray_tune
from ray.data.dataset import MaterializedDataset
from ray.train import Checkpoint
from ray.tune import ResultGrid
from ray.tune.search.basic_variant import BasicVariantGenerator
from ray.tune.search.bayesopt import BayesOptSearch as RayBayesOptSearch

# Snowflake imports
from snowflake.ml.data.data_connector import DataConnector
from snowflake.runtime.utils.logger import LogType, get_logger

# Local imports
from common_utils.common_util import in_multi_node_env
from common_utils.shared_storage_fs_util import get_py_filesystem_for_stage
from entities.sampling_function import (
    Choice,
    LogUniform,
    RandInt,
    SamplingFunction,
    Uniform,
)
from entities.search_algorithm import (
    BayesOpt,
    GridSearch,
    RandomSearch,
    SearchAlgorithm,
)
from entities.search_space import SearchSpace
from entities.tuner_config import TunerConfig
from entities.tuner_context import TunerContext, set_tuner_context
from events.producer import RayTuneCallback
from internal_entities.internal_tuner_results import InternalTunerResults
from web.jobs.common import (
    TUNE_FILE_NAME,
    get_request_id,
    job_function_decorator,
    load_arguments,
    serialize_object,
)
from shared_storage.constants import INTERNAL_HPO_STAGE_PATH
from implementations.ray_data_ingester import RayDataIngester

# Columns to filter out from results dataframes to reduce noise
FILTERED_COLUMNS = [
    "timestamp",
    "checkpoint_dir_name",
    "done",
    "training_iteration",
    "date",
    "time_this_iter_s",
    "pid",
    "hostname",
    "node_ip",
    "time_since_restore",
    "iterations_since_restore",
    "logdir",
    "iterations",
]

# File name for serialized model artifacts
MODEL_PICKLE_FILE = "model.pkl"

logger = get_logger()


@job_function_decorator
def run_tune(use_shared_storage: Optional[bool] = None) -> None:
    """
    Run hyperparameter tuning job.

    Args:
        use_shared_storage: Use shared storage for checkpoints. Auto-detected if None.
    """
    request_id = get_request_id()
    args = load_arguments()
    tuner_config = args.tuner_config
    search_space = args.search_space
    dataset_map = args.dataset_map

    logger.info(
        f"{request_id}: Starting tuning job. Received raw arguments: {args}. ",
        extra={"log_types": [LogType.SYSTEM]},
    )

    with open(args.train_func_file_path, "r+b") as f:
        train_func = cp.load(f)

    use_shared_storage = (
        use_shared_storage if use_shared_storage is not None else in_multi_node_env()
    )

    # Materialize Ray Datasets once inside the Ray Tune job context
    # This loads data into Ray's object store so trials can reuse it without reloading
    if dataset_map and tuner_config.persist_data_in_object_store:
        logger.info("Materializing Ray Datasets for HPO trials...")
        materialized_dataset_map = {}
        for key, data_connector in dataset_map.items():
            materialized_dataset_map[key] = data_connector
            if isinstance(data_connector._ingestor, RayDataIngester):
                ray_ds = getattr(data_connector._ingestor, "_ray_ds", None)
                if not isinstance(ray_ds, MaterializedDataset):
                    materialized_ds = data_connector._ingestor.ray_ds.materialize()
                    new_ingestor = RayDataIngester(ray_ds=materialized_ds)
                    materialized_dataset_map[key] = DataConnector(ingestor=new_ingestor)

        dataset_map = materialized_dataset_map

    # num_trials has to be set before calling _adapt_tuner, because the callback is created in _get_run_config
    num_trials = _get_num_trials(tuner_config, search_space)

    ray_tuner = _adapt_tuner(
        train_func=train_func,
        search_space=search_space,
        use_shared_storage=use_shared_storage,
        num_trials=num_trials,
        request_id=request_id,
        tuner_config=tuner_config,
        dataset_map=dataset_map,
    )

    results = ray_tuner.fit()

    tuner_results = _adapt_tune_results(
        results=results,
        metric=tuner_config.metric,
        mode=tuner_config.mode,
        use_shared_storage=use_shared_storage,
    )

    logger.info(
        f"{request_id}: Tuning completed. Serializing tuning results...",
        extra={"log_types": [LogType.SYSTEM]},
    )

    serialize_object(tuner_results, TUNE_FILE_NAME)


def _get_num_trials(tuner_config: TunerConfig, search_space: SearchSpace) -> int:
    """
    Calculate number of trials. For GridSearch: product of all options. Others: num_trials.
    """
    if isinstance(tuner_config.search_alg, GridSearch):
        return math.prod(len(v) for v in search_space.values())
    return tuner_config.num_trials


def _get_run_config(
    use_shared_storage: bool, num_trials: int, request_id: str
) -> ray_tune.RunConfig:
    """
    Create Ray RunConfig with optional shared storage and callbacks.

    Note: Ray 2.52+ requires using ray.tune.RunConfig (not ray.train.RunConfig)
    when passing to ray.tune.Tuner. See:
    https://github.com/ray-project/ray/issues/49454
    """
    custom_fs = get_py_filesystem_for_stage(INTERNAL_HPO_STAGE_PATH)

    run_config = (
        ray_tune.RunConfig(
            storage_path="/",
            storage_filesystem=custom_fs,
        )
        if use_shared_storage
        else ray_tune.RunConfig()
    )
    if num_trials is not None:
        run_config.callbacks = [
            RayTuneCallback(request_id=request_id, total_iterations=num_trials)
        ]
    return run_config


def _create_placement_group_factory(
    tuner_config: TunerConfig,
) -> ray_tune.PlacementGroupFactory:
    """
    Create PlacementGroupFactory. Snowflake trainers get head+worker nodes, others get worker only.
    """
    if tuner_config.uses_snowflake_trainer:
        # Head node + worker node configuration
        return ray_tune.PlacementGroupFactory(
            [{"CPU": 0}, tuner_config.resource_per_trial]
        )
    else:
        # Worker node only configuration
        return ray_tune.PlacementGroupFactory([tuner_config.resource_per_trial])


def _adapt_tuner(
    train_func: Callable,
    search_space: SearchSpace,
    use_shared_storage: bool,
    num_trials: int,
    request_id: str,
    tuner_config: TunerConfig = None,
    dataset_map: Optional[Dict[str, DataConnector]] = None,
) -> ray_tune.Tuner:
    """
    Create configured Ray Tune Tuner instance.
    """

    def wrapper_func(
        config: Dict[str, Any],
        progress_reporter: Callable[[Dict[str, Any], Optional[Any]], None],
        dataset_map: Optional[Dict[str, Type[DataConnector]]] = None,
    ):
        context = TunerContext(
            hyper_params=config,
            progress_reporter=progress_reporter,
            dataset_map=dataset_map,
        )
        set_tuner_context(context)
        return train_func()

    # resource_per_trial should have already been set once reach server side.
    assert tuner_config.resource_per_trial is not None

    return ray_tune.Tuner(
        ray_tune.with_resources(
            ray_tune.with_parameters(
                wrapper_func,
                progress_reporter=_get_report_callback,
                dataset_map=dataset_map,
            ),
            resources=_create_placement_group_factory(tuner_config),
        ),
        param_space=_adapt_search_space(search_space, tuner_config),
        tune_config=_adapt_tuner_config(tuner_config),
        run_config=_get_run_config(use_shared_storage, num_trials, request_id),
    )


def _adapt_sampling_function(func: SamplingFunction) -> Any:
    """
    Convert custom sampling function to Ray Tune equivalent.
    """
    if isinstance(func, Uniform):
        return ray_tune.uniform(lower=func.lower, upper=func.upper)
    elif isinstance(func, Choice):
        return ray_tune.choice(func.options)
    elif isinstance(func, LogUniform):
        return ray_tune.loguniform(lower=func.lower, upper=func.upper)
    elif isinstance(func, RandInt):
        return ray_tune.randint(lower=func.lower, upper=func.upper)
    raise TypeError(f"Unsupported sampling function: {type(func)}")


def _adapt_search_space(
    search_space: SearchSpace, tuner_config: TunerConfig
) -> Optional[Dict[str, Any]]:
    """
    Convert search space to Ray Tune format. GridSearch uses grid_search, others use sampling functions.
    """
    result = {}
    for k, v in search_space.items():
        if isinstance(tuner_config.search_alg, GridSearch):
            assert isinstance(
                v, list
            ), "Please ensure search space for Gridsearch is of Python list type"
            result[k] = ray_tune.grid_search(v)
        elif isinstance(v, SamplingFunction):
            result[k] = _adapt_sampling_function(v)
        else:
            result[k] = v

    return result


def _adapt_search_algorithm(*, alg: SearchAlgorithm, max_concurrent_trials: int) -> Any:
    """
    Convert search algorithm to Ray Tune equivalent.
    """
    if isinstance(alg, BayesOpt):
        return RayBayesOptSearch(utility_kwargs=alg.utility_kwargs)
    elif isinstance(alg, RandomSearch):
        return BasicVariantGenerator(
            random_state=alg.random_state, max_concurrent=max_concurrent_trials
        )
    elif isinstance(alg, GridSearch):
        return BasicVariantGenerator(max_concurrent=max_concurrent_trials)
    raise ValueError(f"Unsupported search algorithm: {type(alg)}")


def _adapt_tuner_config(tuner_config: TunerConfig) -> ray_tune.TuneConfig:
    """
    Convert tuner config to Ray Tune TuneConfig.
    """
    return ray_tune.TuneConfig(
        metric=tuner_config.metric,
        mode=tuner_config.mode,
        search_alg=_adapt_search_algorithm(
            alg=tuner_config.search_alg,
            max_concurrent_trials=tuner_config.max_concurrent_trials,
        ),
        num_samples=tuner_config.num_trials,
        max_concurrent_trials=tuner_config.max_concurrent_trials,
        # Artifact example: HPO_SHARED_STORAGE/wrapper_func_2025-01-15_17-29-00/wrapper_func_435be_00000/...
        trial_dirname_creator=lambda t: "{}_{}".format(t.trainable_name, t.trial_id),
    )


def _get_report_callback(metrics: Dict[str, Any], model: Optional[Any] = None) -> None:
    """
    Report metrics and optionally checkpoint model.

    Note: Ray 2.52+ deprecated ray.train.report() when running in a Tune context.
    Use ray.tune.report() instead. See:
    https://github.com/ray-project/ray/issues/49454
    """
    if model is None:
        ray_tune.report(metrics)
        return

    with tempfile.TemporaryDirectory() as temp_checkpoint_dir:
        with open(os.path.join(temp_checkpoint_dir, MODEL_PICKLE_FILE), "w+b") as f:
            cp.dump(model, f)
        ray_tune.report(
            metrics, checkpoint=Checkpoint.from_directory(temp_checkpoint_dir)
        )


def _adapt_tune_results(
    results: ResultGrid, metric: str, mode: str, use_shared_storage: bool
) -> InternalTunerResults:
    """
    Process Ray Tune results into internal format with filtered columns.
    """
    results_df = None
    best_result_df = None
    best_model_path = None

    if len(results.errors) == 0:
        best_result = results.get_best_result(metric=metric, mode=mode)
        results_df = results.get_dataframe()
        best_result_df = best_result.metrics_dataframe

        if best_result.checkpoint:
            best_model_path = os.path.join(
                best_result.checkpoint.path, MODEL_PICKLE_FILE
            )

        results_df = results_df.drop(
            columns=[col for col in FILTERED_COLUMNS if col in results_df.columns]
        )
        best_result_df = best_result_df.drop(
            columns=[col for col in FILTERED_COLUMNS if col in best_result_df.columns]
        )

    # Convert exception objects to strings to avoid pickling issues
    # Ray exceptions can conflict with Snowflake exception serialization
    serializable_errors = []
    for error in results.errors:
        if hasattr(error, "cause") and error.cause:
            serializable_errors.append(str(error.cause))
        else:
            serializable_errors.append(str(error))

    return InternalTunerResults(
        results=results_df,
        best_result=best_result_df,
        best_model_path=best_model_path,
        shared_storage_stage_path=INTERNAL_HPO_STAGE_PATH
        if use_shared_storage
        else None,
        errors=serializable_errors,
    )


if __name__ == "__main__":
    ray.init(ignore_reinit_error=True, log_to_driver=False, logging_level="CRITICAL")
    run_tune()
