import asyncio
import enum
import os
import queue
import textwrap

import uuid
import cloudpickle as cp

from datetime import datetime
from typing import Dict, Callable, Optional
from snowflake.ml.data.data_connector import DataConnector

from common_utils.common_util import get_num_ray_nodes, get_total_cluster_cpus
from entities.tuner_config import configure_tuner_resources
from implementations.ray_data_ingester import RayDataIngester
from snowflake.ml.data.sharded_data_connector import ShardedDataConnector
from snowflake.ml.data.internal_data_connector import InternalDataConnector

from internal_entities.internal_tuner_results import InternalTunerResults
from shared_storage.constants import USER_STAGE_NAME
from snowflake.ml.modeling.distributors.pytorch.pytorch_trainer import (
    PyTorchDistributorResult,
)
from snowflake.ml.modeling.distributors.pytorch.scaling_config import (
    PyTorchScalingConfig,
    DefaultScalingConfig,
)
from snowflake.runtime.utils.async_utils import safe_run_awaitable, aio_queue_reader
from snowflake.runtime.utils.metrics import (
    MLRSPrometheusMetrics,
)
from entities.sharded_data_ingestor import (
    ShardedDataConnector as InternalShardedDataConnector,
)

from web.request_handler import (
    TrainV2Handler,
    TrainV3Handler,
    TuneHandler,
)
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_info,
)
from snowflake.runtime.utils.global_contextvars import set_context_head

TRAIN_FUNC_DIR = "/tmp/train_funcs"
logger = get_logger()

DEFAULT_TORCH_STAGE_LOCATION = f"{USER_STAGE_NAME}/SF_PYTORCH"


def _should_use_ray_job(use_ray_job: bool) -> bool:
    """
    Determine if ray job submission should be used based on the use_ray_job parameter
    and the PYTORCH_DISABLE_RAY_JOB environment variable.

    Args:
        use_ray_job: Boolean parameter passed by the caller

    Returns:
        True if ray job should be used, False otherwise

    Logic:
        - If PYTORCH_DISABLE_RAY_JOB="true", always return False (disabled)
        - Otherwise, return the use_ray_job parameter value
    """
    is_ray_job_disabled = (
        os.getenv("PYTORCH_DISABLE_RAY_JOB", "false").lower() == "true"
    )

    return use_ray_job and not is_ray_job_disabled


class RequestStatus(enum.Enum):
    SUCCESS = "success"
    FAILED = "failed"
    ABANDONED = "abandoned"
    RECEIVED = "received"
    IN_PROGRESS = "in_progress"


class MLRuntimeTrainer(object):
    def __init__(self, local_dir: str = TRAIN_FUNC_DIR):
        self._local_dir = local_dir

    def _load_train_func(self, train_func: Callable, request_id: str) -> str:
        if not os.path.exists(self._local_dir):
            os.makedirs(self._local_dir)

        file_path = os.path.join(self._local_dir, f"{request_id}.pkl")
        with open(file_path, mode="w+b") as train_func_file:
            cp.dump(train_func, train_func_file)

        return file_path

    def _map_serializable_dataset(self, dataset_map) -> Dict[str, DataConnector]:
        """Returns a serializable representation of a dataset map"""
        serializable_ds_map = {}
        if dataset_map is not None:
            for key, data_connector in dataset_map.items():
                if isinstance(data_connector._ingestor, RayDataIngester):
                    ingestor = RayDataIngester(
                        data_sources=data_connector._ingestor.data_sources,
                        ray_ds=data_connector._ingestor._ray_ds,
                    )
                else:
                    ingestor = RayDataIngester(
                        data_sources=data_connector._ingestor.data_sources,
                    )
                if isinstance(data_connector, ShardedDataConnector):
                    serializable_ds_map[key] = InternalShardedDataConnector(
                        ingestor=ingestor, equal=data_connector.equal
                    )
                else:
                    serializable_ds_map[key] = InternalDataConnector(ingestor=ingestor)
        return serializable_ds_map

    async def _train_async(
        self,
        request_id,
        train_func_file_path,
        scaling_config,
        hyper_params,
        dataset_map,
        artifact_stage_location,
    ) -> PyTorchDistributorResult:
        start_datetime = datetime.now()
        train_handler = TrainV2Handler(request_id=request_id)
        comm_queue: queue.Queue = queue.Queue()
        process_completed = False

        loop = asyncio.get_event_loop()
        train_task = None

        try:
            train_task = loop.create_task(
                train_handler.trainV2(
                    train_func_file_path=train_func_file_path,
                    num_nodes=scaling_config.num_node,
                    num_workers_per_node=scaling_config.num_workers_per_node,
                    num_cpus_per_worker=scaling_config.resource_requirements_per_worker.num_cpus,
                    num_gpus_per_worker=scaling_config.resource_requirements_per_worker.num_gpus,
                    hyper_params=hyper_params,
                    dataset_map=dataset_map,
                    artifact_stage_location=artifact_stage_location,
                    comm_queue=comm_queue,
                )
            )
            # Read the message from the comm queue without blocking.
            # This queue reader will finish yielding once `done` is in the msg response.
            async for msg in aio_queue_reader(comm_queue):
                if "done" in msg and msg["done"]:
                    logger.info(f"{request_id}: train(...) request completed.")
                    if "trained_model" in msg:
                        print("Training job completed successfully.")
                        model_location = (
                            msg["response"].model_location
                            if msg["response"].model_location
                            else msg["trained_model"]
                        )
                        metrics = msg["response"].metrics
                        checkpoint_stage_location = msg["response"].checkpoint_location

                        MLRSPrometheusMetrics.TRAIN_SUCCESS.value.inc()
                        MLRSPrometheusMetrics.TRAIN_DURATION_SUCCESS.value.observe(
                            (datetime.now() - start_datetime).total_seconds()
                        )
                        process_completed = True
                    elif "exception" in msg:
                        logger.info(f"Failed with exception {msg['exception']}")
                        e = msg["exception"]
                        MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
                        raise RuntimeError(f"Training job failed. Details: {repr(e)}")
                    else:
                        MLRSPrometheusMetrics.TRAIN_PARSE_ERROR.value.inc()
                        logger.exception(f"Job failed with unexpected response {msg}")
                        raise RuntimeError("Training job failed with unknown error")

                else:
                    print(msg["log_lines"])

        except Exception as e:
            logger.error(f"Error while training: {repr(e)}")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
            raise e

        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_datetime).total_seconds()
            )
            if not process_completed:
                train_handler.close()
                if train_task is not None:
                    train_task.cancel()
            else:
                return PyTorchDistributorResult(
                    model_dir=model_location,
                    metrics=metrics,
                    checkpoint_location=checkpoint_stage_location,
                )

    async def _train_async_non_rayjob(
        self,
        request_id,
        train_func: Callable,
        scaling_config,
        hyper_params,
        dataset_map,
        artifact_stage_location,
    ) -> PyTorchDistributorResult:
        start_datetime = datetime.now()
        train_handler = TrainV3Handler(request_id=request_id)
        comm_queue: queue.Queue = queue.Queue()
        process_completed = False

        loop = asyncio.get_event_loop()
        train_task = None

        try:
            train_task = loop.create_task(
                train_handler.trainV3(
                    train_func=train_func,
                    num_nodes=scaling_config.num_node,
                    num_workers_per_node=scaling_config.num_workers_per_node,
                    num_cpus_per_worker=scaling_config.resource_requirements_per_worker.num_cpus,
                    num_gpus_per_worker=scaling_config.resource_requirements_per_worker.num_gpus,
                    hyper_params=hyper_params,
                    dataset_map=dataset_map,
                    artifact_stage_location=artifact_stage_location,
                    comm_queue=comm_queue,
                )
            )
            # Read the message from the comm queue without blocking.
            # This queue reader will finish yielding once `done` is in the msg response.
            async for msg in aio_queue_reader(comm_queue):
                if "done" in msg and msg["done"]:
                    logger.info(f"{request_id}: train(...) request completed.")
                    if "trained_model" in msg:
                        print("Training job completed successfully.")
                        model_location = (
                            msg["response"].model_location
                            if msg["response"].model_location
                            else msg["trained_model"]
                        )
                        metrics = msg["response"].metrics
                        checkpoint_stage_location = msg["response"].checkpoint_location

                        MLRSPrometheusMetrics.TRAIN_SUCCESS.value.inc()
                        MLRSPrometheusMetrics.TRAIN_DURATION_SUCCESS.value.observe(
                            (datetime.now() - start_datetime).total_seconds()
                        )
                        process_completed = True
                    elif "exception" in msg:
                        logger.info(f"Failed with exception {msg['exception']}")
                        e = msg["exception"]
                        MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
                        raise RuntimeError(f"Training job failed. Details: {repr(e)}")
                    else:
                        MLRSPrometheusMetrics.TRAIN_PARSE_ERROR.value.inc()
                        logger.exception(f"Job failed with unexpected response {msg}")
                        raise RuntimeError("Training job failed with unknown error")

                else:
                    print(msg["log_lines"])

        except Exception as e:
            logger.error(f"Error while training: {repr(e)}")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
            raise e

        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_datetime).total_seconds()
            )
            if not process_completed:
                train_handler.close()
                if train_task is not None:
                    train_task.cancel()
            else:
                return PyTorchDistributorResult(
                    model_dir=model_location,
                    metrics=metrics,
                    checkpoint_location=checkpoint_stage_location,
                )

    async def _tune_async(
        self,
        request_id,
        train_func_file_path,
        search_space,
        tuner_config,
        dataset_map,
    ):
        start_datetime = datetime.now()
        tune_handler = TuneHandler(request_id=request_id)
        comm_queue: queue.Queue = queue.Queue()
        process_completed = False

        loop = asyncio.get_event_loop()
        tune_task = None

        final_status = RequestStatus.RECEIVED
        try:
            tune_task = loop.create_task(
                tune_handler.tune(
                    train_func_file_path=train_func_file_path,
                    search_space=search_space,
                    tuner_config=tuner_config,
                    dataset_map=dataset_map,
                    comm_queue=comm_queue,
                )
            )
            # Read the message from the comm queue without blocking.
            # This queue reader will finish yielding once `done` is in the msg response.
            async for msg in aio_queue_reader(comm_queue):
                if "done" in msg and msg["done"]:
                    logger.info(f"{request_id}: tune request completed.")
                    if "tune_results" in msg:
                        tune_results = msg["tune_results"]
                        final_status = RequestStatus.SUCCESS
                        process_completed = True
                    elif "exception" in msg:
                        final_status = RequestStatus.FAILED
                        logger.info(f"Failed with exception {msg['exception']}")
                        e = msg["exception"]

                        MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
                        raise RuntimeError(
                            f"Hyperparameter tuning job failed. Details: {e}"
                        )
        except Exception as e:
            final_status = RequestStatus.FAILED
            logger.error(f"{request_id}: Error while tuning: {str(e)}")
            MLRSPrometheusMetrics.TRAIN_PARSE_ERROR.value.inc()
            raise  # Re-raise the original exception without wrapping
        finally:
            duration = (datetime.now() - start_datetime).total_seconds()
            MLRSPrometheusMetrics.TUNE_REQUESTS.value.labels(
                status=final_status.value
            ).inc()
            MLRSPrometheusMetrics.TUNE_DURATION.value.labels(
                status=final_status.value
            ).observe(duration)
            if not process_completed:
                tune_handler.close()
                tune_task.cancel()
            else:
                return tune_results

    def trainV2(
        self,
        train_func: Callable,
        scaling_config: Optional[PyTorchScalingConfig] = None,
        dataset_map: Optional[Dict[str, DataConnector]] = None,
        hyper_params: Optional[Dict[str, str]] = None,
        artifact_stage_location: Optional[str] = None,
        use_ray_job: bool = True,
    ) -> PyTorchDistributorResult:
        request_id = uuid.uuid4().hex
        set_context_head(request_id)
        hyper_params = hyper_params or {}

        logger.info(f"Serving trainV2(...) request. RequestId: {request_id}")
        MLRSPrometheusMetrics.TRAIN_ATTEMPTS.value.inc()
        MLRSPrometheusMetrics.TRAIN_PYTORCH.value.inc()

        use_ray_job = _should_use_ray_job(use_ray_job)

        # Track execution mode: ray_job submission vs direct execution
        execution_mode = "ray_job" if use_ray_job else "non_ray_job"
        MLRSPrometheusMetrics.TRAIN_PYTORCH_EXECUTION_MODE.value.labels(
            mode=execution_mode
        ).inc()

        if scaling_config is None:
            scaling_config = DefaultScalingConfig()

        if scaling_config.num_node > 1 and artifact_stage_location is None:
            info_str = textwrap.dedent(
                """
                Multi-node training requires a stage to store checkpoint and model information. Your Snowflake user
                stage will be used by default in a SF_PYTORCH folder.
            """
            )
            print_user_log_info(logger, info_str)
            artifact_stage_location = DEFAULT_TORCH_STAGE_LOCATION
        serializable_ds_map = self._map_serializable_dataset(dataset_map)

        # try:
        if use_ray_job:
            file_path = self._load_train_func(train_func, request_id)
            train_response = safe_run_awaitable(
                self._train_async(
                    request_id=request_id,
                    train_func_file_path=file_path,
                    scaling_config=scaling_config,
                    hyper_params=hyper_params,
                    dataset_map=serializable_ds_map,
                    artifact_stage_location=artifact_stage_location,
                )
            )
            return train_response
        else:
            train_response = safe_run_awaitable(
                self._train_async_non_rayjob(
                    request_id=request_id,
                    train_func=train_func,
                    scaling_config=scaling_config,
                    hyper_params=hyper_params,
                    dataset_map=serializable_ds_map,
                    artifact_stage_location=artifact_stage_location,
                )
            )
            return train_response

    def tune(
        self,
        train_func: Callable,
        search_space,
        tuner_config,
        dataset_map: Optional[Dict[str, DataConnector]] = None,
    ) -> InternalTunerResults:
        request_id = uuid.uuid4().hex
        set_context_head(request_id)

        logger.info(f"Serving tune request. RequestId: {request_id}")

        MLRSPrometheusMetrics.TUNE_REQUESTS.value.labels(
            status=RequestStatus.RECEIVED.value
        ).inc()

        file_path = self._load_train_func(train_func, request_id)

        configure_tuner_resources(
            tuner_config,
            total_nodes=get_num_ray_nodes(),
            total_cluster_cpus=int(get_total_cluster_cpus()),
        )
        serializable_ds_map = self._map_serializable_dataset(dataset_map)

        tune_response = safe_run_awaitable(
            self._tune_async(
                request_id=request_id,
                train_func_file_path=file_path,
                search_space=search_space,
                tuner_config=tuner_config,
                dataset_map=serializable_ds_map,
            )
        )
        return tune_response
