from dataclasses import dataclass
from typing import Optional, Any, Dict
from datetime import datetime, timezone
import ray
from ray.util.queue import (
    Queue as RayQueue,
    Empty,
)


@dataclass(frozen=True)
class Event:
    """Base class for all events in the system."""

    timestamp: datetime = datetime.now(timezone.utc)
    source: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ProgressEvent(Event):
    """Event representing progress in an iterative process."""

    iteration: int = 0
    total_iterations: int = 0
    message: Optional[str] = None


class EventQueue:
    """Queue for handling events."""

    def __init__(self, request_id: str):
        """Initialize event queue with given request ID.

        Args:
            request_id: Unique identifier for the queue
        """
        queue_name = f"mlrs_events_queue-{request_id}"
        queue_namespace = "mlrs"

        try:
            self._queue = ray.get_actor(name=queue_name, namespace=queue_namespace)
        except ValueError:
            # Create new queue if it doesn't exist
            # Store the direct RayQueue instance to prevent garbage collection
            self._ray_queue_instance = RayQueue(
                actor_options={
                    "name": queue_name,
                    "namespace": queue_namespace,
                    "num_cpus": 0,
                }
            )
            # Get the actor reference for operations
            self._queue = ray.get_actor(name=queue_name, namespace=queue_namespace)

    def put(self, event: Event) -> None:
        """Add event to the queue.

        Args:
            event: Event to be added to queue
        """
        # NOTE: The put() below is a PRIVATE method of the Ray queue actor, not the public method of Ray queue.
        # Technically, we should use the public put() but I do think it is overhead as Ray queue is essentially a
        # wrapper of the Ray queue actor. Passing the Ray queue instance around makes the code more complex, whereas
        # we can get the actor by simply calling ray.get_actor() anywhere.
        self._queue.put.remote(event)

    def get(self, timeout: Optional[float] = None) -> Optional[Event]:
        """Get the next event from the queue.

        Args:
            timeout: Maximum time to wait for an event, in seconds

        Returns:
            Next event from the queue
        """
        if timeout is None:
            timeout = 0.2

        # NOTE: The get() below is a PRIVATE method of the Ray queue actor, not the public method of Ray queue. See
        # put() for more details.
        future = self._queue.get.remote(timeout=timeout)

        try:
            return ray.get(future)
        except Empty:
            # If the queue is empty, return None
            return None
