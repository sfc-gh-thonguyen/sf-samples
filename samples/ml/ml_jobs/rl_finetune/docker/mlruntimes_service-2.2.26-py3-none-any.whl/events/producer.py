import os
from typing import Dict, List
from snowflake.runtime.utils.logger import get_logger
from xgboost import Booster
from events.events import EventQueue, ProgressEvent
from ray.train.xgboost._xgboost_utils import (
    RayTrainReportCallback as RayTrainXGBoostReportCallback,
)
from ray.train.lightgbm._lightgbm_utils import (
    RayTrainReportCallback as RayTrainLightGBMReportCallback,
)
from ray.tune import Callback as TuneCallback
from ray.tune.experiment.trial import Trial
from xgboost.callback import TrainingCallback as XGBoostTrainingCallback

try:
    import streamlit as st
except ImportError:
    st = None
USE_STREAMLIT_WIDGETS = os.getenv("USE_STREAMLIT_WIDGETS", "1") == "1"
if not USE_STREAMLIT_WIDGETS:
    st = None
logger = get_logger()


class TrainProgressMixin:
    """Mixin class providing event queue reporting functionality for training callbacks.

    This mixin adds the ability to track training progress by reporting ProgressEvent
    objects through an EventQueue. It can be combined with different callback base classes.
    """

    def __init__(self, request_id: str, total_iterations: int, **kwargs):
        """Initialize the progress tracking functionality.

        Args:
            request_id: Unique identifier for the training job
            total_iterations: Total number of iterations expected in training
        """
        super().__init__(**kwargs)
        self.request_id = request_id
        self.total_iterations = total_iterations
        if st is not None:
            self._queue = EventQueue(self.request_id)
            # Initialize progress bar to show "0/N (0%)" when training starts.
            # We pass -1 because the display logic in handlers.py adds +1 to all iteration numbers,
            # so -1 + 1 = 0, which gives us the initial "0/N" state we want.
            self._report_progress(-1)

    def _report_progress(self, epoch: int):
        """Report training progress by sending a ProgressEvent to the EventQueue.

        Args:
            model: The current model being trained
            epoch: The current epoch/iteration number
        """
        self._queue.put(
            ProgressEvent(
                iteration=epoch,
                total_iterations=self.total_iterations,
            )
        )


class OSSTrainXGBoostCallback(TrainProgressMixin, XGBoostTrainingCallback):
    """Callback for reporting training progress events with the OSS XGBoost API.

    This callback extends XGBoost's TrainingCallback to add event queue reporting
    functionality.
    """

    def after_iteration(self, model: Booster, epoch: int, evals_log: Dict) -> bool:
        """Called after each training iteration.

        Args:
            model: The current model being trained
            epoch: The current epoch/iteration number
            evals_log: Dictionary containing evaluation metrics
        """
        # We should not produce any events if Streamlit is not available
        if st is not None:
            self._report_progress(epoch)
        return XGBoostTrainingCallback.after_iteration(self, model, epoch, evals_log)


# LightGBM does not have a native callback class.
class OSSTrainLGBMCallback(TrainProgressMixin):
    """Callback for reporting training progress events with the LightGBM API.

    This callback implements the LightGBM callback interface to add event queue reporting
    functionality.
    """

    def __init__(self, request_id: str, total_iterations: int):
        """Initialize callback.

        Args:
            request_id: Unique identifier for the training job
            total_iterations: Total number of iterations expected in training
        """
        super().__init__(request_id=request_id, total_iterations=total_iterations)
        # This callback is most similar to the record evaluation callback since it's recording/reporting progress
        self.order = 20
        # Execute after iteration
        self.before_iteration = False

    def __call__(self, env):
        """Called by LightGBM after each iteration.

        Args:
            env: The callback environment provided by LightGBM with the following attributes:
                - model: The current LightGBM Booster model
                - iteration: The current iteration (0-based)
                - evaluation_result_list: List of evaluation results
        """
        # We should not produce any events if Streamlit is not available
        if st is not None:
            self._report_progress(env.iteration)


class RayTrainXGBoostCallback(TrainProgressMixin, RayTrainXGBoostReportCallback):
    """Callback for reporting XGBoost training progress events with Ray Train."""

    def after_iteration(self, model: Booster, epoch: int, evals_log: Dict):
        """Called after each training iteration.

        Args:
            model: The current model being trained
            epoch: The current epoch/iteration number
            evals_log: Dictionary containing evaluation metrics
        """
        # We should not produce any events if Streamlit is not available
        if st is not None:
            self._report_progress(epoch)
        RayTrainXGBoostReportCallback.after_iteration(self, model, epoch, evals_log)


class RayTrainLGBMCallback(OSSTrainLGBMCallback, RayTrainLightGBMReportCallback):
    """Callback for reporting LightGBM training progress events with Ray Train."""

    def __call__(self, env):
        """Called by LightGBM after each iteration.

        Args:
            env: The callback environment provided by LightGBM with the following attributes:
                - model: The current LightGBM Booster model
                - iteration: The current iteration (0-based)
        """
        RayTrainLightGBMReportCallback.__call__(self, env)
        OSSTrainLGBMCallback.__call__(self, env)


class RayTuneCallback(TrainProgressMixin, TuneCallback):
    """Callback for reporting training progress events with Ray Tune."""

    def __init__(self, request_id: str, total_iterations: int):
        """Initialize callback.

        Args:
            request_id: Unique identifier for the training job
            total_iterations: Total number of iterations expected in training
        """
        super().__init__(request_id=request_id, total_iterations=total_iterations)
        self.current_iteration = 0

    def on_trial_complete(
        self, iteration: int, trials: List[Trial], trial: Trial, **kwargs
    ):
        """Called when a trial completes.

        Args:
            iteration: The current iteration
            trials: The list of trials
            trial: The current trial
            **kwargs: Additional keyword arguments
        """
        if st is not None:
            self._report_progress(self.current_iteration)
            self.current_iteration += 1
        TuneCallback.on_trial_complete(self, iteration, trials, trial, **kwargs)
