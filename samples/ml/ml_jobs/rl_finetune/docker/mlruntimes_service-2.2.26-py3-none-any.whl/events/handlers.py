import threading
import logging
from abc import ABC, abstractmethod
import time

try:
    import streamlit as st
    from streamlit.runtime.scriptrunner import add_script_run_ctx
except ImportError:
    st = None
    add_script_run_ctx = None
from typing import Optional
from events.events import Event, EventQueue, ProgressEvent
from common_utils.common_util import get_ray_resource_metrics

logger = logging.getLogger(__name__)


class EventHandler(ABC):
    """Base class for handling events from an event queue."""

    def __init__(self, request_id: str, msg: str):
        """Initialize the event handler with a request ID.

        Args:
            request_id: Unique identifier for the event queue
        """
        self._event_queue = EventQueue(request_id)
        self._stop_processing: threading.Event = threading.Event()
        self._processing_thread: Optional[threading.Thread] = None
        self._metrics_thread: Optional[threading.Thread] = None
        self._status_text = ""
        self._msg = msg

    @abstractmethod
    def _update_metrics(self) -> None:
        """Get resource metrics from Ray. Not used in non-streamlit env."""
        pass

    @abstractmethod
    def _handle_event(self, event: Event) -> None:
        """Process a single event.

        Args:
            event: The event to process
        """
        if isinstance(event, ProgressEvent):
            training_percentage = (event.iteration + 1) / event.total_iterations
            if event.message:
                self._status_text = (
                    f"### Training Progress: {event.iteration + 1}/"
                    f"{event.total_iterations} ({training_percentage * 100:.1f}%) - {event.message}"
                )
            else:
                self._status_text = (
                    f"### Training Progress: {event.iteration + 1}/{event.total_iterations} "
                    f"({training_percentage * 100:.1f}%)"
                )

    def _batch_pull_events(self) -> None:
        """Pull events from the queue in batches."""
        event = self._event_queue.get()
        while event is not None:
            self._handle_event(event)
            event = self._event_queue.get()

    def _process_events(self) -> None:
        """Process events from the queue.

        This method starts processing events from the queue in a blocking manner.
        It will continue processing until stop_processing() is called.
        """
        while not self._stop_processing.is_set():
            try:
                self._batch_pull_events()
            except Exception as e:
                logger.error(f"Error processing event: {e}")
            time.sleep(0.2)
        # Process all remaining events in the queue
        if self._stop_processing.is_set():
            self._batch_pull_events()

    def start_processing(self) -> None:
        """Start processing events in a background thread.

        This method launches a background thread that processes events
        from the queue without blocking the main thread.
        """
        if self._processing_thread is not None and self._processing_thread.is_alive():
            logger.warning("Event processing thread is already running")
            return

        if self._metrics_thread is not None and self._metrics_thread.is_alive():
            logger.warning("Background thread is already running")
            return

        self._processing_thread = threading.Thread(
            target=self._process_events, daemon=True
        )
        # The following line is used to suppress streamlit benign warnings
        add_script_run_ctx(self._processing_thread)
        self._processing_thread.start()

        self._metrics_thread = threading.Thread(
            target=self._update_metrics, daemon=True
        )
        add_script_run_ctx(self._metrics_thread)
        self._metrics_thread.start()

    def stop_processing(self) -> None:
        """Stop processing events.

        This signals the processing thread to stop and waits for it to complete.
        """
        self._stop_processing.set()
        # Wait for the processing thread to finish
        time.sleep(2)
        if self._processing_thread is not None:
            if self._processing_thread.is_alive():
                logger.warning(
                    f"[{self._msg}] Event processing thread did not stop cleanly"
                )
            if self._event_queue.get() is not None:
                logger.warning(
                    f"[{self._msg}] Event queue is not empty after stopping event processing thread"
                )
        if self._metrics_thread is not None:
            if self._metrics_thread.is_alive():
                logger.warning(f"[{self._msg}] Metrics thread did not stop cleanly")


class StreamlitEventHandler(EventHandler):
    """Event handler that updates Streamlit widgets based on events.

    This handler creates a Streamlit progress bar and updates it
    based on events received from the event queue.
    """

    def __init__(self, request_id: str, msg: str):
        """Initialize the Streamlit event handler.

        Args:
            request_id: Unique identifier for the event queue
        """
        super().__init__(request_id, msg)

        if hasattr(st, "runtime") and st.runtime.exists():
            self._status_container = st.empty()
            self._progress_container = st.empty()
            self._resource_table_title = st.empty()
            self._ray_resource_container = st.empty()
            self._last_progress_pct = 0.0
        else:
            raise RuntimeError("Streamlit is not available")

    def _update_metrics(self) -> None:
        """Get resource metrics from Ray."""
        self._resource_table_title.write("### Resource Usage by Node")
        while not self._stop_processing.is_set():
            self._ray_resource_container.dataframe(get_ray_resource_metrics())
            time.sleep(1)

    def _handle_event(self, event: Event) -> None:
        """Update Streamlit widgets based on the event.

        Args:
            event: The event to process
        """
        super()._handle_event(event)

        if isinstance(event, ProgressEvent):
            self._status_container.write(self._status_text)
            # Need to add 1 to the iteration because the iteration starts at 0
            progress_pct = max(
                min((event.iteration + 1) / event.total_iterations, 1.0),
                self._last_progress_pct,
            )
            self._last_progress_pct = progress_pct
            self._progress_container.progress(progress_pct)
        else:
            st.error(
                f"Streamlit event handler received an unexpected event type: {type(event)}",
                icon="⚠️",
            )

    def stop_processing(self, err_msg: Optional[str] = None) -> None:
        super().stop_processing()
        if err_msg is None:
            st.success(f"{self._msg} completed", icon="✅")
        else:
            st.error(err_msg)
            st.error(f"{self._msg} failed. See above for details.", icon="⚠️")
