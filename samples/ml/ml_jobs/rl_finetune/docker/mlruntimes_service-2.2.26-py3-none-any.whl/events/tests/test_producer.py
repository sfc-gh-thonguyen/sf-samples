import unittest
import uuid
import ray
import pytest
from unittest.mock import patch, MagicMock

from events.producer import RayTrainXGBoostCallback
from events.events import ProgressEvent


class MockBooster:
    """Mock Booster class for testing."""

    def __init__(self, n_estimators=10):
        self.n_estimators = n_estimators

    def get_params(self):
        return {"n_estimators": self.n_estimators}


streamlit_mock = MagicMock()
streamlit_mock.runtime.exists.return_value = True
# replace the actual Streamlit module with our mock
with patch.dict("sys.modules", {"streamlit": streamlit_mock}):
    import importlib

    # Reloads the events.producer module to ensure it uses our mocked Streamlit
    import events.producer

    importlib.reload(events.producer)


@pytest.fixture(scope="module", autouse=True)
def setup_ray():
    if ray.is_initialized():
        ray.shutdown()
    ray.init(ignore_reinit_error=True)
    yield
    ray.shutdown()


class TestTrainReportCallback(unittest.TestCase):
    def test_init_with_total_iterations(self):
        """Test callback initialization with total_iterations."""
        request_id = str(uuid.uuid4())
        total_iterations = 50
        callback = RayTrainXGBoostCallback(
            request_id=request_id, total_iterations=total_iterations
        )

        self.assertEqual(callback.request_id, request_id)
        self.assertEqual(callback.total_iterations, total_iterations)

    @patch("events.events.EventQueue.put")
    @patch("ray.train.xgboost._xgboost_utils.RayTrainReportCallback.after_iteration")
    def test_after_iteration_sends_progress_event(
        self, mock_ray_after_iteration, mock_put
    ):
        """Test that after_iteration sends a ProgressEvent to the queue.

        Note: We mock RayTrainReportCallback.after_iteration because Ray 2.52+
        strictly enforces that ray.train.report() can only be called from within
        a Ray Train worker context. The production code works correctly inside
        trainer.fit(), but tests run outside that context.
        """
        request_id = str(uuid.uuid4())
        total_iterations = 30
        callback = RayTrainXGBoostCallback(
            request_id=request_id, total_iterations=total_iterations
        )
        mock_put.assert_called_once()

        model = MockBooster()
        epoch = 10
        callback.after_iteration(model, epoch, {})

        # Verify parent callback was called (self is passed as first arg for unbound method)
        mock_ray_after_iteration.assert_called_once()
        call_args = mock_ray_after_iteration.call_args[0]
        self.assertEqual(call_args[1], model)  # model
        self.assertEqual(call_args[2], epoch)  # epoch
        self.assertEqual(call_args[3], {})  # evals_log

        assert mock_put.call_count == 2
        event = mock_put.call_args[0][0]

        self.assertIsInstance(event, ProgressEvent)
        self.assertEqual(event.iteration, epoch)
        self.assertEqual(event.total_iterations, total_iterations)


if __name__ == "__main__":
    unittest.main()
