import unittest
import pytest
import ray
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock

from events.events import Event, ProgressEvent, EventQueue


@pytest.fixture(scope="module", autouse=True)
def setup_ray():
    if ray.is_initialized():
        ray.shutdown()
    ray.init(ignore_reinit_error=True)
    yield
    ray.shutdown()


class TestEventQueue(unittest.TestCase):
    def setUp(self):
        self.request_id = f"test_{datetime.now(timezone.utc).timestamp()}"

    def tearDown(self):
        try:
            actor = ray.get_actor(
                name=f"mlrs_events_queue-{self.request_id}", namespace="mlrs"
            )
            ray.kill(actor)
        except ValueError:
            pass

    def test_queue_creation(self):
        # Test that a new queue is created
        queue = EventQueue(self.request_id)
        self.assertIsNotNone(queue._queue)

    def test_put_get(self):
        queue = EventQueue(self.request_id)
        event = Event(source="test")
        assert (
            event is not None
        ), "Event is None. Have you run `pip install -e service`?"
        queue.put(event)

        received_event = queue.get()
        self.assertEqual(received_event.source, "test")

    def test_put_get_progress_event(self):
        queue = EventQueue(self.request_id)

        progress_event = ProgressEvent(
            iteration=5, total_iterations=10, message="Halfway there"
        )
        assert (
            progress_event is not None
        ), "ProgressEvent is None. Have you run `pip install -e service`?"
        queue.put(progress_event)
        received_event = queue.get()

        self.assertEqual(received_event.iteration, 5)
        self.assertEqual(received_event.total_iterations, 10)
        self.assertEqual(received_event.message, "Halfway there")

    @patch("ray.get_actor")
    def test_existing_queue_retrieval(self, mock_get_actor):
        mock_queue = MagicMock()
        mock_get_actor.return_value = mock_queue

        # Create queue instance - should use the existing one
        queue = EventQueue(self.request_id)

        mock_get_actor.assert_called_with(
            name=f"mlrs_events_queue-{self.request_id}", namespace="mlrs"
        )

        self.assertEqual(queue._queue, mock_queue)


if __name__ == "__main__":
    pytest.main()
