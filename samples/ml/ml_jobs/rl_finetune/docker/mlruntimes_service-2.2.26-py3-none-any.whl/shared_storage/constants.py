import tempfile

LOCAL_BASE_URL = f"{tempfile.gettempdir()}/mlrs_data/"
COPY_BASE_URL = f"{tempfile.gettempdir()}/temp_copy/"
USER_STAGE_NAME = "@~"
# This is a user-stage that each snowflake user has access to.
INTERNAL_HPO_STAGE_PATH = "@~/HPO_SHARED_STORAGE"
