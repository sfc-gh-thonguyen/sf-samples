import os

from shared_storage.abstract_local_buffered_file import AbstractLocalBufferedFile
from shared_storage.constants import LOCAL_BASE_URL
from fsspec.spec import AbstractFileSystem


class StageBufferedWriteFile(AbstractLocalBufferedFile):
    """
    Buffered File for write sync between Local file and Stage file.
    """

    def __init__(
        self, fs: AbstractFileSystem, path: str, stage_fs, mode="rb", **kwargs
    ):
        """
        stage_fs: FileSystem instance for Stage file
        """
        self._stage_fs = stage_fs
        super().__init__(fs, path, mode, **kwargs)

    def _close(self):
        self._temp_file.close()
        super().close()

    def close(self):
        """
        Close the local temp file, Sync the file to stage location and delete the local temp file.
        """
        self._close()
        self._stage_fs.write_file_to_stage(
            self.path, os.path.relpath(self.path, LOCAL_BASE_URL)
        )
        if os.path.exists(self.path):
            os.remove(self.path)
