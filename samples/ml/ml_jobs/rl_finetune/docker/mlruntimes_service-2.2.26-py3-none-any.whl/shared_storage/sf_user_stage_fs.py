from typing import Any
from snowflake.runtime.utils.stage_fs import SFStageFileSystem


class SFUserStageFileSystem(SFStageFileSystem):
    """
    SFStageFileSystem implementation to support User Stage path/name
    This is required to override stage_name, _stage_path_to_relative_path to support User stage.
    SFStageFileSystem only supports named stages.
    """

    _USER_STAGE_NAME = "@~"

    def __init__(self, db, schema, stage, **kwargs: Any):
        super().__init__(db=db, schema=schema, stage=stage, **kwargs)
        self._stage = "~"

    @property
    def stage_name(self) -> str:
        """Get the path for user stage."""
        return self._USER_STAGE_NAME

    def _stage_path_to_relative_path(self, stage_path: str) -> str:
        return stage_path.removeprefix(self._USER_STAGE_NAME)
