from typing import Any
from shared_storage.abtract_stage_shared_filesystem import AbstractStageSharedFileSystem
from snowflake.ml.fileset.sfcfs import SFFileSystem


class NamedStageSharedFileSystem(AbstractStageSharedFileSystem):
    """
    File System implementing pyarrow.fs.FileSystem using Snowflake Named Stage for storage.
    https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage
    """

    def __init__(
        self,
        stage_path: str,
    ):
        """
        stage_path: Fully qualified Named Stage Path.
        """
        super().__init__(stage_path)
        self.sf_file_system = SFFileSystem(snowpark_session=self.session)

    protocol = "namedspfs"

    @property
    def type_name(self):
        """
        The filesystem's type name.
        """
        return NamedStageSharedFileSystem

    @staticmethod
    def from_uri(uri: str):
        return NamedStageSharedFileSystem(uri)

    def listdir(self, path: str, detail=False) -> Any:
        st_path = self._get_stage_path_from_local_path(path)
        list_files = self.sf_file_system.ls(st_path, detail)
        return list_files

    def info(self, path: str, **kwargs: Any) -> Any:
        if isinstance(path, dict):
            fpath = path["name"]
        else:
            fpath = path
        st_path = self._get_stage_path_from_local_path(fpath)
        inf = self.sf_file_system.info(st_path, **kwargs)
        inf["name"] = inf["name"].replace(self.stage_path, "")
        return inf

    def open_input_file(self, path: str, **kwargs):
        """
        For named stage we can directly get a signed url and open a http stream to read the file.
        """
        st_path = self._get_stage_path_from_local_path(path)
        return self.sf_file_system.open(st_path, mode="rb", **kwargs)

    @staticmethod
    def _reconstruct(kwargs):
        # __reduce__ doesn't allow passing named arguments directly to the
        # reconstructor, hence this wrapper.
        return NamedStageSharedFileSystem(**kwargs)

    def __reduce__(self):
        return NamedStageSharedFileSystem._reconstruct, (
            dict(
                stage_path=self.stage_path,
            ),
        )
