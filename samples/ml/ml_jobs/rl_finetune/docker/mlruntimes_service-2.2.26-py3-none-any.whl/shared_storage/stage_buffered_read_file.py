import os

from shared_storage.abstract_local_buffered_file import AbstractLocalBufferedFile
from fsspec.spec import AbstractFileSystem


class StageBufferedReadFile(AbstractLocalBufferedFile):
    """
    Buffered File for read sync between Local file and Stage file.
    """

    def __init__(self, fs: AbstractFileSystem, path: str, mode="rb", **kwargs):
        super().__init__(fs, path, mode, **kwargs)

    def _close(self):
        self._temp_file.close()
        super().close()

    def close(self):
        """
        Close file IO and delete the temporary file after read operation is complete.
        """
        self._close()
        if os.path.exists(self.path):
            os.remove(self.path)
