import os

from typing import Any
from fsspec.implementations.local import LocalFileSystem
from pyarrow.fs import FileSystem, FileInfo, FileType
from snowflake.runtime.utils.session_utils import get_session

from shared_storage.lru_cache import LRUCache
from shared_storage.stage_buffered_write_file import StageBufferedWriteFile
from shared_storage.constants import LOCAL_BASE_URL, COPY_BASE_URL

file_type_mapping = {
    "file": FileType.File,
    "directory": FileType.Directory,
    "not_found": FileType.NotFound,
    "unknown": FileType.Unknown,
}


class AbstractStageSharedFileSystem(FileSystem):
    """
    Abstract File System for implementing pyarrow.fs.FileSystem
    """

    def __init__(
        self,
        stage_path,
    ):
        """file system instance with stage information and a snowflake connection.

        Args:
            session: A Snowpark session object. Mutually exclusive to `sf_connection`.
            db_name: the database name of the target stage
            schema_name: The schema name of the target internal stage.
            stage: Fully qualified Stage Path.
        """
        self.session = get_session()
        self.db_name = self.session.get_current_database()
        self.schema_name = self.session.get_current_schema()
        self.stage_path = stage_path
        os.makedirs(LOCAL_BASE_URL, exist_ok=True)
        os.makedirs(COPY_BASE_URL, exist_ok=True)
        self.lru_cache = LRUCache(1000)

    protocol = "spfs"

    @classmethod
    def _parent(cls, path: str) -> str:
        return os.path.dirname(path)

    @classmethod
    def _get_sql_path(cls, path: str) -> str:
        return f"'{path}'"

    @classmethod
    def _get_num_parallel(cls):
        return max(4, os.cpu_count() // 4)

    def _get_stage_path_from_local_path(self, path: str) -> str:
        if not path.startswith(self.stage_path):
            path = path.lstrip("/")
            return os.path.join(self.stage_path, path)
        return path

    def _get_local_path_from_stage_path(self, path: str) -> str:
        if path.startswith(self.stage_path):
            return path.removeprefix(self.stage_path)
        return path

    @property
    def type_name(self):
        """
        The filesystem's type name.
        """
        return AbstractStageSharedFileSystem

    def copy_file(self, src: str, dest: str):
        """
        Copy file from stage(src))to local dir
        Copy file from local dir to stage location(dest)
        """
        src_path, src_file = os.path.split(self._get_local_path_from_stage_path(src))
        stage_src_path = self._get_stage_path_from_local_path(src)
        self.session.file.get(stage_src_path, COPY_BASE_URL)
        stage_dest_path = self._get_stage_path_from_local_path(dest)
        self.write_file_to_stage(os.path.join(COPY_BASE_URL, src_file), stage_dest_path)

    def create_dir(self, path: str, *args, **kwargs):
        self.mkdir(path, *args, **kwargs)

    def mkdir(self, path: str, *args, **kwargs):
        """
        File on stage don't need a directory created before writing
        Stage API will write files at any path
        This only works for Ray use case - where info or ls is not called on empty directory
        """
        pass

    def write_file_to_stage(self, local_path: str, remote_path: str):
        remote_path_dir, remote_file = os.path.split(remote_path)
        stage_path = self._get_stage_path_from_local_path(remote_path_dir)
        self.session.file.put(
            local_path,
            self._get_sql_path(stage_path),
            auto_compress=False,
            overwrite=True,
            parallel=self._get_num_parallel(),
        )

    def delete_dir(self, path: str):
        self.delete_file(path)

    def delete_dir_contents(self, path: str, *args, **kwargs):
        self.delete_file(path)

    def delete_file(self, path: str):
        st_path = self._get_stage_path_from_local_path(path)
        self.session.sql(f"REMOVE '{st_path}'").collect()

    @staticmethod
    def from_uri(uri: str):
        return AbstractStageSharedFileSystem(uri)

    def normalize_path(self, path: str) -> str:
        return path

    def get_file_info(self, selector):
        if not self.isdir(selector.base_dir):
            if self.exists(selector.base_dir):
                raise NotADirectoryError(selector.base_dir)
            else:
                if selector.allow_not_found:
                    return []
                else:
                    raise FileNotFoundError(selector.base_dir)

        if selector.recursive:
            maxdepth = None
        else:
            maxdepth = 1

        infos = []
        selected_files = self.find(
            selector.base_dir, maxdepth=maxdepth, withdirs=True, detail=True
        )
        for path, info in selected_files.items():
            pth = info.get("name").replace(self.stage_path, "")
            infos.append(
                FileInfo(
                    path=pth,
                    size=int(info.get("size")),
                    type=file_type_mapping.get(info.get("type")),
                )
            )
        return infos

    def exists(self, path: str) -> bool:
        return self.info(path) is not None

    def copy(self, src: str, dest: str):
        self.copy_file(src, dest)

    def move(self, src: str, dest: str):
        self.mv(src, dest)

    def mv(self, src: str, dest: str, recursive=False):
        raise NotImplementedError()

    def find(self, base: str, maxdepth=None, withdirs=False, detail=False):
        """
        Note: maxdepth is not supported, for supporting this param recursively walk all directories and ls to find
        """
        items = []
        if maxdepth is not None and maxdepth != 1:
            raise ValueError("Unsupported params : maxdepth > 1")

        for item in self.listdir(base, detail):
            if self.isdir(item) and not withdirs:
                continue
            else:
                items.append(self.info(item))
        return {item["name"]: item for item in items}

    def rm(self, path: str, recursive=True):
        """
        path will be deleted recursively by default
        """
        if not recursive:
            raise ValueError("Unsupported params : recursive=False")
        self.delete_file(path)

    def isdir(self, path: str) -> bool:
        key = f"isdir::{path}"
        if self.lru_cache.get(key) is None:
            isdir_val = self.info(path).get("type") == "directory"
            self.lru_cache.put(key, isdir_val)
        return self.lru_cache.get(key)

    def isfile(self, path: str) -> bool:
        key = f"isfile::{path}"
        if self.lru_cache.get(key) is None:
            isfile_val = self.info(path).get("type") == "file"
            self.lru_cache.put(key, isfile_val)
        return self.lru_cache.get(key)

    def ls(self, path: str, detail=False):
        return self.listdir(path, detail)

    def listdir(self, path: str, detail=False):
        raise NotImplementedError()

    def open(self, path: str, mode: str = "rb"):
        if mode == "rb":
            return self.open_input_file(path)
        else:
            return self.open_output_stream(path)

    def info(self, path: str, **kwargs: Any):
        raise NotImplementedError()

    def open_input_file(self, path: str, **kwargs: Any):
        raise NotImplementedError()

    def open_output_stream(
        self, path: str, compression="detect", buffer_size=None, metadata=None
    ):
        """
        Create a local temp File to write, all writes to the file system interface will write to Local temp file.
        When file is closed after write StageBufferedWriteFile.close() is called which will Sync the file to stage,
        and delete the local temp file.

        StageBufferedWriteFile - is used to handle writes and close operations for the temp file.
        LocalFileSystem - is the filesystem for local files.
        """
        base_dir_path = LOCAL_BASE_URL
        path = path.lstrip("/")
        local_file_to_watch = os.path.join(base_dir_path, path)
        src_path, src_file = os.path.split(local_file_to_watch)
        os.makedirs(base_dir_path, exist_ok=True)
        os.makedirs(src_path, exist_ok=True)
        if not os.path.exists(local_file_to_watch):
            with open(local_file_to_watch, "a") as _:
                pass
        return StageBufferedWriteFile(
            LocalFileSystem(), local_file_to_watch, self, "wb"
        )

    @staticmethod
    def _reconstruct(kwargs):
        # __reduce__ doesn't allow passing named arguments directly to the
        # reconstructor, hence this wrapper.
        return AbstractStageSharedFileSystem(**kwargs)

    def __reduce__(self):
        return AbstractStageSharedFileSystem._reconstruct, (
            dict(
                stage_path=self.stage_path,
            ),
        )
