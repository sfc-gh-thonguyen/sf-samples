from fsspec.spec import AbstractBufferedFile, AbstractFileSystem


class AbstractLocalBufferedFile(AbstractBufferedFile):
    """
    Abstract Buffered File for implementing read/write sync between Local file and Stage file.
    """

    def __init__(self, fs: AbstractFileSystem, path: str, mode="rb", **kwargs):
        """
        fs: FileSystem instance for Local file
        path: Local path to the file
        """
        self.path = path
        self._temp_file = open(path, mode)
        super().__init__(fs, path, mode, **kwargs)

    def flush(self, force=False):
        if not self._temp_file.closed:
            self._temp_file.flush()
        super().flush(force=force)

    def _close(self):
        raise NotImplementedError()

    def read(self, *args, **kwargs):
        return self._temp_file.read(*args, **kwargs)

    def write(self, *args, **kwargs):
        return self._temp_file.write(*args, **kwargs)

    def tell(self, *args, **kwargs):
        return self._temp_file.tell(*args, **kwargs)

    def seek(self, *args, **kwargs):
        return self._temp_file.seek(*args, **kwargs)

    def seekable(self, *args, **kwargs):
        return self._temp_file.seekable(*args, **kwargs)

    def readline(self, *args, **kwargs):
        return self._temp_file.readline(*args, **kwargs)

    def readlines(self, *args, **kwargs):
        return self._temp_file.readlines(*args, **kwargs)

    def close(self):
        if not self._temp_file.closed:
            self._temp_file.close()
        super().close()
