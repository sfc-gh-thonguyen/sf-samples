import os

from typing import Any, Dict, List, cast, Optional, Union
from fsspec.implementations.local import LocalFileSystem
from fsspec.spec import AbstractBufferedFile

import snowflake
from snowflake.connector.nanoarrow_arrow_iterator import OperationalError

from shared_storage.abtract_stage_shared_filesystem import AbstractStageSharedFileSystem
from shared_storage.stage_buffered_read_file import StageBufferedReadFile
from shared_storage.sf_user_stage_fs import SFUserStageFileSystem
from shared_storage.constants import COPY_BASE_URL, USER_STAGE_NAME


class UserStageSharedFileSystem(AbstractStageSharedFileSystem):
    """
    File System implementing pyarrow.fs.FileSystem using Snowflake User Stage for storage.
    https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage
    """

    def __init__(
        self,
        stage_path: str,
    ):
        """
        stage_path: Fully qualified Named Stage Path.
        """
        stage_path = stage_path.rstrip("/")
        super().__init__(stage_path)
        if not stage_path.startswith(USER_STAGE_NAME):
            raise ValueError(
                f"Invalid User stage path {stage_path}. Should start with {USER_STAGE_NAME}"
            )
        self.relative_stage_path = stage_path.removeprefix(USER_STAGE_NAME)
        self.stage_fs = SFUserStageFileSystem(
            db=self.db_name,
            schema=self.schema_name,
            stage=stage_path,
            snowpark_session=self.session,
        )

    protocol = "userspfs"

    @property
    def type_name(self):
        """
        The filesystem's type name.
        """
        return UserStageSharedFileSystem

    @staticmethod
    def from_uri(uri: str):
        return UserStageSharedFileSystem(uri)

    def _get_relative_path(self, path: str) -> str:
        local_path = self._get_local_path(path)
        if not local_path.startswith(self.relative_stage_path):
            local_path = local_path.lstrip("/")
            return os.path.join(self.relative_stage_path, local_path)
        return local_path

    def _get_local_path(self, path: str) -> str:
        if path.startswith(self.stage_path):
            return path.removeprefix(self.stage_path)
        elif path.startswith(self.relative_stage_path):
            return path.removeprefix(self.relative_stage_path)
        return path

    def _decorate_ls_res(
        self,
        stage_path_list,
        detail: bool,
    ) -> Union[List[str], List[Dict[str, Any]]]:
        """Add the stage location as the prefix of file names returned by ls()"""
        if detail:
            for path in stage_path_list:
                path["name"] = self._get_local_path("/" + path["name"].lstrip("/"))
            return stage_path_list
        else:
            return [
                self._get_local_path("/" + path.lstrip("/")) for path in stage_path_list
            ]

    def listdir(self, path: str, detail=False) -> Any:
        st_path = self._get_relative_path(path)
        stage_path_list = self.stage_fs.ls(st_path, detail=detail)
        stage_path_list = cast(List[Dict[str, Any]], stage_path_list)
        ls_res = self._decorate_ls_res(stage_path_list, detail)
        return ls_res

    def info(self, path: str, **kwargs: Any) -> Any:
        if isinstance(path, dict):
            fpath = path["name"]
        else:
            fpath = path
        st_path = self._get_relative_path(fpath)
        out = self.ls(st_path, detail=True, **kwargs)
        out1 = [o for o in out if o["name"].rstrip("/") == fpath]
        if len(out1) == 1:
            if "size" not in out1[0]:
                out1[0]["size"] = None
            res = out1[0]
        elif len(out1) > 1 or out:
            res = {"name": fpath, "size": 0, "type": "directory"}
        else:
            raise FileNotFoundError(fpath)

        if res:
            res["name"] = self._get_local_path("/" + res["name"].lstrip("/"))
        return res

    def unwrap_single_quote(self, name: str) -> str:
        new_name = name.strip()
        if new_name.startswith("'") and new_name.endswith("'"):
            new_name = new_name[1:-1]
        new_name = new_name.replace("\\'", "'")
        return new_name

    def split_path(self, path: str) -> list[str]:
        """Split a file path into directory and file name."""
        path = self.unwrap_single_quote(path)
        return path.rsplit("/", maxsplit=1)

    def get_read_stream(
        self,
        stage_path: str,
        parallel: int = 4,
        decompress: bool = False,
        statement_params: Optional[Dict[str, str]] = None,
    ) -> AbstractBufferedFile:
        """
        Use stage GET api to download the file to local temp file path and return read stream for local temp file.
        After read IO is closed, StageBufferedReadFile.close() is called and will delete the local temp file.
        """
        if decompress:
            raise ValueError("Unsupported param : decompress")
        options = {"parallel": parallel}
        tmp_dir = COPY_BASE_URL
        src_file_name = self.split_path(stage_path)[1]
        local_file_name = os.path.join(tmp_dir, src_file_name)
        plan = self.session._plan_builder.file_operation_plan(
            "get",
            f"file://{tmp_dir}",
            self._get_sql_path(stage_path),
            options=options,
        )
        try:
            snowflake.snowpark.dataframe.DataFrame(self.session, plan).collect(
                statement_params=statement_params
            )
        except OperationalError as oe:
            raise oe

        return StageBufferedReadFile(LocalFileSystem(), local_file_name, "rb")

    def open_input_file(self, path: str) -> AbstractBufferedFile:
        st_path = self._get_stage_path_from_local_path(path)
        return self.get_read_stream(st_path, parallel=self._get_num_parallel())

    @staticmethod
    def _reconstruct(kwargs):
        return UserStageSharedFileSystem(**kwargs)

    def __reduce__(self):
        return UserStageSharedFileSystem._reconstruct, (
            dict(
                stage_path=self.stage_path,
            ),
        )
