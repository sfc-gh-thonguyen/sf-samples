import ray.train._internal.storage

# Ray Train V2 uses a different StorageContext class
try:
    import ray.train.v2._internal.execution.storage as v2_storage

    _HAS_V2_STORAGE = True
except ImportError:
    _HAS_V2_STORAGE = False


def _check_validation_file(self):
    """
    Note: This is a patch to override shared storage requirement for Ray train API.
    Ray 2.52 has TWO StorageContext classes:
      - ray/train/_internal/storage.py (legacy)
      - ray/train/v2/_internal/execution/storage.py (v2, default in Ray 2.52)
    When upgrading Ray version, make sure this is still valid.
    """
    pass


def _create_validation_file(self):
    """
    Note: This is a patch to skip creating the validation file for shared storage.
    """
    pass


def bypass_ray_storage_check():
    """
    _check_validation_file and _create_validation_file calls are used by Ray to
    verify shared storage is enabled and accessible by all nodes.
    Skip this validation to use Ray trainer without the shared storage requirement.

    This allows multi-node training to work without requiring shared storage (S3, NFS, etc),
    by bypassing Ray's validation that checks if all nodes can access the storage path.

    Note: Ray 2.52+ uses Ray Train V2 by default, which has a different StorageContext.
    """
    # Patch legacy StorageContext (for backward compatibility)
    ray.train._internal.storage.StorageContext._check_validation_file = (
        _check_validation_file
    )
    ray.train._internal.storage.StorageContext._create_validation_file = (
        _create_validation_file
    )

    # Patch V2 StorageContext (default in Ray 2.52+)
    if _HAS_V2_STORAGE:
        v2_storage.StorageContext._check_validation_file = _check_validation_file
        v2_storage.StorageContext._create_validation_file = _create_validation_file
