import subprocess
import os
import time
import logging
import shutil
from snowflake.runtime.utils import env_utils

PROMETHEUS_ENV_VAR = "PROMETHEUS_MULTIPROC_DIR"


def get_service_path() -> str:
    root_path = env_utils.get_mlruntimes_path()
    service_path = root_path / "service"
    return service_path.resolve().as_posix()


class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)
        print(self.newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)


def _wait_for_stop(process, stop_event):
    while not stop_event.is_set():
        time.sleep(0.5)

    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
    except Exception as e:
        logging.error(f"Encounter error when terminating the server process: {e}")


def run_mlrs_server(stop_event):
    with cd(get_service_path()):
        process = subprocess.Popen(["python", "-m", "web.dev_local_cli"])
        _wait_for_stop(process, stop_event)


def run_notebook_server(file_path: str, stop_event):
    env = os.environ.copy()
    service_path = env_utils.get_mlruntimes_path() / "service"
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{service_path}{os.pathsep}{existing_pythonpath}"
    # To workaround an but in snowbook
    env["SNOWFLAKE_HOST"] = ""
    process = subprocess.Popen(
        ["python", "-m", "snowbook.web.cli", "-f", file_path],
        cwd=env_utils.get_mlruntimes_path().as_posix(),
        env=env,
    )
    _wait_for_stop(process, stop_event)


def set_up_mlrs_log_directory(path_to_dir):
    if not os.path.exists(path_to_dir):
        os.makedirs(path_to_dir)


def set_up_prometheus_multiprocess_dir(path_to_dir):
    if not os.path.exists(path_to_dir):
        os.makedirs(path_to_dir)
    os.environ[PROMETHEUS_ENV_VAR] = path_to_dir


def clean_up_prometheus_multiprocess_dir(path_to_dir):
    if os.path.exists(path_to_dir):
        shutil.rmtree(path_to_dir)
    os.environ.pop(PROMETHEUS_ENV_VAR, None)
