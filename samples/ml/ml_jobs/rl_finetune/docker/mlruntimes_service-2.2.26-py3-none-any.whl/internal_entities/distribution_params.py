from dataclasses import dataclass


@dataclass
class DistributionParams:
    num_nodes: int = 1
    cpus_per_node: int = -1  # To deprecate after snowml pushdown
    gpus_per_node: int = -1  # To deprecate after snowml pushdown
    num_workers: int = 1
    cpus_per_worker: int = 1
    gpus_per_worker: int = 1
    use_gpus: bool = False
