from dataclasses import dataclass
from typing import Optional, List

import pandas as pd


@dataclass
class InternalTunerResults:
    results: pd.DataFrame
    best_result: pd.DataFrame
    best_model_path: str
    shared_storage_stage_path: Optional[str]
    errors: List[str]
