from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, Tuple, List, Union

import numpy as np
from scipy.sparse import csr_matrix
from snowflake.ml.data.data_connector import DataConnector

import xgboost as xgb
import lightgbm as lgb

from internal_entities.distribution_params import DistributionParams
import pandas as pd


class DistributedTrainer(ABC):
    def __init__(self, distribution_params: Optional[DistributionParams]):
        self.distribution_params = distribution_params

    @abstractmethod
    def fit(
        self,
        data_connector: DataConnector,
        input_cols: List[str],
        label_cols: List[str],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[Union[xgb.Booster, lgb.Booster]] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
    ) -> Tuple[Union[lgb.Booster, xgb.Booster], Optional[Dict[str, Any]]]:
        raise NotImplementedError()

    @abstractmethod
    def fit_in_memory(
        self,
        X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[Union[xgb.Booster, lgb.Booster]] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
    ) -> Tuple[Union[lgb.Booster, xgb.Booster], Optional[Dict[str, Any]]]:
        raise NotImplementedError()
