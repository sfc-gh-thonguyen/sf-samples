from functools import cached_property, lru_cache
import time

from ray.data import Datasource, ReadTask, Dataset, DataIterator
from ray.data.block import BlockMetadata, BlockMetadataWithSchema

from entities.sharded_data_ingestor import ShardedDataIngestor
from snowflake import snowpark
from snowflake.connector.result_batch import ResultBatch
from snowflake.ml._internal.utils.identifier import get_inferred_names, _is_quoted
from snowflake.ml.data.data_ingestor import DataIngestor
from snowflake.ml.data.data_source import (
    DataSource as SnowflakeDataSource,
    DataFrameInfo,
    DatasetInfo,
)
from snowflake.ml.data.ingestor_utils import (
    get_dataframe_result_batches,
    get_dataset_files,
    get_dataset_filesystem,
)
from typing import List, Optional, Iterable, Iterator, Dict, Any, TYPE_CHECKING
import numpy as np
import numpy.typing as npt
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_info,
    configure_ray_data_logging,
)
from snowflake.runtime.utils.data_type_utils import convert_doubles_to_float32_arrow

import ray
import ray.widgets.util
from lightgbm_ray import RayDMatrix as LightGBMRayDMatrix
from snowflake.runtime.utils.session_utils import get_session
from snowflake.runtime.utils.ray_utils import RuntimeRayTaskError


if TYPE_CHECKING:
    import pandas as pd

logger = get_logger()
NUM_RAY_WORKERS = 1

# Monkey patch in_notebook to always return True
# We need to monkey patch this because Ray Log will behave differently if it thinks it's running in a notebook
# We patch this one here because so far only ray dataset read this value.
ray.widgets.util.in_notebook = lambda: True

# Configure Ray Data logging at module level (applies when this module is imported)
configure_ray_data_logging()

# Get context reference for later use (e.g., read_op_min_num_blocks)
context = ray.data.DataContext.get_current()


class SnowflakeResultBatchReadError(RuntimeRayTaskError):
    """This is annotator exception calss that indicate error
    when reading a Ray read task fails reading a result batch.

    This is used for indicating read error when reading a result batch.
    The original error throw by snowpark is not pickable,
    which cause a different error to be thrown and caused confusion.
    """

    pass


@ray.remote(num_cpus=0)
class BatchRefreshActor:
    """Centralized actor for managing presigned URL refresh across all Ray workers.

    Snowflake presigned URLs expire after 6 hours, but Ray read tasks may not execute
    for hours after creation. Snowflake generates presigned URLs which are embedded into
    Ray ReadTasks. Workers generating new presigned URLs would be wasteful as new URLs
    are not shared across tasks.

    BatchRefreshActor handles refreshing presigned URLs and update workers with new URLs
    in cache. Actor will refresh and store new URLs, which will be used by workers to after
    calling Actor to fetch. Actor is also single-threaded, preventing simultaneous refresh.

    If worker's URLs ref is the same as cached, which mean cached URLs also expired. Need to refresh.
    Otherwise, the worker can download using the cached URLs. BatchRefreshActor is only returning
    objectRef to workers, and if worker's ref is the same as cached, it means cached URLs also expired.
    Need to refresh.

    Example after worker failed to download data due to expired URLs:
        >>> # Actor is created once and reused across all workers
        >>> actor = BatchRefreshActor.options(name="global_batch_refresh_actor").remote()
        >>> # Fetching new URLs from RefreshActor. Actor will decide if we need new URLs or can use cached URLs.
        >>> refreshed_ref = ray.get(actor.get_refreshed_batch_ref.remote(
        ...     data_source=data_source,
        ...     attempt=0,
        ...     last_ref=current_batches_ref
        ... ))
        >>> # Worker get the new URLs and use it to download again.
        >>> fresh_batches = ray.get(refreshed_ref)
    """

    def __init__(self):
        self._batch_ref_cache: Dict[str, ray.ObjectRef] = {}

    def contains_query(self, query_id: str) -> bool:
        """Check if the actor has cached batches for the given query_id."""
        return query_id in self._batch_ref_cache

    def get_refreshed_batch_ref(
        self,
        data_source: DataFrameInfo,
        expected_count: int,
        last_ref_id: Optional[
            str
        ] = None,  # use to check if cached URLs was used before.
    ) -> Optional[ray.ObjectRef]:
        """
        Get refreshed batch reference with two-tier strategy:
        return stored batches if available
        If stored batches ref is the same as last_ref, we will re-generate new batches.

        Returns Ray ObjectRef pointing to the refreshed batches if successful.
        Returns None if refresh failed.
        """
        if not data_source or not data_source.query_id:
            return None

        query_id = data_source.query_id

        # If cache is available, try to use cached BatchResult
        # If worker's URLs ref is the same as cached, which mean cached URLs also expired. Need to refresh.
        if (
            query_id in self._batch_ref_cache
            and last_ref_id != self._batch_ref_cache[query_id].hex()
        ):
            return self._batch_ref_cache[query_id]

        # Regenerate new presigned URLs
        try:
            print_user_log_info(
                logger,
                f"Attempting to refresh pre-signed URLs for query_id: {query_id}",
            )
            refresh_batches = get_dataframe_result_batches(get_session(), data_source)

            if len(refresh_batches) != expected_count:
                logger.error(
                    f"Refreshed batch count mismatch. Expected: {expected_count}, but got: {len(refresh_batches)}"
                )
                return None

            # Store the refreshed batches in object store
            batches_ref = ray.put(refresh_batches)
            self._batch_ref_cache[query_id] = batches_ref

            print_user_log_info(logger, "Successfully refreshed expired URLs.")
            return batches_ref

        except Exception as e:
            logger.error(f"Failed to refresh batches: {str(e)}")
            return None

    def __ray_shutdown__(self):
        """
        Ray-specific shutdown hook called during graceful actor termination.

        This ensures cache is cleaned up when actor is shut down gracefully.
        Note: This is NOT called on actor crash or forced termination.
        """
        if self._batch_ref_cache:
            self._batch_ref_cache.clear()


GLOBAL_BATCH_REFRESH_ACTOR_NAME = "global_batch_refresh_actor"


def query_is_refreshed(actor_name: str, query_id: str) -> bool:
    """Check if a named actor exists without creating it"""
    try:
        actor = ray.get_actor(actor_name)
        return ray.get(
            actor.contains_query.remote(query_id)
        )  # Get the actual boolean result
    except ValueError:
        return False


# global instance of BatchRefreshActor to keep alive within current context
_global_refresh_actor_instance = None


def get_or_create_refresh_actor():
    """
    Get or create the global refresh actor using Ray's built-in singleton pattern.

    This is thread-safe: if multiple workers call this simultaneously, Ray ensures
    only one actor is created and all workers get the same actor handle.

    The actor will automatically restart on failure, and method calls from Worker B
    will block if Worker A is still initializing the actor.
    """
    global _global_refresh_actor_instance
    if _global_refresh_actor_instance is not None:
        return _global_refresh_actor_instance

    try:
        # Use get_if_exists=True to handle race conditions automatically
        # If actor exists, return existing handle; otherwise create new one
        actor = BatchRefreshActor.options(  # type: ignore[attr-defined]
            name=GLOBAL_BATCH_REFRESH_ACTOR_NAME,
            get_if_exists=True,
            max_restarts=3,
            max_task_retries=3,
        ).remote()
        _global_refresh_actor_instance = actor
        return actor
    except Exception as e:
        logger.error(f"Failed to get or create global batch refresh actor: {str(e)}")
        return None


class ResultSetDataSource(Datasource):
    def __init__(
        self, batches: List[ResultBatch], data_source: Optional[DataFrameInfo] = None
    ) -> None:
        self.batches = batches
        self.data_source = data_source
        # Assuming each batch is small and downloading first batch to get schema.
        self.first_batch = (
            convert_doubles_to_float32_arrow(
                batches[0].to_arrow(get_session().connection)
            )
            if batches
            else None
        )

    def estimate_inmemory_data_size(self) -> Optional[int]:
        """Return an estimate of the in-memory data size, or None if unknown.

        Note that the in-memory data size may be larger than the on-disk data size.
        """
        return None

    def _get_first_last_element(self, worker_idx, element_per_worker, remainder):
        """
        This function calculate first and last batch index for each worker based on
        the number batches and the number of workers.

        The goal is to make the batch distribution between workers as even as possible.

        For example, if we have 10 batches and 3 workers, the distribution will be:

        element_per_worker = 10 // 3 = 3
        reminder = 10 % 3 = 1

        Worker 0:
            first element: 0 * 3 + min(0, 1) = 0
            last element: 0 + 3 + (1 if 0 < 1 else 0) = 4
            total elements: 4
        Worker 1:
            first element: 1 * 3 + min(1, 1) = 4
            last element: 4 + 3 + (1 if 1 < 1 else 0) = 7
            total elements: 3
        Worker 2:
            first element: 2 * 3 + min(2, 1) = 7
            last element: 7 + 3 + (1 if 2 < 1 else 0) = 10
            total elements: 3
        """
        first_element = worker_idx * element_per_worker + min(worker_idx, remainder)
        last_element = (
            first_element + element_per_worker + (1 if worker_idx < remainder else 0)
        )
        return first_element, last_element

    def _get_read_task(self, worker_idx, element_per_worker, remainder):
        """
        This function creates a read task for each worker based on the batch distribution.
        """
        first_element, last_element = self._get_first_last_element(
            worker_idx, element_per_worker, remainder
        )
        current_batches = self.batches[first_element:last_element]
        num_rows = 0
        size_bytes = 0
        for batch in current_batches:
            num_rows += batch.rowcount
            if batch.compressed_size is not None:
                size_bytes += batch.compressed_size

        base_metadata = BlockMetadata(
            num_rows=num_rows,
            size_bytes=size_bytes,
            input_files=None,
            exec_stats=None,
        )
        metadata = BlockMetadataWithSchema(
            metadata=base_metadata,
            schema=self.first_batch.schema if self.first_batch is not None else None,
        )

        # Capture what's needed for the closure
        cached_first_batch = self.first_batch if worker_idx == 0 else None
        data_source = self.data_source
        query_id = data_source.query_id if data_source else None
        total_batch_count = len(self.batches)
        max_retries = 3

        def _is_url_expired_error(error: Exception) -> bool:
            """Check if the error is related to URL expiration"""
            error_msg = str(error).lower()
            url_expired_indicators = [
                "expired",
                "forbidden",
                "credential",
                "presigned",
                "403",
                "timeout",
            ]
            return any(indicator in error_msg for indicator in url_expired_indicators)

        def _retrieve_new_batches_ref(
            data_source: DataFrameInfo,
            total_batch_count: int,
            last_ref: Optional[ray.ObjectRef] = None,
        ) -> ray.ObjectRef:
            """
            Retrieve refreshed batches from the refresh actor.

            Returns:
                Ray ObjectRef pointing to the refreshed batches

            Raises:
                RuntimeError: If refresh actor unavailable or refresh fails
            """
            refresh_actor = get_or_create_refresh_actor()
            if refresh_actor is None:
                raise RuntimeError("Failed to get refresh actor")

            batches_ref = ray.get(
                refresh_actor.get_refreshed_batch_ref.remote(
                    data_source,
                    total_batch_count,
                    last_ref.hex()
                    if last_ref is not None
                    else None,  # pass hex string for ID, Ray actor dereference objectRef automatically.
                )
            )
            if batches_ref is None:
                raise RuntimeError("Failed to retrieve refreshed batches")

            return batches_ref

        def _read_fn():
            nonlocal current_batches

            # Stores URLs objectRef if retrieved from Actor. Uses to force refresh if needed.
            batches_ref = None
            # If batch refresh actor is active, check actor's content for latest batch results.
            if (
                query_id is not None
                and data_source is not None
                and query_is_refreshed(GLOBAL_BATCH_REFRESH_ACTOR_NAME, query_id)
            ):
                try:
                    batches_ref = _retrieve_new_batches_ref(
                        data_source,
                        total_batch_count,
                    )

                    all_batches = ray.get(batches_ref)
                    current_batches = all_batches[first_element:last_element]
                except RuntimeError as e:
                    # Log but continue with existing batches
                    logger.warning(f"Failed to retrieve refreshed batches: {e}")

            logger.info(
                f"Loading {len(current_batches)} batches with worker {worker_idx}"
            )
            for batch_index in range(len(current_batches)):
                for attempt in range(max_retries):
                    try:
                        if batch_index == 0 and worker_idx == 0:
                            # Return cached batch
                            yield cached_first_batch
                            break
                        else:
                            batch = current_batches[batch_index]
                            yield convert_doubles_to_float32_arrow(
                                batch.to_arrow(get_session().connection)
                            )
                            break
                    except Exception as e:
                        if not _is_url_expired_error(e) or not data_source:
                            raise e
                        if isinstance(data_source, DataFrameInfo) and not query_id:
                            raise RuntimeError(
                                "Unable to refresh batches: invalid query_id"
                            )

                        # Last attempt - no more retries left
                        if attempt == max_retries - 1:
                            logger.error(
                                f"Failed to download batch {batch_index} after {max_retries} attempts"
                            )
                            raise RuntimeError(
                                f"Failed to download batch after {max_retries} attempts with expired URLs"
                            )

                        batches_ref = _retrieve_new_batches_ref(
                            data_source,
                            total_batch_count,
                            batches_ref,
                        )

                        all_batches = ray.get(batches_ref)
                        current_batches = all_batches[first_element:last_element]
                        del all_batches

        return ReadTask(_read_fn, metadata)

    def get_read_tasks(
        self, parallelism: int, per_task_row_limit: Optional[int] = None
    ) -> List["ReadTask"]:
        """Execute the read and return read tasks.

        Args:
            parallelism: The requested read parallelism. The number of read
                tasks should equal to this value if possible.

        Returns:
            A list of read tasks that can be executed to read blocks from the
            datasource in parallel.
        """
        if not self.batches:
            return []

        parallelism = min(parallelism, len(self.batches))

        element_per_worker = len(self.batches) // parallelism
        remainder = len(self.batches) % parallelism

        result = [
            self._get_read_task(idx, element_per_worker, remainder)
            for idx in range(parallelism)
        ]

        total_estimated_rows = sum(
            task.metadata.num_rows for task in result if task.metadata.num_rows
        )

        from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics

        MLRSPrometheusMetrics.DATA_INGESTER_TABLE_ROWS_READ.value.inc(
            total_estimated_rows
        )

        return result


def read_datasource(
    datasource: ray.data.Datasource,
    read_data_source_options: Optional[Dict[str, Any]] = None,
) -> ray.data.Dataset:
    """
    Read a Ray datasource with optional read_data_source_options.

    Args:
       datasource: A Ray `Datasource` to read from.
       read_data_source_options: Optional dictionary of read options passed down to ray.data.read_datasource

    Returns:
       A Ray `Dataset` read from the given datasource.
    """
    concurrency = None
    try:
        import os

        concurrency_env = os.getenv("RAY_DATA_READ_CONCURRENCY")
        concurrency = int(concurrency_env) if concurrency_env is not None else None
    except Exception:
        logger.debug(
            "Invalid RAY_DATA_READ_CONCURRENCY value, using default concurrency"
        )

    if concurrency:
        print_user_log_info(
            logger, f"Reading datasource with concurrency: {concurrency}"
        )
        if read_data_source_options:
            if concurrency is not None:
                read_data_source_options["concurrency"] = concurrency
            return ray.data.read_datasource(datasource, **read_data_source_options)
        return ray.data.read_datasource(datasource, concurrency=concurrency)
    else:
        if read_data_source_options:
            return ray.data.read_datasource(datasource, **read_data_source_options)
        return ray.data.read_datasource(datasource)


def _load_data(
    session: snowpark.Session,
    data_source: SnowflakeDataSource,
    read_data_source_options: Optional[Dict[str, Any]] = None,
) -> Dataset:
    read_data_source_options = (
        read_data_source_options.copy() if read_data_source_options is not None else {}
    )
    ray_ds: Dataset
    from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics

    if isinstance(data_source, DataFrameInfo):
        start_time = time.perf_counter()
        info_str = "Loading data from Snowpark Dataframe"
        if data_source.query_id is not None:
            info_str += f" from query id {data_source.query_id}"

        print_user_log_info(logger, info_str)
        batches = get_dataframe_result_batches(session, data_source)

        cds = ResultSetDataSource(batches, data_source)

        if "override_num_blocks" not in read_data_source_options:
            # Prevent too many blocks from being created.
            read_data_source_options["override_num_blocks"] = min(
                context.read_op_min_num_blocks, len(batches)
            )

        MLRSPrometheusMetrics.DATA_INGESTER_READ_JOB.value.labels(
            data_type="table", status="attempt"
        ).inc()
        ray_ds = read_datasource(cds, read_data_source_options=read_data_source_options)
        MLRSPrometheusMetrics.DATA_INGESTER_READ_JOB.value.labels(
            data_type="table", status="success"
        ).inc()
        end_time = time.perf_counter()
        MLRSPrometheusMetrics.DATA_INGESTER_READ_DURATION.value.labels(
            data_type="table"
        ).observe(end_time - start_time)
        print_user_log_info(logger, "Loaded data into ray dataset.")

    elif isinstance(data_source, DatasetInfo):
        # TODO (SNANDAMURI): Column name renaming for Dataset based DataIngester is still a problem.
        # That still need to be fixed.
        start_time = time.perf_counter()
        print_user_log_info(logger, "Loading data from Snowflake Dataset.")
        fs = get_dataset_filesystem(session, data_source)
        # MLRSPrometheusMetrics.DATA_INGESTER_READ_JOB.value.labels(
        #     data_type="dataset", status="attempt"
        # ).inc()
        ray_ds = ray.data.read_parquet(
            get_dataset_files(session, data_source, filesystem=fs),
            filesystem=fs,
        )
        end_time = time.perf_counter()
        # MLRSPrometheusMetrics.DATA_INGESTER_READ_JOB.value.labels(
        #     data_type="dataset", status="success"
        # ).inc()
        # MLRSPrometheusMetrics.DATA_INGESTER_READ_DURATION.value.labels(
        #     data_type="dataset"
        # ).observe(end_time - start_time)
    else:
        raise RuntimeError(f"Unsupported source type: {type(data_source)}")

    # The columns need to be updated using `get_inferred_name`
    # Default batch_format for map_batches is Dict[str, np.ndarray]
    # Check if columns need to be renamed
    renamed_cols = {}

    # Note: Querying metadata from ray_ds before executing the dataset would result in retuning
    # information from metadata of ReadTask which may not always be accurate.
    for column_name in ray_ds.columns():
        # If column name is different, add to key
        snowflake_col_name = get_inferred_names(column_name)
        if column_name != snowflake_col_name:
            renamed_cols[column_name] = snowflake_col_name

    if len(renamed_cols) > 0:
        ray_ds = ray_ds.map_batches(
            RenameHelper(new_cols=renamed_cols), concurrency=NUM_RAY_WORKERS
        )

    return ray_ds


class RenameHelper:
    def __init__(self, new_cols) -> None:
        self.new_cols = new_cols

    def __call__(self, batch):
        for k in self.new_cols:
            batch[self.new_cols[k]] = batch.pop(k)
        return batch


class RayDataIngester(ShardedDataIngestor):
    def __init__(
        self,
        data_sources: Optional[List[SnowflakeDataSource]] = None,
        ray_ds: Optional[ray.data.Dataset] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize a RayDataIngester.
        Ingests data by either creating a Ray Dataset from a single Snowflake data source, or by accepting an existing
        Ray Dataset directly.

        Args:
            data_sources: Optional list containing a single Snowflake data source to load from.
                Must contain exactly one item if provided. Mutually exclusive with `ray_ds`.
            ray_ds: Optional existing Ray Dataset to wrap. Mutually exclusive with `data_sources`.
            **kwargs: Additional configuration options:
                - read_data_source_options (dict, optional): Dictionary of options passed to
                  `ray.data.read_datasource()`. Can include options like 'concurrency',
                  'override_num_blocks', etc. Defaults to None (empty dict).
                - target_inmemory_buffer_size (int, optional): Approximate buffer size in
                  bytes for in-memory buffering during `to_batches()` operations. Used to
                  optimize memory usage when iterating over batches. Defaults to 1_000_000.

        Raises:
            ValueError: If both `data_sources` and `ray_ds` are provided, or if `data_sources`
                contains more than one item.
        """
        # Initialize Ingester with dataset or data sources.
        data_source = None
        # If ray_ds is not provided, we will load data from data_sources.
        if ray_ds is None:
            sources: List[SnowflakeDataSource] = data_sources or []
            if len(sources or []) != 1:
                raise ValueError(
                    f"Currently only single data sources are supported (got {len(sources or [])})"
                )
            data_source = sources[0]

            # Start creating result batches immediately when data connector is initialized.
            session = get_session()
            if isinstance(data_source, DataFrameInfo) and data_source.query_id is None:
                data_source = DataFrameInfo(
                    sql=data_source.sql,
                    query_id=session.sql(data_source.sql).collect_nowait().query_id,
                )

        # Read_data_source_options is for loading data from SnowflakeDatasource
        # Will not be used if ray_ds is provided directly.
        self._read_data_source_options = kwargs.get("read_data_source_options", None)
        self._target_inmemory_buffer_size = int(
            kwargs.get("target_inmemory_buffer_size", 1e6)
        )  # Buffer size for to_batches optimizations.

        self._data_source = data_source
        self._splits: List[DataIterator] = []
        self._ray_ds = ray_ds

    @property
    def ray_ds(self) -> Dataset:
        if not self._ray_ds:
            session = get_session()
            self._ray_ds = _load_data(
                session, self._data_source, self._read_data_source_options
            )

        return self._ray_ds

    def _iter_batches(
        self, batch_size: int, *args: Any, **kwargs: Any
    ) -> Iterable[Dict[str, np.ndarray]]:
        return self.ray_ds.iter_batches(batch_size=batch_size, *args, **kwargs)

    def to_ray_dataset(self) -> Dataset:
        """
        Returns the Ray Dataset object.
        """
        return self.ray_ds

    @classmethod
    def from_sources(
        cls,
        session: snowpark.Session,
        sources: List[SnowflakeDataSource],
        **kwargs: Any,
    ) -> "RayDataIngester":
        if cls is RayDataIteratorIngester:
            raise TypeError(
                "RayDataIteratorIngester.from_sources() is not supported. "
                "Use RayDataIngester.from_sources() to load from SnowflakeDataSource, "
                "then call .shard() and .get_shard_by_id() to create iterator-based shards."
            )
        return cls(data_sources=sources, **kwargs)

    @classmethod
    def from_ray_dataset(
        cls,
        ray_ds: ray.data.Dataset,
        **kwargs: Any,
    ) -> "RayDataIngester":
        return cls(ray_ds=ray_ds, **kwargs)

    @property
    def data_sources(self) -> List[SnowflakeDataSource]:
        return [self._data_source]

    def to_batches(
        self,
        batch_size: int,
        shuffle: bool = True,
        drop_last_batch: bool = True,
    ) -> Iterator[Dict[str, npt.NDArray[Any]]]:
        from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics

        max_buffer = int(self._target_inmemory_buffer_size)
        in_memory_buffer_size = int(max_buffer // batch_size) * batch_size
        # Set local shuffle buffer size to match the default in pytorch.
        # In the future, this could be updated to be a parameter users pass through instead of a boolean.
        # Pytorch documentation: https://pytorch.org/data/main/generated/torchdata.datapipes.iter.Shuffler.html
        local_shuffle_buffer_size = max_buffer if shuffle else None

        if local_shuffle_buffer_size is not None or batch_size > max_buffer:
            # Ray will provide a local buffer to shuffle data, and we don't need to implement one ourselves
            MLRSPrometheusMetrics.DATA_INGESTER_TOBATCH.value.labels(
                batch_type="default"
            ).inc()
            yield from self._iter_batches(
                batch_size=batch_size,
                local_shuffle_buffer_size=local_shuffle_buffer_size,
                drop_last=drop_last_batch,
            )
        else:
            MLRSPrometheusMetrics.DATA_INGESTER_TOBATCH.value.labels(
                batch_type="buffer"
            ).inc()
            for buffer_batch in self._iter_batches(batch_size=in_memory_buffer_size):
                # Safety check for empty buffer
                if buffer_batch is None:
                    continue

                buffer_batch_size = len(next(iter(buffer_batch.values())))
                # Only last buffer have smaller size than in_memory_buffer
                is_last_buffer = buffer_batch_size != in_memory_buffer_size

                for start_idx in range(0, buffer_batch_size, batch_size):
                    end_idx = start_idx + batch_size

                    # drop last batch if needed
                    if (
                        drop_last_batch
                        and is_last_buffer
                        and end_idx > buffer_batch_size
                    ):
                        return

                    mini_batch = {
                        k: arr[start_idx:end_idx] for k, arr in buffer_batch.items()
                    }
                    yield mini_batch

    def to_pandas(self, limit: Optional[int] = None) -> "pd.DataFrame":
        ray_ds = self.ray_ds
        if limit is not None:
            ray_ds = ray_ds.limit(limit)

        print_user_log_info(logger, "Loading data into a pandas dataframe.")
        pd_df = ray_ds.to_pandas()

        def is_quoted(col_name):
            """Check if the column name is quoted."""
            try:
                return _is_quoted(col_name)
            except ValueError:
                return False

        renamed_cols = [
            get_inferred_names(column_name)
            if not is_quoted(column_name)
            else column_name
            for column_name in pd_df.columns
        ]
        pd_df.columns = renamed_cols
        return pd_df

    def convert_to_lightgbm_d_matrix(
        self,
        input_cols: List[str],
        label_col: str,
        sample_weight_col: Optional[str],
    ) -> LightGBMRayDMatrix:
        return LightGBMRayDMatrix(
            self.ray_ds,
            label=label_col,
            columns=input_cols + [label_col],
            weight=sample_weight_col,
        )

    @lru_cache(maxsize=None)
    def get_num_classes(self, label_col: str) -> int:
        return len(self.ray_ds.unique(label_col))

    def shard(self, num_shards: int, equal: bool) -> None:
        self._splits = self.ray_ds.streaming_split(n=num_shards, equal=equal)

    def get_shard_by_id(self, index: int) -> DataIngestor:
        if index < 0 or len(self._splits) <= index:
            raise IndexError(
                "Index should be between zero and number of shards. Make sure that `shard` has already been called on"
                "this ingester."
            )

        return RayDataIteratorIngester(
            data_sources=[self._splits[index]],
            target_inmemory_buffer_size=self._target_inmemory_buffer_size,
        )

    def __del__(self):
        """Cleanup on garbage collection - Remove all refs"""
        self._data_source = None
        self._ray_ds = None
        self._splits = []


class RayDataIteratorIngester(RayDataIngester):
    def __init__(
        self,
        data_sources: List[DataIterator],
        target_inmemory_buffer_size: int = int(1e6),
    ) -> None:
        """Constructs a RayDataIngester using Ray DataIterator objects.

        Args:
            data_sources: List containing exactly one DataIterator object.
            target_inmemory_buffer_size: Buffer size for to_batches operations.
                Defaults to 1_000_000 bytes.

        Note: This class does not support read_data_source_options since DataIterators
        represent already-loaded data that doesn't require ray.data.read_datasource().
        """
        self._splits: List[DataIterator] = []
        self._target_inmemory_buffer_size = target_inmemory_buffer_size
        if len(data_sources) != 1:
            raise ValueError(
                f"Currently only single data sources are supported (got {len(data_sources)})"
            )
        self._data_source: DataIterator = data_sources[0]

    @cached_property
    def ray_ds(self) -> Dataset:
        return self._data_source.materialize()

    def _iter_batches(
        self, batch_size: int, *args: Any, **kwargs: Any
    ) -> Iterable[Dict[str, np.ndarray]]:
        return self._data_source.iter_batches(batch_size=batch_size, *args, **kwargs)

    def __del__(self):
        """Cleanup on garbage collection - Remove all refs."""
        try:
            self._data_source = None
            self._splits = []
            # Clean up @cached_property
            if hasattr(self, "__dict__") and "ray_ds" in self.__dict__:
                del self.__dict__["ray_ds"]
        except Exception:
            pass
