from ray.train.xgboost import XGBoostTrainer
from functools import partial
from typing import Any, Dict, Optional

import ray.train
from ray.train import Checkpoint
from ray.train.constants import _DEPRECATED_VALUE
from ray.train.trainer import GenDataset
from ray.train.xgboost import RayTrainReportCallback
from ray.train.xgboost.xgboost_trainer import _xgboost_train_fn_per_worker
from ray_train_bypass_shared_storage_check.override_storage_validation import (
    bypass_ray_storage_check,
)


def distributed_xgboost_train_fn_per_worker(
    config: dict,
    label_column: str,
    num_boost_round: int,
    dataset_keys: set,
    xgboost_train_kwargs: dict,
):
    bypass_ray_storage_check()
    _xgboost_train_fn_per_worker(
        config, label_column, num_boost_round, dataset_keys, xgboost_train_kwargs
    )


class DistributedXGBoostTrainer(XGBoostTrainer):
    """
    Note : This code is a forked from Ray 2.36.1 xgb trainer -
    https://github.com/ray-project/ray/blob/releases/2.36.1/python/ray/train/xgboost/xgboost_trainer.py
    Adds a call to bypass_ray_storage_check to skip shared storage validation.
    """

    def __init__(
        self,
        *,
        datasets: Dict[str, GenDataset],
        label_column: str,
        params: Dict[str, Any],
        dmatrix_params: Optional[Dict[str, Dict[str, Any]]] = _DEPRECATED_VALUE,
        num_boost_round: int = 10,
        scaling_config: Optional[ray.train.ScalingConfig] = None,
        run_config: Optional[ray.train.RunConfig] = None,
        dataset_config: Optional[ray.train.DataConfig] = None,
        resume_from_checkpoint: Optional[Checkpoint] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **train_kwargs,
    ):
        # This is required for distributed XGB without shared storage
        bypass_ray_storage_check()

        if dmatrix_params != _DEPRECATED_VALUE:
            raise DeprecationWarning(
                "`dmatrix_params` is deprecated, since XGBoostTrainer no longer "
                "depends on the `xgboost_ray.RayDMatrix` utility. "
                "You can remove this argument and use `dataset_config` instead "
                "to customize Ray Dataset ingestion."
            )

        # Initialize a default Ray Train metrics/checkpoint reporting callback if needed
        callbacks = train_kwargs.get("callbacks", [])
        user_supplied_callback = any(
            isinstance(callback, RayTrainReportCallback) for callback in callbacks
        )
        callback_kwargs = {}
        if run_config:
            checkpoint_frequency = run_config.checkpoint_config.checkpoint_frequency
            checkpoint_at_end = run_config.checkpoint_config.checkpoint_at_end

            callback_kwargs["frequency"] = checkpoint_frequency
            # Default `checkpoint_at_end=True` unless the user explicitly sets it.
            callback_kwargs["checkpoint_at_end"] = (
                checkpoint_at_end if checkpoint_at_end is not None else True
            )

        if not user_supplied_callback:
            callbacks.append(RayTrainReportCallback(**callback_kwargs))
        train_kwargs["callbacks"] = callbacks

        train_fn_per_worker = partial(
            distributed_xgboost_train_fn_per_worker,
            label_column=label_column,
            num_boost_round=num_boost_round,
            dataset_keys=set(datasets),
            xgboost_train_kwargs=train_kwargs,
        )

        super(XGBoostTrainer, self).__init__(
            train_loop_per_worker=train_fn_per_worker,
            train_loop_config=params,
            scaling_config=scaling_config,
            run_config=run_config,
            datasets=datasets,
            dataset_config=dataset_config,
            resume_from_checkpoint=resume_from_checkpoint,
            metadata=metadata,
        )
