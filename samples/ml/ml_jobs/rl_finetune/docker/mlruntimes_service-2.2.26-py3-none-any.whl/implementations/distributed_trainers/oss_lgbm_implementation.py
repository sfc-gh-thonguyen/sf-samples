from typing import Optional, Dict, Any, Tuple, List, Union

import numpy as np
from scipy.sparse import csr_matrix
from snowflake.ml.data.data_connector import DataConnector

import lightgbm as lgb

from events.producer import OSSTrainLGBMCallback
from implementations.distributed_trainers.ray_utils import (
    EVAL_DATASET_KEY,
)
from internal_entities.distributed_trainer import DistributedTrainer
from snowflake.runtime.utils.logger import LogType, get_logger, print_user_log_info
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df
import pandas as pd

logger = get_logger()


def _check_pandas_df_has_required_columns(
    df: pd.DataFrame, required_cols: List[str]
) -> None:
    df_columns = df.columns.tolist()
    if not all(col in df_columns for col in required_cols):
        raise ValueError(
            f"Input dataset does not have all required columns {required_cols}"
        )


class OSSLGBMTrainer(DistributedTrainer):
    def __init__(self) -> None:
        super().__init__(distribution_params=None)

    def fit(
        self,
        data_connector: DataConnector,
        input_cols: List[str],
        label_cols: List[str],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[OSSTrainLGBMCallback]] = None,
    ) -> Tuple[lgb.Booster, Optional[Dict[str, Any]]]:
        dataset = data_connector
        if len(label_cols) > 1:
            raise ValueError(
                "Multilabel output is not supported by the Ray xgboost trainer."
            )

        if sample_weight_col is not None:
            raise ValueError("Sample weights are not supported for this estimator.")

        label_col = label_cols[0]

        print_user_log_info(
            logger,
            "Training LightGBM using CPU single node",
            extra={"log_types": [LogType.SYSTEM]},
        )
        train_df = dataset.to_pandas()
        eval_df = eval_set.to_pandas() if eval_set else None

        required_cols = input_cols + label_cols
        _check_pandas_df_has_required_columns(train_df, required_cols)
        if eval_df is not None:
            _check_pandas_df_has_required_columns(eval_df, required_cols)
        # We need to remove this otherwise a confusing log message that
        # says "parameter n_estimator is not used" will be printed
        num_boost_round = params.get("n_estimators", 100)
        params.pop("n_estimators", None)

        X_train, y_train = train_df[input_cols], train_df[label_col]
        eval_results: Dict[str, Any] = {}
        lgb_callbacks: Any = [lgb.record_evaluation(eval_results)]

        if callbacks:
            lgb_callbacks.extend(callbacks)

        booster = lgb.train(
            params,
            lgb.Dataset(X_train, label=y_train),
            num_boost_round=num_boost_round,
            init_model=init_model,
            valid_sets=[lgb.Dataset(eval_df[input_cols], label=eval_df[label_col])]
            if eval_df is not None
            else None,
            valid_names=[EVAL_DATASET_KEY],
            callbacks=lgb_callbacks,
        )
        return (booster, eval_results if len(eval_results) > 0 else None)

    def fit_in_memory(
        self,
        X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[OSSTrainLGBMCallback]] = None,
    ) -> Tuple[lgb.Booster, Optional[Dict[str, Any]]]:
        if sample_weight_col is not None:
            raise ValueError("Sample weights are not supported for this estimator.")

        logger.info(
            "Training LightGBM using OSS training",
            extra={"log_types": [LogType.SYSTEM]},
        )
        X, y = convert_to_pandas_df(X), convert_to_pandas_df(y)
        eval_df = eval_set.to_pandas() if eval_set else None
        input_cols = X.columns.tolist()
        label_col = y.columns.tolist()[0]
        _check_pandas_df_has_required_columns(
            eval_df, input_cols + [label_col]
        ) if eval_df else None
        num_boost_round = params.get("n_estimators", 100)
        params.pop("n_estimators", None)
        eval_results: Dict[str, Any] = {}
        lgb_callbacks: Any = [lgb.record_evaluation(eval_results)]

        if callbacks:
            lgb_callbacks.extend(callbacks)

        booster = lgb.train(
            params,
            lgb.Dataset(X, label=y),
            num_boost_round=num_boost_round,
            init_model=init_model,
            valid_sets=[lgb.Dataset(eval_df[input_cols], label=eval_df[label_col])]
            if eval_df
            else None,
            callbacks=lgb_callbacks,
        )
        return (booster, eval_results if len(eval_results) > 0 else None)
