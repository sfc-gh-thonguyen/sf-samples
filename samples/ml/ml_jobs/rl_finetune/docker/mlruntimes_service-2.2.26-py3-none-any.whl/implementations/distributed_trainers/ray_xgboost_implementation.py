from typing import Optional, Dict, Any, Tuple, List, Union

import numpy as np
from ray.air.constants import TRAIN_DATASET_KEY
from ray.train.xgboost import RayTrainReportCallback
from scipy.sparse import csr_matrix
from events.producer import RayTrainXGBoostCallback
from snowflake.ml.data.data_connector import DataConnector

import xgboost as xgb

from implementations.distributed_trainers.ray_utils import (
    get_scaling_config_dict,
    convert_data_connector_to_ray_dataset,
    convert_model_to_ray_checkpoint,
    convert_to_ray_train_dataset,
    DEFAULT_LABEL_COL,
    get_ray_scaling_config,
    EVAL_DATASET_KEY,
    prepare_ray_trainer_dataset,
    extract_eval_results,
    get_run_config,
)
from implementations.distributed_trainers.xgboost_trainer import (
    DistributedXGBoostTrainer,
)
from internal_entities.distributed_trainer import DistributedTrainer
from internal_entities.distribution_params import DistributionParams
from snowflake.runtime.utils.logger import LogType, get_logger, print_user_log_info
import pandas as pd

logger = get_logger()


class RayXGBoostTrainer(DistributedTrainer):
    def __init__(self, distribution_params: DistributionParams):
        super().__init__(distribution_params=distribution_params)

    def fit(
        self,
        data_connector: DataConnector,
        input_cols: List[str],
        label_cols: List[str],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        init_model: Optional[xgb.Booster] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[RayTrainXGBoostCallback]] = None,
    ) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
        if sample_weight_col is not None:
            raise ValueError("Sample weights are not supported for this estimator.")

        if len(label_cols) > 1:
            raise ValueError(
                "Multilabel output is not supported by the Ray xgboost trainer."
            )
        label_col = label_cols[0]
        xgb_model = init_model
        dataset = data_connector

        print_user_log_info(
            logger,
            f"Number of nodes active for training: {self.distribution_params.num_nodes} nodes",
        )

        scaling_config = get_ray_scaling_config(
            self.distribution_params.num_workers,
            self.distribution_params.cpus_per_worker,
            self.distribution_params.use_gpus,
            num_alive_nodes=self.distribution_params.num_nodes,
        )
        print_user_log_info(
            logger,
            f"Scaling Config: {get_scaling_config_dict(scaling_config)}",
            extra={"log_types": [LogType.USER, LogType.SYSTEM]},
        )

        print_user_log_info(logger, "Materializing Data ...")
        ray_train_dataset = prepare_ray_trainer_dataset(
            dataset, eval_set, input_cols, label_col
        )
        xgb_model_ckpt = (
            convert_model_to_ray_checkpoint(xgb_model) if xgb_model else None
        )
        train_kwargs: Dict[str, Any] = {}
        train_kwargs["verbose_eval"] = verbose_eval

        num_boost_round = (
            params.get("n_estimators")
            if params.get("n_estimators") is not None
            else 100
        )

        if not isinstance(num_boost_round, int):
            raise TypeError(
                "Unsupported type for `n_estimators`. Please pass an integer value."
            )

        num_boost_round = num_boost_round + (
            xgb_model.num_boosted_rounds() if xgb_model else 0
        )
        # Remove n_estimators from params because RayXGBTrainer takes num_boost_round as first-class parameter
        params.pop("n_estimators", None)

        if callbacks:
            train_kwargs["callbacks"] = callbacks

        logger.info(
            f"Creating DistributedXGBoostTrainer... num_boosting_round: {num_boost_round}",
            extra={"log_types": [LogType.SYSTEM]},
        )
        run_config = get_run_config()
        trainer = DistributedXGBoostTrainer(
            label_column=label_cols[0],
            params=params,
            # Here we are adding the number of boosted rounds to the total number of rounds
            # Ray Trainer num_boost_round is the total number of rounnds of the model
            # but we want to follow xgboost convention where num_boost_round
            # is the number of "additional" boosted rounds
            num_boost_round=num_boost_round,
            scaling_config=scaling_config,
            datasets=ray_train_dataset,
            resume_from_checkpoint=xgb_model_ckpt,
            run_config=run_config,
            **train_kwargs,  # type: ignore
        )

        print_user_log_info(
            logger, "Starting training job...", extra={"log_types": [LogType.SYSTEM]}
        )

        result = trainer.fit()

        print_user_log_info(
            logger, "Training job completed", extra={"log_types": [LogType.SYSTEM]}
        )

        booster = RayTrainReportCallback.get_model(result.checkpoint)
        return booster, extract_eval_results(result.metrics_dataframe)

    def fit_in_memory(
        self,
        X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        init_model: Optional[xgb.Booster] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[RayTrainXGBoostCallback]] = None,
    ) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
        if sample_weight_col is not None:
            raise ValueError("Sample weights are not supported for this estimator.")

        xgb_model = init_model
        print_user_log_info(
            logger,
            f"Number of nodes active for training: {self.distribution_params.num_nodes} nodes",
        )
        ray_trainer_dataset = {}
        ray_ds = convert_to_ray_train_dataset(X, y)
        print_user_log_info(logger, "Converted data to Ray Dataset")

        ray_trainer_dataset[TRAIN_DATASET_KEY] = ray_ds
        if eval_set is not None:
            eval_ds = convert_data_connector_to_ray_dataset(eval_set)
            ray_trainer_dataset[EVAL_DATASET_KEY] = eval_ds

        train_kwargs: Dict[str, Any] = {}
        train_kwargs["verbose_eval"] = verbose_eval

        num_boost_round = params.get("n_estimators", 100)

        if not isinstance(num_boost_round, int):
            raise TypeError(
                "Unsupported type for `n_estimators`. Please pass an integer value."
            )

        num_boost_round = num_boost_round + (
            xgb_model.num_boosted_rounds() if xgb_model else 0
        )
        # Remove n_estimators from params because RayXGBTrainer takes num_boost_round as first-class parameter
        params.pop("n_estimators", None)

        if callbacks:
            train_kwargs["callbacks"] = callbacks

        xgb_model_ckpt = (
            convert_model_to_ray_checkpoint(xgb_model) if xgb_model else None
        )
        ray_scaling_config = get_ray_scaling_config(
            self.distribution_params.num_workers,
            self.distribution_params.cpus_per_worker,
            self.distribution_params.use_gpus,
            num_alive_nodes=self.distribution_params.num_nodes,
        )

        print_user_log_info(
            logger,
            f"Scaling Config: {get_scaling_config_dict(ray_scaling_config)}",
            extra={"log_types": [LogType.USER, LogType.SYSTEM]},
        )

        run_config = get_run_config()
        ray_trainer = DistributedXGBoostTrainer(
            label_column=DEFAULT_LABEL_COL,
            params=params,
            num_boost_round=num_boost_round,
            resume_from_checkpoint=xgb_model_ckpt,
            scaling_config=ray_scaling_config,
            datasets=ray_trainer_dataset,
            run_config=run_config,
            **train_kwargs,
        )

        result = ray_trainer.fit()
        eval_results = extract_eval_results(result.metrics_dataframe)
        return RayTrainReportCallback.get_model(result.checkpoint), eval_results
