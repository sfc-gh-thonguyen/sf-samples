from typing import Optional, Dict, Any, Tuple, List, Union

import numpy as np
from scipy.sparse import csr_matrix
from snowflake.ml.data.data_connector import DataConnector

import xgboost as xgb

from implementations.distributed_trainers.ray_utils import (
    EVAL_DATASET_KEY,
)
from events.producer import OSSTrainXGBoostCallback
from internal_entities.distributed_trainer import DistributedTrainer
from snowflake.runtime.utils.logger import LogType, get_logger, print_user_log_info
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df
import pandas as pd
from ray.air.constants import TRAIN_DATASET_KEY


logger = get_logger()


def _check_pandas_df_has_required_columns(
    df: pd.DataFrame, required_cols: List[str]
) -> None:
    df_columns = df.columns.tolist()
    if not all(col in df_columns for col in required_cols):
        raise ValueError(
            f"Input dataset does not have all required columns {required_cols}"
        )


class OSSXGBoostTrainer(DistributedTrainer):
    def __init__(self) -> None:
        super().__init__(distribution_params=None)

    def fit(
        self,
        data_connector: DataConnector,
        input_cols: List[str],
        label_cols: List[str],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[xgb.Booster] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[OSSTrainXGBoostCallback]] = None,
    ) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
        dataset = data_connector
        xgb_model = init_model
        print_user_log_info(
            logger,
            "Training XGBoost using CPU single node",
            extra={"log_types": [LogType.SYSTEM]},
        )
        train_df = dataset.to_pandas()
        eval_df = eval_set.to_pandas() if eval_set else None
        _check_pandas_df_has_required_columns(train_df, input_cols + label_cols)
        return self._fit_util(
            train_df[input_cols],
            train_df[label_cols],
            eval_df,
            input_cols,
            label_cols,
            params,
            xgb_model,
            verbose_eval,
            callbacks,
        )

    def fit_in_memory(
        self,
        X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
        params: Dict[str, Any],
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[xgb.Booster] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        sample_weight_col: Optional[str] = None,
        callbacks: Optional[List[OSSTrainXGBoostCallback]] = None,
    ) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
        xgb_model = init_model
        logger.info(
            "Training XGBoost using OSS training",
            extra={"log_types": [LogType.SYSTEM]},
        )
        X, y = convert_to_pandas_df(X), convert_to_pandas_df(y)
        eval_df = eval_set.to_pandas() if eval_set else None
        input_cols = X.columns.tolist()
        label_col = y.columns.tolist()[
            0
        ]  # TODO: Consider supporting multi-output in the future
        return self._fit_util(
            X,
            y,
            eval_df,
            input_cols,
            [label_col],
            params,
            xgb_model,
            verbose_eval,
            callbacks,
        )

    def _fit_util(
        self,
        X: pd.DataFrame,
        y: pd.DataFrame,
        eval_df: pd.DataFrame,
        input_cols: List[str],
        label_col: List[str],
        params: Dict[str, Any],
        xgb_model: Optional[xgb.Booster] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        callbacks: Optional[List[Any]] = None,
    ) -> Tuple[xgb.Booster, Optional[Dict[str, Any]]]:
        if eval_df is not None:
            _check_pandas_df_has_required_columns(eval_df, input_cols + label_col)
        eval_results: Dict[str, Any] = {}
        num_boost_round = params.get("n_estimators", 100)
        # Need to remove n_estimators.
        # Otherwise, there will be a confusing log message "parameter n_estimators is not used"
        params.pop("n_estimators", None)
        dtrain = xgb.DMatrix(X, label=y)
        evals = [(dtrain, TRAIN_DATASET_KEY)]
        if eval_df is not None:
            deval = xgb.DMatrix(eval_df[input_cols], label=eval_df[label_col])
            evals.append((deval, EVAL_DATASET_KEY))

        xgb_callbacks = callbacks or []

        booster = xgb.train(
            params,
            dtrain,
            num_boost_round=num_boost_round,
            xgb_model=xgb_model,
            evals=evals,
            evals_result=eval_results,
            verbose_eval=verbose_eval,
            callbacks=xgb_callbacks,
        )
        return (booster, eval_results if len(eval_results) > 0 else None)
