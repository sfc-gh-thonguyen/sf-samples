import pytest
import pandas as pd
import numpy as np
from unittest import mock

from implementations.distributed_trainers.ray_utils import (
    get_ray_scaling_config,
    extract_eval_results,
    train_using_gpu,
)
import xgboost as xgb
from ray.data import from_pandas
from ray.train import ScalingConfig
from ray.train.xgboost import XGBoostTrainer

from web.jobs.common import RAY_PLACEMENT_SPREAD, RAY_PLACEMENT_PACK


def test_train_with_invalid_gpu():
    # If customer calls with using gpu but no gpu available, it will raise ValueError
    with mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_gpu",
        return_value=0,
    ):
        with pytest.raises(ValueError):
            train_using_gpu(user_use_gpu=True)


def test_validate_invalid_n_workers():
    # request workers is more than available GPUs will raise ValueError
    with mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_gpu",
        return_value=0,
    ), mock.patch(
        "web.jobs.train_boosting_model.get_cluster_size", return_value=1
    ), mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_cpu",
        return_value=2,
    ):
        with pytest.raises(ValueError):
            get_ray_scaling_config(
                input_num_workers=2,
                input_num_cpu_per_worker=1,
                use_gpu=True,
                num_alive_nodes=1,
            )


SAMPLE_USABLE_GPUS = 2
SAMPLE_USABLE_CPUS = 8


# Test if our extract_eval_results function can extract the metrics from the metrics_dataframe correctly
def test_extract_metrics_from_ray_trainer():
    df = pd.DataFrame(
        {
            "A": np.random.rand(100),
            "B": np.random.rand(100),
        }
    )

    import ray
    import ray.train
    from ray.train.xgboost import RayTrainReportCallback

    if not ray.is_initialized():
        ray.init()

    # Training function required by Ray Train V2
    def train_fn(config):
        train_ds = ray.train.get_dataset_shard("train")
        eval_ds = ray.train.get_dataset_shard("eval")
        train_df = train_ds.materialize().to_pandas()
        eval_df = eval_ds.materialize().to_pandas()
        dtrain = xgb.DMatrix(train_df.drop(columns=["B"]), label=train_df["B"])
        deval = xgb.DMatrix(eval_df.drop(columns=["B"]), label=eval_df["B"])
        xgb.train(
            config,
            dtrain,
            num_boost_round=10,
            evals=[(dtrain, "train"), (deval, "eval")],
            callbacks=[RayTrainReportCallback()],
        )

    ray_ds = from_pandas(df)
    trainer = XGBoostTrainer(
        train_loop_per_worker=train_fn,
        train_loop_config={
            "objective": "reg:squarederror",
            "eval_metric": ["rmse", "mae"],
        },
        datasets={"train": ray_ds, "eval": ray_ds},
        scaling_config=ScalingConfig(num_workers=1),
    )
    result = trainer.fit()

    eval_result_from_extraction_method = extract_eval_results(result.metrics_dataframe)

    # Verify the structure is correct
    assert "eval" in eval_result_from_extraction_method
    assert "rmse" in eval_result_from_extraction_method["eval"]
    assert "mae" in eval_result_from_extraction_method["eval"]

    # Verify values are lists with at least one value
    assert isinstance(eval_result_from_extraction_method["eval"]["rmse"], list)
    assert isinstance(eval_result_from_extraction_method["eval"]["mae"], list)
    assert len(eval_result_from_extraction_method["eval"]["rmse"]) >= 1
    assert len(eval_result_from_extraction_method["eval"]["mae"]) >= 1

    # Verify values are numeric (valid metrics)
    assert all(
        isinstance(v, (int, float))
        for v in eval_result_from_extraction_method["eval"]["rmse"]
    )
    assert all(
        isinstance(v, (int, float))
        for v in eval_result_from_extraction_method["eval"]["mae"]
    )


@pytest.mark.parametrize(
    "total_cpus, total_gpus, total_alive_nodes, input_num_workers, input_cpu_per_worker, use_gpu, "
    "expected_num_workers, expected_cpu_per_worker, expected_gpu_per_worker, expected_strategy",
    [
        # CPU nodes
        (112, 0, 4, -1, -1, False, 28, 3, 0, RAY_PLACEMENT_SPREAD),
        (112, 0, 4, 10, -1, False, 10, 8, 0, RAY_PLACEMENT_SPREAD),
        (112, 0, 4, -1, 7, False, 12, 7, 0, RAY_PLACEMENT_SPREAD),
        # 2 or 3 CPUs per node
        (8, 0, 4, -1, -1, False, 4, 1, 0, RAY_PLACEMENT_SPREAD),
        (9, 0, 3, -1, -1, False, 3, 2, 0, RAY_PLACEMENT_SPREAD),
        (6, 0, 3, -1, -1, False, 3, 1, 0, RAY_PLACEMENT_SPREAD),
        (6, 0, 1, -1, -1, False, 1, 3, 0, RAY_PLACEMENT_PACK),
        # 1 CPU per node
        (4, 0, 4, -1, -1, False, 4, 0.5, 0, RAY_PLACEMENT_SPREAD),
        (1, 0, 1, -1, -1, False, 1, 0.5, 0, RAY_PLACEMENT_PACK),
        (1, 0, 1, 1, -1, False, 1, 0.5, 0, RAY_PLACEMENT_PACK),
        (1, 0, 1, -1, 1, False, 1, 1, 0, RAY_PLACEMENT_PACK),
        (2, 0, 2, -1, 1, False, 1, 1, 0, RAY_PLACEMENT_SPREAD),
        (2, 0, 1, -1, -1, False, 1, 1, 0, RAY_PLACEMENT_PACK),
        (6, 0, 3, 1, -1, False, 1, 1, 0, RAY_PLACEMENT_SPREAD),
        (6, 0, 3, 2, -1, False, 2, 1, 0, RAY_PLACEMENT_SPREAD),
        # GPU nodes
        (176, 16, 4, -1, -1, True, 16, 4, 1, RAY_PLACEMENT_SPREAD),
        (176, 16, 4, 10, -1, True, 10, 7, 1, RAY_PLACEMENT_SPREAD),
        (176, 16, 4, -1, 7, True, 16, 4, 1, RAY_PLACEMENT_SPREAD),
        (6, 3, 3, 1, -1, True, 1, 1, 1, RAY_PLACEMENT_SPREAD),
        (6, 3, 3, -1, -1, True, 3, 1, 1, RAY_PLACEMENT_SPREAD),
        (6, 3, 3, 2, -1, True, 2, 1, 1, RAY_PLACEMENT_SPREAD),
        # 4, 3 CPUs
        (4, 1, 4, -1, -1, True, 1, 2, 1, RAY_PLACEMENT_SPREAD),
        (3, 1, 4, -1, -1, True, 1, 2, 1, RAY_PLACEMENT_SPREAD),
        (3, 1, 1, -1, -1, True, 1, 2, 1, RAY_PLACEMENT_PACK),
        (1, 1, 1, -1, -1, True, 1, 0.5, 1, RAY_PLACEMENT_PACK),
        (3, 3, 3, -1, -1, True, 3, 0.5, 1, RAY_PLACEMENT_SPREAD),
    ],
)
def test_scaling_config_cpu_gpu(
    total_cpus,
    total_gpus,
    total_alive_nodes,
    input_num_workers,
    input_cpu_per_worker,
    use_gpu,
    expected_num_workers,
    expected_cpu_per_worker,
    expected_gpu_per_worker,
    expected_strategy,
):
    with mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_gpu",
        return_value=total_gpus,
    ), mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_cpu",
        return_value=total_cpus,
    ):
        actual_scaling_config = get_ray_scaling_config(
            input_num_workers, input_cpu_per_worker, use_gpu, total_alive_nodes
        )

        # Build expected label_selector based on multi-node vs single-node
        if total_alive_nodes > 1:
            expected_label_selector = [
                {"node-type": "head"},  # rank 0 -> head node
                *[{} for _ in range(expected_num_workers - 1)],
            ]
        else:
            expected_label_selector = None

        if expected_gpu_per_worker == 0:
            expected_config = ScalingConfig(
                num_workers=expected_num_workers,
                resources_per_worker={"CPU": expected_cpu_per_worker},
                placement_strategy=expected_strategy,
                label_selector=expected_label_selector,
            )
        else:
            expected_config = ScalingConfig(
                num_workers=expected_num_workers,
                resources_per_worker={
                    "CPU": expected_cpu_per_worker,
                    "GPU": expected_gpu_per_worker,
                },
                placement_strategy=expected_strategy,
                use_gpu=use_gpu,
                label_selector=expected_label_selector,
            )
        assert actual_scaling_config == expected_config


@pytest.mark.parametrize(
    "total_cpus, total_gpus, total_alive_nodes, input_num_workers, input_cpu_per_worker, use_gpu",
    [
        # CPU nodes
        (9, 0, 3, 25, -1, False),
        (3, 0, 3, 8, -1, False),
        (3, 0, 3, 7, -1, False),
        (3, 0, 3, -1, 2, False),
        # GPU nodes
        (36, 12, 3, 13, -1, True),
    ],
)
def test_scaling_config_error(
    total_cpus,
    total_gpus,
    total_alive_nodes,
    input_num_workers,
    input_cpu_per_worker,
    use_gpu,
):
    # test scaling config for gpu and cpu
    with mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_gpu",
        return_value=total_gpus,
    ), mock.patch(
        "implementations.distributed_trainers.ray_utils.get_available_cpu",
        return_value=total_cpus,
    ):
        with pytest.raises(ValueError):
            get_ray_scaling_config(
                input_num_workers, input_cpu_per_worker, use_gpu, total_alive_nodes
            )


if __name__ == "__main__":
    pytest.main()
