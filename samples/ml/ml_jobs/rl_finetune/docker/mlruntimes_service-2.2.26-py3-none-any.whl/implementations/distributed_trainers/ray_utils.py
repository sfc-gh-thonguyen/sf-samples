import math
import os
import uuid
from typing import Optional, Dict, Any, Tuple, List, cast, Union

import numpy as np
import pandas as pd
from ray.air.constants import TRAIN_DATASET_KEY
from scipy.sparse import csr_matrix
from snowflake.ml.data.data_connector import DataConnector
import xgboost as xgb
import lightgbm as lgb
from collections import OrderedDict

from implementations.ray_data_ingester import RayDataIngester
from snowflake.ml.runtime_cluster.cluster_manager import (
    get_available_cpu,
    get_available_gpu,
)
from snowflake.runtime.utils.logger import get_logger
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df
from ray.train import ScalingConfig, Checkpoint
from ray.data import Dataset as RayDataset, from_pandas
from ray.train import RunConfig
from web.jobs.common import (
    RAY_PLACEMENT_SPREAD,
    RAY_PLACEMENT_PACK,
    NON_COMPUTE_PERCENT_GPU_NODE,
    NON_COMPUTE_PERCENT_CPU_NODE,
)
from shared_storage.constants import INTERNAL_HPO_STAGE_PATH
from common_utils.shared_storage_fs_util import get_py_filesystem_for_stage

DEFAULT_LABEL_COL = "_label_col"
EVAL_DATASET_KEY = "eval"

logger = get_logger()


CHECKPOINT_DIR = "/tmp/checkpoints"


def _get_num_workers_and_cpus(
    num_compute_cpus: float, num_alive_nodes: int
) -> Tuple[int, Union[int, float]]:
    num_cpus_per_node = num_compute_cpus // num_alive_nodes
    num_workers, num_cpus_per_worker = (
        int(max(num_cpus_per_node // 3, 1)),
        3 if num_cpus_per_node >= 3 else num_cpus_per_node,
    )
    return (
        num_workers * num_alive_nodes,
        num_cpus_per_worker if num_cpus_per_worker > 0 else 0.5,
    )


def _get_usable_cpus_for_compute(
    total_cpus: float, non_compute_cpus_percent: float
) -> float:
    """Get usable cpus for training after reserving non_compute_cpus_percent amount to other processes
    For GPU and CPU nodes the percent of CPUs required for training is determined based on these tests:
    https://docs.google.com/document/d/1aZzxiVEzBDoQxfeKuR3u8h6P7ApJsJxWUPI6cH0mTos/edit?tab=t.0#bookmark=id.bbq3m26a9ztk
    """
    non_compute_cpus = math.floor(total_cpus * non_compute_cpus_percent)
    compute_cpus = float(total_cpus - non_compute_cpus)
    if non_compute_cpus == 0:
        compute_cpus = 0.5 if total_cpus == 1 else (compute_cpus - 1)
    return compute_cpus


def _get_atleast_half_cpu(num_cpu: float) -> float:
    # If there is only one CPU available use at-least 0.5 CPU
    return max(num_cpu, 0.5)


def _check_required_columns(
    ray_ds: RayDataset, input_cols: List[str], label_cols: str
) -> None:
    ds_cols = set(ray_ds.columns())
    expected_cols = set(input_cols + [label_cols])
    if len(expected_cols - ds_cols) > 0:
        raise ValueError(
            f"Input dataset has fewer columns {ds_cols} than input columns {expected_cols}"
        )
    if len(ds_cols - expected_cols) > 0:
        diff = ds_cols - expected_cols
        logger.warning(f"Dropping extra columns {diff} in the dataset.")


def convert_model_to_ray_checkpoint(
    boosting_model: Union[xgb.Booster, lgb.Booster],
) -> Checkpoint:
    unique_id = uuid.uuid4().hex
    model_path = os.path.join(CHECKPOINT_DIR, f"boosting_model_{unique_id}.json")
    boosting_model.save_model(model_path)

    return Checkpoint.from_directory(model_path)


def get_scaling_config_dict(scaling_config: ScalingConfig):
    return {
        "num_workers": scaling_config.num_workers,
        "resources_per_worker": scaling_config.resources_per_worker,
        "use_gpu": scaling_config.use_gpu,
    }


def train_using_gpu(user_use_gpu: Optional[bool]) -> bool:
    """
    Check if the training should be done using GPU. If user_use_gpu_choice is not None, it will be used to determine
    if GPU should be used.
    """
    gpu_available = get_available_gpu()

    if user_use_gpu is not None:
        if user_use_gpu and not gpu_available:
            raise ValueError(
                "GPU is not available in the environment but use_gpu is set to True"
            )
        return user_use_gpu

    # User didn't specify use_gpu, we will use GPU if there are available GPUs
    return gpu_available > 0


def convert_data_connector_to_ray_dataset(data_connector: DataConnector) -> RayDataset:
    if not isinstance(data_connector._ingestor, RayDataIngester):
        raise ValueError(
            f"DataConnector ingestor is not of type RayDataIngester, got {type(data_connector._ingestor).__name__}"
        )

    return cast(RayDataIngester, data_connector._ingestor).ray_ds


def convert_to_ray_train_dataset(
    X: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
    y: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix],
) -> RayDataset:
    """
    Convert in memory data into ray dataset.

    For now ray doesn't have a way to support converting from each individual type to ray dataset,
    and it doesn't have a good way to merge two matrices into one dataset.
    Hence we need to convert all the data types to pandas dataframe and then convert to ray dataset.
    """

    X, y = convert_to_pandas_df(X), convert_to_pandas_df(y)
    if X.shape[0] != y.shape[0]:
        raise ValueError(
            f"X and y have different number of rows, got {X.shape[0]} and {y.shape[0]}"
        )

    if y.shape[1] > 1:
        raise ValueError(f"y should have only one column, got {y.shape[1]}")

    y.columns = [DEFAULT_LABEL_COL]
    # make sure X columns are string type, which are requiremed by Ray Dataset
    X = X.rename(columns=lambda x: str(x))
    X = X.reset_index(drop=True)
    y = y.reset_index(drop=True)
    joined_df = pd.concat([X, y], axis=1)
    return from_pandas(joined_df)


def get_run_config() -> RunConfig:
    """Get RunConfig with appropriate storage configuration.

    For HPO/Tune context, uses shared storage (Snowflake stage).
    For regular training (including multi-node), uses default RunConfig.
    Multi-node training relies on bypass_ray_storage_check() in DistributedXGBoostTrainer
    and DistributedLightGBMTrainer to skip the shared storage validation.
    """
    if is_running_in_ray_tune_context():
        fs = get_py_filesystem_for_stage(INTERNAL_HPO_STAGE_PATH)
        return RunConfig(
            storage_path="/",
            storage_filesystem=fs,
        )
    return RunConfig()


def get_ray_scaling_config(
    input_num_workers: int,
    input_num_cpu_per_worker: int,
    use_gpu: Optional[bool],
    num_alive_nodes: int,
) -> ScalingConfig:
    ray_use_gpu = train_using_gpu(use_gpu)
    available_gpus = get_available_gpu()
    total_cpus = get_available_cpu()
    if ray_use_gpu:
        usable_cpus_for_compute = _get_usable_cpus_for_compute(
            total_cpus, NON_COMPUTE_PERCENT_GPU_NODE
        )
    else:
        usable_cpus_for_compute = _get_usable_cpus_for_compute(
            total_cpus, NON_COMPUTE_PERCENT_CPU_NODE
        )
    num_cpus_per_node = max(usable_cpus_for_compute // num_alive_nodes, 0.5)
    if ray_use_gpu and input_num_workers > available_gpus:
        raise ValueError(
            f"Number of workers is greater than the number of available GPUs, detected {available_gpus} GPUs"
        )

    # Find optimal number of workers
    # TODO: Refine this part after multi-node GPU support
    if ray_use_gpu:
        if input_num_workers == -1 and input_num_cpu_per_worker == -1:
            # IN GPU Env, if num_workers & n_cpu are not specified, it would be the total number of GPUs available
            ray_num_workers, ray_cpu_per_worker = (
                available_gpus,
                _get_atleast_half_cpu(usable_cpus_for_compute // available_gpus),
            )
        elif input_num_workers == -1:
            # calculate number of workers based on the number of GPUs
            ray_num_workers, ray_cpu_per_worker = (
                available_gpus,
                input_num_cpu_per_worker,
            )
            if ray_num_workers * ray_cpu_per_worker > usable_cpus_for_compute:
                logger.warning(
                    "Total number of requested CPUs is more than usable CPUs, cluster might be overloaded."
                )
                # Reduce the number of workers to the number of CPUs available
                # Here we don't want to directly raise error because the number of usable CPUs are not equal
                # to CPU avaiable in the cluster/instance, we reserved some of the CPUs for process.
                ray_cpu_per_worker = usable_cpus_for_compute // ray_num_workers
        elif input_num_cpu_per_worker == -1:
            # If user specifiy cpu per worker, we calculate the number of workers based on the number of GPUs
            if input_num_workers > available_gpus:
                raise ValueError(
                    f"Number of workers is greater than the number of available GPUs, "
                    f"{usable_cpus_for_compute} usable GPUs"
                )
            ray_num_workers, ray_cpu_per_worker = (
                input_num_workers,
                usable_cpus_for_compute // max(input_num_workers, num_alive_nodes),
            )
        else:
            # Both n_worker and cpu_per_worker are both specified, we use the specified values
            ray_num_workers, ray_cpu_per_worker = (
                input_num_workers,
                input_num_cpu_per_worker,
            )
    else:
        if input_num_workers == -1 and input_num_cpu_per_worker == -1:
            # In CPU ENV, if it would just 1 worker with n_cores to maximize performance
            ray_num_workers, ray_cpu_per_worker = _get_num_workers_and_cpus(
                usable_cpus_for_compute, num_alive_nodes
            )
        elif input_num_workers == -1:
            # calculate n worker based on available CPUs and requested cpu per worker
            if math.ceil(input_num_cpu_per_worker) > math.ceil(num_cpus_per_node):
                raise ValueError(
                    f"Number of CPUs per worker is greater than the number of available CPUs per node, "
                    f"{num_cpus_per_node} usable CPUs"
                )
            ray_num_workers, ray_cpu_per_worker = (
                int(max(usable_cpus_for_compute // input_num_cpu_per_worker, 1)),
                input_num_cpu_per_worker,
            )
        elif input_num_cpu_per_worker == -1:
            # calculate n_cpu_per_worker based on available CPUs and requested number of workers
            ray_num_workers, ray_cpu_per_worker = (
                input_num_workers,
                _get_atleast_half_cpu(
                    usable_cpus_for_compute // max(input_num_workers, num_alive_nodes)
                ),
            )
            if ray_num_workers * ray_cpu_per_worker > usable_cpus_for_compute:
                raise ValueError(
                    f"Number of workers is greater than the number of available CPUs, "
                    f"{usable_cpus_for_compute} usable CPUs"
                )
        else:
            # both n_worker and cpu_per_worker are specified, we use the specified values
            ray_num_workers, ray_cpu_per_worker = (
                input_num_workers,
                input_num_cpu_per_worker,
            )

    resource_per_worker = (
        {"CPU": ray_cpu_per_worker, "GPU": 1}
        if ray_use_gpu
        else {"CPU": ray_cpu_per_worker}
    )

    num_workers_int = math.floor(ray_num_workers)

    if num_alive_nodes > 1 and num_workers_int >= 1:
        placement_strategy = RAY_PLACEMENT_SPREAD
        # Force rank 0 to be on head node so checkpoint is accessible to driver
        # Other ranks can be placed on any node
        # Note: Head node must be started with --labels="node-type=head"
        label_selector = [
            {"node-type": "head"},  # rank 0 -> head node
            *[{} for _ in range(num_workers_int - 1)],
        ]
    else:
        placement_strategy = RAY_PLACEMENT_PACK
        label_selector = None

    return ScalingConfig(
        num_workers=num_workers_int,
        use_gpu=ray_use_gpu,
        resources_per_worker=resource_per_worker,
        placement_strategy=placement_strategy,
        label_selector=label_selector,
    )


def prepare_ray_trainer_dataset(
    dataset: DataConnector,
    eval_set: Optional[DataConnector],
    input_cols: List[str],
    label_col: str,
) -> Dict[str, RayDataset]:
    ray_train_ds = convert_data_connector_to_ray_dataset(dataset)
    ray_eval_ds = convert_data_connector_to_ray_dataset(eval_set) if eval_set else None

    _check_required_columns(ray_train_ds, input_cols, label_col)
    _check_required_columns(ray_eval_ds, input_cols, label_col) if ray_eval_ds else None

    ray_train_ds = ray_train_ds.select_columns(input_cols + [label_col])
    ray_eval_ds = (
        ray_eval_ds.select_columns(input_cols + [label_col]) if ray_eval_ds else None
    )

    ray_trainer_dataset = {}
    if ray_train_ds is not None:
        ray_trainer_dataset[TRAIN_DATASET_KEY] = ray_train_ds
    if ray_eval_ds is not None:
        ray_trainer_dataset[EVAL_DATASET_KEY] = ray_eval_ds
    return ray_trainer_dataset


def extract_eval_results(df: pd.DataFrame) -> Dict[str, Any]:
    # Ray XGB/LightGBM Trainer will name the column with the following format
    # "eval-{metrics_name}" Filter columns that start with "eval-"

    eval_columns = [col for col in df.columns if col.startswith(f"{EVAL_DATASET_KEY}-")]

    result = OrderedDict()

    for col in eval_columns:
        # Extract the key (string after "eval-")
        key = col[len(EVAL_DATASET_KEY) + 1 :]  # Slice the string to remove "eval-"

        # Get the list of values from the column
        values = df[col].tolist()

        # Ray's old behavior was to checkpoint at the end, adding one extra row with duplicate metrics.
        # In that case, we remove the last row to stay in sync with OSS results.
        # Ray Train V2 (Ray 2.52+) only stores final metrics (1 row), so we keep all values.
        # https://docs.ray.io/en/latest/train/api/doc/ray.train.CheckpointConfig.html
        if len(values) > 1:
            values = values[:-1]

        result[key] = values

    # Put into a dictionary with key as 'eval' as this is how oss will return the results
    return {"eval": result}


def is_running_in_ray_tune_context() -> bool:
    try:
        # Ray's implementation runs distributed trainer as ray tune:
        # https://github.com/ray-project/ray/blob/master/python/ray/train/base_trainer.py
        # Hence context is always not None; but context.get_trial_id only exists for actual tune job
        import ray.tune

        context = ray.tune.get_context()
        return context and context.get_trial_id()
    except Exception:
        return False
