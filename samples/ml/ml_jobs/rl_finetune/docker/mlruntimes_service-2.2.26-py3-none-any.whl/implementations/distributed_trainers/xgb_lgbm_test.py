from unittest import mock
import pytest
import pandas as pd
import numpy as np
import sklearn.model_selection
import xgboost
from sklearn.datasets import make_classification
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from snowflake.ml.data import DataSource
from snowflake.ml.data.data_connector import DataConnector

from implementations.distributed_trainers.oss_lgbm_implementation import OSSLGBMTrainer
from implementations.distributed_trainers.oss_xgboost_implementation import (
    OSSXGBoostTrainer,
)
from implementations.distributed_trainers.ray_lgbm_implementation import RayLGBMTrainer
from implementations.distributed_trainers.ray_xgboost_implementation import (
    RayXGBoostTrainer,
)
from implementations.ray_data_ingester import RayDataIngester
from internal_entities.distribution_params import DistributionParams
import lightgbm as lgb
import ray


FEAT_COL_NAMES = [f"COL_{x}" for x in range(20)]


class FakeEstimator:
    def __init__(self, trainer, params):
        self._trainer = trainer
        self._booster = None
        self._params = params

    def fit(self, X, y):
        booster, _ = self._trainer.fit_in_memory(
            init_model=None,
            X=X,
            y=y,
            params=self._params,
        )
        self._booster = booster


@pytest.fixture
def sample_classification_data():
    X, y = make_classification(
        n_samples=1200, n_features=20, n_informative=10, n_classes=2, random_state=42
    )
    return pd.DataFrame(X, columns=FEAT_COL_NAMES), pd.Series(y)


@pytest.mark.parametrize(
    "trainer_config",
    [
        (RayLGBMTrainer, "binary", lgb.LGBMClassifier),
        (RayXGBoostTrainer, "binary:logistic", xgboost.XGBClassifier),
    ],
)
def test_ray_trainer(sample_classification_data, trainer_config) -> None:
    mock_trainer = mock.MagicMock()
    mock_booster = mock.MagicMock()
    with mock.patch(
        "implementations.distributed_trainers.ray_xgboost_implementation.DistributedXGBoostTrainer",
        return_value=mock_trainer,
    ), mock.patch(
        "implementations.distributed_trainers.ray_lgbm_implementation.DistributedLightGBMTrainer",
        return_value=mock_trainer,
    ), mock.patch(
        "implementations.distributed_trainers.ray_xgboost_implementation.RayTrainReportCallback.get_model",
        return_value=mock_booster,
    ), mock.patch(
        "implementations.distributed_trainers.ray_lgbm_implementation.RayTrainReportCallback.get_model",
        return_value=mock_booster,
    ):
        df, y = sample_classification_data
        df["LABEL"] = y
        distribution_params = DistributionParams(num_workers=1, cpus_per_worker=1)

        train_set, eval_set = sklearn.model_selection.train_test_split(df)

        trainer_cls, objective, _ = trainer_config
        trainer = trainer_cls(distribution_params=distribution_params)

        params = {
            "objective": objective,
            "metric": "binary_logloss",
            "n_estimators": 100,
        }

        data_connector = DataConnector(
            ingestor=RayDataIngester(
                data_sources=[mock.Mock(spec=DataSource)],
                ray_ds=ray.data.from_pandas(train_set),
            )
        )

        eval_data_connector = DataConnector(
            ingestor=RayDataIngester(
                data_sources=[mock.Mock(spec=DataSource)],
                ray_ds=ray.data.from_pandas(eval_set),
            )
        )
        _, _ = trainer.fit(
            init_model=None,
            data_connector=data_connector,
            input_cols=FEAT_COL_NAMES,
            label_cols=["LABEL"],
            params=params,
            eval_set=eval_data_connector,
        )

        assert mock_trainer.fit.called is True


@pytest.mark.parametrize(
    "trainer_config",
    [
        (OSSLGBMTrainer, "binary", ("metric", "binary_logloss"), lgb.LGBMClassifier),
        (
            OSSXGBoostTrainer,
            "binary:logistic",
            ("eval_metric", "logloss"),
            xgboost.XGBClassifier,
        ),
    ],
)
def test_oss_trainer(sample_classification_data, trainer_config) -> None:
    df, y = sample_classification_data
    df["LABEL"] = y
    train_set, eval_set = sklearn.model_selection.train_test_split(df)

    trainer_cls, objective, metric, oss_estimator = trainer_config
    trainer = trainer_cls()

    params = {"objective": objective, metric[0]: metric[1], "n_estimators": 100}

    data_connector = DataConnector(
        ingestor=RayDataIngester(
            data_sources=[mock.Mock(spec=DataSource)],
            ray_ds=ray.data.from_pandas(train_set),
        )
    )

    eval_data_connector = DataConnector(
        ingestor=RayDataIngester(
            data_sources=[mock.Mock(spec=DataSource)],
            ray_ds=ray.data.from_pandas(eval_set),
        )
    )

    booster, eval_results = trainer.fit(
        init_model=None,
        data_connector=data_connector,
        input_cols=FEAT_COL_NAMES,
        label_cols=["LABEL"],
        params=params,
        eval_set=eval_data_connector,
    )

    # Compare to OSS classifier directly
    classifier = oss_estimator(**params)
    classifier.fit(
        train_set[FEAT_COL_NAMES],
        train_set["LABEL"],
        eval_set=[(eval_set[FEAT_COL_NAMES], eval_set["LABEL"])],
    )

    if isinstance(classifier, xgboost.XGBClassifier):
        np.testing.assert_allclose(
            classifier.evals_result()["validation_0"][metric[1]],
            eval_results["eval"][metric[1]],
            rtol=1e-5,
        )
        data = xgboost.DMatrix(eval_set[FEAT_COL_NAMES])
        y_predict = booster.predict(data)
    else:
        np.testing.assert_allclose(
            classifier.evals_result_["valid_0"][metric[1]],
            eval_results["eval"][metric[1]],
            rtol=1e-5,
        )
        y_predict = booster.predict(eval_set[FEAT_COL_NAMES])

    oss_predictions = classifier.predict(eval_set[FEAT_COL_NAMES])
    np.testing.assert_array_equal(oss_predictions, np.round(y_predict))


@pytest.mark.parametrize(
    "trainer_config",
    [
        (RayLGBMTrainer, "binary", ("metric", "binary_logloss")),
        (RayXGBoostTrainer, "binary:logistic", ("eval_metric", "logloss")),
    ],
)
def test_ray_trainer_in_memory(sample_classification_data, trainer_config):
    mock_trainer = mock.MagicMock()
    mock_booster = mock.MagicMock()
    with mock.patch(
        "implementations.distributed_trainers.ray_xgboost_implementation.DistributedXGBoostTrainer",
        return_value=mock_trainer,
    ), mock.patch(
        "implementations.distributed_trainers.ray_lgbm_implementation.DistributedLightGBMTrainer",
        return_value=mock_trainer,
    ), mock.patch(
        "implementations.distributed_trainers.ray_xgboost_implementation.RayTrainReportCallback.get_model",
        return_value=mock_booster,
    ), mock.patch(
        "implementations.distributed_trainers.ray_lgbm_implementation.RayTrainReportCallback.get_model",
        return_value=mock_booster,
    ):
        X, y = sample_classification_data
        distribution_params = DistributionParams(num_workers=1, cpus_per_worker=1)

        X_train, _, y_train, _ = sklearn.model_selection.train_test_split(X, y)

        trainer_cls, objective, metric = trainer_config
        trainer = trainer_cls(distribution_params=distribution_params)

        params = {
            "objective": objective,
            metric[0]: metric[1],
            "n_estimators": 100,
        }

        _, _ = trainer.fit_in_memory(
            init_model=None,
            X=X_train,
            y=y_train,
            params=params,
        )

        assert mock_trainer.fit.called is True


@pytest.mark.parametrize(
    "trainer_config",
    [
        (OSSLGBMTrainer, "binary", ("metric", "binary_logloss"), lgb.LGBMClassifier),
        (
            OSSXGBoostTrainer,
            "binary:logistic",
            ("eval_metric", "logloss"),
            xgboost.XGBClassifier,
        ),
    ],
)
def test_oss_trainer_in_memory(sample_classification_data, trainer_config):
    with mock.patch(
        "implementations.distributed_trainers.oss_lgbm_implementation.lgb.train",
        return_value=True,
    ), mock.patch(
        "implementations.distributed_trainers.oss_xgboost_implementation.xgb.train",
        return_value=True,
    ):
        X, y = sample_classification_data
        X_train, _, y_train, _ = sklearn.model_selection.train_test_split(X, y)

        trainer_cls, objective, metric, oss_estimator = trainer_config
        trainer = trainer_cls()

        params = {
            "objective": objective,
            metric[0]: metric[1],
            "n_estimators": 100,
        }

        was_called, _ = trainer.fit_in_memory(
            init_model=None,
            X=X_train,
            y=y_train,
            params=params,
        )

        # Compare to OSS classifier directly
        classifier = oss_estimator(**params)
        classifier.fit(X_train, y_train)

        assert was_called is True


@pytest.mark.parametrize(
    "trainer_config",
    [
        (OSSLGBMTrainer, lgb.LGBMClassifier),
        (OSSXGBoostTrainer, xgboost.XGBClassifier),
    ],
)
def test_sklearn_pipeline(sample_classification_data, trainer_config) -> None:
    with mock.patch(
        "implementations.distributed_trainers.oss_lgbm_implementation.lgb.train",
        return_value=True,
    ), mock.patch(
        "implementations.distributed_trainers.oss_xgboost_implementation.xgb.train",
        return_value=True,
    ):
        X, y = sample_classification_data
        trainer_cls, _ = trainer_config

        trainer = trainer_cls()

        params = {"n_estimators": 100}

        # Fit a pipeline that uses a CR distributed estimator
        cr_estimator = FakeEstimator(trainer=trainer, params=params)
        cr_pipeline = Pipeline(
            steps=[
                ("preprocessing", StandardScaler()),
                ("polynomial", PolynomialFeatures(degree=3)),
                ("Training", cr_estimator),
            ]
        )
        cr_pipeline.fit(X, y)

        assert cr_pipeline[-1]._booster is True


if __name__ == "__main__":
    pytest.main()
