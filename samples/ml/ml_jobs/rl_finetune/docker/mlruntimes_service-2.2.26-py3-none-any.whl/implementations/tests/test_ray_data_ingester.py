from unittest import mock

import pyarrow as pa
import pandas as pd
import ray
import pytest
from implementations.ray_data_ingester import (
    _load_data,
    ResultSetDataSource,
    NUM_RAY_WORKERS,
    RayDataIngester,
    BatchRefreshActor,
)
from snowflake.ml.data.data_source import DataFrameInfo, DatasetInfo

from snowflake import snowpark


@pytest.fixture
def ray_start_2_cpus():
    if ray.is_initialized():
        ray.shutdown()

    # Use a different port to avoid conflicts with integration test Ray cluster
    address_info = ray.init(num_cpus=2, dashboard_port=8269)
    yield address_info

    ray.shutdown()


@pytest.fixture
def mock_session():
    mocked_session = mock.Mock(spec=snowpark.Session)
    mocked_session.connection = mock.Mock()
    return mocked_session


@pytest.fixture
def mock_dataframe_info():
    return mock.Mock(spec=DataFrameInfo)


@pytest.fixture
def mock_dataset_info():
    return mock.Mock(spec=DatasetInfo)


@mock.patch("snowflake.runtime.utils.metrics.MLRSPrometheusMetrics")
def test_result_set_data_source_has_correct_element_per_worker(
    mock_metrics, mock_session
):
    mock_tasks_metric = mock.MagicMock()
    mock_metrics.DATA_INGESTER_TABLE_ROWS_READ.value.labels.return_value = (
        mock_tasks_metric
    )

    num_columns = 100
    test_arrow_table = pa.Table.from_pydict({f"c_{i}": [0] for i in range(num_columns)})
    total_batches = 22
    parallelism = 5
    mock_result_batch = mock.Mock()
    mock_result_batch.rowcount = 100
    mock_result_batch.compressed_size = 100
    mock_result_batch.to_arrow.return_value = test_arrow_table
    batches = [mock_result_batch for _ in range(total_batches)]
    expected_element_per_worker = (
        total_batches // parallelism
    )  # min number of batches per worker
    expected_remainder = (
        total_batches % parallelism
    )  # # number of workers that will have 1 more batch

    with (
        mock.patch("implementations.ray_data_ingester.get_session") as mock_get_session,
        mock.patch(
            "implementations.ray_data_ingester.ResultSetDataSource._get_read_task"
        ) as mock_get_read_task,
    ):
        mock_get_session.return_value = mock_session
        ray_data_source = ResultSetDataSource(batches=batches)
        _ = ray_data_source.get_read_tasks(parallelism)

        assert mock_get_read_task.call_count == parallelism
        expected_calls = []
        for i in range(parallelism):
            expected_calls.append(
                mock.call(i, expected_element_per_worker, expected_remainder)
            )

        assert mock_get_read_task.call_args_list == expected_calls


def test_result_set_data_source_get_elements(mock_session):
    # test case with uneven distribution
    total_batches = 22
    parallelism = 5
    num_columns = 100
    test_arrow_table = pa.Table.from_pydict({f"c_{i}": [0] for i in range(num_columns)})
    mock_result_batch = mock.Mock()
    mock_result_batch.rowcount = 100
    mock_result_batch.compressed_size = 100
    mock_result_batch.to_arrow.return_value = test_arrow_table
    batches = [mock_result_batch for _ in range(total_batches)]
    expected_element_per_worker = (
        total_batches // parallelism
    )  # min number of batches per worker
    expected_remainder = (
        total_batches % parallelism
    )  # # number of workers that will have 1 more batch

    with mock.patch(
        "implementations.ray_data_ingester.get_session"
    ) as mock_get_session:
        mock_get_session.return_value = mock_session
        ray_data_source = ResultSetDataSource(batches=batches)
        expected_first_elements = [0, 5, 10, 14, 18]
        expected_last_elements = [5, 10, 14, 18, 22]
        for i in range(parallelism):
            first, last = ray_data_source._get_first_last_element(
                i, expected_element_per_worker, expected_remainder
            )
            assert first == expected_first_elements[i]
            assert last == expected_last_elements[i]

        # test case with EVEN distribution
        total_batches = 20
        parallelism = 5
        batches = [mock_result_batch for _ in range(total_batches)]
        expected_element_per_worker = (
            total_batches // parallelism
        )  # min number of batches per worker
        expected_remainder = (
            total_batches % parallelism
        )  # # number of workers that will have 1 more batch

        ray_data_source = ResultSetDataSource(batches=batches)
        expected_first_elements = [0, 4, 8, 12, 16]
        expected_last_elements = [4, 8, 12, 16, 20]
        for i in range(parallelism):
            first, last = ray_data_source._get_first_last_element(
                i, expected_element_per_worker, expected_remainder
            )
            assert first == expected_first_elements[i]
            assert last == expected_last_elements[i]

        # test case with less batch than workers
        total_batches = 1
        parallelism = 5
        batches = [mock_result_batch]
        expected_element_per_worker = (
            total_batches // parallelism
        )  # min number of batches per worker
        expected_remainder = (
            total_batches % parallelism
        )  # # number of workers that will have 1 more batch

        ray_data_source = ResultSetDataSource(batches=batches)
        expected_first_elements = [0, 1, 1, 1, 1]
        expected_last_elements = [
            1,
            1,
            1,
            1,
            1,
        ]  # this is a special case, ray will get 0 read tasks for workers idx > 1

        for i in range(parallelism):
            first, last = ray_data_source._get_first_last_element(
                i, expected_element_per_worker, expected_remainder
            )
            assert first == expected_first_elements[i]
            assert last == expected_last_elements[i]


def test_ray_data_source_will_return_zero_read_task(mock_session):
    with mock.patch(
        "implementations.ray_data_ingester.get_session"
    ) as mock_get_session:
        mock_get_session.return_value = mock_session
        batches = []
        ray_data_source = ResultSetDataSource(batches=batches)
        read_tasks = ray_data_source.get_read_tasks(5)

        assert len(read_tasks) == 0


def test_ray_data_source_returns_correct_column_names(ray_start_2_cpus, mock_session):
    """Test that ResultSetDataSource correctly exposes column names through schema."""

    # Picklable fake ResultBatch for testing (mock.Mock objects can't be pickled by Ray)
    class FakeResultBatch:
        def __init__(self, arrow_table, rowcount=100, compressed_size=100):
            self._arrow_table = arrow_table
            self.rowcount = rowcount
            self.compressed_size = compressed_size

        def to_arrow(self, connection=None):
            return self._arrow_table

    # Picklable fake session (MagicMock creates circular refs that fail to pickle)
    class FakeSession:
        connection = None

    num_columns = 100
    total_batches = 10
    test_arrow_table = pa.Table.from_pydict({f"c_{i}": [0] for i in range(num_columns)})
    batches = [FakeResultBatch(test_arrow_table) for _ in range(total_batches)]

    with mock.patch(
        "implementations.ray_data_ingester.get_session", lambda: FakeSession()
    ):
        ray_data_source = ResultSetDataSource(batches=batches)

        ray_ds = ray.data.read_datasource(ray_data_source, parallelism=2)
        column_names = ray_ds.columns()
        expected_column_names = [f"c_{i}" for i in range(num_columns)]
        assert column_names == expected_column_names


def test_load_data_with_single_dataframe_info(mock_session, mock_dataframe_info):
    data_source = mock_dataframe_info
    mock_batches = [mock.Mock()]
    mock_ray_dataset = mock.Mock()
    with (
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch(
            "implementations.ray_data_ingester.ResultSetDataSource"
        ) as MockResultSetDataSource,
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        MockResultSetDataSource.return_value = mock.Mock()
        mock_read_datasource.return_value = mock_ray_dataset
        mock_ray_dataset.columns.return_value = ["col1", "col2"]
        _ = _load_data(mock_session, data_source)

        # Make sure ResultSetDataSource is created with the correct batches
        MockResultSetDataSource.assert_called_once_with(mock_batches, data_source)
        # Make sure ray data is read from the data source
        mock_read_datasource.assert_called_once()


def test_load_data_with_single_dataset_info(mock_session, mock_dataset_info):
    data_source = mock_dataset_info
    mock_filesystem = mock.Mock()
    mock_files = ["file1", "file2"]
    mock_ray_dataset = mock.Mock()
    mock_ray_dataset.columns.return_value = ["col1", "col2"]

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_dataset_filesystem",
            return_value=mock_filesystem,
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataset_files",
            return_value=mock_files,
        ),
        mock.patch("ray.data.read_parquet") as mock_read_parquet,
    ):
        mock_read_parquet.return_value = mock_ray_dataset
        _ = _load_data(mock_session, data_source)

        # Assert ray read_parquet is called with the correct arguments
        mock_read_parquet.assert_called_once_with(
            mock_files, filesystem=mock_filesystem
        )


def test_load_data_with_invalid_data_source(mock_session):
    data_source = "invalid_source"

    with pytest.raises(RuntimeError, match="Unsupported source type: <class 'str'>"):
        _load_data(mock_session, data_source)


def test_load_data_with_column_renaming(mock_session, mock_dataframe_info):
    data_source = mock_dataframe_info
    mock_batches = [mock.Mock()]
    mock_ray_ds = mock.Mock()
    mock_ray_ds.columns.return_value = ["col1", "col2"]

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch(
            "implementations.ray_data_ingester.ResultSetDataSource"
        ) as MockResultSetDataSource,
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
        mock.patch(
            "implementations.ray_data_ingester.get_inferred_names",
            side_effect=lambda x: f"sf_{x}",
        ),
        mock.patch(
            "implementations.ray_data_ingester.RenameHelper"
        ) as MockRenameHelper,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        _ = _load_data(mock_session, data_source)

        # Assert ResultSetDataSource is created with the correct batches
        MockResultSetDataSource.assert_called_once_with(mock_batches, data_source)

        # Assert renaming is happenging
        mock_ray_ds.map_batches.assert_called_once_with(
            MockRenameHelper(new_cols={"col1": "sf_col1", "col2": "sf_col2"}),
            concurrency=NUM_RAY_WORKERS,
        )


def test_ray_ds_cached_property_and_data_source(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    mock_ray_ds = mock.Mock()
    mock_ray_ds.columns.return_value = ["col1", "col2"]

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session",
            return_value=mock_session,
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch(
            "implementations.ray_data_ingester.ResultSetDataSource"
        ) as MockResultSetDataSource,
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        # Access the cached property
        ray_ds = ingester.ray_ds

        # Ensure _load_data is called once
        MockResultSetDataSource.assert_called_once_with(mock_batches, data_sources[0])
        mock_read_datasource.assert_called_once()

        # Access the cached property again
        ray_ds_cached = ingester.ray_ds

        # Ensure the cached property is used and _load_data is not called again
        assert ray_ds is ray_ds_cached
        MockResultSetDataSource.assert_called_once()
        mock_read_datasource.assert_called_once()

        # assert data_source is saved correctly
        assert ingester.data_sources == data_sources


def test_to_ray_dataset(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    mock_ray_ds = mock.Mock()
    mock_ray_ds.columns.return_value = ["col1", "col2"]

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session",
            return_value=mock_session,
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
        mock.patch.object(
            RayDataIngester, "ray_ds", new_callable=mock.PropertyMock
        ) as mock_ray_ds_prop,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)
        _ = ingester.to_ray_dataset()
        assert mock_ray_ds_prop.call_count == 1


def test_to_pandas_without_limit(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ["COL1", "COL2"]
    sample_pandas_df = pd.DataFrame({c: [0] for c in column_names})
    mock_ray_ds = mock.Mock()
    mock_ray_ds.to_pandas.return_value = sample_pandas_df
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        pd_df = ingester.to_pandas()

        # Ensure to_pandas is called without limit
        mock_ray_ds.to_pandas.assert_called_once_with()
        # Ensure columns are renamed correctly
        assert list(pd_df.columns) == list(column_names)


def test_to_pandas_with_quoted_columns(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ['"col1"', '"col2"']
    sample_pandas_df = pd.DataFrame({c: [0] for c in column_names})
    mock_ray_ds = mock.Mock()
    mock_ray_ds.to_pandas.return_value = sample_pandas_df
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        pd_df = ingester.to_pandas()

        # Ensure to_pandas is called without limit
        mock_ray_ds.to_pandas.assert_called_once_with()
        # Ensure columns are renamed correctly
        assert list(pd_df.columns) == list(column_names)


def test_get_num_of_classes(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ['"col1"', '"col2"']
    sample_pandas_df = pd.DataFrame({c: [0] for c in column_names})
    mock_ray_ds = mock.Mock()
    mock_ray_ds.to_pandas.return_value = sample_pandas_df
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds
    mock_ray_ds.unique.return_value = [0]

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        n_class = ingester.get_num_classes(label_col="col1")

        assert n_class == 1


def test_shard_and_get_shard_by_id(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ['"col1"', '"col2"']
    mock_ray_ds = mock.Mock()
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds
    mock_ray_ds_iterator = mock.Mock()
    mock_list_of_splits = [mock_ray_ds_iterator, mock_ray_ds_iterator]
    mock_ray_ds.streaming_split.return_value = mock_list_of_splits
    mock_ray_ds_iterator.materialize.return_value = mock.Mock()
    num_shards = 2
    equal = True

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        ingester.shard(num_shards=num_shards, equal=equal)

        mock_ray_ds.streaming_split.assert_called_once_with(n=num_shards, equal=equal)

        materialized_ray_data_ingester = ingester.get_shard_by_id(index=0)
        fake_ray_ds_shared = materialized_ray_data_ingester.ray_ds

        assert fake_ray_ds_shared is not None
        mock_ray_ds_iterator.materialize.assert_called_once()

        # check if index is invalid
        with pytest.raises(IndexError):
            ingester.get_shard_by_id(index=2)

        with pytest.raises(IndexError):
            ingester.get_shard_by_id(index=-1)


def test_to_batches_with_ray_local_buffer(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ['"col1"', '"col2"']
    sample_pandas_df = pd.DataFrame({c: [0] for c in column_names})
    mock_ray_ds = mock.Mock()
    mock_ray_ds.to_pandas.return_value = sample_pandas_df
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds
    mock_ray_ds.unique.return_value = [0]
    row_count = 1
    batch_size_requested = 2
    mock_ray_ds.count.return_value = row_count
    mock_returned_batches = [mock.Mock()]
    mock_ray_ds.iter_batches.return_value = iter(mock_returned_batches)

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        ingester = RayDataIngester(data_sources)

        batches = []
        for batch in ingester.to_batches(
            batch_size=batch_size_requested,
            shuffle=True,
            drop_last_batch=True,
        ):
            batches.append(batch)

        mock_ray_ds.iter_batches.assert_called_once_with(
            batch_size=batch_size_requested,
            local_shuffle_buffer_size=1e6,  # Default local buffer size
            drop_last=True,
        )
        assert len(batches) == len(mock_returned_batches)


def test_to_batches_with_custom_local_buffer(mock_session, mock_dataframe_info):
    data_sources = [mock_dataframe_info]
    mock_batches = [mock.Mock()]
    column_names = ['"col1"', '"col2"']

    mock_ray_ds = mock.Mock()
    mock_ray_ds.columns.return_value = column_names
    mock_ray_ds.map_batches.return_value = mock_ray_ds
    mock_ray_ds.unique.return_value = [0]
    row_count = int(1e3)  # Fake a large table
    batch_size_requested = int(1e1)
    mock_ray_ds.count.return_value = row_count
    mock_single_batch = {"K": [1 for _ in range(batch_size_requested)]}
    mock_returned_batches = [
        mock_single_batch for _ in range(int(row_count // batch_size_requested))
    ]
    mock_ray_ds.iter_batches.return_value = iter(mock_returned_batches)

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester.get_dataframe_result_batches",
            return_value=mock_batches,
        ),
        mock.patch("implementations.ray_data_ingester.ResultSetDataSource"),
        mock.patch("ray.data.read_datasource") as mock_read_datasource,
    ):
        mock_read_datasource.return_value = mock_ray_ds
        # Change the in-memory buffer size so that we don't need to build a super large array
        # to avoid memory issues.
        ingester = RayDataIngester(data_sources, target_inmemory_buffer_size=1e2)
        expected_in_memory_buffer_size = int(
            int(ingester._target_inmemory_buffer_size // batch_size_requested)
            * batch_size_requested
        )
        batches = []
        for batch in ingester.to_batches(
            batch_size=batch_size_requested,
            shuffle=False,
            drop_last_batch=True,
        ):
            batches.append(batch)

        mock_ray_ds.iter_batches.assert_called_once_with(
            batch_size=expected_in_memory_buffer_size,
        )
        assert len(batches) == len(mock_returned_batches)


def test_from_ray_dataset_with_kwargs():
    column_names = ['"col1"', '"col2"']
    sample_pandas_df = pd.DataFrame({c: [0] for c in column_names})
    ray_ds = ray.data.from_pandas(sample_pandas_df)

    test_kwargs = {
        "target_inmemory_buffer_size": 5000,
    }

    ingester = RayDataIngester.from_ray_dataset(ray_ds, **test_kwargs)

    assert (
        ingester._target_inmemory_buffer_size
        == test_kwargs["target_inmemory_buffer_size"]
    )
    assert ingester._ray_ds.count() == ray_ds.count()


def test_from_sources_with_kwargs(mock_session, mock_dataframe_info):
    """Test that kwargs are stored AND passed through to _load_data when ray_ds is accessed"""
    data_sources = [mock_dataframe_info]

    test_kwargs = {
        "read_data_source_options": {"batch_size": 1000, "timeout": 30},
        "target_inmemory_buffer_size": 5000,
    }

    # Create fake ray dataset to return
    column_names = ['"col1"', '"col2"']
    sample_pandas_df = pd.DataFrame({c: [0, 1, 2] for c in column_names})
    fake_ray_ds = ray.data.from_pandas(sample_pandas_df)

    with (
        mock.patch(
            "implementations.ray_data_ingester.get_session", return_value=mock_session
        ),
        mock.patch(
            "implementations.ray_data_ingester._load_data", return_value=fake_ray_ds
        ) as mock_load_data,
    ):
        # Create ingester with kwargs
        ingester = RayDataIngester(data_sources, **test_kwargs)

        # Step 1: Verify kwargs are stored
        assert (
            ingester._read_data_source_options
            == test_kwargs["read_data_source_options"]
        )
        assert (
            ingester._target_inmemory_buffer_size
            == test_kwargs["target_inmemory_buffer_size"]
        )
        assert len(ingester.data_sources) == len(data_sources)

        # Step 2: Trigger lazy loading by accessing ray_ds
        result_ds = ingester.ray_ds

        # Step 3: Verify _load_data was called with the correct options
        mock_load_data.assert_called_once()
        call_args = mock_load_data.call_args

        # Check that read_data_source_options were passed
        assert call_args[0][0] == mock_session  # First arg: session
        assert call_args[0][1] == data_sources[0]  # Second arg: data_source
        assert (
            call_args[0][2] == test_kwargs["read_data_source_options"]
        )  # Third arg: options

        # Verify the returned dataset is stored
        assert result_ds is fake_ray_ds
        assert ingester._ray_ds is fake_ray_ds


def test_batch_refresh_actor_contains_query_empty(ray_start_2_cpus):
    """Test that contains_query returns False for non-existent queries"""
    actor = BatchRefreshActor.remote()

    # Query not in cache should return False
    assert ray.get(actor.contains_query.remote("nonexistent_query")) is False
    assert ray.get(actor.contains_query.remote("another_query")) is False


def test_batch_refresh_actor_handles_none_data_source(ray_start_2_cpus):
    """Test that actor handles None data source gracefully"""
    actor = BatchRefreshActor.remote()

    result = ray.get(actor.get_refreshed_batch_ref.remote(None, 2, 0))
    assert result is None


def test_batch_refresh_actor_handles_missing_query_id(ray_start_2_cpus):
    """Test that actor handles data source without query_id"""
    actor = BatchRefreshActor.remote()

    data_source = DataFrameInfo(sql="SELECT * FROM table", query_id=None)
    result = ray.get(actor.get_refreshed_batch_ref.remote(data_source, 2, 0))
    assert result is None


def test_batch_refresh_actor_shutdown_with_empty_cache(ray_start_2_cpus):
    """Test that __ray_shutdown__ handles empty cache gracefully"""
    actor = BatchRefreshActor.remote()

    # Shutdown with empty cache should not crash
    ray.get(actor.__ray_shutdown__.remote())

    # Actor should still be responsive
    is_cached = ray.get(actor.contains_query.remote("test"))
    assert is_cached is False


@mock.patch("implementations.ray_data_ingester.get_session")
@mock.patch("implementations.ray_data_ingester.get_dataframe_result_batches")
def test_batch_refresh_actor_with_last_ref(
    mock_get_batches, mock_get_session, ray_start_2_cpus
):
    """Test that actor correctly handles last_ref_id comparison"""
    mock_session = mock.Mock()
    mock_get_session.return_value = mock_session

    mock_get_batches.return_value = [mock.Mock(), mock.Mock()]

    # Create actor AFTER setting up mocks
    actor = BatchRefreshActor.remote()

    data_source = DataFrameInfo(sql="SELECT * FROM table", query_id="test_id")

    # First call - no last_ref_id, should store in cache
    result = ray.get(actor.get_refreshed_batch_ref.remote(data_source, 2, None))
    print(f"First call result: {result}")
    assert result is not None

    # Get the hex ID from the returned ObjectRef
    first_ref_id = result.hex()

    # Second call with different ref ID - should return cached
    result2 = ray.get(
        actor.get_refreshed_batch_ref.remote(data_source, 2, "different_id")
    )
    print(f"Second call result: {result2}")
    assert result2 is not None
    assert result2.hex() == first_ref_id  # Should return same cached ObjectRef

    # Third call with same ref ID - should regenerate
    result3 = ray.get(
        actor.get_refreshed_batch_ref.remote(data_source, 2, first_ref_id)
    )
    print(f"Third call result: {result3}")
    assert result3 is not None
    assert result3.hex() != first_ref_id  # Should be a new ObjectRef


if __name__ == "__main__":
    pytest.main()
