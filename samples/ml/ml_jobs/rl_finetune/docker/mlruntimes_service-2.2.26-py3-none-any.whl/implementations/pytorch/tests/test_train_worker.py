import pytest
import ray
import ray._private.ray_constants as ray_constants
import time
from implementations.pytorch.train_worker import (
    TrainWorkerGroup,
    Worker,
    TrainWorkerMetadata,
)
from collections import defaultdict

import gc
import weakref


def wait_for_condition(condition_fn, timeout=5.0, check_interval=0.1):
    """Poll for a condition to become true within a timeout period.

    Args:
        condition_fn: Callable that returns True when condition is met
        timeout: Maximum time to wait in seconds
        check_interval: Time between checks in seconds

    Returns:
        True if condition was met, False if timeout occurred
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        if condition_fn():
            return True
        time.sleep(check_interval)
    return False


@pytest.fixture
def ray_start_2_cpus():
    if ray.is_initialized():
        ray.shutdown()

    try:
        address_info = ray.init(num_cpus=2, dashboard_port=8267)
        yield address_info
    # The code after the yield will run as teardown code.
    finally:
        ray.shutdown()


@pytest.fixture
def ray_start_2_cpus_and_gpus():
    if ray.is_initialized():
        ray.shutdown()

    try:
        address_info = ray.init(num_cpus=2, num_gpus=2, dashboard_port=8268)
        yield address_info
    # The code after the yield will run as teardown code.
    finally:
        ray.shutdown()


def test_worker_creation(ray_start_2_cpus):
    assert ray.available_resources()["CPU"] == 2
    wg = TrainWorkerGroup(num_workers_per_node=2)
    assert len(wg.workers) == 2
    assert len(wg.placement_groups) == 1
    # We need to sleep for a short period here as the avaiable_resource
    # is not updated immediately. Rather it depends on the the ray_syncer
    # which is boardcasted every 100ms by default.
    time.sleep(1)
    # Make sure both CPUs are being used by the actors.
    assert "CPU" not in ray.available_resources()
    wg.shutdown()


def test_worker_creation_num_cpus(ray_start_2_cpus):
    assert ray.available_resources()["CPU"] == 2
    wg = TrainWorkerGroup(resources_per_worker={"CPU": 2})
    time.sleep(1)
    assert len(wg.workers) == 1
    # Make sure both CPUs are being used by the actor.
    assert "CPU" not in ray.available_resources()
    wg.shutdown()


def test_worker_shutdown(ray_start_2_cpus):
    assert ray.available_resources()["CPU"] == 2
    wg = TrainWorkerGroup(num_workers_per_node=2)
    time.sleep(1)
    assert "CPU" not in ray.available_resources()
    assert len(ray._private.state.actors()) == 2
    wg.shutdown()
    time.sleep(1)
    assert ray.available_resources()["CPU"] == 2

    with pytest.raises(RuntimeError):
        wg.execute(lambda: 1)


def test_worker_with_gpu_ids(ray_start_2_cpus_and_gpus):
    num_gpus = 2
    wg = TrainWorkerGroup(num_workers_per_node=2, resources_per_worker={"GPU": 1})
    assert len(wg.workers) == 2
    time.sleep(1)
    assert ray_constants.GPU not in ray.available_resources()
    wg.execute(lambda: 1)
    assert len(wg.workers) == 2
    for w in wg.workers:
        resource_ids = w.metadata.resource_ids
        gpu_ids = resource_ids[ray_constants.GPU]
        for gpu_id in gpu_ids:
            assert gpu_id in [str(i) for i in range(num_gpus)]


def test_execute_async(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)
    futures = wg.execute_async(lambda: 1)
    assert len(futures) == 2
    outputs = ray.get(futures)

    assert all(o == 1 for o in outputs)


def test_execute(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)
    outputs = wg.execute(lambda: 1)
    assert len(outputs) == 2
    assert all(o == 1 for o in outputs)


def test_execute_with_args(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)
    outputs = wg.execute(lambda x: x, 1)
    assert len(outputs) == 2
    assert all(o == 1 for o in outputs)


def test_execute_single(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)

    def f():
        import os

        os.environ["TEST"] = "1"

    wg.execute_single(1, f)

    def check():
        import os

        return os.environ.get("TEST", "0")

    assert wg.execute(check) == ["0", "1"]

    with pytest.raises(ValueError):
        wg.execute_single(2, f)


def test_bad_resources(ray_start_2_cpus):
    with pytest.raises(ValueError):
        TrainWorkerGroup(resources_per_worker={"CPU": -1})

    with pytest.raises(ValueError):
        TrainWorkerGroup(resources_per_worker={"GPU": -1})

    with pytest.raises(ValueError):
        TrainWorkerGroup(resources_per_worker={"memory": -1})


def test_remove_workers(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)
    assert len(wg.workers) == 2
    wg.remove_workers([1])
    assert len(wg.workers) == 1
    wg.remove_workers([0])
    assert len(wg.workers) == 0


def test_sort_local_workers_by_gpu_id(ray_start_2_cpus):
    def modify_workers(worker_group, pids, node_ips, gpu_ids):
        # Create test workers just for asserting the sorting
        worker_group.workers = [
            Worker(
                actor=None,
                metadata=TrainWorkerMetadata(
                    node_id="dummy",
                    node_ip=node_ip,
                    hostname="dummy",
                    resource_ids={"GPU": gpu_id.split() if gpu_id else []},
                    pid=pid,
                ),
            )
            for pid, node_ip, gpu_id in zip(pids, node_ips, gpu_ids)
        ]
        return

    def setup_and_check_worker_group(
        worker_group: TrainWorkerGroup, pids, node_ips, gpu_ids, expected_local_ranks
    ):
        """
        Create a worker group, group workers by Node ID,
        and check local ranks assignment.

        Args:
            pids: List of unique process IDs.
            node_ids: List of Node IDs corresponding to each PID.
            gpu_ids: List of GPU IDs or None for each PID.
            expected_local_ranks: Dictionary mapping PID to the
                expected local rank.
        """

        modify_workers(
            worker_group=worker_group, pids=pids, node_ips=node_ips, gpu_ids=gpu_ids
        )
        worker_group.sort_workers_by_ip_and_gpu_id()

        # Build local ranks according to the logics in
        # `BackendExecutor._create_rank_world_size_mappings()`
        node_ip_dict: dict = defaultdict(int)
        local_ranks_map: dict = defaultdict(int)
        for w in worker_group.workers:
            local_ranks_map[w.metadata.pid] = node_ip_dict[w.metadata.node_ip]
            node_ip_dict[w.metadata.node_ip] += 1

        local_ranks = [local_ranks_map[pid] for pid in pids]

        assert (
            local_ranks == expected_local_ranks
        ), "Incorrect local ranks allocation!\n"
        f"Expect: {expected_local_ranks}\nGot: {local_ranks}"

    # Define the worker configurations for different scenarios
    # For workers without GPU resources, their original order will be preserved
    cpu_workers_config = {
        "pids": [0, 1, 2, 3, 4, 5, 6, 7],
        "node_ips": [
            "2.2.2.2",
            "2.2.2.2",
            "1.1.1.1",
            "1.1.1.1",
            "2.2.2.2",
            "1.1.1.1",
            "1.1.1.1",
            "2.2.2.2",
        ],
        "gpu_ids": [None] * 8,
        "expected_local_ranks": [0, 1, 0, 1, 2, 2, 3, 3],
    }

    gpu_workers_single_gpu_config = {
        "pids": [0, 1, 2, 3, 4, 5, 6, 7],
        "node_ips": [
            "2.2.2.2",
            "2.2.2.2",
            "1.1.1.1",
            "1.1.1.1",
            "2.2.2.2",
            "1.1.1.1",
            "1.1.1.1",
            "2.2.2.2",
        ],
        "gpu_ids": ["1", "0", "3", "2", "2", "0", "1", "3"],
        "expected_local_ranks": [1, 0, 3, 2, 2, 0, 1, 3],
    }

    # For workers with multiple gpus, sort by their lowest gpu id
    gpu_workers_multiple_gpus_config = {
        "pids": [0, 1, 2, 3],
        "node_ips": ["2.2.2.2", "1.1.1.1", "1.1.1.1", "2.2.2.2"],
        "gpu_ids": ["1,3", "2,1", "0,3", "0,2"],
        "expected_local_ranks": [1, 1, 0, 0],
    }

    # Setup and check worker groups for each configuration
    wg = TrainWorkerGroup(num_workers_per_node=2)
    setup_and_check_worker_group(wg, **cpu_workers_config)
    setup_and_check_worker_group(wg, **gpu_workers_single_gpu_config)
    setup_and_check_worker_group(wg, **gpu_workers_multiple_gpus_config)


def test_worker_length(ray_start_2_cpus):
    wg = TrainWorkerGroup(num_workers_per_node=2)
    assert len(wg) == 2


def test_train_worker_group_del_cleanup(ray_start_2_cpus):
    """Test that __del__ properly cleans up resources when object is garbage collected."""
    # Verify initial state
    assert ray.available_resources()["CPU"] == 2

    # Create worker group
    wg = TrainWorkerGroup(num_workers_per_node=2)

    # Verify workers are created
    assert len(wg.workers) == 2
    assert len(wg.placement_groups) == 1

    # Poll for resources to be consumed
    assert wait_for_condition(
        lambda: "CPU" not in ray.available_resources(), timeout=5.0
    ), "CPUs should be consumed by actors within timeout"

    # Create weak reference to track when object is deleted
    wg_ref = weakref.ref(wg)

    # Delete the object and force garbage collection
    del wg
    gc.collect()

    # Verify object was garbage collected
    assert wg_ref() is None, "Worker group should be garbage collected"

    # Poll for resources to be released after cleanup
    assert wait_for_condition(
        lambda: ray.available_resources().get("CPU") == 2, timeout=5.0
    ), "CPUs should be released after cleanup within timeout"
