from typing import Callable, Dict, List, Optional, Union, Tuple
from collections import defaultdict

from contextlib import closing
import socket
import os
import ray

from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.data.internal_data_connector import InternalDataConnector

from common_utils.common_util import get_total_node_resources
from entities.sharded_data_ingestor import ShardedDataConnector
from implementations.distributed_trainers.ray_utils import _get_usable_cpus_for_compute
from snowflake.runtime.utils.dev_env_python_path_utils import set_python_path_in_dev_env
from snowflake.runtime.utils.logger import get_logger, configure_ray_data_logging

from implementations.pytorch.train_worker import TrainWorkerGroup, Worker
from implementations.pytorch.torch_train_context import (
    init_torch_train_context,
    get_torch_train_context,
)
from web.jobs.common import (
    TrainV2Response,
    NON_COMPUTE_PERCENT_CPU_NODE,
    NON_COMPUTE_PERCENT_GPU_NODE,
)
from snowflake.ml.runtime_cluster.cluster_manager import get_ray_dashboard_url
import math

logger = get_logger()


def _calculate_default_cpu(use_gpu: bool) -> int:
    node_resources = get_total_node_resources()
    num_cpus_available_per_node = node_resources.get("CPU", 1)
    max_cpus_per_worker = (
        _get_usable_cpus_for_compute(
            num_cpus_available_per_node, NON_COMPUTE_PERCENT_CPU_NODE
        )
        if not use_gpu
        else _get_usable_cpus_for_compute(
            num_cpus_available_per_node, NON_COMPUTE_PERCENT_GPU_NODE
        )
    )
    return math.floor(max_cpus_per_worker)


def _create_rank_world_size_mappings(workers: List[Worker]) -> Tuple[Dict, Dict, Dict]:
    """Create rank and world size mappings for workers.
    There are three maps returned:
        - local_rank_map, which maps from worker world_rank to local_rank.
        - local_world_size_map, which maps from world_rank to local_world_size
        - node_rank_map, which maps from world rank to node rank
    Example:
        Worker -> Node ip
        Worker 0: 0.0.0.0
        Worker 1: 0.0.0.0
        Worker 2: 0.0.0.1
        Worker 3: 0.0.0.0
        Worker 4: 0.0.0.1
        Workers 0, 1, 3 are on node with ip 0.0.0.0.
        Workers 2, 4 are on node with ip 0.0.0.1.
        Expected local_rank_map: {world_rank -> local_rank}
        {
            0 -> 0,
            1 -> 1,
            2 -> 0,
            3 -> 2,
            4 -> 1
        }
        Expected local_world_size_map: {world_rank -> local_world_size}
        {
            0 -> 3,
            1 -> 3,
            2 -> 2,
            3 -> 3,
            4 -> 2
        }
        Expected node_rank_map: {world_rank -> node_rank}
        {
            0 -> 0,
            1 -> 0,
            2 -> 1,
            3 -> 0,
            4 -> 1
        }
    """
    local_rank_map = {}  # map from world rank to local rank
    local_world_size_map = {}  # map from world rank to local world size
    node_rank_map = {}  # map from world rank to node rank
    node_ips = {}  # map from node ip to node index
    node_cnt = 0  # count the number of nodes

    ip_dict: Dict[str, int] = defaultdict(
        int
    )  # map from node ip to the number of workers on it.
    for world_rank in range(len(workers)):
        worker = workers[world_rank]
        node_ip = worker.metadata.node_ip
        local_rank_map[world_rank] = ip_dict[node_ip]
        ip_dict[node_ip] += 1

        if node_ip not in node_ips:
            node_ips[node_ip] = node_cnt
            node_cnt += 1
        node_rank_map[world_rank] = node_ips[node_ip]

    for world_rank in range(len(workers)):
        worker = workers[world_rank]
        node_ip = worker.metadata.node_ip
        local_world_size_map[world_rank] = ip_dict[node_ip]

    workers_info = "\n".join(
        [
            f"- (ip={w.metadata.node_ip}, pid={w.metadata.pid}) "
            f"world_rank={i}, local_rank={local_rank_map[i]}, "
            f"node_rank={node_rank_map[i]}"
            for i, w in enumerate(workers)
        ]
    )
    logger.info(f"Started distributed worker processes: \n{workers_info}")

    return local_rank_map, local_world_size_map, node_rank_map


class TrainHelper:
    """Helper class for training."""

    @staticmethod
    def _setup_model_dir(model_dir: str) -> None:
        """Setup the model directory."""
        os.makedirs(model_dir, exist_ok=True)

    @staticmethod
    def _get_updated_model_files(model_dir: str) -> List[str]:
        """Get the updated model files."""
        context = get_torch_train_context()
        artifact_manager = context.get_artifact_manager()
        return artifact_manager.get_updated_model_files(model_dir)

    @staticmethod
    def _sync_files(model_dir: str, files: List[str]) -> None:
        """Compare local files with Snowflake stage and upload new or updated files."""
        context = get_torch_train_context()
        artifact_manager = context.get_artifact_manager()
        artifact_manager.upload_model_files_to_stage(model_dir, files)


class TorchTrainer:
    def __init__(
        self,
        *,
        train_func: Union[Callable[[], None], Callable[[Dict], None]],
        train_config: Optional[Dict] = None,
        num_nodes: int = 1,
        num_workers_per_node: int = 1,
        num_cpus_per_worker: int = 1,
        num_gpus_per_worker: int = 0,
        hyper_params: Dict[str, str],
        model_dir: str,
        dataset_map: Optional[Dict[str, DataConnector]],
        artifact_stage_location: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        self._train_func = train_func
        self._train_config = train_config

        self._num_nodes = num_nodes
        self._num_workers_per_node = num_workers_per_node
        self._num_cpus_per_worker = num_cpus_per_worker
        self._num_gpus_per_worker = num_gpus_per_worker
        self._model_dir = model_dir
        self._hyper_params = hyper_params
        self._dataset_map = dataset_map
        self._artifact_stage_location = artifact_stage_location

        self._request_id = request_id

    def _validate_scaling_config(self) -> None:
        # This validation happens after the scaling config is updated from
        # its specification in the Tuner `param_space`
        if self._num_gpus_per_worker <= 0 and "GPU" in ray.available_resources():
            logger.info(
                "GPUs are detected in your Ray cluster, but GPU "
                "training is not enabled for this trainer. To enable "
                "GPU training, make sure to set `use_gpu` to True "
                "in your scaling config."
            )

        if self._num_gpus_per_worker > 0 and "GPU" not in ray.available_resources():
            raise ValueError(
                "GPU training is requested but, GPUs are not available in the Ray cluster."
            )

        if self._num_nodes <= 0:
            raise ValueError("num_nodes must be >= 0.")

    def _share_resource_ids(
        self, resource: str = "GPU", env_var: str = "CUDA_VISIBLE_DEVICES"
    ):
        """Sets the given env_var on all workers to enable resource sharing.
        For each worker, the cores/devices are visible to all the
        workers on that worker's node.This allows workers on the
        same node to communicate with one another.
        Example:
            Setup:
            - Node1:
                - Worker1: {0, 1}
                - Worker2: {2, 3}
            - Node2:
                - Worker3: {0, 1}
            NEURON_RT_VISIBLE_CORES/TPU_VISIBLE_CHIPS/...:
            - Worker1: "0,1,2,3"
            - Worker2: "0,1,2,3"
            - Worker2: "0,1"
        Args:
            resource: The name of the resource/accelerator. "GPU", "neuron_cores", or "TPU"
            env_var: The name of the environment variable to set.
                "CUDA_VISIBLE_DEVICES", "NEURON_RT_VISIBLE_CORES", or "TPU_VISIBLE_CHIPS"
        """
        node_ids_and_resource_ids = [
            (
                w.metadata.node_id,
                w.metadata.resource_ids[resource],
            )
            for w in self.worker_group.workers
        ]
        node_id_to_worker_id = defaultdict(set)
        node_id_to_resource_ids = defaultdict(set)

        for worker_id, (node_id, resource_ids) in enumerate(node_ids_and_resource_ids):
            node_id_to_worker_id[node_id].add(worker_id)
            node_id_to_resource_ids[node_id].update(resource_ids)

        futures = []
        for node_id, resource_ids in node_id_to_resource_ids.items():
            resource_ids = sorted(resource_ids)
            all_resource_ids = ",".join(resource_ids)

            def set_resource_ids():
                os.environ[env_var] = all_resource_ids

            for worker_id in node_id_to_worker_id[node_id]:
                futures.append(
                    self.worker_group.execute_single_async(worker_id, set_resource_ids)
                )
        ray.get(futures)  # type: ignore[arg-type]

    def training_loop(self) -> TrainV2Response:
        self._validate_scaling_config()

        configure_ray_data_logging()

        resources_per_worker: Dict[str, float] = {}
        if self._num_cpus_per_worker != -1:
            resources_per_worker["CPU"] = self._num_cpus_per_worker
        else:
            resources_per_worker["CPU"] = _calculate_default_cpu(
                self._num_gpus_per_worker != 0
            )

        if self._num_gpus_per_worker > 0:
            resources_per_worker["GPU"] = self._num_gpus_per_worker

        self.worker_group = TrainWorkerGroup(
            num_nodes=self._num_nodes,
            num_workers_per_node=self._num_workers_per_node,
            resources_per_worker=resources_per_worker,
        )

        self.worker_group.execute(set_python_path_in_dev_env)

        self.worker_group.sort_workers_by_ip_and_gpu_id()
        self._share_resource_ids()

        # master_addr and master_port
        def get_address_and_port() -> Tuple[str, int]:
            """Returns the IP address and a free port on this node."""
            addr = ray.util.get_node_ip_address()
            with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
                s.bind(("", 0))
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                free_port = s.getsockname()[1]
            return addr, free_port

        master_addr, master_port = self.worker_group.execute_single(
            0, get_address_and_port
        )

        (
            local_rank_map,
            local_world_size_map,
            node_rank_map,
        ) = _create_rank_world_size_mappings(self.worker_group.workers)

        world_size = len(self.worker_group)

        if self._dataset_map is not None:
            for k, dataset in self._dataset_map.items():
                if isinstance(dataset, ShardedDataConnector):
                    # Pre-shard the data into the same number of shards as the trainer's `world_size`.
                    dataset.prepare_shards(num_shards=world_size)
                elif not isinstance(dataset, InternalDataConnector):
                    self._dataset_map[k] = InternalDataConnector(
                        ingestor=dataset._ingestor, **dataset._kwargs
                    )

        futures = []
        for index in range(len(self.worker_group)):
            futures.append(
                self.worker_group.execute_single_async(
                    index,
                    init_torch_train_context,
                    training_func=self._train_func,
                    world_rank=index,
                    local_rank=local_rank_map[index],
                    node_rank=node_rank_map[index],
                    local_world_size=local_world_size_map[index],
                    world_size=world_size,
                    master_addr=master_addr,
                    master_port=master_port,
                    model_dir=self._model_dir,
                    hyper_params=self._hyper_params,
                    dataset_map=self._dataset_map,
                    artifact_stage_location=self._artifact_stage_location,
                    request_id=self._request_id,
                )
            )
        ray.get(futures)  # type: ignore[arg-type]

        self.worker_group.execute_async(TrainHelper._setup_model_dir, self._model_dir)

        # Print Ray dashboard URL for rank 0 worker logs
        try:
            dashboard_url = get_ray_dashboard_url()
            rank_0_actor = self.worker_group.workers[0].actor
            actor_id = rank_0_actor._actor_id.hex()
            log_url = f"{dashboard_url}/#/actors/{actor_id}"
            print(f"Ray Dashboard URL for Rank 0 Worker Logs: {log_url}")
        except Exception as e:
            logger.error(f"Could not generate Ray dashboard URL: {e}")

        # Run training function asynchronously
        def train():
            context = get_torch_train_context()
            context.start_training()

        self.worker_group.execute(train)

        def wait_for_completion():
            context = get_torch_train_context()
            context.wait_for_completion()

        self.worker_group.execute(wait_for_completion)

        def get_metrics():
            context = get_torch_train_context()
            return context.get_metrics_reporter().get_metrics()

        # Only metrics from rank 0 worker will be used. However, in order to ensure consistency,
        # metrics_reporter.report_metrics() is callable on each worker.
        metrics = self.worker_group.execute_single(0, get_metrics)

        # Sync model files
        if self._artifact_stage_location:
            all_files = set()
            worker_to_updated_files = defaultdict(list)
            for i in range(len(self.worker_group)):
                updated_files = self.worker_group.execute_single(
                    i, TrainHelper._get_updated_model_files, self._model_dir
                )
                worker_to_updated_files[i] = [
                    f for f in updated_files if f not in all_files
                ]
                all_files.update(updated_files)

            upload_tasks = []
            for i in range(len(self.worker_group)):
                if worker_to_updated_files[i]:
                    upload_tasks.append(
                        self.worker_group.execute_single_async(
                            i,
                            TrainHelper._sync_files,
                            self._model_dir,
                            worker_to_updated_files[i],
                        )
                    )
            ray.get(upload_tasks)

        def get_artifact_locations():
            context = get_torch_train_context()
            try:
                artifact_manager = context.get_artifact_manager()
                return (
                    artifact_manager.get_checkpoint_location(),
                    artifact_manager.get_model_location(),
                )
            except RuntimeError:
                # Fallback when artifact_stage_location was not provided
                return ("", context.get_model_dir())
            except Exception:
                return ("", "")

        checkpoint_location, model_location = self.worker_group.execute_single(
            0, get_artifact_locations
        )

        return TrainV2Response(
            metrics=metrics,
            checkpoint_location=checkpoint_location,
            model_location=model_location,
        )
