from typing import Callable, Optional, List, Dict, Any
import time
import os
import sys
from threading import Thread
import ray
import traceback

from snowflake.snowpark import Session
from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.modeling.distributors.pytorch.artifact_manager import (
    ArtifactManager,
    StageArtifactManager,
)

from snowflake.runtime.utils import session_utils


class UserCodeError(Exception):
    pass


class ErrorRaisingThread(Thread):
    def __init__(self, target: Callable, rank: int = 0):
        super().__init__(target=target)
        self.rank = rank

    def run(self):
        self.exc = None
        # Redirect stdout and stderr for non-rank-0 workers to suppress their print statements
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        if self.rank != 0:
            sys.stdout = open(os.devnull, "w")
            sys.stderr = open(os.devnull, "w")

        try:
            self.ret = self._target(*self._args, **self._kwargs)
        except BaseException as e:
            ex_info = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            self.exc = UserCodeError(ex_info)
        finally:
            # Restore original stdout and stderr
            if self.rank != 0:
                sys.stdout.close()
                sys.stderr.close()
            sys.stdout = original_stdout
            sys.stderr = original_stderr

    def join(self, timeout=None):
        super(ErrorRaisingThread, self).join(timeout)
        if self.exc:
            raise self.exc
        return self.ret


class TorchMetricsReporter:
    def __init__(self, rank: int):
        self.rank = rank
        self.metrics: Dict[str, Any] = {}

    def log_metrics(self, metrics: Dict[str, Any]):
        # TODO: Stream metrics to client.
        # For now just log them so that they can be seen in the notebook logs.
        print(f"[Rank={self.rank}]: {metrics}")
        for name, value in metrics.items():
            self.metrics[name] = value

    def get_metrics(self) -> Dict[str, Any]:
        return self.metrics


class TorchTrainContext:
    """Holds information for training on each worker."""

    def __init__(
        self,
        training_func: Callable,
        world_rank: int,
        local_rank: int,
        node_rank: int,
        local_world_size: int,
        world_size: int,
        master_addr: str,
        master_port: int,
        model_dir: str,
        dataset_map: Optional[Dict[str, DataConnector]] = None,
        hyper_params: Optional[Dict[str, str]] = None,
        artifact_stage_location: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        self.world_rank = world_rank
        self.local_rank = local_rank
        self.node_rank = node_rank
        self.local_world_size = local_world_size
        self.world_size = world_size
        self.master_addr = master_addr
        self.master_port = master_port
        self.model_dir = model_dir
        self.dataset_map = dataset_map
        self.hyper_params = hyper_params

        self.last_report_time = time.time()
        self.iteration = 0
        self.time_total = 0.0
        self.local_ip = ray.util.get_node_ip_address()

        self.accelerator = None

        self.artifact_stage_location = artifact_stage_location

        self.runner_thread = ErrorRaisingThread(target=training_func, rank=world_rank)
        self.metrics_reporter = TorchMetricsReporter(rank=world_rank)

        self.request_id = request_id

        # Use StageArtifactManager if stage location is provided
        self.artifact_manager = None
        if self.artifact_stage_location:
            self.artifact_manager = StageArtifactManager(
                session=session_utils.get_session(),
                stage_location=self.artifact_stage_location,
                request_id=self.request_id,
            )

    def get_world_size(self) -> int:
        """
        Number of workers(or processes) participating in the job.
        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then the world size is 8 (2 nodes * 4 GPUs per node. Usually each GPU corresponds
        to a training process.)
        """
        return self.world_size

    def get_rank(self) -> int:
        """
        Rank of the current process across all the processes in the world. Rank is
        the unique ID given to a process to identify it uniqely across the world.
        Rank should be a number between 0 and world_size-1.
        **Some frameworks aslo call it world_rank, to distinguish it from local_rank.**
        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then the rank of workers will be [0, 1, 2, 3, 4, 5, 6, 7], i.e., 0 to world_size-1.
        """
        return self.world_rank

    def get_local_rank(self) -> int:
        """
        Local rank is the a unique local ID for worker (or process) running in the current node.
        For example, if training is running on 2 nodes (servers) each with 4 GPUs, then
        local rank for workers(or processes) running on node 0 will be [0, 1, 2, 3] and
        similarly four workers(or processes) running on node 1 will have local_rank [0, 1, 2, 3].
        """
        return self.local_rank

    def get_local_world_size(self) -> int:
        """
        Number of workers(or processes) running in the current node.
        For example, if training is running on 2 nodes (servers) each with 4 GPUs, then
        local_world_size will be 4 for all processes on node 0 and node 1, because each node
        is running 4 workers (one worker of process per GPU on the node).
        """
        return self.local_world_size

    def get_node_rank(self) -> int:
        """
        Rank of current node across all the nodes in the world. Node rank is the unique Id given
        to each node to identify it uniqely across all the node in the world.
        For example, if training is running on 2 nodes (servers) each with 4 GPUs, then node rank for
        the two nodes will be 0, 1 respectively.
        """
        return self.node_rank

    def get_master_addr(self) -> str:
        """
        IP address of the master node, i.e., address of the node with node_rank 0.
        """
        return self.master_addr

    def get_master_port(self) -> int:
        """
        The port on the master_addr that hosts the rendezvous server.
        """
        return self.master_port

    def get_default_backend(self) -> str:
        """
        Default backend selected by the MCE.
        """
        return "gloo"

    def get_supported_backends(self) -> List[str]:
        """
        List of supported backends by MCE.
        """
        return ["gloo", "mpi", "nccl"]

    def get_hyper_params(self) -> Optional[Dict[str, str]]:
        """
        Hyper param map provided to trainer.run(...) method.
        """
        return self.hyper_params

    def get_dataset_map(self) -> Optional[Dict[str, DataConnector]]:
        """
        Dataset map provided to trainer.run(...) method.
        """
        return self.dataset_map

    def get_model_dir(self) -> str:
        """Return the path to a directory where the model should be saved.
        All the model artifacts written to this directory will be preserved after the training job.

        Returns:
            str: The path to the model directory.
        """
        return self.model_dir

    def get_metrics_reporter(self) -> TorchMetricsReporter:
        """Return the metric reporter object for logging training metrics.

        Returns:
            MetricReporter: An instance of the MetricReporter interface.
        """
        return self.metrics_reporter

    def get_session(self) -> Session:
        return session_utils.get_session()

    def get_artifact_manager(self) -> ArtifactManager:
        """Return the artifact manager for handling model and checkpoint artifacts.

        Returns:
            ArtifactManager: The configured artifact manager instance.

        Raises:
            RuntimeError: If artifact_stage_location was not provided to trainer.run().
        """
        if self.artifact_manager is None:
            raise RuntimeError(
                "ArtifactManager is not available. To use checkpoint and artifact management features, "
                "please provide 'artifact_stage_location' parameter to trainer.run() method. "
                "Example: trainer.run(dataset_map=..., artifact_stage_location='@my_stage')"
            )
        return self.artifact_manager

    def start_training(self) -> None:
        self.runner_thread.start()

    def wait_for_completion(self) -> None:
        self.runner_thread.join()


# Global context
_torch_train_context: Optional[TorchTrainContext] = None


def init_torch_train_context(
    training_func: Callable,
    world_rank: int,
    local_rank: int,
    node_rank: int,
    local_world_size: int,
    world_size: int,
    master_addr: str,
    master_port: int,
    model_dir: str,
    dataset_map: Optional[Dict[str, DataConnector]] = None,
    hyper_params: Optional[Dict[str, str]] = None,
    artifact_stage_location: Optional[str] = None,
    request_id: Optional[str] = None,
) -> None:
    global _torch_train_context
    if _torch_train_context:
        raise ValueError("TorchTrainContext is already in initialized.")

    _torch_train_context = TorchTrainContext(
        training_func=training_func,
        world_rank=world_rank,
        local_rank=local_rank,
        node_rank=node_rank,
        local_world_size=local_world_size,
        world_size=world_size,
        master_addr=master_addr,
        master_port=master_port,
        model_dir=model_dir,
        dataset_map=dataset_map,
        hyper_params=hyper_params,
        artifact_stage_location=artifact_stage_location,
        request_id=request_id,
    )

    # Setup env variables to enable environment based initialization of torch.dist.init_process_group(...)
    os.environ["MASTER_ADDR"] = master_addr
    os.environ["MASTER_PORT"] = str(master_port)
    os.environ["WORLD_SIZE"] = str(world_size)
    os.environ["RANK"] = str(world_rank)
    os.environ["LOCAL_RANK"] = str(local_rank)
    os.environ["LOCAL_WORLD_SIZE"] = str(local_world_size)
    os.environ["NCCL_SOCKET_IFNAME"] = "eth"  # Required for NCCL backend
    os.environ["NCCL_SOCKET_NTHREADS"] = str(4)  # Required for NCCL performance


def get_torch_train_context() -> TorchTrainContext:
    if _torch_train_context is None:
        raise ValueError("TorchTrainContext is not yet initialized.")
    return _torch_train_context
