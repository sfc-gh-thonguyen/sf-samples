import pytest
import unittest
from implementations.pytorch.torch_train_context import (
    TorchMetricsReporter,
    ErrorRaisingThread,
    UserCodeError,
    init_torch_train_context,
    get_torch_train_context,
)
from snowflake.ml.data.data_connector import DataConnector
from unittest.mock import Mock


@pytest.fixture
def reporter():
    return TorchMetricsReporter(rank=0)


def test_log_metrics_partial_update(reporter):
    initial_metrics = {"accuracy": 0.95, "loss": 0.0}
    reporter.log_metrics(initial_metrics)
    new_metrics = {"loss": 0.05, "auc": 0.8}
    reporter.log_metrics(new_metrics)
    response = reporter.get_metrics()
    assert len(response) == 3
    assert response["accuracy"] == 0.95
    assert response["loss"] == 0.05
    assert response["auc"] == 0.8


def test_get_metrics_empty(reporter):
    assert reporter.get_metrics() == {}


class TorchTrainContextTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_torch_train_context(
            training_func=Mock(),
            world_rank=0,
            local_rank=0,
            node_rank=0,
            local_world_size=1,
            world_size=1,
            master_addr="127.0.0.1",
            master_port=12345,
            model_dir="/tmp/model",
            dataset_map={"train": Mock(spec=DataConnector)},
            hyper_params={"lr": "0.01"},
        )

    def test_train_context(self):
        torch_train_context = get_torch_train_context()
        assert torch_train_context.get_world_size() == 1
        assert torch_train_context.get_rank() == 0
        assert torch_train_context.get_local_rank() == 0
        assert torch_train_context.get_local_world_size() == 1
        assert torch_train_context.get_node_rank() == 0
        assert torch_train_context.get_master_addr() == "127.0.0.1"
        assert torch_train_context.get_master_port() == 12345
        assert torch_train_context.get_default_backend() == "gloo"
        assert torch_train_context.get_supported_backends() == ["gloo", "mpi", "nccl"]
        assert torch_train_context.get_hyper_params() == {"lr": "0.01"}
        assert "train" in torch_train_context.get_dataset_map()
        assert torch_train_context.get_model_dir() == "/tmp/model"
        reporter = torch_train_context.get_metrics_reporter()
        assert isinstance(reporter, TorchMetricsReporter)
        assert reporter.rank == 0

    def test_duplicate_initialization_raises(self):
        with pytest.raises(ValueError):
            init_torch_train_context(
                training_func=Mock(),
                world_rank=0,
                local_rank=0,
                node_rank=0,
                local_world_size=1,
                world_size=1,
                master_addr="127.0.0.1",
                master_port=12345,
                model_dir="/tmp/model",
                dataset_map={"train": Mock(spec=DataConnector)},
                hyper_params={"lr": "0.01"},
            )


def test_error_raising_thread():
    def faulty_func():
        raise ValueError("Test error")

    thread = ErrorRaisingThread(target=faulty_func)
    thread.start()
    with pytest.raises(UserCodeError):
        thread.join()


if __name__ == "__main__":
    pytest.main()
