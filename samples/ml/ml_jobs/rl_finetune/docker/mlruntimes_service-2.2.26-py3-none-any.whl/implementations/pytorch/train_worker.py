import os
import socket
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, TypeVar

import ray
from ray.actor import ActorHandle
from ray.types import ObjectRef

from ray.util.placement_group import (
    PlacementGroup,
    placement_group,
    remove_placement_group,
)
from ray.util.scheduling_strategies import PlacementGroupSchedulingStrategy

from snowflake.runtime.utils.ray_utils import get_node_ip_address
from snowflake.runtime.utils.logger import get_logger, configure_ray_data_logging

logger = get_logger()

T = TypeVar("T")


class TrainWorker:
    """
    An actor class to execute training related functions. Does not hold any state.

    There is no static @remote annotation on this class to enable dynamically setting
    resource requirements for the actors.
    """

    def __execute(self, func: Callable[..., T], *args, **kwargs) -> T:
        """Executes the input function and returns the output.
        Args:
            func: The function to execute.
            args, kwargs: The arguments to pass into func.
        """
        os.chdir(os.path.expanduser("~"))

        configure_ray_data_logging()

        return func(*args, **kwargs)


@dataclass
class TrainWorkerMetadata:
    """Metadata for each train worker/actor.
    Args:
        node_id: ID of the node this worker is on.
        node_ip: IP address of the node this worker is on.
            # TODO: IP is going to be 0.0.0.0 for all the workers.
            # Work with SPCS to get proper IP address for each node.
        hostname: Hostname that this worker is on.
        resource_ids: Map of accelerator resources
            ("GPU", "neuron_cores", ..) to their IDs.
        pid: Process ID of this worker.
    """

    node_id: str
    node_ip: str
    hostname: str
    resource_ids: Dict[str, List[str]]
    pid: int


@dataclass
class Worker:
    """Class representing a Worker."""

    actor: ActorHandle
    metadata: TrainWorkerMetadata


def construct_metadata() -> TrainWorkerMetadata:
    """Creates metadata for this worker.
    This function is expected to be run on the actor.
    """
    node_id = ray.get_runtime_context().get_node_id()
    node_ip = get_node_ip_address()
    hostname = socket.gethostname()
    accelerator_ids = ray.get_runtime_context().get_accelerator_ids()
    pid = os.getpid()

    return TrainWorkerMetadata(
        node_id=node_id,
        node_ip=node_ip,
        hostname=hostname,
        resource_ids=accelerator_ids,
        pid=pid,
    )


class TrainWorkerGroup:
    """Group of Ray Actors that can execute arbitrary functions.
    Args: TrainArgs:
        num_workers: The number of workers (Ray actors) to launch.
        resources_per_worker (Optional[Dict[str, float]]):
            Dictionary specifying the resources that will be
            requested for each worker.
    """

    def __init__(
        self,
        num_nodes: int = 1,
        num_workers_per_node: int = 1,
        resources_per_worker: Optional[Dict[str, float]] = None,
    ):
        if resources_per_worker is None:
            resources_per_worker = {"CPU": 1}
        else:
            resources_per_worker = resources_per_worker.copy()

        # TODO: Move to API handling layer.
        # if num_workers <= 0:
        #     raise ValueError(
        #         "The provided `num_workers` must be greater "
        #         f"than 0. Received num_workers={num_workers} "
        #         f"instead."
        #     )

        if any(v < 0 for v in resources_per_worker.values()):
            raise ValueError(
                "The number of resources per worker must not be negative. "
                f"Received resources_per_worker={resources_per_worker}."
            )

        self.num_nodes = num_nodes
        self.num_workers_per_node = num_workers_per_node

        self.num_cpus_per_worker = resources_per_worker.pop("CPU", 0)
        self.num_gpus_per_worker = resources_per_worker.pop("GPU", 0)
        self.memory_per_worker = resources_per_worker.pop("memory", 0)

        bundle = {}
        if self.num_cpus_per_worker > 0:
            bundle["CPU"] = self.num_cpus_per_worker
        if self.num_gpus_per_worker > 0:
            bundle["GPU"] = self.num_gpus_per_worker
        if self.memory_per_worker > 0:
            bundle["memory"] = self.memory_per_worker

        # We need to create #num_nodes placement groups with #num_workers_per_node bundles per group
        # and with placcement strategy "STRICT_PACK". Placement strategy "STRICT_PACK" ensures that
        # bundles with in the same group don't cross the node boundary.
        self.placement_groups = []
        try:
            for i in range(0, self.num_nodes):
                bundles = [bundle] * num_workers_per_node
                pg = placement_group(bundles=bundles, strategy="STRICT_PACK")
                ray.get(pg.ready(), timeout=10)
                self.placement_groups.append(pg)
        except Exception:
            raise RuntimeError(
                f"Insufficient Resources: Failed to reserve {self.num_nodes} group(s) of "
                f"{self.num_workers_per_node} workers, each requiring {bundle} resources per worker."
            )

        self.workers: List[Worker] = []
        self._shutdown_called = False

        self._placement_group = "default"

        self._remote_cls = ray.remote(
            num_cpus=self.num_cpus_per_worker,
            num_gpus=self.num_gpus_per_worker,
            memory=self.memory_per_worker,
            resources=resources_per_worker,
        )(TrainWorker)
        self.start()

    def start(self):
        """Starts all the workers in this worker group."""
        if self.workers and len(self.workers) > 0:
            raise RuntimeError(
                "The workers have already been started. "
                "Please call `shutdown` first if you want to "
                "restart them."
            )

        logger.info(
            f"Starting {self.num_nodes * self.num_workers_per_node} workers spread across {self.num_nodes} node(s)."
        )
        for i in range(0, self.num_nodes):
            self.add_workers(self.num_workers_per_node, self.placement_groups[i])
        logger.info(f"{len(self.workers)} workers have successfully started.")

    def shutdown(self, timout_s: float = 5):
        """Shutdown all the workers in this worker group.
        Args:
            timout_s: Attempt a graceful shutdown
                of the workers for this many seconds. Fallback to force kill
                if graceful shutdown is not complete after this time.
        """
        if hasattr(self, "_shutdown_called") and self._shutdown_called:
            return
        self._shutdown_called = True
        logger.debug(f"Shutting down {len(self.workers)} workers.")
        done_refs = [w.actor.__ray_terminate__.remote() for w in self.workers]
        # Wait for actors to die gracefully.
        done, not_done = ray.wait(done_refs, timeout=timout_s)
        if not_done:
            logger.debug("Graceful termination failed. Falling back to force kill.")
            # If all actors are not able to die gracefully, then kill them.
            for worker in self.workers:
                ray.kill(worker.actor)

        for pg in self.placement_groups:
            remove_placement_group(pg)

        logger.debug("Shutdown successful.")
        self.workers = []
        self.placement_groups = []

    def execute_async(self, func: Callable[..., T], *args, **kwargs) -> List[ObjectRef]:
        """Execute ``func`` on each worker and return the futures.
        Args:
            func: A function to call on each worker.
            args, kwargs: Passed directly into func.
        Returns:
            (List[ObjectRef]) A list of ``ObjectRef`` representing the
                output of ``func`` from each worker. The order is the same
                as ``self.workers``.
        """
        if len(self.workers) <= 0:
            raise RuntimeError(
                "There are no active workers. This worker "
                "group has most likely been shut down. Please"
                "create a new WorkerGroup or restart this one."
            )

        return [
            w.actor._TrainWorker__execute.options(
                name=f"_TrainWorker__execute.{func.__name__}"
            ).remote(func, *args, **kwargs)
            for w in self.workers
        ]

    def execute(self, func: Callable[..., T], *args, **kwargs) -> List[T]:
        """Execute ``func`` on each worker and return the outputs of ``func``.
        Args:
            func: A function to call on each worker.
            args, kwargs: Passed directly into func.
        Returns:
            (List[T]) A list containing the output of ``func`` from each
                worker. The order is the same as ``self.workers``.
        """
        return ray.get(self.execute_async(func, *args, **kwargs))  # type: ignore[arg-type]

    def execute_single_async(
        self, worker_index: int, func: Callable[..., T], *args, **kwargs
    ) -> ObjectRef:
        """Execute ``func`` on worker ``worker_index`` and return futures.
        Args:
            worker_index: The index to execute func on.
            func: A function to call on the first worker.
            args, kwargs: Passed directly into func.
        Returns:
            (ObjectRef) An ObjectRef representing the output of func.
        """
        if worker_index >= len(self.workers):
            raise ValueError(
                f"The provided worker_index {worker_index} is "
                f"not valid for {len(self.workers)} workers."
            )
        return (
            self.workers[worker_index]
            .actor._TrainWorker__execute.options(
                name=f"_TrainWorker__execute.{func.__name__}"
            )
            .remote(func, *args, **kwargs)
        )

    def execute_single(
        self, worker_index: int, func: Callable[..., T], *args, **kwargs
    ) -> T:
        """Execute ``func`` on worker with index ``worker_index``.
        Args:
            worker_index: The index to execute func on.
            func: A function to call on the first worker.
            args, kwargs: Passed directly into func.
        Returns:
            (T) The output of func.
        """

        return ray.get(self.execute_single_async(worker_index, func, *args, **kwargs))  # type: ignore[call-overload]

    def remove_workers(self, worker_indexes: List[int]):
        """Removes the workers with the specified indexes.
        The removed workers will go out of scope and their actor processes
        will be terminated.
        Args:
            worker_indexes (List[int]): The indexes of the workers to remove.
        """
        new_workers = []
        for i in range(len(self.workers)):
            if i not in worker_indexes:
                new_workers.append(self.workers[i])
        self.workers = new_workers

    def add_workers(self, num_workers: int, placement_group: PlacementGroup):
        """Adds ``num_workers`` to this WorkerGroup.
        Args:
            num_workers: The number of workers to add.
            placement_group: Placement group to place the worker in.
        """
        new_actors = []
        new_actor_metadata = []
        for _ in range(num_workers):
            actor = self._remote_cls.options(
                scheduling_strategy=PlacementGroupSchedulingStrategy(
                    placement_group=placement_group,
                )
            ).remote()
            new_actors.append(actor)
            new_actor_metadata.append(
                actor._TrainWorker__execute.options(
                    name="_TrainWorker__execute.construct_metadata"
                ).remote(construct_metadata)
            )

        # Get metadata from all actors.
        metadata = ray.get(new_actor_metadata)

        for i in range(len(new_actors)):
            self.workers.append(Worker(actor=new_actors[i], metadata=metadata[i]))

    def sort_workers_by_ip_and_gpu_id(self, _first_ip: Optional[str] = None):
        """Reorder the workers by their node ip and the lowest GPU id.
        This is useful for collocating workers on the same node.
        Example:
            Given workers with the following attributes:
                worker_0: ip=1, gpu_ids=[1]
                worker_1: ip=0, gpu_ids=[0]
                worker_2: ip=1, gpu_ids=[0]
                worker_3: ip=0, gpu_ids=[1]
            The function will perform the following steps:
                1. Group by node IP:
                    ip=0: worker_1, worker_3
                    ip=1: worker_0, worker_2
                2. Sort each group by GPU ID:
                    ip=0: worker_1 (gpu_id=0), worker_3 (gpu_id=1)
                    ip=1: worker_2 (gpu_id=0), worker_0 (gpu_id=1)
            Resulting in the order: [worker_1, worker_3, worker_2, worker_0]
        Args:
            _first_ip: The first IP to group by.
                Set this to the node IP of the trainer coordinator to ensure that the
                rank 0 worker is on the same node.
        """
        ip_to_workers: Dict[str, List[Worker]] = defaultdict(list)

        if _first_ip is not None:
            ip_to_workers[_first_ip] = []

        for worker in self.workers:
            ip_to_workers[worker.metadata.node_ip].append(worker)

        # Sort workers on the same node by the lowest GPU id
        # More details: https://github.com/ray-project/ray/issues/40803
        def get_lowest_gpu_id(worker) -> int:
            gpu_ids = worker.metadata.resource_ids.get("GPU", [])
            # If there are no GPU IDs, return 0 as a default
            if not gpu_ids:
                return 0

            # Attempt to convert GPU IDs to integers and find the minimum ID.
            # Fallback to return the minimum string-based ID
            try:
                return min(int(gpu_id) for gpu_id in gpu_ids)
            except ValueError:
                return min(gpu_ids)

        for node_ip in ip_to_workers:
            ip_to_workers[node_ip].sort(key=get_lowest_gpu_id)

        sorted_workers = []
        for workers in ip_to_workers.values():
            sorted_workers.extend(workers)

        self.workers = sorted_workers

    def __len__(self):
        return len(self.workers)

    # This is required on cases where the TrainWorkerGroup is not
    # explicitly shutdown. For non-Rayjob, we need this to ensure all placement groups
    # are fully cleaned up even with unexpected interruptions.
    def __del__(self):
        try:
            if not ray.is_initialized():
                return
            self.shutdown()
        except Exception as e:
            logger.warning(f"Failed to shutdown train worker group: {e}")
