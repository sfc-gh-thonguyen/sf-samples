"""
Configuration management for the Code Sandbox.

This module handles configuration loading from environment variables
and provides default values for the sandbox application.
"""

import logging
from typing import Dict, Any
from pydantic import Field, field_validator, ConfigDict
from pydantic_settings import BaseSettings


class SandboxConfig(BaseSettings):
    """Configuration settings for the Code Sandbox."""

    # Server settings
    sandbox_port: int = Field(default=50053, description="Server port")
    sandbox_host: str = Field(default="0.0.0.0", description="Server host")

    # Logging settings
    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
    )

    # Kernel management settings
    # Defaults to 5 minutes, can be overridden by environment variable
    cleanup_interval: int = Field(
        default=60 * 5,
        description="Time in seconds for a kernel to be idle before cleanup",
    )

    # Execution settings
    # Defaults to 60 minutes, can be overridden by environment variable
    execution_timeout: int = Field(
        default=60 * 60, description="Execution timeout for a single code query"
    )

    model_config = ConfigDict(
        env_prefix="SANDBOX_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore extra environment variables
    )

    # Add properties for backward compatibility with the original field names
    @property
    def port(self) -> int:
        return self.sandbox_port

    @property
    def host(self) -> str:
        return self.sandbox_host

    @field_validator("sandbox_port")
    @classmethod
    def validate_port(cls, v):
        if v < 1 or v > 65535:
            raise ValueError(f"Port must be between 1 and 65535, got {v}")
        return v

    @field_validator("execution_timeout")
    @classmethod
    def validate_execution_timeout(cls, v):
        if v < 20:
            raise ValueError(f"execution_timeout must be >= 20, got {v}")
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v):
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"log_level must be one of {valid_levels}, got {v}")
        return v.upper()

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary for logging."""
        return {
            "port": self.port,
            "host": self.host,
            "log_level": self.log_level,
            "cleanup_interval": self.cleanup_interval,
            "execution_timeout": self.execution_timeout,
        }


def setup_logging(config: SandboxConfig) -> None:
    """Set up logging based on configuration."""
    # Convert string log level to logging constant
    log_level = getattr(logging, config.log_level.upper())

    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Configure specific loggers
    logging.getLogger("werkzeug").setLevel(logging.WARNING)  # Reduce Flask request logs

    logger = logging.getLogger(__name__)
    logger.info(f"Logging configured with level: {config.log_level}")


def get_config() -> SandboxConfig:
    """Get the application configuration."""
    return SandboxConfig()
