"""
Kernel Manager for Code Sandbox
"""

import os
import time
import asyncio
import logging
import json
import uuid
from typing import AsyncGenerator, Dict, List, Optional, Tuple
from jupyter_client import AsyncKernelManager as JupyterKernelManager
from jupyter_client import AsyncKernelClient as JupyterKernelClient
from jupyter_client.kernelspec import KernelSpecManager
import re

from data_science_agent.code_sandbox.models import (
    ExecutionMessage,
    ErrorMessage,
    KernelStatus,
    EventName,
)
from data_science_agent.code_sandbox.exceptions import (
    SandboxKernelNotFoundError,
    SandboxKernelBusyError,
    SandboxKernelCreationError,
    SandboxKernelExecutionError,
    SandboxKernelTimeoutError,
    SandboxKernelSessionInitializationError,
)

logger = logging.getLogger(__name__)

ENABLE_SANDBOX_READ_ONLY_MODE = (
    os.getenv("ENABLE_SANDBOX_READ_ONLY_MODE", "true").lower() == "true"
)


def get_session_start_code(enable_read_only_mode: bool) -> str:
    """Generate session initialization code with proper error handling."""
    return f"""
from snowflake.runtime.utils.session_utils import get_session
from snowflake.snowpark.exceptions import SnowparkSQLException

try:
    # Initialize session
    print("Initializing sandbox session...")
    session = get_session()
    assert session is not None, "Session not initialized"

    # Set read-only mode if enabled
    if {enable_read_only_mode}:
        try:
            result = session.sql("ALTER SESSION SET CORTEX_READ_ONLY = true").collect()
            print("Successfully enabled CORTEX_READ_ONLY mode")
        except SnowparkSQLException as e:
            # Print warning but don't fail initialization if read-only mode can't be set
            print(f"Warning: Could not set CORTEX_READ_ONLY mode: {{e}}")
        except Exception as e:
            print(f"Warning: Unexpected error setting CORTEX_READ_ONLY mode: {{e}}")

    print("Sandbox session initialized successfully")

except Exception as e:
    print(f"ERROR: Failed to initialize sandbox session: {{e}}")
    raise RuntimeError(f"Session initialization failed: {{e}}")
"""


class SandboxKernel:
    def __init__(self, id: str, execution_timeout_seconds: int):
        """
        Initialize the SandboxKernel.
        Args:
            id (str): Unique identifier for the kernel.
            execution_timeout_seconds (int): Timeout for code execution in seconds.
        """
        self.kernel_manager: JupyterKernelManager = JupyterKernelManager()
        self.id: str = id
        self.status: KernelStatus = KernelStatus.PENDING
        self.execution_timeout_seconds: int = execution_timeout_seconds
        self.last_activity: float = time.time()
        self.session_initialized: bool = False

    async def startup(self):
        """
        Start the Jupyter kernel and set up the client.
        This method initializes the kernel manager and client, setting the status to AVAILABLE.
            Raises:
                SandboxKernelCreationError: If the kernel cannot be started.
        """
        try:
            await self.kernel_manager.start_kernel()
            self.kernel_client: JupyterKernelClient = self.kernel_manager.client()
            self.kernel_client.start_channels()
            await self.kernel_client.wait_for_ready(timeout=30)
            await self._initialize_session()
            self.status = KernelStatus.AVAILABLE
        except Exception as e:
            logger.error(f"Failed to start kernel {self.id}: {e}")
            # Ensure kernel is properly cleaned up on startup failure
            try:
                if hasattr(self, "kernel_client") and self.kernel_client:
                    self.kernel_client.stop_channels()
                if await self.kernel_manager._async_is_alive():
                    await self.kernel_manager.shutdown_kernel(now=True)
            except Exception as cleanup_error:
                logger.error(
                    f"Error during cleanup after startup failure for kernel {self.id}: {cleanup_error}"
                )
            self.status = KernelStatus.KILLED
            raise SandboxKernelCreationError(self.id, str(e))

    async def terminate(self):
        """
        Terminate the Jupyter kernel and clean up resources.
        This method stops the kernel channels and shuts down the kernel.
        """
        try:
            # Check if kernel client exists and channels are running
            if hasattr(self, "kernel_client") and self.kernel_client:
                try:
                    # stop_channels() is synchronous in jupyter-client 8.6.3
                    self.kernel_client.stop_channels()
                except Exception as e:
                    logger.warning(f"Error stopping channels for kernel {self.id}: {e}")

            # Always attempt to shutdown the kernel if it's alive
            if await self.kernel_manager._async_is_alive():
                try:
                    await asyncio.wait_for(
                        self.kernel_manager.shutdown_kernel(now=True), timeout=10.0
                    )
                except asyncio.TimeoutError:
                    logger.warning(
                        f"Kernel {self.id} shutdown timed out, may require force kill"
                    )

            self.status = KernelStatus.KILLED
            logger.info(f"Kernel {self.id} terminated successfully")
        except Exception as e:
            logger.error(f"Error terminating kernel {self.id}: {e}")
            self.status = KernelStatus.KILLED

    def _is_warning_message(self, stderr_text: str) -> bool:
        """
        Determine if a stderr message is a warning that should be ignored during session initialization.

        Args:
            stderr_text (str): The stderr message to check.

        Returns:
            bool: True if the message is a warning that should be ignored, False if it's an actual error.
        """
        WARNING_PATTERNS = [
            "SnowflakeLoginOptions() is in private preview",
            "Bad owner or permissions on",
            "connections.toml",
            "UserWarning:",
            'warn(f"Bad owner or permissions on',
            "To change owner, run `chown",
            "To restrict permissions, run `chmod",
        ]

        return any(pattern in stderr_text for pattern in WARNING_PATTERNS)

    async def _initialize_session(self):
        """
        Initialize the Snowflake session in the kernel.
        This method executes the session initialization code and verifies that the session was initialized successfully.
        """
        try:
            # Generate session initialization code with current environment settings
            session_code = get_session_start_code(ENABLE_SANDBOX_READ_ONLY_MODE)

            # Execute session initialization code and verify it succeeded
            session_errors = []
            async for message in self.execute(session_code):
                if message.stderr:
                    # Filter out warning messages that are not actual errors
                    if self._is_warning_message(message.stderr):
                        logger.debug(
                            f"Ignoring warning message in kernel {self.id}: {message.stderr}"
                        )
                    else:
                        session_errors.append(message.stderr)
                        logger.error(
                            f"Session initialization error in kernel {self.id}: {message.stderr}"
                        )

            # Check if session initialization failed
            if session_errors:
                error_msg = "Session initialization failed: " + "".join(session_errors)
                raise Exception(error_msg)

            # Mark session as successfully initialized
            self.session_initialized = True
            logger.info(f"Successfully initialized session for kernel: {self.id}")
        except Exception as e:
            logger.error(f"Error initializing session in kernel {self.id}: {e}")
            raise SandboxKernelSessionInitializationError(self.id, str(e))

    def _save_last_activity(self):
        """
        Update the last activity timestamp.
        """
        self.last_activity = time.time()

    def _strip_ansi_codes(self, text: str) -> str:
        ANSI_ESCAPE_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
        try:
            return ANSI_ESCAPE_RE.sub("", text) if text else text
        except Exception as e:
            logger.error(f"Error stripping ANSI codes in kernel {self.id}: {e}")
            return text

    def _parse_jupyter_message(self, msg: Dict) -> ExecutionMessage:
        """
        Parse a Jupyter message into an ExecutionMessage.
        Args:
            msg (Dict): The Jupyter message to parse.
        """
        msg_type = msg["msg_type"]
        content = msg["content"]

        if msg_type == "stream":
            stream_name = content["name"]
            text = content["text"]
            text = self._strip_ansi_codes(text)
            if stream_name == "stdout":
                return ExecutionMessage(stdout=text)
            elif stream_name == "stderr":
                return ExecutionMessage(stderr=text)

        elif msg_type == "error":
            traceback = "\n".join(content["traceback"])
            traceback = self._strip_ansi_codes(traceback)
            return ExecutionMessage(stderr=traceback)

        # Return empty message for other message types
        return ExecutionMessage()

    def _determine_message_match(self, msg: Dict, msg_id: str) -> bool:
        """
        This ensures that the message we are processing matches the expected message ID.
        This is crucial for ensuring that we are processing the correct response to our execution request.
        Args:
            msg (Dict): The Jupyter message to check.
            msg_id (str): The expected message ID to match against.
        Returns:
            bool: True if the message matches the expected message ID, False otherwise.
        """
        return msg["parent_header"].get("msg_id") == msg_id

    def _kernel_is_idle(self, msg: Dict) -> bool:
        """
        Check if the kernel is idle based on the message type and content.
        Args:
            msg (Dict): The Jupyter message to check.
        Returns:
            bool: True if the kernel is idle, False otherwise.
        """
        msg_type = msg["msg_type"]
        content = msg["content"]
        return msg_type == "status" and content["execution_state"] == "idle"

    async def execute(self, code: str) -> AsyncGenerator[ExecutionMessage, None]:
        """
        Execute code in the Jupyter kernel and yield execution messages.
        Args:
            code (str): The code to execute in the kernel.
        Yields:
            ExecutionMessage: Messages from the kernel during execution.
        Raises:
            SandboxKernelNotFoundError: If the kernel is not found.
            SandboxKernelBusyError: If the kernel is busy.
            SandboxKernelTimeoutError: If the execution times out.
        """
        if self.status == KernelStatus.KILLED:
            raise SandboxKernelNotFoundError(self.id)

        if self.status == KernelStatus.RUNNING:
            raise SandboxKernelBusyError(self.id)

        try:
            self.status = KernelStatus.RUNNING
            msg_id = self.kernel_client.execute(code)
            logger.debug(f"Executing code in kernel {self.id} with message ID {msg_id}")

            while True:
                try:
                    msg = await asyncio.wait_for(
                        self.kernel_client.get_iopub_msg(),
                        timeout=self.execution_timeout_seconds,
                    )
                    logger.debug(f"Received message in kernel {self.id}: {msg}")
                except asyncio.TimeoutError:
                    logger.error(f"Execution timeout for kernel {self.id}")
                    raise SandboxKernelTimeoutError(
                        self.id, "code execution", self.execution_timeout_seconds
                    )
                except Exception as e:
                    logger.error(f"Error getting message from kernel {self.id}: {e}")
                    break

                if not self._determine_message_match(msg, msg_id):
                    continue

                if self._kernel_is_idle(msg):
                    break

                execution_message = self._parse_jupyter_message(msg)
                self._save_last_activity()

                yield execution_message

                # Yield control back to the event loop
                await asyncio.sleep(0)

        except (
            SandboxKernelTimeoutError,
            SandboxKernelBusyError,
            SandboxKernelNotFoundError,
        ):
            # Re-raise known exceptions
            raise
        except Exception as e:
            logger.error(f"Unexpected error during execution in kernel {self.id}: {e}")
            # Mark kernel as killed on unexpected errors to prevent further use
            self.status = KernelStatus.KILLED
            raise SandboxKernelExecutionError(self.id, str(e))
        finally:
            self._save_last_activity()
            # Only set to AVAILABLE if not killed due to errors
            if self.status != KernelStatus.KILLED:
                self.status = KernelStatus.AVAILABLE


class SandboxKernelManager:
    """Manages Jupyter kernels for executing code in the sandbox."""

    def __init__(self, execution_timeout_seconds: int, cleanup_timeout_seconds: int):
        """
        Initialize the SandboxKernelManager.
        Args:
            execution_timeout_seconds (int): Timeout for code execution in seconds.
            cleanup_timeout_seconds (int): Timeout for cleaning up idle kernels in seconds.
        """
        self.execution_timeout_seconds = execution_timeout_seconds
        self.cleanup_timeout_seconds = cleanup_timeout_seconds
        self.kernels: Dict[str, SandboxKernel] = {}

        # Store results for pull-based execution
        # This is a map from session IDs to their execution results
        self._pull_results: Dict[str, List[ExecutionMessage]] = dict()
        # This is a map from session IDs to their completion status
        self._pull_complete: Dict[str, bool] = dict()
        # This is a map from session IDs to their currently executing code string
        self._pull_current_code: Dict[str, str] = dict()

    async def get_kernel(self, kernel_id: str) -> SandboxKernel:
        """
        Retrieve an existing kernel by ID or create a new one if it doesn't exist.
        Args:
            kernel_id (str): The unique identifier for the kernel.
        Returns:
            SandboxKernel: The kernel instance associated with the given ID.
        Raises:
            SandboxKernelNotFoundError: If the kernel was killed and cannot be found."""
        if kernel_id not in self.kernels:
            logger.info(f"Creating new kernel for ID: {kernel_id}")
            kernel = await self.create_kernel(kernel_id)
            self.kernels[kernel_id] = kernel
        else:
            kernel = self.kernels[kernel_id]
            if kernel.status == KernelStatus.KILLED:
                logger.warning(f"Kernel {kernel_id} was killed, removing from registry")
                del self.kernels[kernel_id]
                raise SandboxKernelNotFoundError(kernel_id)

        return self.kernels[kernel_id]

    async def create_kernel(self, kernel_id: str) -> SandboxKernel:
        """
        Create a new Jupyter kernel.
        Args:
            kernel_id (str): The unique identifier for the kernel.
        Returns:
            SandboxKernel: The newly created kernel instance.
        """
        try:
            new_kernel = SandboxKernel(kernel_id, self.execution_timeout_seconds)
            await new_kernel.startup()
            self.kernels[kernel_id] = new_kernel
            logger.info(f"Successfully created kernel: {kernel_id}")
            return new_kernel
        except SandboxKernelCreationError:
            # Re-raise kernel creation errors
            raise
        except Exception as e:
            logger.error(f"Unexpected error creating kernel {kernel_id}: {e}")
            raise SandboxKernelCreationError(kernel_id, str(e))

    async def sse_stream_code(
        self, kernel_id: str, code: str
    ) -> AsyncGenerator[str, None]:
        """
        Execute code in a specific kernel and yield execution messages in SSE format.

        This method handles all exceptions internally and yields error events instead
        of raising exceptions, ensuring the streaming response can properly communicate
        errors to the client.

        Args:
            kernel_id (str): The unique identifier for the kernel.
            code (str): The code to execute in the kernel.
        Yields:
            str: SSE-formatted messages from the kernel during execution, including
                 error events if exceptions occur.
        """
        # Create a queue to decouple message production from consumption
        message_queue: asyncio.Queue[Optional[str]] = asyncio.Queue()

        async def producer():
            """Producer coroutine that executes code and puts messages in the queue."""
            try:
                sandbox_kernel = await self.get_kernel(kernel_id)
                async for msg in sandbox_kernel.execute(code):
                    sse_resp = self._convert_to_sse(
                        name=str(EventName.EXECUTION_MESSAGE),
                        id=str(uuid.uuid4()),
                        msg=msg,
                    )
                    await message_queue.put(sse_resp)
                # Signal end of execution
                await message_queue.put(None)
            except Exception as e:
                # Put error message in queue and signal end
                error_sse = self._handle_execution_error(e, kernel_id)
                await message_queue.put(error_sse)
                await message_queue.put(None)

        async def healthcheck_producer():
            """Producer coroutine that periodically checks kernel health."""
            HEALTHCHECK_INTERVAL = 5
            while True:
                msg = ExecutionMessage()
                sse_resp = self._convert_to_sse(
                    name=str(EventName.EXECUTION_MESSAGE),
                    id=str(uuid.uuid4()),
                    msg=msg,
                )
                await message_queue.put(sse_resp)
                await asyncio.sleep(HEALTHCHECK_INTERVAL)

        # Start the producer task
        producer_task = asyncio.create_task(producer())
        healthcheck_task = asyncio.create_task(healthcheck_producer())

        try:
            # Consumer: yield messages from the queue
            while True:
                message = await message_queue.get()
                if message is None:  # End of execution signal
                    break
                yield message
                message_queue.task_done()
        except asyncio.CancelledError:
            logger.debug("Client has disconnected prematurely")
            pass
        finally:
            if not producer_task.done():
                producer_task.cancel()
                try:
                    await producer_task
                except asyncio.CancelledError:
                    pass
            if not healthcheck_task.done():
                healthcheck_task.cancel()
                try:
                    await healthcheck_task
                except asyncio.CancelledError:
                    pass

    def _handle_execution_error(self, exception: Exception, kernel_id: str) -> str:
        try:
            raise exception
        except SandboxKernelNotFoundError as e:
            logger.error(f"Kernel not found: {e}")
            return self._create_error_sse(
                error_type="SandboxKernelNotFoundError",
                error_message="Kernel not found",
                session_id=e.request_id,
            )
        except SandboxKernelBusyError as e:
            logger.error(f"Kernel is busy: {e}")
            return self._create_error_sse(
                error_type="SandboxKernelBusyError",
                error_message="Kernel is busy",
                session_id=e.request_id,
            )
        except SandboxKernelCreationError as e:
            logger.error(f"Kernel creation failed: {e}")
            return self._create_error_sse(
                error_type="SandboxKernelCreationError",
                error_message="Failed to create kernel",
                session_id=e.request_id,
                reason=e.reason,
            )
        except SandboxKernelExecutionError as e:
            logger.error(f"Execution error: {e}")
            return self._create_error_sse(
                error_type="SandboxKernelExecutionError",
                error_message="Code execution failed",
                session_id=e.request_id,
                reason=e.error_message,
            )
        except SandboxKernelTimeoutError as e:
            logger.error(f"Execution timeout: {e}")
            return self._create_error_sse(
                error_type="SandboxKernelTimeoutError",
                error_message="Execution timeout",
                session_id=e.request_id,
                operation=e.operation,
                timeout_seconds=e.timeout_seconds,
            )
        except Exception as e:
            logger.error(f"Unexpected error executing code for kernel {kernel_id}: {e}")
            return self._create_error_sse(
                error_type="UnexpectedError",
                error_message=f"Internal server error: {str(e)}",
                session_id=kernel_id,
            )

    async def execute_code(
        self, kernel_id: str, code: str
    ) -> AsyncGenerator[ExecutionMessage, None]:
        """Execute code in a specific kernel and yield execution messages.
        Args:
            kernel_id (str): The unique identifier for the kernel.
            code (str): The code to execute in the kernel.
        Yields:
            str: SSE-formatted messages from the kernel during execution.
        Raises:
            SandboxKernelNotFoundError: If the kernel is not found.
            SandboxKernelBusyError: If the kernel is busy.
            SandboxKernelCreationError: If the kernel cannot be created.
            SandboxKernelExecutionError: If there is an error during execution.
            SandboxKernelTimeoutError: If the execution times out.
        """
        try:
            sandbox_kernel = await self.get_kernel(kernel_id)
            async for msg in sandbox_kernel.execute(code):
                yield msg
        except (
            SandboxKernelNotFoundError,
            SandboxKernelBusyError,
            SandboxKernelCreationError,
            SandboxKernelExecutionError,
            SandboxKernelTimeoutError,
        ):
            # Re-raise known exceptions
            raise
        except Exception as e:
            logger.error(f"Unexpected error executing code for kernel {kernel_id}: {e}")
            raise SandboxKernelExecutionError(kernel_id, str(e))

    def _get_kernels(self) -> List[str]:
        """
        Return the current list of active kernels.
        Returns:
            List[str]: A list of kernel IDs currently managed by the kernel manager."""
        return list(self.kernels.keys())

    def get_kernel_status(self, kernel_id: str) -> KernelStatus:
        """
        Get the status of a specific kernel.
        Args:
            kernel_id (str): The unique identifier for the kernel.
        Returns:
            KernelStatus: The current status of the kernel.
        """
        if kernel_id in self.kernels:
            return self.kernels[kernel_id].status
        return KernelStatus.MISSING

    async def terminate_kernel(self, kernel_id: str) -> KernelStatus:
        """
        Terminate a specific kernel by ID.

        Args:
            kernel_id (str): The unique identifier for the kernel.
        Returns:
            KernelStatus: The status of the kernel after termination.
        """
        if kernel_id in self.kernels:
            try:
                sandbox_kernel = self.kernels[kernel_id]
                await sandbox_kernel.terminate()
                # Set the status to KILLED after successful termination
                self.kernels[kernel_id].status = KernelStatus.KILLED
                logger.info(f"Terminated kernel: {kernel_id}")

                # Remove from registry immediately to prevent memory accumulation
                del self.kernels[kernel_id]
                logger.debug(f"Removed kernel {kernel_id} from registry")

                return KernelStatus.KILLED
            except Exception as e:
                logger.error(f"Error terminating kernel {kernel_id}: {e}")
                # Still mark as killed and remove even if termination had errors
                if kernel_id in self.kernels:
                    self.kernels[kernel_id].status = KernelStatus.KILLED
                    del self.kernels[kernel_id]
                return KernelStatus.KILLED
        else:
            logger.warning(f"Attempted to terminate non-existent kernel: {kernel_id}")
            return KernelStatus.MISSING

    async def start_pull_execution(self, session_id: str, code: str):
        """
        Start executing code in pull mode.

        Args:
            session_id (str): The session identifier.
            code (str): The code to execute in the kernel.
        """
        # Reset execution state
        self._pull_complete[session_id] = False
        self._pull_results[session_id] = list()
        self._pull_current_code[session_id] = code

        # Start execution in background task
        asyncio.create_task(self._run_pull_execution(session_id, code))

    async def _run_pull_execution(self, session_id: str, code: str):
        """
        Run the execution and store results for pulling.

        Args:
            session_id (str): The session identifier.
            code (str): The code to execute in the kernel.
        """
        try:
            async for msg in self.execute_code(session_id, code):
                self._pull_results[session_id].append(msg)
        except Exception as e:
            # Store error as stderr message
            self._pull_results[session_id].append(
                ExecutionMessage(stderr=f"Sandbox Execution Error: {str(e)}\n")
            )
        finally:
            self._pull_complete[session_id] = True

    # TODO: This will be removed
    def get_pull_results(self, session_id: str) -> Tuple[str, str, bool]:
        """
        Get accumulated results for a pull-based execution.

        Args:
            session_id (str): The session identifier.

        Returns:
            Tuple[str, str, bool]: (stdout, stderr, is_complete)
        """

        # Collect messages from last_index to current_size
        stdout = ""
        stderr = ""
        while len(self._pull_results[session_id]) > 0:
            # pop the front of the list
            msg = self._pull_results[session_id].pop(0)
            stdout += msg.stdout
            stderr += msg.stderr

        is_complete = self._pull_complete[session_id]

        # Clean up completed executions
        if is_complete:
            del self._pull_results[session_id]
            del self._pull_complete[session_id]

        return stdout, stderr, is_complete

    def get_complete_pull_results(self, session_id: str) -> Tuple[str, str, str, bool]:
        """
        Get the complete results up to this point for a pull-based execution and return status.

        Args:
            session_id (str): The session identifier.

        Returns:
            Tuple[str, str, str, bool]: (stdout, stderr, all_output, is_complete)
        """
        stdout = ""
        stderr = ""
        all_output = ""

        for msg in self._pull_results[session_id]:
            stdout += msg.stdout
            stderr += msg.stderr
            all_output += msg.stdout + msg.stderr

        is_complete = self._pull_complete[session_id]

        return stdout, stderr, all_output, is_complete

    def is_already_running_code(self, session_id: str, code: str) -> bool:
        """
        Determines if the specified code is already running in the given session.

        Args:
            session_id (str): The session identifier.
            code (str): The code to check.

        Returns:
            bool: True if the code is already running, False otherwise.
        """
        kernel_status = self.get_kernel_status(session_id)
        if kernel_status != KernelStatus.RUNNING:
            return False
        if session_id not in self._pull_current_code:
            return False
        current_code = self._pull_current_code.get(session_id, "")
        return current_code == code

    def check_pull_exists(self, session_id: str) -> bool:
        """
        Determines if a pull-based execution exists for the given session ID.

        Args:
            session_id (str): The session identifier.

        Returns:
            bool: True if a pull-based execution exists, False otherwise.
        """
        return session_id in self._pull_results

    async def cleanup_kernels(self):
        """
        Cleanup kernels that have been idle for too long.
        This method checks all kernels and terminates those that have been idle
        for longer than the specified cleanup timeout.
        It also removes kernels that have been marked as KILLED.
        """
        kernels_to_remove = []

        for kernel_id, kernel in list(self.kernels.items()):
            try:
                current_time = time.time()
                if (
                    kernel.status == KernelStatus.AVAILABLE
                    and (current_time - kernel.last_activity)
                    > self.cleanup_timeout_seconds
                ):
                    logger.info(f"Cleaning up idle kernel: {kernel_id}")
                    await self.terminate_kernel(kernel_id)
                elif kernel.status == KernelStatus.KILLED:
                    logger.info(f"Removing killed kernel from registry: {kernel_id}")
                    kernels_to_remove.append(kernel_id)
            except Exception as e:
                logger.error(f"Error during cleanup of kernel {kernel_id}: {e}")
                # Mark for removal if cleanup fails
                kernels_to_remove.append(kernel_id)

        # Remove killed kernels from registry
        for kernel_id in kernels_to_remove:
            if kernel_id in self.kernels:
                del self.kernels[kernel_id]

    async def generate_simple_stream(self) -> AsyncGenerator[str, None]:
        """
        Generate a simple test stream for debugging purposes.

        This function provides a basic streaming interface for testing
        when actual kernel execution is not needed.
        Yields:
            str: SSE-formatted messages simulating kernel execution.
        """
        outputs = [
            ExecutionMessage(stdout="Starting execution...\n"),
            ExecutionMessage(stdout="Processing data...\n"),
            ExecutionMessage(stderr="Warning: This is a test warning.\n"),
            ExecutionMessage(stdout="Result: 42\n"),
            ExecutionMessage(stdout="Execution complete.\n"),
        ]

        for output in outputs:
            resp = self._convert_to_sse(
                name=EventName.EXECUTION_MESSAGE,
                id=str(uuid.uuid4()),
                msg=output,
            )
            yield resp
            await asyncio.sleep(1)  # Simulate processing time

    def _create_error_sse(
        self, error_type: str, error_message: str, session_id: str, **kwargs
    ) -> str:
        """
        Create an SSE-formatted error response.

        Args:
            error_type (str): The type of error that occurred.
            error_message (str): The error message to send.
            session_id (str): The session ID where the error occurred.
            **kwargs: Additional fields for the ErrorMessage (e.g., reason, operation, timeout_seconds).

        Returns:
            str: SSE-formatted error message.
        """
        error_msg = ErrorMessage(
            error_type=error_type,
            error_message=error_message,
            session_id=session_id,
            **kwargs,
        )
        return self._convert_to_sse(
            name=str(EventName.ERROR),
            id=str(uuid.uuid4()),
            msg=error_msg,
        )

    def _convert_to_sse(
        self, name: str, id: str, msg: ExecutionMessage | ErrorMessage
    ) -> str:
        """
        Convert message to Server-Sent Events (SSE) format.

        Args:
            name (str): The event name for SSE.
            id (str): The unique identifier for the event.
            msg (ExecutionMessage | ErrorMessage): The message to convert.
        Returns:
            str: The SSE formatted message string following the SSE protocol:
            event: {name}
            id: {id}
            data: {json_data}

            (with double newline at the end)
        """
        data = json.dumps(msg.model_dump())
        sse_response = f"event: {name}\nid: {id}\ndata: {data}\n\n"

        # Log every SSE message being sent out
        logger.debug(f"Sending SSE message - Event: {name}, ID: {id}, Data: {data}")

        return sse_response

    def _kernel_discovery(self):
        ksm = KernelSpecManager()
        logger.info(f"Available kernels: {ksm.get_all_specs()}")
