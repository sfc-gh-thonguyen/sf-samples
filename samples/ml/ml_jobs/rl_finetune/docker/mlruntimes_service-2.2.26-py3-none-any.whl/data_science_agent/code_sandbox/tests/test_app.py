# """
# Test cases for the Code Sandbox FastAPI application.

# This module tests all endpoints of the FastAPI app including:
# - Request validation
# - Successful execution flows
# - Error handling for various failure scenarios
# - SSE (Server-Sent Events) streaming functionality
# """

# import pytest
# import json
# import time
# import uuid
# from unittest.mock import AsyncMock, patch
# from fastapi.testclient import TestClient

# from service.data_science_agent.code_sandbox.app import app
# from service.data_science_agent.code_sandbox.models import (
#     KernelStatus,
#     ExecutionMessage,
#     EventName,
# )
# from service.data_science_agent.code_sandbox.exceptions import (
#     SandboxKernelNotFoundError,
#     SandboxKernelBusyError,
#     SandboxKernelCreationError,
#     SandboxKernelExecutionError,
#     SandboxKernelTimeoutError,
# )


# @pytest.fixture
# def client():
#     """Create a test client for the FastAPI app."""
#     return TestClient(app)


# def _create_sse_message(
#     event_name: str, event_id: str, message: ExecutionMessage
# ) -> str:
#     """Helper function to create SSE formatted messages for testing."""
#     data = json.dumps(message.model_dump())
#     return f"event: {event_name}\nid: {event_id}\ndata: {data}\n\n"


# class TestStreamExecuteEndpoint:
#     """Test cases for the /stream-execute endpoint."""

#     def test_execute_request_validation_missing_fields(self, client):
#         """Test request validation failure when required fields are missing."""
#         # Test missing code_string
#         response = client.post("/stream-execute", json={"session_id": "test-session"})
#         assert response.status_code == 422
#         error_detail = response.json()
#         assert "detail" in error_detail
#         assert any("code_string" in str(detail) for detail in error_detail["detail"])

#         # Test missing session_id
#         response = client.post(
#             "/stream-execute", json={"code_string": "print('hello')"}
#         )
#         assert response.status_code == 422
#         error_detail = response.json()
#         assert "detail" in error_detail
#         assert any("session_id" in str(detail) for detail in error_detail["detail"])

#         # Test empty request body
#         response = client.post("/stream-execute", json={})
#         assert response.status_code == 422

#     def test_execute_request_validation_empty_fields(self, client):
#         """Test request validation failure when required fields are empty."""
#         # Test empty code_string
#         response = client.post(
#             "/stream-execute", json={"code_string": "", "session_id": "test-session"}
#         )
#         assert response.status_code == 422
#         error_detail = response.json()
#         assert "detail" in error_detail

#         # Test empty session_id
#         response = client.post(
#             "/stream-execute", json={"code_string": "print('hello')", "session_id": ""}
#         )
#         assert response.status_code == 422
#         error_detail = response.json()
#         assert "detail" in error_detail

#     def test_execute_request_validation_invalid_json(self, client):
#         """Test request validation failure with invalid JSON."""
#         response = client.post(
#             "/stream-execute",
#             content="invalid json",
#             headers={"content-type": "application/json"},
#         )
#         assert response.status_code == 422

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_successful_streaming(self, mock_manager, client):
#         """Test successful code execution with SSE streaming response."""

#         # Mock SSE streaming generator
#         async def mock_sse_generator():
#             event_id = str(uuid.uuid4())
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 event_id,
#                 ExecutionMessage(stdout="Hello, ", stderr=""),
#             )
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 str(uuid.uuid4()),
#                 ExecutionMessage(stdout="World!\n", stderr=""),
#             )

#         mock_manager.sse_stream_code.return_value = mock_sse_generator()

#         response = client.post(
#             "/stream-execute",
#             json={
#                 "code_string": "print('Hello, World!')",
#                 "session_id": "test-session-success",
#             },
#         )

#         assert response.status_code == 200
#         assert response.headers["content-type"] == "text/event-stream; charset=utf-8"
#         assert "cache-control" in response.headers
#         assert response.headers["cache-control"] == "no-cache"

#         # Verify the SSE streaming content
#         content = response.text
#         assert "event: execution_message" in content
#         assert "data:" in content
#         assert "id:" in content

#         # Parse the SSE events
#         lines = content.strip().split("\n")
#         event_lines = [line for line in lines if line.startswith("event:")]
#         data_lines = [line for line in lines if line.startswith("data:")]
#         id_lines = [line for line in lines if line.startswith("id:")]

#         assert len(event_lines) >= 1
#         assert len(data_lines) >= 1
#         assert len(id_lines) >= 1

#         # Verify event format
#         assert "event: execution_message" in event_lines[0]

#         # Verify data contains expected JSON structure
#         first_data_line = data_lines[0].replace("data: ", "")
#         data_json = json.loads(first_data_line)
#         assert "stdout" in data_json
#         assert "stderr" in data_json

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_kernel_not_found_error(self, mock_manager, client):
#         """Test handling of SandboxKernelNotFoundError."""
#         mock_manager.sse_stream_code.side_effect = SandboxKernelNotFoundError(
#             "test-session"
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('hello')", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Kernel not found"
#         assert error_data["session_id"] == "test-session"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_kernel_busy_error(self, mock_manager, client):
#         """Test handling of SandboxKernelBusyError."""
#         mock_manager.sse_stream_code.side_effect = SandboxKernelBusyError(
#             "test-session"
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('hello')", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Kernel is busy"
#         assert error_data["session_id"] == "test-session"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_kernel_creation_error(self, mock_manager, client):
#         """Test handling of SandboxKernelCreationError."""
#         mock_manager.sse_stream_code.side_effect = SandboxKernelCreationError(
#             "test-session", "Failed to start kernel process"
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('hello')", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Failed to create kernel"
#         assert error_data["reason"] == "Failed to start kernel process"
#         assert error_data["session_id"] == "test-session"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_kernel_execution_error(self, mock_manager, client):
#         """Test handling of SandboxKernelExecutionError."""
#         mock_manager.sse_stream_code.side_effect = SandboxKernelExecutionError(
#             "test-session", "NameError: name 'undefined_var' is not defined"
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print(undefined_var)", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Code execution failed"
#         assert error_data["details"] == "NameError: name 'undefined_var' is not defined"
#         assert error_data["session_id"] == "test-session"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_kernel_timeout_error(self, mock_manager, client):
#         """Test handling of SandboxKernelTimeoutError."""
#         mock_manager.sse_stream_code.side_effect = SandboxKernelTimeoutError(
#             "test-session", "code_execution", 30.0
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "while True: pass", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Execution timeout"
#         assert error_data["operation"] == "code_execution"
#         assert error_data["timeout_seconds"] == 30.0
#         assert error_data["session_id"] == "test-session"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_execute_unexpected_error(self, mock_manager, client):
#         """Test handling of unexpected exceptions."""
#         mock_manager.sse_stream_code.side_effect = RuntimeError(
#             "Unexpected error occurred"
#         )

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('hello')", "session_id": "test-session"},
#         )

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Internal server error"
#         assert "Unexpected error occurred" in error_data["details"]


# class TestTestExecuteEndpoint:
#     """Test cases for the /test-execute endpoint."""

#     def test_test_execute_validation_missing_fields(self, client):
#         """Test request validation failure for test endpoint."""
#         response = client.post("/test-execute", json={})
#         assert response.status_code == 422

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_test_execute_successful_streaming(self, mock_manager, client):
#         """Test successful mock SSE streaming response."""

#         # Mock simple SSE stream
#         async def mock_simple_sse_stream():
#             messages = [
#                 ExecutionMessage(stdout="Starting execution...\n"),
#                 ExecutionMessage(stdout="Processing data...\n"),
#                 ExecutionMessage(stderr="Warning: This is a test warning.\n"),
#                 ExecutionMessage(stdout="Result: 42\n"),
#                 ExecutionMessage(stdout="Execution complete.\n"),
#             ]

#             for msg in messages:
#                 yield _create_sse_message(
#                     EventName.EXECUTION_MESSAGE, str(uuid.uuid4()), msg
#                 )

#         mock_manager.generate_simple_stream.return_value = mock_simple_sse_stream()

#         response = client.post(
#             "/test-execute",
#             json={"code_string": "print('test')", "session_id": "test-session"},
#         )

#         assert response.status_code == 200
#         assert response.headers["content-type"] == "text/event-stream; charset=utf-8"

#         # Verify the response contains SSE data
#         content = response.text
#         assert "event: execution_message" in content
#         assert "data:" in content
#         assert "id:" in content


# class TestStatusEndpoint:
#     """Test cases for the /status endpoint."""

#     def test_status_request_validation_missing_session_id(self, client):
#         """Test status request validation failure."""
#         response = client.post("/status", json={})
#         assert response.status_code == 422

#     def test_status_request_validation_empty_session_id(self, client):
#         """Test status request validation with empty session_id."""
#         response = client.post("/status", json={"session_id": ""})
#         assert response.status_code == 422

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_status_successful_response(self, mock_manager, client):
#         """Test successful status response."""
#         mock_manager.get_kernel_status.return_value = KernelStatus.AVAILABLE

#         response = client.post("/status", json={"session_id": "test-session"})

#         assert response.status_code == 200
#         data = response.json()
#         assert data["status"] == "available"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_status_all_kernel_states(self, mock_manager, client):
#         """Test status endpoint with all possible kernel states."""
#         test_cases = [
#             KernelStatus.PENDING,
#             KernelStatus.AVAILABLE,
#             KernelStatus.RUNNING,
#             KernelStatus.KILLED,
#             KernelStatus.MISSING,
#         ]

#         for status in test_cases:
#             mock_manager.get_kernel_status.return_value = status
#             response = client.post("/status", json={"session_id": "test-session"})

#             assert response.status_code == 200
#             data = response.json()
#             assert data["status"] == status.value

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_status_error_handling(self, mock_manager, client):
#         """Test status endpoint error handling."""
#         mock_manager.get_kernel_status.side_effect = RuntimeError("Status error")

#         response = client.post("/status", json={"session_id": "test-session"})

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Internal server error"


# class TestCancelEndpoint:
#     """Test cases for the /cancel endpoint."""

#     def test_cancel_request_validation_missing_session_id(self, client):
#         """Test cancel request validation failure."""
#         response = client.post("/cancel", json={})
#         assert response.status_code == 422

#     def test_cancel_request_validation_empty_session_id(self, client):
#         """Test cancel request validation with empty session_id."""
#         response = client.post("/cancel", json={"session_id": ""})
#         assert response.status_code == 422

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_cancel_successful_response(self, mock_manager, client):
#         """Test successful cancel response."""
#         mock_manager.terminate_kernel = AsyncMock(return_value=KernelStatus.KILLED)

#         response = client.post("/cancel", json={"session_id": "test-session"})

#         assert response.status_code == 200
#         data = response.json()
#         assert data["status"] == "killed"

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_cancel_error_handling(self, mock_manager, client):
#         """Test cancel endpoint error handling."""
#         mock_manager.terminate_kernel = AsyncMock(
#             side_effect=RuntimeError("Cancel error")
#         )

#         response = client.post("/cancel", json={"session_id": "test-session"})

#         assert response.status_code == 500
#         error_data = response.json()
#         assert error_data["error"] == "Internal server error"


# class TestHealthEndpoint:
#     """Test cases for the /health endpoint."""

#     def test_health_check_successful(self, client):
#         """Test successful health check response."""
#         response = client.get("/health")

#         assert response.status_code == 200
#         data = response.json()
#         assert data["status"] == "healthy"
#         assert "timestamp" in data
#         assert isinstance(data["timestamp"], (int, float))

#         # Verify timestamp is recent (within last 10 seconds)
#         current_time = time.time()
#         assert abs(current_time - data["timestamp"]) < 10

#     def test_health_check_no_parameters_required(self, client):
#         """Test health endpoint doesn't require any parameters."""
#         response = client.get("/health")
#         assert response.status_code == 200

#         # Test with query parameters (should still work)
#         response = client.get("/health?extra=param")
#         assert response.status_code == 200


# class TestSSEStreamingResponse:
#     """Test cases for Server-Sent Events streaming functionality."""

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_sse_format_validation(self, mock_manager, client):
#         """Test that SSE responses are properly formatted."""

#         async def mock_sse_generator():
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 str(uuid.uuid4()),
#                 ExecutionMessage(stdout="line1\n", stderr=""),
#             )
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 str(uuid.uuid4()),
#                 ExecutionMessage(stdout="line2\n", stderr="error1\n"),
#             )

#         mock_manager.sse_stream_code.return_value = mock_sse_generator()

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('test')", "session_id": "test-session"},
#         )

#         assert response.status_code == 200
#         content = response.text

#         # Verify SSE format
#         lines = content.split("\n")
#         event_lines = [line for line in lines if line.startswith("event:")]
#         data_lines = [line for line in lines if line.startswith("data:")]
#         id_lines = [line for line in lines if line.startswith("id:")]

#         # Should have at least one of each
#         assert len(event_lines) >= 1
#         assert len(data_lines) >= 1
#         assert len(id_lines) >= 1

#         # Each data line should contain valid JSON
#         for data_line in data_lines:
#             json_str = data_line.replace("data: ", "")
#             data = json.loads(json_str)
#             assert "stdout" in data
#             assert "stderr" in data

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_streaming_with_stderr(self, mock_manager, client):
#         """Test streaming response that includes stderr output."""

#         async def mock_sse_generator():
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 str(uuid.uuid4()),
#                 ExecutionMessage(stdout="", stderr="Warning: test warning\n"),
#             )
#             yield _create_sse_message(
#                 EventName.EXECUTION_MESSAGE,
#                 str(uuid.uuid4()),
#                 ExecutionMessage(stdout="Success!\n", stderr=""),
#             )

#         mock_manager.sse_stream_code.return_value = mock_sse_generator()

#         response = client.post(
#             "/stream-execute",
#             json={"code_string": "print('test')", "session_id": "test-session"},
#         )

#         assert response.status_code == 200
#         content = response.text

#         # Verify stderr is included in the response
#         assert "Warning: test warning" in content
#         assert "Success!" in content


# class TestErrorResponseFormat:
#     """Test cases to verify error response formats match the ErrorResponse model."""

#     @patch("service.data_science_agent.code_sandbox.app.kernel_manager")
#     def test_error_response_format_consistency(self, mock_manager, client):
#         """Test that all error responses follow the ErrorResponse model format."""
#         test_cases = [
#             (
#                 SandboxKernelNotFoundError("test"),
#                 {"error": "Kernel not found", "session_id": "test"},
#             ),
#             (
#                 SandboxKernelBusyError("test"),
#                 {"error": "Kernel is busy", "session_id": "test"},
#             ),
#             (
#                 SandboxKernelCreationError("test", "reason"),
#                 {
#                     "error": "Failed to create kernel",
#                     "reason": "reason",
#                     "session_id": "test",
#                 },
#             ),
#             (
#                 SandboxKernelExecutionError("test", "error msg"),
#                 {
#                     "error": "Code execution failed",
#                     "details": "error msg",
#                     "session_id": "test",
#                 },
#             ),
#             (
#                 SandboxKernelTimeoutError("test", "op", 30.0),
#                 {
#                     "error": "Execution timeout",
#                     "operation": "op",
#                     "timeout_seconds": 30.0,
#                     "session_id": "test",
#                 },
#             ),
#         ]

#         for exception, expected_fields in test_cases:
#             mock_manager.sse_stream_code.side_effect = exception

#             response = client.post(
#                 "/stream-execute",
#                 json={"code_string": "print('test')", "session_id": "test"},
#             )

#             assert response.status_code == 500
#             data = response.json()

#             # Verify all expected fields are present
#             for key, value in expected_fields.items():
#                 assert key in data
#                 assert data[key] == value
