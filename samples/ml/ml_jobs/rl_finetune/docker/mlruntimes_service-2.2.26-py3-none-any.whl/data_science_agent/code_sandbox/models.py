"""
Data models for the Code Sandbox application.

This module defines the request/response models and enums used throughout
the sandbox API.
"""

from enum import Enum
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional


class KernelStatus(str, Enum):
    """Enumeration of possible kernel states."""

    PENDING = "pending"
    AVAILABLE = "available"
    RUNNING = "running"
    KILLED = "killed"
    MISSING = "missing"


class EventName(str, Enum):
    """Enumeration of possible event names."""

    EXECUTION_MESSAGE = "execution_message"
    ERROR = "error"

    def __str__(self):
        return self.value


class ExecuteRequest(BaseModel):
    """Request model for the /stream-execute endpoint."""

    code_string: str = Field(..., description="Python code to execute", min_length=1)
    session_id: str = Field(..., description="Unique session identifier", min_length=1)

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "code_string": "print('Hello, World!')",
                "session_id": "session-123",
            }
        }
    )


class TestErrorRequest(BaseModel):
    """Request model for the /test-execute-error endpoint."""

    session_id: str = Field(..., description="Unique session identifier", min_length=1)
    error_type: str = Field(
        default="random",
        description="Type of error to simulate",
        pattern="^(kernel_not_found|kernel_busy|kernel_creation|execution_error|timeout|unexpected|random)$",
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "session_id": "test-session-123",
                "error_type": "timeout",
            }
        }
    )


class ExecuteResponse(BaseModel):
    """Response model for the /stream-execute endpoint."""

    stdout: str = Field(default="", description="Standard output from execution")
    stderr: str = Field(default="", description="Standard error from execution")

    model_config = ConfigDict(
        json_schema_extra={"example": {"stdout": "Hello, World!\n", "stderr": ""}}
    )


class StatusRequest(BaseModel):
    """Request model for the /status endpoint."""

    session_id: str = Field(..., description="Unique session identifier", min_length=1)

    model_config = ConfigDict(
        json_schema_extra={"example": {"session_id": "session-123"}}
    )


class StatusResponse(BaseModel):
    """Response model for the /status endpoint."""

    status: KernelStatus = Field(..., description="Current kernel status")

    model_config = ConfigDict(json_schema_extra={"example": {"status": "available"}})


class CancelRequest(BaseModel):
    """Request model for the /cancel endpoint."""

    session_id: str = Field(..., description="Unique session identifier", min_length=1)

    model_config = ConfigDict(
        json_schema_extra={"example": {"session_id": "session-123"}}
    )


class CancelResponse(BaseModel):
    """Response model for the /cancel endpoint."""

    status: KernelStatus = Field(..., description="Kernel status after cancellation")

    model_config = ConfigDict(json_schema_extra={"example": {"status": "killed"}})


class ExecutionMessage(BaseModel):
    """Internal model for streaming execution messages."""

    stdout: str = Field(default="", description="Standard output message")
    stderr: str = Field(default="", description="Standard error message")


class PullResultsRequest(BaseModel):
    """Request model for the /pull-results endpoint."""

    session_id: str = Field(
        ..., description="Session identifier to pull results from", min_length=1
    )

    model_config = ConfigDict(
        json_schema_extra={"example": {"session_id": "session-123"}}
    )


class PullResultsResponse(BaseModel):
    """Response model for the /pull-results endpoint."""

    stdout: str = Field(
        default="", description="Accumulated standard output since last pull"
    )
    stderr: str = Field(
        default="", description="Accumulated standard error since last pull"
    )
    is_complete: bool = Field(..., description="Whether the execution is complete")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {"stdout": "Hello, World!\n", "stderr": "", "is_complete": False}
        }
    )


class CompletePullResultsResponse(BaseModel):
    """Response model for the /pull-results endpoint when execution is complete."""

    stdout: str = Field(default="", description="Accumulated standard output")
    stderr: str = Field(default="", description="Accumulated standard error")
    all_output: str = Field(default="", description="All accumulated output")
    is_complete: bool = Field(..., description="Whether the execution is complete")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "stdout": "Hello, World!\n",
                "stderr": "",
                "all_output": "Hello, World!\n",
                "is_complete": True,
            }
        }
    )


class ErrorMessage(BaseModel):
    """Internal model for streaming error messages."""

    error_type: str = Field(..., description="Type of error that occurred")
    error_message: str = Field(..., description="Detailed error message")
    session_id: str = Field(..., description="Session ID where the error occurred")
    operation: str = Field(default="", description="Operation that was being performed")
    timeout_seconds: int = Field(default=0, description="Timeout value if applicable")
    reason: str = Field(
        default="", description="Additional reason/context if available"
    )


class HealthResponse(BaseModel):
    """Response model for the /health endpoint."""

    status: str = Field(..., description="Service health status")
    timestamp: float = Field(..., description="Unix timestamp of the health check")

    model_config = ConfigDict(
        json_schema_extra={"example": {"status": "healthy", "timestamp": 1642684800.0}}
    )


class ErrorResponse(BaseModel):
    """Generic error response model."""

    error: str = Field(..., description="Error message")
    details: Optional[str] = Field(None, description="Additional error details")
    session_id: Optional[str] = Field(
        None, description="Session ID associated with the error"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "error": "Kernel not found",
                "details": "No kernel exists for the given session ID",
                "session_id": "session-123",
            }
        }
    )
