"""
Unit tests for kernel_manager.py

This module tests the SandboxKernel and SandboxKernelManager classes,
including their async operations, error handling, and integration with Jupyter.
"""

import os
import time
import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

# Import the classes and functions to test
from data_science_agent.code_sandbox.kernel_manager import (
    SandboxKernel,
    SandboxKernelManager,
    get_session_start_code,
    ENABLE_SANDBOX_READ_ONLY_MODE,
)
from data_science_agent.code_sandbox.models import (
    ExecutionMessage,
    ErrorMessage,
    KernelStatus,
)
from data_science_agent.code_sandbox.exceptions import (
    SandboxKernelNotFoundError,
    SandboxKernelBusyError,
    SandboxKernelCreationError,
    SandboxKernelExecutionError,
    SandboxKernelTimeoutError,
    SandboxKernelSessionInitializationError,
)


class TestGetSessionStartCode:
    """Test the get_session_start_code helper function."""

    def test_get_session_start_code_read_only_enabled(self):
        """Test session start code generation with read-only mode enabled."""
        code = get_session_start_code(enable_read_only_mode=True)

        assert "get_session" in code
        assert "ALTER SESSION SET CORTEX_READ_ONLY = true" in code
        assert "if True:" in code
        assert "Session initialization failed" in code

    def test_get_session_start_code_read_only_disabled(self):
        """Test session start code generation with read-only mode disabled."""
        code = get_session_start_code(enable_read_only_mode=False)

        assert "get_session" in code
        assert "ALTER SESSION SET CORTEX_READ_ONLY = true" in code
        assert "if False:" in code
        assert "Session initialization failed" in code

    def test_get_session_start_code_contains_error_handling(self):
        """Test that session start code includes proper error handling."""
        code = get_session_start_code(enable_read_only_mode=True)

        assert "try:" in code
        assert "except Exception as e:" in code
        assert "raise RuntimeError" in code
        assert "SnowparkSQLException" in code


class TestSandboxKernel:
    def test_strip_ansi_codes_removes_ansi(self):
        """Test that _strip_ansi_codes removes ANSI escape codes from text."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        ansi_text = "\x1b[31mThis is red text\x1b[0m and normal."
        result = kernel._strip_ansi_codes(ansi_text)
        assert result == "This is red text and normal."

    def test_strip_ansi_codes_no_ansi(self):
        """Test that _strip_ansi_codes returns text unchanged if no ANSI codes present."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        plain_text = "Just plain text."
        result = kernel._strip_ansi_codes(plain_text)
        assert result == plain_text

    def test_strip_ansi_codes_empty(self):
        """Test that _strip_ansi_codes returns empty string if input is empty."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        result = kernel._strip_ansi_codes("")
        assert result == ""

    def setup_method(self):
        """Set up test fixtures."""
        self.kernel_id = "test-kernel-123"
        self.timeout_seconds = 30

    def test_sandbox_kernel_init(self):
        """Test SandboxKernel initialization."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        assert kernel.id == self.kernel_id
        assert kernel.execution_timeout_seconds == self.timeout_seconds
        assert kernel.status == KernelStatus.PENDING
        assert not kernel.session_initialized
        assert isinstance(kernel.last_activity, float)

    @pytest.mark.asyncio
    async def test_sandbox_kernel_startup_success(self):
        """Test successful kernel startup."""
        with patch(
            "data_science_agent.code_sandbox.kernel_manager.JupyterKernelManager"
        ) as mock_manager_class:
            mock_kernel_manager = Mock()
            mock_kernel_client = Mock()
            mock_kernel_client.start_channels = Mock()
            mock_kernel_client.wait_for_ready = AsyncMock()

            mock_manager_class.return_value = mock_kernel_manager
            mock_kernel_manager.client.return_value = mock_kernel_client
            mock_kernel_manager.start_kernel = AsyncMock()
            mock_kernel_manager._async_is_alive = AsyncMock(return_value=False)

            kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

            # Mock successful session initialization
            with patch.object(
                kernel, "_initialize_session", new_callable=AsyncMock
            ) as mock_init:
                await kernel.startup()

                mock_kernel_manager.start_kernel.assert_called_once()
                mock_kernel_client.start_channels.assert_called_once()
                mock_kernel_client.wait_for_ready.assert_called_once_with(timeout=30)
                mock_init.assert_called_once()
                assert kernel.status == KernelStatus.AVAILABLE

    @pytest.mark.asyncio
    async def test_sandbox_kernel_startup_failure(self):
        """Test kernel startup failure with proper cleanup."""
        with patch(
            "data_science_agent.code_sandbox.kernel_manager.JupyterKernelManager"
        ) as mock_manager_class:
            mock_kernel_manager = Mock()
            mock_manager_class.return_value = mock_kernel_manager
            mock_kernel_manager.start_kernel.side_effect = Exception("Startup failed")
            mock_kernel_manager._async_is_alive = AsyncMock(return_value=True)
            mock_kernel_manager.shutdown_kernel = AsyncMock()

            kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

            with pytest.raises(SandboxKernelCreationError) as exc_info:
                await kernel.startup()

            assert self.kernel_id in str(exc_info.value)
            assert kernel.status == KernelStatus.KILLED
            mock_kernel_manager.shutdown_kernel.assert_called_once_with(now=True)

    @pytest.mark.asyncio
    async def test_sandbox_kernel_terminate_success(self):
        """Test successful kernel termination."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        mock_kernel_manager = Mock()
        mock_kernel_client = Mock()
        kernel.kernel_manager = mock_kernel_manager
        kernel.kernel_client = mock_kernel_client
        kernel.status = KernelStatus.AVAILABLE
        mock_kernel_manager._async_is_alive = AsyncMock(return_value=True)
        mock_kernel_manager.shutdown_kernel = AsyncMock()
        mock_kernel_client.stop_channels = Mock()

        await kernel.terminate()

        mock_kernel_client.stop_channels.assert_called_once()
        mock_kernel_manager.shutdown_kernel.assert_called_once_with(now=True)
        assert kernel.status == KernelStatus.KILLED

    @pytest.mark.asyncio
    async def test_sandbox_kernel_terminate_timeout(self):
        """Test kernel termination with timeout."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        mock_kernel_manager = Mock()
        mock_kernel_client = Mock()
        kernel.kernel_manager = mock_kernel_manager
        kernel.kernel_client = mock_kernel_client
        mock_kernel_manager._async_is_alive = AsyncMock(return_value=True)
        mock_kernel_client.stop_channels = Mock()

        # Simulate timeout during shutdown
        mock_kernel_manager.shutdown_kernel = AsyncMock(
            side_effect=asyncio.TimeoutError()
        )

        await kernel.terminate()

        assert kernel.status == KernelStatus.KILLED

    def test_is_warning_message(self):
        """Test warning message detection."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        # Test warning patterns
        assert kernel._is_warning_message(
            "SnowflakeLoginOptions() is in private preview"
        )
        assert kernel._is_warning_message("Bad owner or permissions on /some/file")
        assert kernel._is_warning_message("UserWarning: Something happened")
        assert kernel._is_warning_message('warn(f"Bad owner or permissions on')
        assert kernel._is_warning_message("To change owner, run `chown")

        # Test non-warning messages
        assert not kernel._is_warning_message("Error: Something went wrong")
        assert not kernel._is_warning_message("Exception: Failed to connect")

    @pytest.mark.asyncio
    async def test_initialize_session_success(self):
        """Test successful session initialization."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        # Mock successful execution with no errors
        async def mock_execute(code):
            yield ExecutionMessage(stdout="Session initialized successfully")

        with patch.object(
            kernel, "execute", side_effect=lambda code: mock_execute(code)
        ):
            await kernel._initialize_session()

            assert kernel.session_initialized

    @pytest.mark.asyncio
    async def test_initialize_session_with_warnings(self):
        """Test session initialization with warning messages."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        # Mock execution with warning messages
        async def mock_execute(code):
            yield ExecutionMessage(
                stderr="SnowflakeLoginOptions() is in private preview"
            )
            yield ExecutionMessage(stdout="Session initialized successfully")

        with patch.object(
            kernel, "execute", side_effect=lambda code: mock_execute(code)
        ):
            await kernel._initialize_session()

            assert kernel.session_initialized

    @pytest.mark.asyncio
    async def test_initialize_session_failure(self):
        """Test session initialization failure."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        # Mock execution with actual error
        async def mock_execute(code):
            yield ExecutionMessage(stderr="Error: Failed to connect to database")

        with patch.object(
            kernel, "execute", side_effect=lambda code: mock_execute(code)
        ):
            with pytest.raises(SandboxKernelSessionInitializationError):
                await kernel._initialize_session()

            assert not kernel.session_initialized

    def test_parse_jupyter_message_stdout(self):
        """Test parsing stdout messages."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        msg = {
            "msg_type": "stream",
            "content": {"name": "stdout", "text": "Hello World\n"},
        }

        result = kernel._parse_jupyter_message(msg)
        assert result.stdout == "Hello World\n"
        assert result.stderr == ""

    def test_parse_jupyter_message_stderr(self):
        """Test parsing stderr messages."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        msg = {
            "msg_type": "stream",
            "content": {"name": "stderr", "text": "Warning: deprecated\n"},
        }

        result = kernel._parse_jupyter_message(msg)
        assert result.stderr == "Warning: deprecated\n"
        assert result.stdout == ""

    def test_parse_jupyter_message_error(self):
        """Test parsing error messages."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        msg = {
            "msg_type": "error",
            "content": {"traceback": ["Traceback:", "ValueError: invalid input"]},
        }

        result = kernel._parse_jupyter_message(msg)
        assert "Traceback:" in result.stderr
        assert "ValueError: invalid input" in result.stderr

    def test_determine_message_match(self):
        """Test message ID matching."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        msg_id = "test-msg-123"
        msg = {"parent_header": {"msg_id": msg_id}}

        assert kernel._determine_message_match(msg, msg_id)
        assert not kernel._determine_message_match(msg, "different-id")

    def test_kernel_is_idle(self):
        """Test kernel idle state detection."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)

        idle_msg = {"msg_type": "status", "content": {"execution_state": "idle"}}

        busy_msg = {"msg_type": "status", "content": {"execution_state": "busy"}}

        other_msg = {
            "msg_type": "stream",
            "content": {"name": "stdout", "text": "output"},
        }

        assert kernel._kernel_is_idle(idle_msg)
        assert not kernel._kernel_is_idle(busy_msg)
        assert not kernel._kernel_is_idle(other_msg)

    @pytest.mark.asyncio
    async def test_execute_code_success(self):
        """Test successful code execution."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        mock_kernel_client = Mock()
        kernel.kernel_client = mock_kernel_client
        kernel.status = KernelStatus.AVAILABLE

        # Mock messages from kernel
        messages = [
            {
                "msg_type": "stream",
                "content": {"name": "stdout", "text": "output"},
                "parent_header": {"msg_id": "msg123"},
            },
            {
                "msg_type": "status",
                "content": {"execution_state": "idle"},
                "parent_header": {"msg_id": "msg123"},
            },
        ]

        mock_kernel_client.execute.return_value = "msg123"

        # Create an async mock for get_iopub_msg that returns messages in sequence
        async def mock_get_iopub_msg():
            for msg in messages:
                return msg

        mock_kernel_client.get_iopub_msg = AsyncMock(side_effect=messages)

        code = "print('hello')"
        results = []
        async for msg in kernel.execute(code):
            results.append(msg)

        assert len(results) == 1
        assert results[0].stdout == "output"
        assert kernel.status == KernelStatus.AVAILABLE

    @pytest.mark.asyncio
    async def test_execute_code_kernel_not_found(self):
        """Test execution when kernel is killed."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        kernel.status = KernelStatus.KILLED

        with pytest.raises(SandboxKernelNotFoundError):
            async for _ in kernel.execute("print('test')"):
                pass

    @pytest.mark.asyncio
    async def test_execute_code_kernel_busy(self):
        """Test execution when kernel is busy."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        kernel.status = KernelStatus.RUNNING

        with pytest.raises(SandboxKernelBusyError):
            async for _ in kernel.execute("print('test')"):
                pass

    @pytest.mark.asyncio
    async def test_execute_code_timeout(self):
        """Test execution timeout."""
        kernel = SandboxKernel(self.kernel_id, 1)  # 1 second timeout
        mock_kernel_client = Mock()
        kernel.kernel_client = mock_kernel_client
        kernel.status = KernelStatus.AVAILABLE

        mock_kernel_client.execute.return_value = "msg123"
        mock_kernel_client.get_iopub_msg = AsyncMock(side_effect=asyncio.TimeoutError())

        with pytest.raises(SandboxKernelTimeoutError):
            async for _ in kernel.execute("print('test')"):
                pass

    def test_save_last_activity(self):
        """Test last activity timestamp update."""
        kernel = SandboxKernel(self.kernel_id, self.timeout_seconds)
        original_time = kernel.last_activity

        time.sleep(0.1)
        kernel._save_last_activity()

        assert kernel.last_activity > original_time


class TestSandboxKernelManager:
    """Test the SandboxKernelManager class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.execution_timeout = 30
        self.cleanup_timeout = 300
        self.manager = SandboxKernelManager(
            self.execution_timeout, self.cleanup_timeout
        )
        self.kernel_id = "test-kernel-456"

    def test_kernel_manager_init(self):
        """Test SandboxKernelManager initialization."""
        assert self.manager.execution_timeout_seconds == self.execution_timeout
        assert self.manager.cleanup_timeout_seconds == self.cleanup_timeout
        assert self.manager.kernels == {}

    @pytest.mark.asyncio
    async def test_get_kernel_create_new(self):
        """Test getting a kernel that doesn't exist (creates new one)."""
        with patch.object(
            self.manager, "create_kernel", new_callable=AsyncMock
        ) as mock_create:
            mock_kernel = Mock()
            mock_create.return_value = mock_kernel

            result = await self.manager.get_kernel(self.kernel_id)

            mock_create.assert_called_once_with(self.kernel_id)
            assert result == mock_kernel
            assert self.manager.kernels[self.kernel_id] == mock_kernel

    @pytest.mark.asyncio
    async def test_get_kernel_existing_available(self):
        """Test getting an existing available kernel."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.AVAILABLE
        self.manager.kernels[self.kernel_id] = mock_kernel

        result = await self.manager.get_kernel(self.kernel_id)

        assert result == mock_kernel

    @pytest.mark.asyncio
    async def test_get_kernel_existing_killed(self):
        """Test getting an existing killed kernel (should raise exception)."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.KILLED
        self.manager.kernels[self.kernel_id] = mock_kernel

        with pytest.raises(SandboxKernelNotFoundError):
            await self.manager.get_kernel(self.kernel_id)

        assert self.kernel_id not in self.manager.kernels

    @pytest.mark.asyncio
    async def test_create_kernel_success(self):
        """Test successful kernel creation."""
        with patch(
            "data_science_agent.code_sandbox.kernel_manager.SandboxKernel"
        ) as mock_kernel_class:
            mock_kernel = AsyncMock()
            mock_kernel_class.return_value = mock_kernel

            result = await self.manager.create_kernel(self.kernel_id)

            mock_kernel_class.assert_called_once_with(
                self.kernel_id, self.execution_timeout
            )
            mock_kernel.startup.assert_called_once()
            assert result == mock_kernel
            assert self.manager.kernels[self.kernel_id] == mock_kernel

    @pytest.mark.asyncio
    async def test_create_kernel_failure(self):
        """Test kernel creation failure."""
        with patch(
            "data_science_agent.code_sandbox.kernel_manager.SandboxKernel"
        ) as mock_kernel_class:
            mock_kernel = AsyncMock()
            mock_kernel.startup.side_effect = Exception("Startup failed")
            mock_kernel_class.return_value = mock_kernel

            with pytest.raises(SandboxKernelCreationError):
                await self.manager.create_kernel(self.kernel_id)

    @pytest.mark.asyncio
    async def test_execute_code_success(self):
        """Test successful code execution."""

        # Create a class that properly implements async iteration
        class MockAsyncGenerator:
            def __init__(self, messages):
                self.messages = messages
                self.index = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                if self.index >= len(self.messages):
                    raise StopAsyncIteration
                message = self.messages[self.index]
                self.index += 1
                return message

        mock_kernel = Mock()
        mock_kernel.execute.return_value = MockAsyncGenerator(
            [ExecutionMessage(stdout="test output")]
        )

        with patch.object(self.manager, "get_kernel", return_value=mock_kernel):
            results = []
            async for msg in self.manager.execute_code(self.kernel_id, "print('test')"):
                results.append(msg)

            assert len(results) == 1
            assert results[0].stdout == "test output"

    @pytest.mark.asyncio
    async def test_sse_stream_code_success(self):
        """Test successful SSE streaming."""

        # Create a class that properly implements async iteration
        class MockAsyncGenerator:
            def __init__(self, messages):
                self.messages = messages
                self.index = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                if self.index >= len(self.messages):
                    raise StopAsyncIteration
                message = self.messages[self.index]
                self.index += 1
                return message

        mock_kernel = Mock()
        mock_kernel.execute.return_value = MockAsyncGenerator(
            [ExecutionMessage(stdout="test output")]
        )

        with patch.object(self.manager, "get_kernel", return_value=mock_kernel):
            results = []
            async for sse_msg in self.manager.sse_stream_code(
                self.kernel_id, "print('test')"
            ):
                results.append(sse_msg)

            assert len(results) == 1
            assert "event: execution_message" in results[0]
            assert "test output" in results[0]

    @pytest.mark.asyncio
    async def test_sse_stream_code_kernel_not_found_error(self):
        """Test SSE streaming with kernel not found error."""
        with patch.object(
            self.manager, "get_kernel", side_effect=SandboxKernelNotFoundError("test")
        ):
            results = []
            async for sse_msg in self.manager.sse_stream_code(
                self.kernel_id, "print('test')"
            ):
                results.append(sse_msg)

            assert len(results) == 1
            assert "event: error" in results[0]
            assert "SandboxKernelNotFoundError" in results[0]

    @pytest.mark.asyncio
    async def test_sse_stream_code_unexpected_error(self):
        """Test SSE streaming with unexpected error."""
        with patch.object(
            self.manager, "get_kernel", side_effect=Exception("Unexpected error")
        ):
            results = []
            async for sse_msg in self.manager.sse_stream_code(
                self.kernel_id, "print('test')"
            ):
                results.append(sse_msg)

            assert len(results) == 1
            assert "event: error" in results[0]
            assert "UnexpectedError" in results[0]

    def test_get_kernels(self):
        """Test getting list of kernel IDs."""
        self.manager.kernels["kernel1"] = Mock()
        self.manager.kernels["kernel2"] = Mock()

        result = self.manager._get_kernels()

        assert set(result) == {"kernel1", "kernel2"}

    def test_get_kernel_status_existing(self):
        """Test getting status of existing kernel."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.AVAILABLE
        self.manager.kernels[self.kernel_id] = mock_kernel

        status = self.manager.get_kernel_status(self.kernel_id)

        assert status == KernelStatus.AVAILABLE

    def test_get_kernel_status_missing(self):
        """Test getting status of non-existent kernel."""
        status = self.manager.get_kernel_status("non-existent")

        assert status == KernelStatus.MISSING

    def test_get_complete_pull_results(self):
        """Test get_complete_pull_results returns correct stdout, stderr, and is_complete."""
        session_id = "session-1"
        # Simulate some results
        msg1 = ExecutionMessage(stdout="out1", stderr="err1")
        msg2 = ExecutionMessage(stdout="out2", stderr="err2")
        self.manager._pull_results[session_id] = [msg1, msg2]
        self.manager._pull_complete[session_id] = False
        (
            stdout,
            stderr,
            all_output,
            is_complete,
        ) = self.manager.get_complete_pull_results(session_id)
        assert stdout == "out1out2"
        assert stderr == "err1err2"
        assert all_output == "out1err1out2err2"
        assert is_complete is False
        msg3 = ExecutionMessage(stdout="out3", stderr="err3")
        self.manager._pull_results[session_id].append(msg3)
        self.manager._pull_complete[session_id] = True
        (
            stdout,
            stderr,
            all_output,
            is_complete,
        ) = self.manager.get_complete_pull_results(session_id)
        assert stdout == "out1out2out3"
        assert stderr == "err1err2err3"
        assert all_output == "out1err1out2err2out3err3"
        assert is_complete is True

    def test_is_already_running_code(self):
        """Test is_already_running_code returns True if code matches, False otherwise."""
        session_id = "session-2"
        code = "print('hi')"
        self.manager._pull_current_code[session_id] = code

        # Patch get_kernel_status to return RUNNING
        with patch.object(
            self.manager, "get_kernel_status", return_value=KernelStatus.RUNNING
        ):
            assert self.manager.is_already_running_code(session_id, code) is True
            assert (
                self.manager.is_already_running_code(session_id, "other code") is False
            )
        # Not present session
        with patch.object(
            self.manager, "get_kernel_status", return_value=KernelStatus.AVAILABLE
        ):
            assert self.manager.is_already_running_code("not-present", code) is False

    @pytest.mark.asyncio
    async def test_start_pull_execution_sets_state_and_starts_task(self):
        """Test start_pull_execution sets state and starts background task."""
        session_id = "session-3"
        code = "print('test')"
        # Patch _run_pull_execution to avoid actually running async code
        with patch.object(
            self.manager, "_run_pull_execution", new_callable=AsyncMock
        ) as mock_run:
            await self.manager.start_pull_execution(session_id, code)
            assert self.manager._pull_complete[session_id] is False
            assert self.manager._pull_results[session_id] == []
            assert self.manager._pull_current_code[session_id] == code
            # Give the event loop a chance to schedule the task
            await asyncio.sleep(0.01)
            mock_run.assert_called_once_with(session_id, code)

    @pytest.mark.asyncio
    async def test_terminate_kernel_success(self):
        """Test successful kernel termination."""
        mock_kernel = AsyncMock()
        self.manager.kernels[self.kernel_id] = mock_kernel

        status = await self.manager.terminate_kernel(self.kernel_id)

        mock_kernel.terminate.assert_called_once()
        assert status == KernelStatus.KILLED
        assert self.kernel_id not in self.manager.kernels

    @pytest.mark.asyncio
    async def test_terminate_kernel_not_found(self):
        """Test terminating non-existent kernel."""
        status = await self.manager.terminate_kernel("non-existent")

        assert status == KernelStatus.MISSING

    @pytest.mark.asyncio
    async def test_terminate_kernel_with_error(self):
        """Test kernel termination with error."""
        mock_kernel = AsyncMock()
        mock_kernel.terminate.side_effect = Exception("Termination failed")
        self.manager.kernels[self.kernel_id] = mock_kernel

        status = await self.manager.terminate_kernel(self.kernel_id)

        assert status == KernelStatus.KILLED
        assert self.kernel_id not in self.manager.kernels

    @pytest.mark.asyncio
    async def test_cleanup_kernels_idle(self):
        """Test cleanup of idle kernels."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.AVAILABLE
        mock_kernel.last_activity = time.time() - 400  # Older than cleanup timeout
        self.manager.kernels[self.kernel_id] = mock_kernel

        with patch.object(
            self.manager, "terminate_kernel", new_callable=AsyncMock
        ) as mock_terminate:
            await self.manager.cleanup_kernels()

            mock_terminate.assert_called_once_with(self.kernel_id)

    @pytest.mark.asyncio
    async def test_cleanup_kernels_killed(self):
        """Test cleanup removes killed kernels."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.KILLED
        self.manager.kernels[self.kernel_id] = mock_kernel

        await self.manager.cleanup_kernels()

        assert self.kernel_id not in self.manager.kernels

    @pytest.mark.asyncio
    async def test_cleanup_kernels_with_error(self):
        """Test cleanup handles errors gracefully."""
        mock_kernel = Mock()
        mock_kernel.status = KernelStatus.AVAILABLE
        mock_kernel.last_activity = time.time() - 400
        self.manager.kernels[self.kernel_id] = mock_kernel

        with patch.object(
            self.manager, "terminate_kernel", side_effect=Exception("Cleanup error")
        ):
            await self.manager.cleanup_kernels()

            # Kernel should be removed even if cleanup fails
            assert self.kernel_id not in self.manager.kernels

    @pytest.mark.asyncio
    async def test_generate_simple_stream(self):
        """Test simple stream generation."""
        results = []
        async for sse_msg in self.manager.generate_simple_stream():
            results.append(sse_msg)

        assert len(results) == 5
        for msg in results:
            assert "event: execution_message" in msg
            assert "data:" in msg

    def test_create_error_sse(self):
        """Test SSE error message creation."""
        error_sse = self.manager._create_error_sse(
            error_type="TestError",
            error_message="Test error message",
            session_id="test-session",
            reason="Test reason",
        )

        assert "event: error" in error_sse
        assert "TestError" in error_sse
        assert "Test error message" in error_sse
        assert "test-session" in error_sse

    def test_convert_to_sse(self):
        """Test message conversion to SSE format."""
        msg = ExecutionMessage(stdout="test output")
        sse_msg = self.manager._convert_to_sse(
            name="test_event", id="test-id-123", msg=msg
        )

        assert "event: test_event" in sse_msg
        assert "id: test-id-123" in sse_msg
        assert "data:" in sse_msg
        assert "test output" in sse_msg
        assert sse_msg.endswith("\n\n")

    def test_convert_to_sse_error_message(self):
        """Test error message conversion to SSE format."""
        error_msg = ErrorMessage(
            error_type="TestError",
            error_message="Test message",
            session_id="test-session",
        )
        sse_msg = self.manager._convert_to_sse(
            name="error", id="error-id-123", msg=error_msg
        )

        assert "event: error" in sse_msg
        assert "TestError" in sse_msg
        assert "Test message" in sse_msg


@pytest.mark.asyncio
class TestIntegrationScenarios:
    """Integration tests for common usage scenarios."""

    def setup_method(self):
        """Set up test fixtures."""
        self.manager = SandboxKernelManager(30, 300)
        self.kernel_id = "integration-test-kernel"

    async def test_full_execution_lifecycle(self):
        """Test complete execution lifecycle from creation to cleanup."""

        # Create a class that properly implements async iteration
        class MockAsyncGenerator:
            def __init__(self, messages):
                self.messages = messages
                self.index = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                if self.index >= len(self.messages):
                    raise StopAsyncIteration
                message = self.messages[self.index]
                self.index += 1
                return message

        with patch(
            "data_science_agent.code_sandbox.kernel_manager.SandboxKernel"
        ) as mock_kernel_class:
            mock_kernel = Mock()
            mock_kernel.status = KernelStatus.AVAILABLE
            mock_kernel.last_activity = time.time()
            mock_kernel.startup = AsyncMock()
            mock_kernel.terminate = AsyncMock()
            mock_kernel.execute.return_value = MockAsyncGenerator(
                [ExecutionMessage(stdout="Executed: print('hello')")]
            )
            mock_kernel_class.return_value = mock_kernel

            # Create and execute code
            results = []
            async for msg in self.manager.execute_code(
                self.kernel_id, "print('hello')"
            ):
                results.append(msg)

            assert len(results) == 1
            assert "Executed: print('hello')" in results[0].stdout

            # Verify kernel is tracked
            assert self.kernel_id in self.manager.kernels

            # Test status
            status = self.manager.get_kernel_status(self.kernel_id)
            assert status == KernelStatus.AVAILABLE

            # Test termination
            final_status = await self.manager.terminate_kernel(self.kernel_id)
            assert final_status == KernelStatus.KILLED
            assert self.kernel_id not in self.manager.kernels


@pytest.mark.parametrize(
    "error_class,error_message",
    [
        (SandboxKernelNotFoundError, "Kernel not found"),
        (SandboxKernelBusyError, "Kernel is busy"),
        (SandboxKernelCreationError, "Failed to create kernel"),
        (SandboxKernelExecutionError, "Code execution failed"),
        (SandboxKernelTimeoutError, "Execution timeout"),
    ],
)
@pytest.mark.asyncio
async def test_error_handling_in_sse_stream(error_class, error_message):
    """Test that all error types are properly handled in SSE streaming."""
    manager = SandboxKernelManager(30, 300)
    kernel_id = "error-test-kernel"

    # Create appropriate exception based on class
    if error_class == SandboxKernelTimeoutError:
        exception = error_class(kernel_id, "test_operation", 30)
    elif error_class == SandboxKernelCreationError:
        exception = error_class(kernel_id, "test reason")
    elif error_class == SandboxKernelExecutionError:
        exception = error_class(kernel_id, "test error")
    else:
        exception = error_class(kernel_id)

    with patch.object(manager, "get_kernel", side_effect=exception):
        results = []
        async for sse_msg in manager.sse_stream_code(kernel_id, "print('test')"):
            results.append(sse_msg)

        assert len(results) == 1
        assert "event: error" in results[0]
        assert error_class.__name__ in results[0]


class TestEnvironmentConfiguration:
    """Test environment-specific configurations."""

    def test_enable_sandbox_read_only_mode_default(self):
        """Test default read-only mode configuration."""
        # Test that the default value is properly imported
        assert isinstance(ENABLE_SANDBOX_READ_ONLY_MODE, bool)

    @patch.dict(os.environ, {"ENABLE_SANDBOX_READ_ONLY_MODE": "false"})
    def test_read_only_mode_disabled_via_env(self):
        """Test read-only mode can be disabled via environment variable."""
        # Re-import to get updated environment value
        import importlib
        from data_science_agent.code_sandbox import kernel_manager

        importlib.reload(kernel_manager)

        assert not kernel_manager.ENABLE_SANDBOX_READ_ONLY_MODE

    @patch.dict(os.environ, {"ENABLE_SANDBOX_READ_ONLY_MODE": "TRUE"})
    def test_read_only_mode_enabled_via_env(self):
        """Test read-only mode can be enabled via environment variable."""
        import importlib
        from data_science_agent.code_sandbox import kernel_manager

        importlib.reload(kernel_manager)

        assert kernel_manager.ENABLE_SANDBOX_READ_ONLY_MODE


if __name__ == "__main__":
    pytest.main([__file__])
