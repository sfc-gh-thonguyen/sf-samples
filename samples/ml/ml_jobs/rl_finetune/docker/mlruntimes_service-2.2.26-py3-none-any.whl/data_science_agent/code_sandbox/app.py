"""
Code Sandbox

This module provides the HTTP API for executing Python code in isolated IPython kernels
for code execution services. It handles kernel lifecycle management, code execution,
and resource cleanup.
"""

import logging
import time
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Response
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from data_science_agent.code_sandbox.kernel_manager import (
    SandboxKernelManager,
)
from data_science_agent.code_sandbox.models import (
    ExecuteRequest,
    StatusRequest,
    StatusResponse,
    CancelRequest,
    CancelResponse,
    HealthResponse,
    ErrorResponse,
    PullResultsRequest,
    PullResultsResponse,
    KernelStatus,
    CompletePullResultsResponse,
)

from data_science_agent.code_sandbox.config import get_config, setup_logging


# Load configuration
config = get_config()
logger = logging.getLogger(__name__)


kernel_manager = SandboxKernelManager(
    execution_timeout_seconds=config.execution_timeout,
    cleanup_timeout_seconds=config.cleanup_interval,
)

# Background cleanup task for idle kernels
cleanup_task = None


async def cleanup_loop():
    while True:
        try:
            await asyncio.sleep(config.cleanup_interval)
            await kernel_manager.cleanup_kernels()
            logger.debug("Running kernel cleanup")
        except Exception as e:
            logger.error(f"Error in cleanup task: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global cleanup_task
    try:
        setup_logging(config)
        cleanup_task = asyncio.create_task(cleanup_loop())
        cleanup_task.set_name("kernel_cleanup_task")
        logger.info("Application startup completed successfully")
        yield
    except Exception as e:
        logger.error(f"Error during application startup: {e}")
        raise
    finally:
        # Shutdown
        if cleanup_task and not cleanup_task.done():
            cleanup_task.cancel()
            try:
                await cleanup_task
            except asyncio.CancelledError:
                pass
            logger.info("Cleanup task cancelled")

        # Terminate all remaining kernels on shutdown
        try:
            active_kernels = list(kernel_manager.kernels.keys())
            logger.info(
                f"Terminating {len(active_kernels)} active kernels during shutdown"
            )
            for kernel_id in active_kernels:
                try:
                    await kernel_manager.terminate_kernel(kernel_id)
                except Exception as e:
                    logger.error(
                        f"Error terminating kernel {kernel_id} during shutdown: {e}"
                    )
        except Exception as e:
            logger.error(f"Error during kernel cleanup on shutdown: {e}")


# Initialize FastAPI app
app = FastAPI(
    title="Code Sandbox API",
    description="API for executing Python code in isolated IPython kernels",
    version="1.0.0",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post(
    "/stream-execute",
    summary="Execute Python code with streaming output",
    description="Execute Python code in an IPython kernel and stream the output via Server-Sent Events",
    response_description="Server-Sent Events stream of execution output",
    responses={
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Execution error"},
    },
)
async def stream_execute(request: ExecuteRequest):
    """
    Execute Python code in an IPython kernel and stream the output.

    All exceptions are now handled internally by sse_stream_code() and sent
    as error events in the SSE stream, ensuring proper error communication
    to the client even after the streaming response has started.
    """
    logger.debug(f"Executing code for request: {request.session_id}")
    return StreamingResponse(
        kernel_manager.sse_stream_code(request.session_id, request.code_string),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@app.post(
    "/test-execute",
    summary="Test endpoint for simple streaming",
    description="Execute Python code in an IPython kernel and stream mock output (test endpoint)",
    response_description="Server-Sent Events stream of test output",
    responses={
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Execution error"},
    },
)
async def test_execute(request: ExecuteRequest):
    """
    Execute Python code in an IPython kernel and stream the output (test endpoint).
    """

    try:
        logger.debug(f"Simple streaming for request: {request.session_id}")

        return StreamingResponse(
            kernel_manager.generate_simple_stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
        )
    except Exception as e:
        logger.error(f"Simple stream error: {e}")
        return JSONResponse(
            {"error": "Internal server error", "details": str(e)}, status_code=500
        )


@app.post(
    "/send-execute",
    response_model=None,
    summary="Execute Python code with pull-based results",
    description="Execute Python code in an IPython kernel using pull-based results",
    responses={
        400: {
            "model": ErrorResponse,
            "description": "Kernel is currently busy or killed",
        },
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal Server error"},
    },
)
async def send_execute(request: ExecuteRequest) -> Response:
    """Start executing Python code using pull methodology."""
    try:
        is_already_running = kernel_manager.is_already_running_code(
            request.session_id, request.code_string
        )
        if is_already_running:
            logger.debug(f"Code is already running for session: {request.session_id}")
            return Response(status_code=202)
        status = kernel_manager.get_kernel_status(request.session_id)
        if status == KernelStatus.RUNNING:
            return JSONResponse(
                {"error": "Kernel is currently running"}, status_code=400
            )
        if status == KernelStatus.KILLED:
            return JSONResponse({"error": "Kernel has been killed"}, status_code=400)
        logger.debug(f"Starting pull execution for session: {request.session_id}")
        await kernel_manager.start_pull_execution(
            request.session_id, request.code_string
        )
        return Response(status_code=200)
    except Exception as e:
        logger.error(f"Error starting pull execution: {e}")
        return JSONResponse({"error": "Internal server error"}, status_code=500)


# TODO: This endpoint will be deprecated
@app.post(
    "/pull-results",
    response_model=PullResultsResponse,
    summary="Pull execution results",
    description="Get accumulated results for a running execution in the session",
    responses={
        404: {
            "model": ErrorResponse,
            "description": "Pull results not found or already finished",
        },
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal Server error"},
    },
)
async def pull_results(request: PullResultsRequest) -> PullResultsResponse:
    """Get accumulated results for a running execution."""
    try:
        logger.debug(f"Pulling results for session: {request.session_id}")
        is_running = kernel_manager.check_pull_exists(request.session_id)
        if not is_running:
            return JSONResponse(
                {"error": "Pull results not found or already finished"}, status_code=404
            )
        stdout, stderr, is_complete = kernel_manager.get_pull_results(
            request.session_id
        )
        return PullResultsResponse(
            stdout=stdout, stderr=stderr, is_complete=is_complete
        )
    except Exception as e:
        logger.error(f"Error pulling results: {e}")
        return JSONResponse(
            {"error": "Internal server error", "details": str(e)}, status_code=500
        )


@app.post(
    "/pull-complete-results",
    response_model=CompletePullResultsResponse,
    summary="Pull execution results",
    description="Get accumulated results for a running execution in the session",
    responses={
        404: {
            "model": ErrorResponse,
            "description": "Pull results not found",
        },
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal Server error"},
    },
)
async def pull_complete_results(
    request: PullResultsRequest,
) -> CompletePullResultsResponse:
    """Get accumulated results for a running execution."""
    try:
        logger.debug(f"Pulling results for session: {request.session_id}")
        pull_exists = kernel_manager.check_pull_exists(request.session_id)
        if not pull_exists:
            return JSONResponse({"error": "Pull results not found"}, status_code=404)
        (
            stdout,
            stderr,
            all_output,
            is_complete,
        ) = kernel_manager.get_complete_pull_results(request.session_id)
        return CompletePullResultsResponse(
            stdout=stdout, stderr=stderr, all_output=all_output, is_complete=is_complete
        )
    except Exception as e:
        logger.error(f"Error pulling results: {e}")
        return JSONResponse(
            {"error": "Internal server error", "details": str(e)}, status_code=500
        )


@app.post(
    "/status",
    response_model=StatusResponse,
    summary="Get kernel status",
    description="Get the current status of a kernel for a given session",
    responses={
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Server error"},
    },
)
async def get_status(request: StatusRequest) -> StatusResponse:
    """
    Get the status of a request's kernel.
    """
    try:
        logger.debug(f"Getting status for request: {request.session_id}")
        kernel_status = kernel_manager.get_kernel_status(request.session_id)
        return StatusResponse(status=kernel_status)
    except Exception as e:
        logger.error(f"Error getting status: {e}")
        return JSONResponse(
            {"error": "Internal server error", "details": str(e)}, status_code=500
        )


@app.post(
    "/cancel",
    response_model=CancelResponse,
    summary="Cancel kernel execution",
    description="Cancel execution and kill the kernel for a given session",
    responses={
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Server error"},
    },
)
async def cancel_execution(request: CancelRequest) -> CancelResponse:
    """
    Cancel execution and kill the kernel for a request.
    """
    try:
        logger.info(f"Cancelling request: {request.session_id}")

        kernel_status = await kernel_manager.terminate_kernel(request.session_id)
        return CancelResponse(status=kernel_status)
    except Exception as e:
        logger.error(f"Error cancelling execution: {e}")
        return JSONResponse(
            {"error": "Internal server error", "details": str(e)}, status_code=500
        )


@app.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    description="Health check endpoint for the sandbox service",
)
def health_check() -> HealthResponse:
    """Health check endpoint for the sandbox service."""
    return HealthResponse(status="healthy", timestamp=time.time())


# If running directly, use uvicorn
if __name__ == "__main__":
    import uvicorn

    logger.info(f"Starting Code Sandbox on port {config.port}")
    setup_logging(config)
    uvicorn.run(
        "data_science_agent.code_sandbox.app:app",
        host=config.host,
        port=config.port,
        reload=True,
    )
