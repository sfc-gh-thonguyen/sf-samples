"""
Custom exceptions for the Code Sandbox application.

This module defines specific exceptions that can occur during kernel
management and code execution.
"""


class SandboxKernelError(Exception):
    """Base exception for sandbox kernel-related errors."""

    pass


class SandboxKernelNotFoundError(SandboxKernelError):
    """Raised when a requested kernel cannot be found."""

    def __init__(self, request_id: str):
        self.request_id = request_id
        super().__init__(f"Kernel not found for request ID: {request_id}")


class SandboxKernelBusyError(SandboxKernelError):
    """Raised when trying to execute code on a busy kernel."""

    def __init__(self, request_id: str):
        self.request_id = request_id
        super().__init__(f"Kernel is busy for request ID: {request_id}")


class SandboxKernelCreationError(SandboxKernelError):
    """Raised when a kernel cannot be created."""

    def __init__(self, request_id: str, reason: str):
        self.request_id = request_id
        self.reason = reason
        super().__init__(
            f"Failed to create kernel for request ID {request_id}: {reason}"
        )


class SandboxKernelExecutionError(SandboxKernelError):
    """Raised when code execution fails in a kernel."""

    def __init__(self, request_id: str, error_message: str):
        self.request_id = request_id
        self.error_message = error_message
        super().__init__(
            f"Execution failed for request ID {request_id}: {error_message}"
        )


class SandboxKernelTimeoutError(SandboxKernelError):
    """Raised when a kernel operation times out."""

    def __init__(self, request_id: str, operation: str, timeout_seconds: float):
        self.request_id = request_id
        self.operation = operation
        self.timeout_seconds = timeout_seconds
        super().__init__(
            f"Timeout after {timeout_seconds}s for operation '{operation}' "
            f"on request ID: {request_id}"
        )


class SandboxKernelSessionInitializationError(SandboxKernelError):
    """Raised when a kernel session initialization fails."""

    def __init__(self, kernel_id: str, error_message: str):
        self.kernel_id = kernel_id
        self.error_message = error_message
        super().__init__(
            f"Session initialization failed for kernel {kernel_id}: {error_message}"
        )
