import os
import tempfile
import uuid
from typing import List
import hashlib
from unittest.mock import call, patch, MagicMock
from snowflake.ml.modeling.distributors.pytorch import (
    StageArtifactManager,
)


class TestArtifactManager:
    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": str(uuid.uuid4())})
    def test_list_local_files(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '"stage_name"/stage_path'
        )
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files in the temporary directory
            file1: str = os.path.join(tmpdir, "file1.txt")
            file2: str = os.path.join(tmpdir, "subdir", "file2.txt")
            os.makedirs(os.path.dirname(file1), exist_ok=True)
            os.makedirs(os.path.dirname(file2), exist_ok=True)
            open(file1, "w").write("content")
            open(file2, "w").write("content")

            files: List[str] = checkpoint_manager._list_local_files(tmpdir)
            assert sorted(files) == sorted(["file1.txt", "subdir/file2.txt"])

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": "request_id"})
    def test_report_checkpoint(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '@"weired_db$a"."even_WEIRED_SCHEMA"."stage_name"/stage_path'
        )
        checkpoint_manager.filesystem.session = mock_session
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files in the temporary directory
            file1: str = os.path.join(tmpdir, "file1.txt")
            file2: str = os.path.join(tmpdir, "subdir", "file2.txt")
            os.makedirs(os.path.dirname(file1), exist_ok=True)
            os.makedirs(os.path.dirname(file2), exist_ok=True)
            open(file1, "w").write("content")
            open(file2, "w").write("content")

            hash_md5 = hashlib.md5()
            hash_md5.update(b"content")

            mock_session.sql.return_value.collect.return_value = [
                {
                    "name": "/stage_name/stage_path/file1.txt",
                    "md5": hash_md5.hexdigest(),
                },
            ]
            checkpoint_manager.report_checkpoint(tmpdir)
            mock_session.file.put.assert_has_calls(
                [
                    call(
                        file1,
                        '\'@"weired_db$a"."even_WEIRED_SCHEMA"."stage_name"/stage_path/checkpoint/request_id\'',
                        auto_compress=False,
                        overwrite=True,
                        parallel=4,
                    ),
                    call(
                        file2,
                        '\'@"weired_db$a"."even_WEIRED_SCHEMA"."stage_name"/stage_path/checkpoint/request_id/subdir\'',
                        auto_compress=False,
                        overwrite=True,
                        parallel=4,
                    ),
                ]
            )

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": str(uuid.uuid4())})
    def test_collect_stage_files(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '"stage_name"/stage_path'
        )

        # Mock the filesystem
        mock_filesystem: MagicMock = MagicMock()
        checkpoint_manager.filesystem = mock_filesystem

        # Test case 1: Simple files and directories
        mock_filesystem.listdir.side_effect = [
            # First call for root path
            [
                {"name": "file1.txt", "type": "file"},
                {"name": "subdir", "type": "directory"},
                {"name": "file2.txt", "type": "file"},
            ],
            # Second call for subdir
            [
                {"name": "subdir/file3.txt", "type": "file"},
                {"name": "subdir/nested_dir", "type": "directory"},
            ],
            # Third call for nested_dir
            [
                {"name": "subdir/nested_dir/file4.txt", "type": "file"},
            ],
        ]

        files: List[str] = checkpoint_manager._collect_stage_files("root_path", set())

        expected_files: List[str] = [
            "file1.txt",
            "file2.txt",
            "subdir/file3.txt",
            "subdir/nested_dir/file4.txt",
        ]
        assert sorted(files) == sorted(expected_files)

        # Verify listdir was called for each directory
        assert mock_filesystem.listdir.call_count == 3
        mock_filesystem.listdir.assert_any_call("root_path", detail=True)
        mock_filesystem.listdir.assert_any_call("subdir", detail=True)
        mock_filesystem.listdir.assert_any_call("subdir/nested_dir", detail=True)

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": str(uuid.uuid4())})
    def test_collect_stage_files_depth_limit(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '"stage_name"/stage_path'
        )

        # Mock the filesystem
        mock_filesystem: MagicMock = MagicMock()
        checkpoint_manager.filesystem = mock_filesystem

        # Test depth limit - should return empty list when depth > MAX_FILESYSTEM_DEPTH
        # MAX_FILESYSTEM_DEPTH is 10 based on the code
        files: List[str] = checkpoint_manager._collect_stage_files(
            "deep_path", set(), depth=11
        )

        assert files == []
        # listdir should not be called when depth limit is exceeded
        mock_filesystem.listdir.assert_not_called()

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": str(uuid.uuid4())})
    def test_collect_stage_files_exception_handling(
        self, mock_session: MagicMock
    ) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '"stage_name"/stage_path'
        )

        # Mock the filesystem
        mock_filesystem: MagicMock = MagicMock()
        checkpoint_manager.filesystem = mock_filesystem

        # Test exception handling - listdir raises exception
        mock_filesystem.listdir.side_effect = Exception("Stage access error")

        files: List[str] = checkpoint_manager._collect_stage_files("error_path", set())

        # Should return empty list when exception occurs
        assert files == []
        mock_filesystem.listdir.assert_called_once_with("error_path", detail=True)

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": str(uuid.uuid4())})
    def test_collect_stage_files_empty_directory(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '"stage_name"/stage_path'
        )

        # Mock the filesystem
        mock_filesystem: MagicMock = MagicMock()
        checkpoint_manager.filesystem = mock_filesystem

        # Test empty directory
        mock_filesystem.listdir.return_value = []

        files: List[str] = checkpoint_manager._collect_stage_files("empty_path", set())

        assert files == []
        mock_filesystem.listdir.assert_called_once_with("empty_path", detail=True)

    @patch("snowflake.snowpark.Session")
    @patch.dict(os.environ, {"RAY_JOB_REQUEST_ID": "request_id"})
    def test_upload_model_files_to_stage(self, mock_session: MagicMock) -> None:
        checkpoint_manager: StageArtifactManager = StageArtifactManager(
            mock_session, '@"weired_db$a"."even_WEIRED_SCHEMA"."stage_name"/stage_path'
        )

        # Mock the filesystem
        mock_filesystem: MagicMock = MagicMock()
        checkpoint_manager.filesystem = mock_filesystem

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some model files in the temporary directory
            file1: str = os.path.join(tmpdir, "model.pkl")
            file2: str = os.path.join(tmpdir, "subdir", "weights.bin")
            file3: str = os.path.join(tmpdir, "config.json")

            os.makedirs(os.path.dirname(file1), exist_ok=True)
            os.makedirs(os.path.dirname(file2), exist_ok=True)
            os.makedirs(os.path.dirname(file3), exist_ok=True)

            with open(file1, "w") as f:
                f.write("model content")
            with open(file2, "w") as f:
                f.write("weights content")
            with open(file3, "w") as f:
                f.write("config content")

            # List of files to upload (relative paths)
            files_to_upload: List[str] = [
                "model.pkl",
                "subdir/weights.bin",
                "config.json",
            ]

            # Call the method under test
            checkpoint_manager.upload_model_files_to_stage(tmpdir, files_to_upload)

            # Verify write_file_to_stage was called for each file
            assert mock_filesystem.write_file_to_stage.call_count == 3

            # Verify the calls with expected arguments
            mock_filesystem.write_file_to_stage.assert_any_call(
                file1, "model/request_id/model.pkl"
            )
            mock_filesystem.write_file_to_stage.assert_any_call(
                file2, "model/request_id/subdir/weights.bin"
            )
            mock_filesystem.write_file_to_stage.assert_any_call(
                file3, "model/request_id/config.json"
            )
