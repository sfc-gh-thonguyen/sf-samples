import threading
from typing import Callable, Dict
from snowflake.runtime.utils.session_utils import get_session
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
)
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_info,
)

from snowflake.ml.data.ingestor_utils import get_dataframe_result_batches
from snowflake.ml.data.data_source import DataFrameInfo

logger = get_logger()


class ResultSetDataLoader:
    """
    This class is responsible for converting a given partitioned Snowpark DataFrame into result batches. Each completed
    result batch is submitted to the Ray actor pool to begin running training workloads. Downstream training actors will
    receive the result batch corresponding to the given partitionedId.
    """

    def __init__(
        self,
        *,
        partition_id_and_query: Dict[str, str],
        execution_options: ExecutionOptions,
        on_partition_ready: Callable[[str], None],
    ):
        self._partition_id_and_query = partition_id_and_query
        self._execution_options = execution_options
        self._on_partition_ready = on_partition_ready
        self._processed_counts = 0

        self._thread = None
        self._stop_event = threading.Event()

    def start(self):
        self._thread = threading.Thread(target=self._load_and_submit, daemon=True)
        self._thread.start()

    def stop(self):
        if self._thread:
            self._stop_event.set()
            self._thread.join()

    def get_processed_counts(self) -> int:
        return self._processed_counts

    def _load_and_submit(self):
        """
        Load result batches and then pass down to train actor.
        """
        session = get_session()
        original_wh = session.get_current_warehouse()
        if self._execution_options.loading_wh is not None:
            print_user_log_info(
                logger,
                f"Switching to use loading warehouse: {self._execution_options.loading_wh}",
            )
            session.sql(f"USE WAREHOUSE {self._execution_options.loading_wh}").collect()

        for partition_id in self._partition_id_and_query.keys():
            if self._stop_event.is_set():
                break

            partitioned_query = self._partition_id_and_query[partition_id]
            dataframe_info = DataFrameInfo(partitioned_query)
            result_batches = get_dataframe_result_batches(session, dataframe_info)

            self._on_partition_ready(
                partition_id=partition_id,
                result_batches=result_batches,
                dataframe_info=dataframe_info,
            )
            self._processed_counts += 1

        # Restore original warehouse
        if self._execution_options.loading_wh is not None:
            session.sql(f"USE WAREHOUSE {original_wh}").collect()
            print_user_log_info(
                logger, f"Switched back to original warehouse: {original_wh}"
            )
