from typing import Any, Dict, Optional

from snowflake.ml.modeling.distributors.many_model.utils import (
    ModelSerde,
    PickleSerde,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.dpf_run import (
    DPFRun,
    _ReadOnlyDPFRun,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    download_and_deserialize_from_stage,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.constants import (
    MMT_STATE_PICKLE_FILENAME,
)
from common_utils.shared_storage_util import convert_to_fully_qualified_stage


class _GetModelMixin:
    """Mixin providing get_model functionality for ManyModel run classes."""

    _serde: ModelSerde
    partition_details: Dict[str, Any]

    def get_model(self, partition_id: str) -> Any:
        """
        Load a model from a specific partition.

        Args:
            partition_id: The partition ID to load the model from

        Returns:
            The deserialized model object

        Raises:
            RuntimeError: If the partition ID is not found
        """
        if partition_id not in self.partition_details:
            raise RuntimeError(f"Partition ID {partition_id} not found")
        details = self.partition_details[partition_id]
        return details.stage_artifacts_manager.get(
            self._serde.filename, read_function=self._serde.read
        )


class ManyModelRun(_GetModelMixin, DPFRun):
    """
    A DPFRun subclass that provides enhanced functionality for many model scenarios.

    This class inherits all standard DPFRun methods while adding convenient model access methods.
    """

    def __init__(self, dpf_run: DPFRun, serde: ModelSerde):
        # Initialize parent class with the same parameters as the underlying DPFRun
        super().__init__(
            dpf_run.run_id,
            orchestrator_ref=dpf_run._orchestrator_ref,
            run_object_ref=dpf_run._run_object_ref,
        )
        self._serde = serde

    @classmethod
    def restore_from(
        cls, run_id: str, stage_name: str, serde: Optional[ModelSerde] = None
    ) -> "_ReadOnlyManyModelRun":
        """
        Restore a completed ManyModel run from its persisted state.

        Args:
            run_id (str): The run ID of the execution to restore.
            stage_name (str): The stage name where the run artifacts are stored.
            serde (Optional[ModelSerde]): The serializer used during training.
                Must match the serde used when the models were trained.
                Defaults to PickleSerde if not specified.

        Returns:
            _ReadOnlyManyModelRun: A read-only ManyModelRun instance with access to
                the completed run's results and get_model() functionality.

        Raises:
            ValueError: If the run state cannot be restored from the specified location.
        """
        return _ReadOnlyManyModelRun.restore_from_stage(
            run_id=run_id,
            stage_name=stage_name,
            serde=serde or PickleSerde(),
        )


class _ReadOnlyManyModelRun(_GetModelMixin, _ReadOnlyDPFRun):
    """
    An internal, read-only handle to a COMPLETED ManyModel run, restored from its
    persisted state file. Provides get_model() functionality for accessing trained models.
    """

    def __init__(self, run_id: str, *, states: Dict[str, Any], serde: ModelSerde):
        super().__init__(run_id=run_id, states=states)
        self._serde = serde

    @classmethod
    def restore_from_stage(
        cls, run_id: str, stage_name: str, serde: ModelSerde
    ) -> "_ReadOnlyManyModelRun":
        fully_qualified_stage_name = convert_to_fully_qualified_stage(stage_name)
        try:
            states = download_and_deserialize_from_stage(
                run_id=run_id,
                stage_name=fully_qualified_stage_name,
                subpath=[MMT_STATE_PICKLE_FILENAME],
            )
            return cls(run_id=run_id, states=states, serde=serde)
        except Exception as e:
            raise ValueError(f"Failed to restore state for run_id='{run_id}': {e}")
