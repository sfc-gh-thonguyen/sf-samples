from typing import List, Protocol, Optional
import os
import tempfile

from snowflake.snowpark import Session
from common_utils.shared_storage_util import (
    convert_to_fully_qualified_stage,
)
from shared_storage.abtract_stage_shared_filesystem import AbstractStageSharedFileSystem
from shared_storage.constants import USER_STAGE_NAME
from shared_storage.named_stage_shared_filesystem import NamedStageSharedFileSystem
from shared_storage.user_stage_shared_filesystem import UserStageSharedFileSystem
from snowflake.runtime.utils.logger import get_logger
from web.jobs.common import get_request_id

MAX_FILESYSTEM_DEPTH = 10

logger = get_logger()


class ArtifactManager(Protocol):
    """
    Interface for managing checkpoints, models and other artifacts during training.
    """

    def report_checkpoint(self, local_checkpoint_path: str) -> None:
        """
        Upload new files from local checkpoint path to remote shared storage.
        """
        ...

    def fetch_remote_checkpoint(self) -> str:
        """
        Fetch the checkpoint from remote shared storage to local storage.
        """
        ...

    def get_updated_model_files(self, local_model_dir: str) -> List[str]:
        """
        Get list of model files that are new or updated compared to the remote storage.

        Args:
            local_model_dir: Local directory containing model files

        Returns:
            List of relative file paths that are new or updated
        """
        ...

    def upload_model_files_to_stage(
        self, local_model_dir: str, files: List[str]
    ) -> None:
        """
        Sync specific model files to remote storage.

        Args:
            local_model_dir: Local directory containing model files
            files: List of relative file paths to sync
        """
        ...

    def get_model_location(self) -> str:
        """
        Get the location where model artifacts are stored.

        Returns:
            Path or location identifier for model storage
        """
        ...

    def get_checkpoint_location(self) -> str:
        """
        Get the location where checkpoint artifacts are stored.

        Returns:
            Path or location identifier for checkpoint storage
        """
        ...


class StageArtifactManager:
    """
    Stage based manager for managing checkpoints, models and other artifacts during training.
    Uses PyFileSystem with fsspec for efficient stage operations.
    """

    def __init__(
        self, session: Session, stage_location: str, request_id: Optional[str] = None
    ) -> None:
        """
        Initialize the ArtifactManager with a Snowpark session and a stage location.

        Args:
            session: Snowpark session object (used for compatibility, but filesystem operations use fsspec).
            stage_location: Snowflake stage location. e.g. <stage_name>/<stage_path>.
            request_id: Request ID for the training job. If not provided, will be generated using the Ray job ID.
        """
        self.session = session

        self.stage_location = (
            stage_location
            if stage_location.startswith(USER_STAGE_NAME)
            else f"@{convert_to_fully_qualified_stage(stage_location)}"
        )

        # Set up subdirectories for checkpoints and models
        self._request_id = request_id if request_id else get_request_id()
        self.checkpoint_sub_dir = f"checkpoint/{self._request_id}"
        self.model_sub_dir = f"model/{self._request_id}"

        # Create PyFileSystem with fsspec for stage operations
        self.filesystem = self._get_filesystem()

        # Maintain a list of files already stored as checkpoints previously so as not to overwrite
        self._checkpointed_files: List[str] = []

    def _get_filesystem(self) -> AbstractStageSharedFileSystem:
        if self.stage_location.startswith(USER_STAGE_NAME):
            stage_fs = UserStageSharedFileSystem(
                stage_path=self.stage_location,
            )
        else:
            stage_fs = NamedStageSharedFileSystem(
                stage_path=self.stage_location,
            )
        return stage_fs

    def _get_file_path_suffix(self, file_path, prefix) -> str:
        return file_path.split(prefix)[-1].lstrip("/")

    def _get_updated_files(self, local_dir: str, stage_sub_dir: str) -> list[str]:
        """Returns the suffixes of the local files that do not yet exist on the stage."""
        local_files = self._list_local_files(local_dir)

        stage_files = self._collect_stage_files(stage_sub_dir, set())
        stage_file_suffixes = [
            self._get_file_path_suffix(file, stage_sub_dir) for file in stage_files
        ]
        return [f for f in local_files if f not in stage_file_suffixes]

    def _collect_stage_files(
        self, path: str, visited: set, depth: int = 0
    ) -> List[str]:
        if (
            depth > MAX_FILESYSTEM_DEPTH or path in visited
        ):  # Prevent deep recursion and cycles
            return []

        visited.add(path)
        files = []

        try:
            items = self.filesystem.listdir(path, detail=True)
            for item in items:
                item_path = item.get("name", "")
                item_type = item.get("type", "")

                if item_type == "directory":
                    # Recurse into subdirectory
                    files.extend(
                        self._collect_stage_files(item_path, visited, depth + 1)
                    )
                else:
                    files.append(item_path)
        except Exception as e:
            logger.warning(f"Error listing path {path}: {e}")

        return files

    def _fetch_files_from_stage(self, local_directory: str) -> None:
        """Fetch all files from a Snowflake stage to a local directory."""
        try:
            # List all files in the stage
            checkpoint_files = self._collect_stage_files(self.checkpoint_sub_dir, set())
            model_files = self._collect_stage_files(self.model_sub_dir, set())

            checkpoint_file_suffixes = [
                self._get_file_path_suffix(file, self.checkpoint_sub_dir)
                for file in checkpoint_files
            ]
            model_file_suffixes = [
                self._get_file_path_suffix(file, self.model_sub_dir)
                for file in model_files
            ]

            for file_path, suffix in zip(
                checkpoint_files + model_files,
                checkpoint_file_suffixes + model_file_suffixes,
            ):
                # Create local directory structure
                local_file_path = os.path.join(local_directory, suffix)
                local_dir = os.path.dirname(local_file_path)
                os.makedirs(local_dir, exist_ok=True)

                # Download file from stage
                with self.filesystem.open_input_file(
                    file_path, decompress=True
                ) as stage_file:
                    with open(local_file_path, "wb") as local_file:
                        local_file.write(stage_file.read())

                logger.info(f"Downloaded: {file_path} to {local_file_path}")

        except Exception as e:
            logger.error(f"Error fetching files from stage: {e}")
            raise e

    def _list_local_files(self, directory: str) -> List[str]:
        """
        Recursively list all files in a local directory.
        """
        files: List[str] = []
        if not os.path.exists(directory):
            return files

        for root, _, filenames in os.walk(directory):
            for filename in filenames:
                full_path = os.path.join(root, filename)
                relative_path = os.path.relpath(full_path, directory)
                files.append(relative_path)
        return files

    def get_updated_model_files(self, local_model_dir: str) -> List[str]:
        """Get list of model files that are new or updated compared to the stage."""
        return self._get_updated_files(local_model_dir, self.model_sub_dir)

    def upload_model_files_to_stage(
        self, local_model_dir: str, files: List[str]
    ) -> None:
        """Sync specific model files to the stage."""
        for file in files:
            local_file_path = os.path.join(local_model_dir, file)
            file_location = self._get_file_path_suffix(file, local_model_dir)
            stage_path = os.path.join(self.model_sub_dir, file_location.lstrip("/"))
            self.filesystem.write_file_to_stage(local_file_path, stage_path)

    def get_checkpoint_location(self) -> str:
        """Get the checkpoint location in the stage."""
        return os.path.join(self.stage_location, self.checkpoint_sub_dir)

    def get_model_location(self) -> str:
        """Get the model location in the stage."""
        return os.path.join(self.stage_location, self.model_sub_dir)

    def report_checkpoint(self, local_checkpoint_path: str, overwrite=False) -> None:
        """
        Upload new files from local checkpoint path to remote shared storage.
        """
        local_files = self._list_local_files(local_checkpoint_path)

        for file in local_files:
            if not overwrite and file not in self._checkpointed_files:
                local_file_path = os.path.join(local_checkpoint_path, file)
                file_location = self._get_file_path_suffix(file, local_checkpoint_path)
                stage_path = os.path.join(
                    self.checkpoint_sub_dir, file_location.lstrip("/")
                )
                self.filesystem.write_file_to_stage(local_file_path, stage_path)
                self._checkpointed_files.append(file)

    def fetch_remote_checkpoint(self) -> str:
        """
        Fetch the checkpoint from remote shared storage to local storage.
        """
        temp_dir = tempfile.mkdtemp()
        self._fetch_files_from_stage(temp_dir)
        return temp_dir
