from lightgbm import LGBMClassifier, LGBMRegressor

from snowflake.ml.modeling.distributors.lightgbm import (
    LightGBMEstimator,
)
from unittest import mock
import pytest
import pandas as pd
import numpy as np
from snowflake.ml.data.data_connector import DataConnector
from scipy.sparse import csr_matrix


SAMPLE_DATA_CONNECTOR = mock.Mock(spec=DataConnector)


@mock.patch("web.request_handler.LGBMTrainingHandler")
def test_lgb_estimator_will_not_predict_when_not_trained(mock_xgb_training_handler):
    estimator = LightGBMEstimator(n_estimators=10)

    with pytest.raises(ValueError):
        estimator.predict(SAMPLE_DATA_CONNECTOR)


@pytest.mark.parametrize(
    "y",
    [
        np.array([0, 1, 0, 2, 1]),
        pd.Series([2, 1, 0, 0, 1]),
        csr_matrix(
            (np.array([1, 0, 2]), (np.array([0, 0, 1]), np.array([0, 1, 0]))),
            shape=(2, 3),
        ),
    ],
)
def test_sklearn_classifier(y):
    # Initialize the estimator
    estimator = LightGBMEstimator(n_estimators=10, objective="multiclass")

    # Mock the trained booster and parameters
    estimator._trained_booster = mock.MagicMock()
    # estimator._params = {"objective": "binary:logistic"}

    # Call the function
    sklearn_estimator = estimator._to_sklearn_estimator(y)

    # Assertions
    assert sklearn_estimator is not None
    assert isinstance(sklearn_estimator, LGBMClassifier)
    assert sklearn_estimator._Booster is estimator._trained_booster
    assert sklearn_estimator.n_classes_ == 3


@pytest.mark.parametrize(
    "y",
    [
        np.array([0, 1, 0, 2, 1]),
        pd.Series([2, 1, 0, 0, 1]),
        csr_matrix(
            (np.array([1, 0, 2]), (np.array([0, 0, 1]), np.array([0, 1, 0]))),
            shape=(2, 3),
        ),
    ],
)
def test_sklearn_regressor(y) -> None:
    # Initialize the estimator
    estimator = LightGBMEstimator(n_estimators=10, objective="regression_l1")

    # Mock the trained booster and parameters
    estimator._trained_booster = mock.MagicMock()

    # Call the function
    sklearn_estimator = estimator._to_sklearn_estimator(y)

    # Assertions
    assert isinstance(sklearn_estimator, LGBMRegressor)
    assert sklearn_estimator._Booster is estimator._trained_booster


@mock.patch(
    "snowflake.ml.modeling.distributors.lightgbm.lightgbm_estimator.safe_run_awaitable"
)
@mock.patch(
    "snowflake.ml.modeling.distributors.lightgbm.lightgbm_estimator.MLRSPrometheusMetrics"
)
def test_fit_increments_metrics(mock_metrics, mock_awaitable) -> None:
    # Initialize the estimator
    estimator = LightGBMEstimator(n_estimators=10, objective="regression_l1")

    dataset_mock = mock.Mock(spec=DataConnector)
    estimator.fit(dataset_mock, input_cols=["test"], label_col="test")

    mock_awaitable.assert_called_once()
    mock_metrics.TRAIN_ATTEMPTS.value.inc.assert_called_once()
    mock_metrics.TRAIN_LGBM.value.inc.assert_called_once()
