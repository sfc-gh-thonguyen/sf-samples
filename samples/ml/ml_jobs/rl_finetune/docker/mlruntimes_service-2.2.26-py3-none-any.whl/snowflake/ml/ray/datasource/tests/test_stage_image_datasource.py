from snowflake.ml.ray.datasource.stage_image_datasource import SFStageImageDataSource
from unittest.mock import patch, MagicMock
from ray.data import ReadTask
from pyarrow.fs import FSSpecHandler, PyFileSystem


@patch("snowflake.ml.ray.datasource.stage_image_datasource.create_stage_filesystem")
@patch("snowflake.ml.ray.datasource.stage_image_datasource.update_metrics")
def test_init_with_all_args(mock_update_metrics, mock_create_fs):
    """Test initialization with all parameters."""
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs

    with patch(
        "ray.data._internal.datasource.image_datasource.ImageDatasource.__init__"
    ) as mock_parent_init:
        mock_parent_init.return_value = None

        datasource = SFStageImageDataSource(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
            file_pattern="*.png",
            local_path="/local/path",
            image_size=(224, 224),
            image_mode="RGB",
            include_paths=True,
        )

        mock_create_fs.assert_called_once_with(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
        )

        assert datasource._local_path == "/local/path"
        assert datasource._DATASOURCE_TYPE == "Image"
        mock_parent_init.assert_called_once()
        # update_metrics is not called during initialization
        mock_update_metrics.assert_not_called()


@patch("snowflake.ml.ray.datasource.stage_image_datasource.update_metrics")
def test_get_read_tasks_success(mock_update_metrics):
    """Test get_read_tasks returns tasks from parent class and calls update_metrics."""
    with patch(
        "ray.data._internal.datasource.image_datasource.ImageDatasource.__init__"
    ), patch(
        "snowflake.ml.ray.datasource.stage_image_datasource.create_stage_filesystem"
    ):
        # Mock successful read tasks from parent
        mock_read_task = MagicMock(spec=ReadTask)
        datasource = SFStageImageDataSource(stage_location="@mystage/path")

        with patch(
            "ray.data._internal.datasource.image_datasource.ImageDatasource.get_read_tasks"
        ) as mock_get_read_tasks:
            mock_get_read_tasks.return_value = [mock_read_task]

            result = datasource.get_read_tasks(parallelism=2)

            assert len(result) == 1
            assert result[0] is mock_read_task

            # Verify update_metrics was called with correct arguments
            mock_update_metrics.assert_called_once_with([mock_read_task], "Image")


@patch("ray.data._internal.datasource.image_datasource.ImageDatasource.__init__")
@patch("snowflake.ml.ray.datasource.stage_image_datasource.update_metrics")
@patch("snowflake.ml.ray.datasource.stage_image_datasource.extract_extension")
@patch("snowflake.ml.ray.datasource.stage_image_datasource.create_stage_filesystem")
def test_parent_class_initialization(
    mock_create_fs, mock_extract_ext, mock_update_metrics, mock_parent_init
):
    """Test that parent class is initialized with correct parameters."""
    # Setup utility function mocks
    mock_extract_ext.return_value = ["png", "jpg"]
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs

    # Set up parent constructor to succeed
    mock_parent_init.return_value = None

    # Initialize the data source
    SFStageImageDataSource(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
        file_pattern=["*.png", "*.jpg"],
        image_size=(256, 256),
        image_mode="RGBA",
        include_paths=False,
    )

    # Assert parent class was initialized with correct parameters
    mock_parent_init.assert_called_once()

    # Check the arguments passed to parent constructor
    mock_parent_init.assert_called_with(
        paths=["//path/to/files"],
        filesystem=PyFileSystem(FSSpecHandler(mock_fs)),
        size=(256, 256),
        mode="RGBA",
        include_paths=False,
        file_extensions=["png", "jpg"],
    )

    # Verify utility functions were called correctly
    mock_create_fs.assert_called_once_with(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
    )
    mock_extract_ext.assert_called_once_with(["*.png", "*.jpg"])

    # update_metrics should not be called during initialization
    mock_update_metrics.assert_not_called()
