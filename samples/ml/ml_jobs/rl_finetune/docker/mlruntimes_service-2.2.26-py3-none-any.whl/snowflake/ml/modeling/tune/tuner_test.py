from unittest import mock
import pytest
from snowflake.ml.modeling import tune
from entities.search_algorithm import GridSearch


def test_grid_search_raise_exception_for_non_list_search_space() -> None:
    with mock.patch(
        "snowflake.ml.modeling.tune.tuner.get_num_cpus_per_node",
        return_value=2,
    ):
        with pytest.raises(ValueError, match="Invalid search space configuration"):
            tune.Tuner(
                train_func=lambda: None,
                search_space={
                    "n_estimators": tune.loguniform(50, 200),
                },
                tuner_config=tune.TunerConfig(
                    metric="rmse",
                    mode="min",
                    search_alg=GridSearch(),
                ),
            )

        with pytest.raises(ValueError, match="Invalid search space configuration"):
            tune.Tuner(
                train_func=lambda: None,
                search_space={
                    "n_estimators": tune.choice([50, 200]),
                },
                tuner_config=tune.TunerConfig(
                    metric="rmse",
                    mode="min",
                    search_alg=GridSearch(),
                ),
            )

        # this is valid
        tune.Tuner(
            train_func=lambda: None,
            search_space={
                "n_estimators": [50, 200],
            },
            tuner_config=tune.TunerConfig(
                metric="rmse",
                mode="min",
                search_alg=GridSearch(),
            ),
        )


def test_tuner_config_without_enough_cpus() -> None:
    with mock.patch(
        "snowflake.ml.modeling.tune.tuner.get_num_cpus_per_node",
        return_value=1,
    ):
        with pytest.raises(
            RuntimeError, match="Please use a machine with at least 2 CPUs."
        ):
            tune.Tuner(
                train_func=lambda: None,
                search_space={
                    "n_estimators": [50, 200],
                },
                tuner_config=tune.TunerConfig(
                    metric="rmse",
                    mode="min",
                    search_alg=GridSearch(),
                ),
            )


if __name__ == "__main__":
    pytest.main()
