from abc import ABC
from snowflake.ml.data.data_connector import DataConnector
from typing import List, Optional, Union
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from dataclasses import dataclass


@dataclass
class BaseScalingConfig:
    """Base class for scaling config."""

    pass


class BaseEstimator(ABC):
    """
    A Base class for estimator style trainer that provide some common methods for all estimators.
    """

    def _validate_fit_input(
        self,
        dataset: Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Optional[Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray]] = None,
        input_cols: Optional[List[str]] = None,
        label_col: Optional[str] = None,
    ):
        """
        In all estimators we support user passing in both DataConnector and in-memory data.
        This method validates the input for fit method.
        """
        if isinstance(dataset, DataConnector) and (
            input_cols is None or label_col is None
        ):
            raise ValueError(
                "input_cols and label_col are required when Data Connector is provided"
            )
        if not isinstance(dataset, DataConnector) and y is None:
            raise ValueError("y is required when dataset is not DataConnector")
        if y is not None and (input_cols is not None or label_col is not None):
            raise ValueError(
                "input_cols and label_col are not required when y is provided"
            )
        if y is not None and not isinstance(
            dataset, (pd.DataFrame, pd.Series, csr_matrix, np.ndarray)
        ):
            raise ValueError(
                "dataset should be one of the following types: pd.DataFrame, pd.Series, csr_matrix, np.ndarray when "
                "y is provided"
            )
        if label_col is not None and not isinstance(label_col, str):
            raise ValueError("Label column `label_col` must be passed as a string.")

    def get_eval_results(self):
        if self._trained_booster is None:
            raise ValueError("Model is not trained yet. Please call fit first.")
        return self._eval_results
