from typing import Callable, Literal, Optional
import ray.data
import uuid

from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    construct_stage_path,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
    RunStatus,
)
from snowflake import snowpark
from snowflake.ml.modeling.distributors.distributed_partition_function.orchestrator_actor import (
    DPFOrchestrator,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.partition_source import (
    PartitionSource,
    SQLPartitionSource,
    StagePartitionSource,
)
from common_utils.shared_storage_util import convert_to_fully_qualified_stage
from snowflake.ml.data import DataConnector

from snowflake.ml.modeling.distributors.distributed_partition_function.dpf_run import (
    DPFRun,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.partition_context import (
    PartitionContext,
)
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_warn,
)
from snowflake.runtime.utils.ray_utils import find_actors, kill_actors
from snowflake.runtime.utils.session_utils import get_session

logger = get_logger()
ORCHESTRATOR_ACTOR_NAME_PREFIX = "orchestrator_actor_"


class DPF:
    """
    Distributed Partition Function (DPF) for executing user-defined functions across data partitions.

    DPF enables distributed processing by partitioning data and executing a user-provided function
    on each partition concurrently using Ray's distributed computing framework. Results and artifacts
    are automatically stored in Snowflake stages for easy retrieval.

    Execution Modes:
        * **SQL mode** (``run()``): Partition a Snowpark DataFrame by column values.
          Data is prefetched in parallel for optimal throughput.
        * **Stage mode** (``run_from_stage()``): Process files from a Snowflake stage.
          Each file becomes a partition. Ideal for large-scale file processing.

    Key features:
        * Automatic data partitioning and distribution
        * Concurrent execution across Ray cluster
        * Built-in artifact management and persistence
        * Progress monitoring
        * Error handling and partial failure recovery

    Typical workflow:
        1. **Define** your data processing function
        2. **Create** DPF instance with function and stage
        3. **Execute** distributed processing on partitioned data
        4. **Monitor** progress until completion
        5. **Retrieve** results from each partition
        6. **Optional**: Restore completed runs later

    Example (SQL Mode):
        Complete end-to-end workflow for distributed analytics:

        **1. Data Structure**

        sales_data is a Snowpark DataFrame with columns:
            - region: 'North', 'South', 'East', 'West'
            - customer_id: unique customer identifiers
            - amount: transaction amounts
            - order_date: transaction dates

        **2. Define Processing Function**

        The data will be partitioned by region, with each partition containing all sales
        records for that specific region. The processing function receives this regional
        data subset and performs analytics on it:

        >>> def process_sales_data(data_connector, context):
        ...     df = data_connector.to_pandas()
        ...     print(f"Processing {len(df)} records for region: {context.partition_id}")
        ...
        ...     # Perform region-specific analytics
        ...     summary = {
        ...         'region': context.partition_id,
        ...         'total_sales': df['amount'].sum(),
        ...         'avg_order_value': df['amount'].mean(),
        ...         'customer_count': df['customer_id'].nunique(),
        ...         'record_count': len(df)
        ...     }
        ...
        ...     # Save results to stage for later retrieval
        ...     import json
        ...     context.upload_to_stage(summary, "sales_summary.json",
        ...         write_function=lambda obj, path: json.dump(obj, open(path, 'w')))

        **3. Execute Distributed Processing**

        >>> dpf = DPF(process_sales_data, "analytics_stage")
        >>> run = dpf.run(
        ...     partition_by="region",  # Creates separate partitions for North, South, East, West
        ...     snowpark_dataframe=sales_data,
        ...     run_id="regional_analytics_2024"
        ... )

        **4. Monitor Progress and Wait for Completion**

        >>> final_status = run.wait()  # Shows progress bar by default
        >>> print(f"Job completed with status: {final_status}")

        **5. Retrieve Results from Each Partition**

        >>> if final_status == RunStatus.SUCCESS:
        ...     # Get results from each region
        ...     import json
        ...     all_results = []
        ...     for partition_id, details in run.partition_details.items():
        ...         summary = details.stage_artifacts_manager.get("sales_summary.json",
        ...             read_function=lambda path: json.load(open(path, 'r')))
        ...         all_results.append(summary)
        ...
        ...     # Combine results across all regions
        ...     total_sales = sum(r['total_sales'] for r in all_results)
        ...     total_customers = sum(r['customer_count'] for r in all_results)
        ... else:
        ...     # Handle failures - check logs for failed partitions
        ...     for partition_id, details in run.partition_details.items():
        ...         if details.status != "DONE":
        ...             error_logs = details.logs

        **6. Optional: Restore Results Later**

        >>> # Restore completed run from stage and access same results as above without re-running.
        >>> restored_run = DPFRun.restore_from("regional_analytics_2024", "analytics_stage")

    Example (Stage Mode):
        Process parquet files from a stage, where each file is a partition:

        >>> def process_file(data_connector, context):
        ...     df = data_connector.to_pandas()
        ...     print(f"Processing file {context.partition_id}: {len(df)} rows")
        ...
        ...     # Process data and save results
        ...     result = {"row_count": len(df), "columns": list(df.columns)}
        ...     import json
        ...     context.upload_to_stage(result, "result.json",
        ...         write_function=lambda obj, path: json.dump(obj, open(path, 'w')))

        >>> dpf = DPF(process_file, "my_stage")
        >>> run = dpf.run_from_stage(
        ...     stage_location="@MY_STAGE/data/",
        ...     run_id="file_processing_2024",
        ...     file_pattern="*.parquet",
        ...     execution_options=ExecutionOptions(num_cpus_per_worker=1),  # Maximize parallelism
        ... )
        >>> run.wait()

    See Also:
        :class:`~snowflake.ml.modeling.distributors.many_model.many_model_training.ManyModelTraining`:
            Specialized DPF for distributed model training with automatic model serialization
        :class:`~snowflake.ml.modeling.distributors.many_model.many_model_inference.ManyModelInference`:
            Specialized DPF for distributed model inference with automatic model loading
    """

    def __init__(
        self,
        func: Callable[[DataConnector, PartitionContext], None],
        stage_name: str,
    ) -> None:
        """
        Initializes Distributed Partition Function(DPF)

        Args:
            func (Callable[[DataConnector, PartitionContext], None]): A user-provided function to be executed.
                It accepts a DataConnector object and PartitionContext for a given partition.
            stage_name (str): The stage where run artifacts (results, logs, models) are stored.
                Each run creates a subdirectory: ``@{stage_name}/{run_id}/``.

                This is the **output** stage for storing artifacts. For stage mode
                (``run_from_stage()``), input data is specified separately via the
                ``stage_location`` parameter.

                Examples::

                    my_stage  # Unqualified (uses session's current database/schema)
                    my_db.my_schema.my_stage  # Fully qualified
        """
        self._fully_qualified_stage_name = convert_to_fully_qualified_stage(
            stage_name=stage_name
        )
        self._func = func

    def _check_existing_artifacts(
        self, run_id: str, on_existing_artifacts: Literal["error", "overwrite"]
    ) -> None:
        if on_existing_artifacts == "error":
            stage_path = construct_stage_path(
                run_id=run_id,
                stage_name=self._fully_qualified_stage_name,
            )
            session = get_session()
            res = session.sql(f"LIST @{stage_path}").collect()
            if res:
                raise RuntimeError(
                    f"Artifacts for run_id '{run_id}' already exist in stage "
                    f"'{self._fully_qualified_stage_name}'. To overwrite existing artifacts, "
                    f"set on_existing_artifacts='overwrite' in the run() method."
                )

    def _cleanup_actors(self):
        matched_actor_names = find_actors(prefix=ORCHESTRATOR_ACTOR_NAME_PREFIX)

        if matched_actor_names:
            print_user_log_warn(
                logger,
                "Detected unfinished processes from a previous dpf run. "
                "This may mean the earlier run didn't finish cleanly, or system resources haven't been fully released "
                "yet. The system will attempt to clean up previous processes and start training automatically.",
            )

            for actor_name in matched_actor_names:
                try:
                    actor = ray.get_actor(actor_name)
                    status = ray.get(actor.get_status.remote())
                    if status == RunStatus.IN_PROGRESS:
                        raise RuntimeError(
                            "Detected an ongoing training run. Please cancel the previous training using "
                            "dpf_run.cancel() before starting a new one, or wait for the current run to finish. "
                            "Only one DPF run is allowed at a time."
                        )
                except (ray.exceptions.RayActorError, ValueError):
                    # ignore other ray.get or ray.get_actor failures.
                    pass

        kill_succeeded = kill_actors(matched_actor_names)
        if not kill_succeeded:
            raise RuntimeError(
                "Failed to kill unfinished processes from a previous training run. Please retry again later."
            )

    def _create_run(
        self,
        *,
        run_id: str,
        on_existing_artifacts: Literal["error", "overwrite"],
        execution_options: Optional[ExecutionOptions],
        partition_source: PartitionSource,
    ) -> DPFRun:
        if execution_options is None:
            execution_options = ExecutionOptions()

        self._cleanup_actors()
        self._check_existing_artifacts(
            run_id=run_id, on_existing_artifacts=on_existing_artifacts
        )

        unique_actor_name = f"{ORCHESTRATOR_ACTOR_NAME_PREFIX}{uuid.uuid4()}"
        orchestrator_ref = DPFOrchestrator.options(
            name=unique_actor_name, max_concurrency=2
        ).remote(
            func=self._func,
            run_id=run_id,
            fully_qualified_stage_name=self._fully_qualified_stage_name,
            execution_options=execution_options,
            partition_source=partition_source,
        )

        assert orchestrator_ref is not None
        run_object_ref = orchestrator_ref.run.remote()
        return DPFRun(
            run_id=run_id,
            orchestrator_ref=orchestrator_ref,
            run_object_ref=run_object_ref,
        )

    def run(
        self,
        *,
        partition_by: str,
        snowpark_dataframe: snowpark.DataFrame,
        run_id: str,
        on_existing_artifacts: Literal["error", "overwrite"] = "error",
        execution_options: Optional[ExecutionOptions] = None,
    ) -> DPFRun:
        """
        Executes the user-defined function on partitions of the Snowpark DataFrame in a distributed manner.

        Partitions the DataFrame by the specified column and executes the function on each partition
        concurrently using Ray's distributed computing framework.

        Args:
            partition_by (str): Column name to partition the DataFrame by. Each unique value creates
                a separate partition processed independently.
            snowpark_dataframe (snowpark.DataFrame): DataFrame to be partitioned and processed.
                Must contain a single query without post-actions.
            run_id (str): Unique identifier for this execution run. This ID serves multiple purposes:

                * Creates a dedicated directory ``{stage_name}/{run_id}/`` to organize all run artifacts
                * Enables tracking and management of execution state across the distributed system

                Best practices: Use descriptive names like ``experiment_2024_01_15`` or ``model_v1_retrain``

            on_existing_artifacts (str, optional): Action for existing artifacts. Defaults to "error".

                * ``"error"``: Raises error if ``{stage_name}/{run_id}/`` artifacts exist
                * ``"overwrite"``: Replaces existing ``{stage_name}/{run_id}/`` artifacts

            execution_options (ExecutionOptions, optional): Configuration for distributed execution.
                Uses defaults if not provided. Available options:

                * ``use_head_node`` (bool): Whether the Ray head node participates in workload execution
                  (True, default) or acts solely as coordinator (False)
                * ``loading_wh`` (str): Optional dedicated warehouse for loading data from Snowflake
                  tables into the stage to accelerate data loading
                * ``num_cpus_per_worker`` (int): Number of CPUs to allocate per worker actor.
                  If None (default), the behavior depends on GPU availability:

                  - With GPUs: CPUs are divided evenly among workers based on GPU count
                  - Without GPUs: Each worker uses all available CPUs (1 worker per node)

                  Examples:

                  - Node with 16 CPUs, 4 GPUs, num_cpus_per_worker=None:
                    → 4 workers (1 GPU each), each gets 4 CPUs
                  - Node with 16 CPUs, 0 GPUs, num_cpus_per_worker=None:
                    → 1 worker, gets all 16 CPUs
                  - Node with 16 CPUs, 4 GPUs, num_cpus_per_worker=4:
                    → 4 workers, each gets 4 CPUs

                * ``num_gpus_per_worker`` (int): Number of GPUs to allocate per worker actor.
                  If None (default), allocates 1 GPU per worker when GPUs are available, 0 otherwise.
                  The actual number of workers per node is constrained by both CPU and GPU availability.

                  Examples:

                  - Node with 16 CPUs, 4 GPUs, num_gpus_per_worker=None:
                    → 4 workers (1 GPU each), each gets 4 CPUs
                  - Node with 16 CPUs, 4 GPUs, num_gpus_per_worker=2:
                    → 2 workers, each gets 2 GPUs and 8 CPUs
                  - Node with 8 CPUs, 4 GPUs, num_gpus_per_worker=1, num_cpus_per_worker=4:
                    → 2 workers (min of 8/4=2 CPU limit, 4/1=4 GPU limit)

                * ``fail_fast`` (bool): If True, stops the entire workload upon the first partition
                  failure. Defaults to False.

        Returns:
            DPFRun: Run management object for monitoring status, canceling jobs, and accessing results.
        """
        if (
            len(snowpark_dataframe.queries["queries"]) != 1
            or len(snowpark_dataframe.queries["post_actions"]) != 0
        ):
            raise ValueError(
                "DataFrames with multiple queries and/or post-actions not supported"
            )

        if execution_options is None:
            execution_options = ExecutionOptions()

        partition_source = SQLPartitionSource(
            partition_by=partition_by,
            query=snowpark_dataframe.queries["queries"][0],
            execution_options=execution_options,
        )

        return self._create_run(
            run_id=run_id,
            on_existing_artifacts=on_existing_artifacts,
            execution_options=execution_options,
            partition_source=partition_source,
        )

    def run_from_stage(
        self,
        *,
        stage_location: str,
        run_id: str,
        file_pattern: str = "*.parquet",
        on_existing_artifacts: Literal["error", "overwrite"] = "error",
        execution_options: Optional[ExecutionOptions] = None,
    ) -> DPFRun:
        """Execute DPF on files from a Snowflake stage.

        Each file becomes a partition, and actors pull partitions from a queue.
        This ensures predictable memory usage and reliable execution.

        For I/O-bound file processing, set num_cpus_per_worker=1 to maximize
        parallelism (one actor per CPU). For CPU-bound workloads, use the
        default or increase num_cpus_per_worker.

        Args:
            stage_location: **Input** stage path containing source data files.
                Each file matching ``file_pattern`` becomes a partition.
                Supports both simple and fully qualified stage names:

                - Simple: ``"@my_stage/data/"`` (uses session's current database/schema)
                - Fully qualified: ``"@my_db.my_schema.my_stage/data/"``

                Note: This is the *input* data location, separate from
                ``stage_name`` (provided to ``DPF.__init__``), which is
                used to store *output* artifacts like logs and results.
            run_id: Unique identifier for this run
            file_pattern: Glob pattern to filter files, e.g. "*.parquet"
            on_existing_artifacts: "error" or "overwrite"
            execution_options: Resource allocation options
        """
        if execution_options is None:
            execution_options = ExecutionOptions()

        partition_source = StagePartitionSource(
            stage_location=stage_location,
            file_pattern=file_pattern,
            execution_options=execution_options,
        )

        return self._create_run(
            run_id=run_id,
            on_existing_artifacts=on_existing_artifacts,
            execution_options=execution_options,
            partition_source=partition_source,
        )
