"""Unit tests for partition_source module."""

from unittest import mock
from unittest.mock import MagicMock
import pytest

from snowflake.ml.modeling.distributors.distributed_partition_function.partition_source import (
    StagePartitionSource,
    PartitionTask,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
    StagePartitionInput,
)


class TestStagePartitionSource:
    """Test suite for StagePartitionSource class."""

    def _mock_list_result(self, file_paths: list) -> list:
        """Helper to create mock LIST query results."""
        return [{" name": p, "name": p} for p in file_paths]

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.partition_source.get_session"
    )
    def test_discover_partitions_error_cases(self, mock_get_session):
        """Test error handling for empty stage and no pattern match."""
        mock_session = MagicMock()
        mock_get_session.return_value = mock_session

        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )

        # Empty stage
        mock_session.sql.return_value.collect.return_value = []
        with pytest.raises(ValueError, match="No files found at stage location"):
            source.discover_partitions()

        # Files exist but none match pattern
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            ["my_stage/file.csv", "my_stage/file.json"]
        )
        with pytest.raises(ValueError, match="No files found matching pattern"):
            source.discover_partitions()

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.partition_source.get_session"
    )
    def test_discover_partitions_handles_complex_paths(self, mock_get_session):
        """Test path handling: filtering, deduplication, nested dirs, relative paths."""
        mock_session = MagicMock()
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/dir1/data.parquet",  # Same filename in different dirs
                "my_stage/dir2/data.parquet",  # Should NOT collide
                "my_stage/a/b/c/nested.parquet",  # Deeply nested
                "my_stage/root.parquet",  # At root
                "my_stage/skip.csv",  # Should be filtered out
            ]
        )
        mock_get_session.return_value = mock_session

        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )

        partition_ids = source.discover_partitions()

        # Should have 4 partitions (csv filtered out), using relative paths as IDs
        assert len(partition_ids) == 4
        assert set(partition_ids) == {
            "dir1/data.parquet",
            "dir2/data.parquet",
            "a/b/c/nested.parquet",
            "root.parquet",
        }

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.partition_source.get_session"
    )
    def test_start_produces_correct_tasks(self, mock_get_session):
        """Test that start() produces PartitionTasks with correct structure."""
        mock_session = MagicMock()
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/subdir/file.parquet",
            ]
        )
        mock_get_session.return_value = mock_session

        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )
        source.discover_partitions()

        received_tasks = []
        source.start(on_task_ready=lambda t: received_tasks.append(t))

        assert len(received_tasks) == 1
        task = received_tasks[0]

        # Verify task structure
        assert isinstance(task, PartitionTask)
        assert task.partition_id == "subdir/file.parquet"
        assert isinstance(task.partition_input, StagePartitionInput)
        assert task.partition_input.file_paths == ["subdir/file.parquet"]
        assert task.partition_input.stage_location == "@my_stage/"

    def test_stop_is_noop(self):
        """Test that stop() completes without error."""
        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )
        source.stop()  # Should not raise

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.partition_source.get_session"
    )
    def test_discover_partitions_normalizes_trailing_slash(self, mock_get_session):
        """Test that stage_location is normalized with trailing slash to avoid prefix matching.

        LIST is a prefix match, so '@stage/my_dir' would also match '@stage/my_directory/'.
        Normalizing to '@stage/my_dir/' prevents this issue.
        """
        mock_session = MagicMock()
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            ["my_stage/subdir/file.parquet"]
        )
        mock_get_session.return_value = mock_session

        # Test without trailing slash - should be normalized
        source = StagePartitionSource(
            stage_location="@my_stage/subdir",  # No trailing slash
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )
        source.discover_partitions()

        # Verify LIST query uses normalized path with trailing slash
        mock_session.sql.assert_called_with("LIST '@my_stage/subdir/'")

        # Test with trailing slash - should remain unchanged
        mock_session.reset_mock()
        source2 = StagePartitionSource(
            stage_location="@my_stage/subdir/",  # Already has trailing slash
            file_pattern="*.parquet",
            execution_options=ExecutionOptions(),
        )
        source2.discover_partitions()

        mock_session.sql.assert_called_with("LIST '@my_stage/subdir/'")

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.partition_source.get_session"
    )
    def test_discover_partitions_file_pattern_matching(self, mock_get_session):
        """Test that file_pattern supports full glob patterns via fnmatch.

        Verifies patterns beyond simple *.extension work correctly:
        - Prefix patterns: data_*.csv
        - Multi-extension: *.csv.gz
        - Exact filenames: report.json
        - Complex patterns: report_2024_*.json
        """
        mock_session = MagicMock()
        mock_get_session.return_value = mock_session

        # Test prefix pattern: data_*.csv
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/data_001.csv",
                "my_stage/data_002.csv",
                "my_stage/other_file.csv",  # Should NOT match
                "my_stage/data_backup.parquet",  # Should NOT match
            ]
        )
        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="data_*.csv",
            execution_options=ExecutionOptions(),
        )
        partition_ids = source.discover_partitions()
        assert set(partition_ids) == {"data_001.csv", "data_002.csv"}

        # Test multi-extension pattern: *.csv.gz
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/data.csv.gz",
                "my_stage/backup.csv.gz",
                "my_stage/data.csv",  # Should NOT match
                "my_stage/data.gz",  # Should NOT match
            ]
        )
        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="*.csv.gz",
            execution_options=ExecutionOptions(),
        )
        partition_ids = source.discover_partitions()
        assert set(partition_ids) == {"data.csv.gz", "backup.csv.gz"}

        # Test exact filename match
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/report.json",
                "my_stage/report2.json",  # Should NOT match
                "my_stage/my_report.json",  # Should NOT match
            ]
        )
        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="report.json",
            execution_options=ExecutionOptions(),
        )
        partition_ids = source.discover_partitions()
        assert partition_ids == ["report.json"]

        # Test complex pattern with multiple wildcards
        mock_session.sql.return_value.collect.return_value = self._mock_list_result(
            [
                "my_stage/report_2024_01.json",
                "my_stage/report_2024_12.json",
                "my_stage/report_2023_01.json",  # Should NOT match
                "my_stage/summary_2024_01.json",  # Should NOT match
            ]
        )
        source = StagePartitionSource(
            stage_location="@my_stage/",
            file_pattern="report_2024_*.json",
            execution_options=ExecutionOptions(),
        )
        partition_ids = source.discover_partitions()
        assert set(partition_ids) == {"report_2024_01.json", "report_2024_12.json"}
