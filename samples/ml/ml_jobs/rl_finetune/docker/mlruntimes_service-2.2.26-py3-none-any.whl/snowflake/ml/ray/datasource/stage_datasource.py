"""
Snowflake Stage Datasource optimized for reading many parquet files.

This datasource only supports parquet format. Non-parquet files will fail at read time.

Example:
    >>> datasource = SFStageDataSource(stage_location="@mystage/data/", file_pattern="*.parquet")
    >>> ds = ray.data.read_datasource(datasource)
"""

import os
import warnings
from typing import Any, Callable, Dict, Iterator, List, Optional, Set, Union

import pyarrow as pa
import pyarrow.parquet as pq
from ray.data.block import Block, BlockMetadata
from ray.data.datasource import Datasource
from ray.data.datasource.datasource import ReadTask

from snowflake.ml._internal.utils import identifier
from snowflake.ml.ray.datasource.datasource_utils import (
    create_stage_filesystem,
    extract_extension,
    update_metrics,
)
from snowflake.runtime.utils.session_utils import get_session


class SFStageDataSource(Datasource):
    """
    Fast datasource for reading parquet files from Snowflake stages.

    Uses SQL LIST for file discovery (~0.6s) instead of per-file metadata reads (~143s
    for 122 files). Tradeoff: no predicate pushdown or column pruning.

    Note:
        Only parquet format is supported. Non-parquet files will fail at read time
        with a pyarrow error. Use SFStageParquetDataSource if you need predicate
        pushdown or schema upfront.

    Args:
        stage_location: e.g. "@mystage/path/to/files"
        database: Defaults to session's current database
        schema: Defaults to session's current schema
        file_pattern: e.g. "*.parquet" (only parquet supported)
        file_paths: Explicit file list (relative paths within stage, e.g.
            ["subdir/file1.parquet", "subdir/file2.parquet"]). Skips LIST query.
    """

    _DATASOURCE_TYPE = "SFStage"

    def __init__(
        self,
        *,
        stage_location: str,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        file_pattern: Optional[Union[str, List[str]]] = None,
        file_paths: Optional[List[str]] = None,
    ):
        self._stage_location = stage_location
        self._file_pattern = file_pattern
        # Convert to set with dots for O(1) lookup with os.path.splitext
        exts = extract_extension(file_pattern)
        self._file_extensions: Optional[Set[str]] = (
            {f".{e}" for e in exts} if exts else None
        )
        self._explicit_file_paths = file_paths

        (
            parsed_db,
            parsed_schema,
            stage_name,
            path,
        ) = identifier.parse_snowflake_stage_path(stage_location)
        self._session = get_session()
        self._database = database or parsed_db or self._session.get_current_database()
        self._schema = schema or parsed_schema or self._session.get_current_schema()
        # parse_snowflake_stage_path returns path with leading "/" or empty string
        self._path_in_stage = path.lstrip("/") if path else ""

        path_suffix = f"/{self._path_in_stage}" if self._path_in_stage else None
        self._full_stage = "@" + identifier.get_schema_level_object_identifier(
            self._database, self._schema, stage_name, path_suffix
        )

        self._fs = create_stage_filesystem(
            stage_location=stage_location,
            database=self._database,
            schema=self._schema,
            stage_name=stage_name,
        )
        self._files: Optional[List[Dict[str, Any]]] = None

    def _list_files(self) -> List[Dict[str, Any]]:
        """List files using fsspec ls(), or use explicit file_paths if provided."""
        if self._files is not None:
            return self._files

        if self._explicit_file_paths is not None:
            self._files = [{"name": p, "size": None} for p in self._explicit_file_paths]
            return self._files

        # Use fsspec ls() which has built-in error handling for missing stages
        raw_files = self._fs.ls(self._path_in_stage, detail=True)
        self._files = []
        for f in raw_files:
            if f.get("type") != "file":
                continue
            name = f["name"]
            if self._file_extensions:
                _, ext = os.path.splitext(name)
                if ext not in self._file_extensions:
                    continue
            self._files.append({"name": name, "size": f["size"]})

        return self._files

    def estimate_inmemory_data_size(self) -> Optional[int]:
        """Estimate in-memory size using a rough heuristic.

        Parquet files typically expand when loaded into memory due to decompression
        and columnar-to-row conversion. We use a 2x multiplier as a conservative
        approximation. Actual expansion varies based on compression ratio, data types,
        and nested structures.

        Returns:
            Estimated bytes, or None if file sizes are unknown.
        """
        files = self._list_files()
        sizes = [f["size"] for f in files if f["size"] is not None]
        if not sizes:
            return None
        return sum(sizes) * 2

    def get_read_tasks(
        self, parallelism: int, per_task_row_limit: Optional[int] = None
    ) -> List[ReadTask]:
        """Create one read task per file. Schema inferred lazily on read."""
        files = self._list_files()

        if not files:
            warnings.warn(
                f"No files found at {self._full_stage} "
                f"matching pattern {self._file_pattern}"
            )
            return []

        read_tasks = []
        for file_info in files:
            file_path = file_info["name"]
            metadata = BlockMetadata(
                num_rows=None,
                size_bytes=file_info["size"],
                input_files=[file_path],
                exec_stats=None,
            )
            read_tasks.append(ReadTask(self._make_read_fn(file_path), metadata))

        update_metrics(read_tasks, self._DATASOURCE_TYPE)
        return read_tasks

    def _make_read_fn(self, file_path: str) -> Callable[[], Iterator[Block]]:
        """Create a read function that reads a parquet file via SFStageFileSystem."""
        fs = self._fs

        def read_fn() -> Iterator[pa.Table]:
            with fs.open(file_path, "rb") as f:
                yield pq.read_table(f)

        return read_fn
