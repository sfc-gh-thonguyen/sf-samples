from snowflake.ml.ray.datasource.stage_csv_file_datasource import SFStageCSVDataSource
from pyarrow import csv
from unittest.mock import patch, MagicMock
from ray.data import ReadTask
from pyarrow.fs import FSSpecHandler, PyFileSystem


@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.create_stage_filesystem")
def test_init_with_all_args(mock_create_fs):
    mock_py_fs = MagicMock()
    mock_create_fs.return_value = mock_py_fs
    with patch(
        "ray.data._internal.datasource.csv_datasource.CSVDatasource.__init__"
    ) as mock_parent_init:
        mock_parent_init.return_value = None
        datasource = SFStageCSVDataSource(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
            file_pattern="*.csv",
            local_path="/local/path",
            arrow_csv_args={
                "read_options": csv.ReadOptions(use_threads=True),
                "parse_options": csv.ParseOptions(delimiter=";"),
            },
        )

        mock_create_fs.assert_called_once_with(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
        )

        assert datasource._local_path == "/local/path"
        assert datasource._DATASOURCE_TYPE == "CSVFile"
        mock_parent_init.assert_called_once()


@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.create_stage_filesystem")
@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.update_metrics")
def test_get_read_tasks_success(mock_update_metrics, mock_create_fs):
    """Test get_read_tasks returns tasks from parent class."""
    with patch("ray.data._internal.datasource.csv_datasource.CSVDatasource.__init__"):
        # Mock successful read tasks from parent
        mock_read_task = MagicMock(spec=ReadTask)
        datasource = SFStageCSVDataSource(stage_location="@mystage/path")

        with patch(
            "ray.data._internal.datasource.csv_datasource.CSVDatasource.get_read_tasks"
        ) as mock_get_read_tasks:
            mock_get_read_tasks.return_value = [mock_read_task]

            result = datasource.get_read_tasks(parallelism=2)

            assert len(result) == 1
            assert result[0] is mock_read_task

            mock_update_metrics.assert_called_once()


@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.create_stage_filesystem")
@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.extract_extension")
@patch("snowflake.ml.ray.datasource.stage_csv_file_datasource.update_metrics")
@patch("ray.data._internal.datasource.csv_datasource.CSVDatasource.__init__")
def test_parent_class_initialization(
    mock_parent_init, mock_update_metrics, mock_extract_ext, mock_create_fs
):
    """Test that parent class is initialized with correct parameters."""
    # Setup utility function mocks
    mock_extract_ext.return_value = ["csv"]
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs

    # Set up parent constructor to succeed
    mock_parent_init.return_value = None

    # Initialize the data source
    SFStageCSVDataSource(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
        file_pattern="*.csv",
        arrow_csv_args={
            "read_options": csv.ReadOptions(use_threads=True),
            "parse_options": csv.ParseOptions(delimiter=";"),
        },
    )

    # Assert parent class was initialized with correct parameters
    mock_parent_init.assert_called_once()

    # Check the arguments passed to parent constructor
    mock_parent_init.assert_called_with(
        paths=["//path/to/files"],
        filesystem=PyFileSystem(FSSpecHandler(mock_fs)),
        arrow_csv_args={
            "read_options": csv.ReadOptions(use_threads=True),
            "parse_options": csv.ParseOptions(delimiter=";"),
        },
        file_extensions=["csv"],
    )

    # Verify utility functions were called correctly
    mock_create_fs.assert_called_once_with(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
    )
    mock_extract_ext.assert_called_once_with("*.csv")
