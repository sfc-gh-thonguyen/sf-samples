import contextlib
import io
from typing import Callable, List
import ray
from ray.actor import ActorHandle

from implementations.distributed_trainers.ray_utils import _get_usable_cpus_for_compute
from implementations.ray_data_ingester import (
    read_datasource,
    ResultSetDataSource,
    RayDataIngester,
)
from snowflake.ml.data import DataConnector
from snowflake.ml.data.data_source import DataFrameInfo

from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    SinglePartitionDetails,
    PartitionStatus,
    DPFUncaughtException,
    PartitionInput,
    StagePartitionInput,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    construct_stage_path,
)
from snowflake.ml.ray.datasource import SFStageDataSource
import traceback
from snowflake.runtime.utils.logger import (
    get_logger,
)
from snowflake.runtime.utils.retry_utils import SYSTEM_ERRORS, with_retry
from snowflake.connector import result_batch

from snowflake.ml.modeling.distributors.distributed_partition_function.partition_context import (
    PartitionContext,
)
from web.jobs.common import NON_COMPUTE_PERCENT_CPU_NODE, NON_COMPUTE_PERCENT_GPU_NODE

logger = get_logger()


@ray.remote
class TrainActor:
    """A Ray actor class that runs a user-defined function on partitioned data."""

    def __init__(
        self,
        id: int,
        func: Callable,
        run_id: str,
        fully_qualified_stage_name: str,
        max_retries: int,
        io_actor: ActorHandle,
    ):
        self.id = id
        self.func = func
        self.run_id = run_id
        self.fully_qualified_stage_name = fully_qualified_stage_name
        self.max_retries = max_retries
        self.io_actor = io_actor

    def ping(self) -> str:
        """
        This function acts as a heartbeat check to ensure actor is successfully initialized before
        assigning tasks to it.
        """
        return "pong"

    def _build_read_options(self) -> dict:
        """Build read_data_source_options with node affinity and concurrency settings.

        Inside each task/actor, we allocate nearly all available CPUs (excluding 2:
        1 for launching the actor/task and 1 reserved for system stability) to data ingestion.
        Additionally, we enforce node affinity scheduling to ensure that the read task
        runs on the same node.

        This approach prioritizes reliability over peak performance by reducing the likelihood
        of resource contention issues.

        Returns:
            Dictionary of options for ray.data.read_datasource()
        """
        node_id = ray.get_runtime_context().get_node_id()
        assigned_resources = ray.get_runtime_context().get_assigned_resources()
        num_cpus = assigned_resources.get("CPU", 1)
        num_gpus = assigned_resources.get("GPU", 0)

        # Calculate usable CPUs for data ingestion based on node type
        # Reserve some CPUs for Ray overhead and system stability
        if num_gpus > 0:
            usable_cpus = _get_usable_cpus_for_compute(
                num_cpus, NON_COMPUTE_PERCENT_GPU_NODE
            )
        else:
            usable_cpus = _get_usable_cpus_for_compute(
                num_cpus, NON_COMPUTE_PERCENT_CPU_NODE
            )

        # Here we make an assumption that we can use 4 Data tasks per CPU, which was benchmarked as part of
        # https://github.com/snowflakedb/mlruntimes/pull/407
        concurrency = max(usable_cpus - 1, 1) * 4

        return {
            "concurrency": concurrency,
            "ray_remote_args": {
                "scheduling_strategy": ray.util.scheduling_strategies.NodeAffinitySchedulingStrategy(
                    node_id=node_id,
                    # whether the scheduler should run the task or actor somewhere else if the target node doesn't
                    # exist (e.g. the node dies) or is infeasible during scheduling.
                    soft=False,
                ),
                # By default, Ray requests 1 CPU per read task, which means one read task per CPU can execute
                # concurrently. For datasources that benefit from more IO parallelism, lowering this value allows more
                # IO parallelism. In this case, this means each CPU can run 4 read tasks.
                "num_cpus": 0,
            },
        }

    def _get_data_connector_from_result_batches(
        self,
        *,
        result_batches: List[result_batch.ResultBatch],
        dataframe_info: DataFrameInfo,
    ) -> DataConnector:
        """Create DataConnector from SQL result batches."""
        cds = ResultSetDataSource(result_batches, dataframe_info)
        ray_ds = read_datasource(
            cds, read_data_source_options=self._build_read_options()
        )
        return DataConnector(
            ingestor=RayDataIngester(data_sources=[dataframe_info], ray_ds=ray_ds)
        )

    def _get_data_connector_from_files(
        self,
        *,
        file_paths: List[str],
        stage_location: str,
    ) -> DataConnector:
        """Create DataConnector from stage files."""
        datasource = SFStageDataSource(
            stage_location=stage_location,
            file_paths=file_paths,
        )
        ray_ds = read_datasource(
            datasource, read_data_source_options=self._build_read_options()
        )
        return DataConnector(ingestor=RayDataIngester(ray_ds=ray_ds))

    def _upload_logs(self, *, stage_path: str, logs: str) -> None:
        """Upload logs to stage via the IO actor."""
        data = logs.encode("utf-8")
        ray.get(
            self.io_actor.upload_to_stage.remote(
                data=data,
                stage_path=stage_path,
                filename="train.log",
            )
        )

    def _with_retry(self, fn, *, description: str):
        """Retry a function with exponential backoff on retryable errors."""
        return with_retry(
            fn,
            max_attempts=self.max_retries + 1,
            retryable_errors=SYSTEM_ERRORS,
            description=description,
        )

    def run(self, partition_input: PartitionInput) -> SinglePartitionDetails:
        """Execute user function on a partition.

        Args:
            partition_input: Typed input containing partition data.
                - SQLPartitionInput: For SQL-based partitions (result batches)
                - StagePartitionInput: For stage-based partitions (file paths)

        Returns:
            SinglePartitionDetails with status (DONE or FAILED) and stage path.

        Retry strategy:
            - Data loading and log upload are retried with exponential backoff.
            - User function is NOT retried.
        """
        partition_id = partition_input.partition_id

        stage_path = construct_stage_path(
            run_id=self.run_id,
            stage_name=self.fully_qualified_stage_name,
            subpath=[partition_id],
        )

        try:
            # TODO[SNOW-1982385]: Instead of return log as string, persist the logs to snowflake event table.
            stdout, stderr = io.StringIO(), io.StringIO()

            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                try:
                    if isinstance(partition_input, StagePartitionInput):
                        dc = self._with_retry(
                            lambda: self._get_data_connector_from_files(
                                file_paths=partition_input.file_paths,
                                stage_location=partition_input.stage_location,
                            ),
                            description="Data loading",
                        )
                    else:  # SQLPartitionInput
                        dc = self._with_retry(
                            lambda: self._get_data_connector_from_result_batches(
                                result_batches=partition_input.result_batches,
                                dataframe_info=partition_input.dataframe_info,
                            ),
                            description="Data loading",
                        )

                    pc = PartitionContext(
                        io_actor=self.io_actor,
                        partition_id=partition_id,
                        stage_path_prefix=stage_path,
                    )

                    self.func(dc, pc)

                    combined_logs = stdout.getvalue()
                    self._with_retry(
                        lambda: self._upload_logs(
                            stage_path=stage_path,
                            logs=combined_logs,
                        ),
                        description="Log upload",
                    )

                    return SinglePartitionDetails(
                        partition_id=partition_id,
                        status=PartitionStatus.DONE,
                        stage_path=stage_path,
                    )
                except Exception as e:
                    combined_logs = (
                        stdout.getvalue()
                        + stderr.getvalue()
                        + str(e)
                        + "\n"
                        + traceback.format_exc()
                    )
                    self._with_retry(
                        lambda: self._upload_logs(
                            stage_path=stage_path,
                            logs=combined_logs,
                        ),
                        description="Log upload",
                    )

                    return SinglePartitionDetails(
                        partition_id=partition_id,
                        status=PartitionStatus.FAILED,
                        stage_path=stage_path,
                    )

        except Exception as e:
            raise DPFUncaughtException(*e.args, partition_id=partition_id) from e

    def __repr__(self):
        return f"DPFActor(index={self.id})"
