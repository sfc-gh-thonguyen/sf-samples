from snowflake.ml.data.data_connector import DataConnector
from typing import Optional, Any
from snowflake import snowpark


class InternalDataConnector(DataConnector):
    def __init__(
        self, ingestor, session: Optional[snowpark.Session] = None, **kwargs: Any
    ):
        super().__init__(ingestor, **kwargs)  # Drop session from kwargs

    def __getstate__(self):
        """Return the object's state for pickling using default behavior."""
        return self.__dict__

    def __setstate__(self, state):
        """Restore the object's state from unpickling using default behavior."""
        self.__dict__.update(state)
