from typing import Dict, List, Tuple, Any
import time

from common_utils.shared_storage_util import convert_to_fully_qualified_stage
from ray.types import ObjectRef
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    SinglePartitionDetails,
    RunStatus,
)
from tqdm.auto import tqdm
from common_utils.common_util import get_ray_resource_metrics
import ray
from snowflake.runtime.utils.ray_utils import (
    interruptible_ray_get,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    download_and_deserialize_from_stage,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.constants import (
    MMT_STATE_PICKLE_FILENAME,
)

try:
    import streamlit as st
except ImportError:
    st = None


class DPFRun:
    """
    A handle to a single execution of a Distributed Partition Function (DPF) run.

    .. note::
        Users do not create ``DPFRun`` instances directly. They are returned by ``DPF.run()``
        or ``DPFRun.restore_from()``.

    This object provides methods to monitor execution progress, manage the running job,
    and retrieve results from the distributed execution across partitions.

    Key capabilities:
        * Monitor execution status and progress
        * Cancel running jobs
        * Access partition-level details and artifacts
        * Wait for completion with optional progress display
        * Restore completed runs from persistent storage

    Example:
        >>> dpf = DPF(process_sales_data, "analytics_stage")
        >>> run = dpf.run(partition_by="region", snowpark_dataframe=sales_data, run_id="analytics_2024")
        >>> final_status = run.wait()  # Wait with progress bar
        >>> if final_status == RunStatus.SUCCESS:
        ...     for partition_id, details in run.partition_details.items():
        ...         summary = details.stage_artifacts_manager.get("sales_summary.json")
    """

    def __init__(
        self,
        run_id: str,
        *,
        orchestrator_ref: ObjectRef,
        run_object_ref: ObjectRef,
    ):
        # Internal constructor - users get DPFRun instances from DPF.run()
        self._run_id = run_id
        self._orchestrator_ref = orchestrator_ref
        self._run_object_ref = run_object_ref

    @property
    def run_id(self) -> str:
        """
        The unique identifier for this execution run.

        Returns:
            str: The run ID specified when the DPF was executed.
        """
        return self._run_id

    @property
    def partition_details(self) -> Dict[str, SinglePartitionDetails]:
        """
        Provides details for each partition processed.

        Returns:
            A dictionary mapping partition IDs to their respective execution details.
        """
        assert (
            self._orchestrator_ref is not None
        ), "DPF instance should invoke run method first"
        return ray.get(self._orchestrator_ref.get_partition_details.remote())

    @property
    def status(self) -> RunStatus:
        """
        Retrieves the overall status of the distributed execution.

        This property aggregates the status across all partitions to provide a summary
        of the entire run.

        Returns:
            The current status of the execution.
        """

        assert (
            self._orchestrator_ref is not None
        ), "DPF instance should invoke run method first"
        return ray.get(self._orchestrator_ref.get_status.remote())

    @classmethod
    def restore_from(cls, run_id: str, stage_name: str) -> "DPFRun":
        """
        Restore a completed DPF run from its persisted state.

        Args:
            run_id (str): The run ID of the execution to restore.
            stage_name (str): The stage name where the run artifacts are stored.

        Returns:
            DPFRun: A read-only DPFRun instance with access to the completed run's results.

        Raises:
            ValueError: If the run state cannot be restored from the specified location.
        """
        return _ReadOnlyDPFRun.restore_from_stage(run_id=run_id, stage_name=stage_name)

    def wait(self, show_progress: bool = True) -> RunStatus:
        """
        Wait for the DPF run to complete.

        Args:
            show_progress (bool, optional): Whether to display a progress bar during execution.
                Defaults to True. Uses Streamlit UI if available, otherwise falls back to tqdm.

        Returns:
            RunStatus: The final status of the run (SUCCESS, FAILURE, PARTIAL_FAILURE, or CANCELLED).
        """
        if show_progress:
            self._show_progress()
        else:
            interruptible_ray_get(self._run_object_ref)

        return self.status

    def get_progress(self) -> Dict[str, List[SinglePartitionDetails]]:
        """
        Returns the current progress of the distributed run.

        Returns:
            A dictionary grouping partition details by their current status.
        """
        progress: Dict[str, List[SinglePartitionDetails]] = {}
        for partition_details in self.partition_details.values():
            status = partition_details.status
            if status not in progress:
                progress[status] = []
            progress[status].append(partition_details)
        return progress

    def _get_processed_counts(
        self,
        is_ingestion_done: bool,
        processed_ingestion_counts: int,
        processed_training_counts: int,
        total_counts: int,
    ) -> Tuple[bool, int, int]:
        assert (
            self._orchestrator_ref is not None
        ), "DPF instance should invoke run method first"

        if not is_ingestion_done:
            processed_ingestion_counts = ray.get(
                self._orchestrator_ref.get_processed_ingestion_counts.remote()
            )
            if processed_ingestion_counts >= total_counts:
                is_ingestion_done = True

        processed_training_counts = ray.get(
            self._orchestrator_ref.get_processed_training_counts.remote()
        )
        return is_ingestion_done, processed_ingestion_counts, processed_training_counts

    def _show_progress(self) -> None:
        """
        Displays a visualization of the execution progress.

        Note:
            Uses Streamlit UI components if available, otherwise falls back to a tqdm bar.
        """
        assert (
            self._orchestrator_ref is not None
        ), "DPF instance should invoke run method first"

        total_counts = ray.get(self._orchestrator_ref.get_total_counts.remote())
        check_interval = 1
        is_ingestion_done = False
        processed_ingestion_counts = 0
        processed_training_counts = 0

        # Check if Streamlit is available
        if st is None or not hasattr(st, "runtime") or not st.runtime.exists():
            # Streamlit is not available, use tqdm instead
            with tqdm(
                total=total_counts, desc="Progress", ncols=100, position=0
            ) as pbar_train:
                while processed_training_counts < total_counts:
                    (
                        is_ingestion_done,
                        processed_ingestion_counts,
                        processed_training_counts,
                    ) = self._get_processed_counts(
                        is_ingestion_done,
                        processed_ingestion_counts,
                        processed_training_counts,
                        total_counts,
                    )
                    alive_nodes = len([n for n in ray.nodes() if n["Alive"]])
                    pbar_train.set_postfix(
                        ongoing_data_ingestion=f"{processed_ingestion_counts}/{total_counts}",
                        nodes=alive_nodes,
                    )
                    pbar_train.n = processed_training_counts
                    pbar_train.update(0)

                    if processed_training_counts >= total_counts:
                        break

                    # Check if run was cancelled
                    if self.status == RunStatus.CANCELLED:
                        break

                    # Sleep for a while before checking again
                    time.sleep(check_interval)
            return

        # Create placeholder containers for streamlit widgets
        col1, col2, col3 = st.columns(3)
        with col1:
            ingestion_metric = st.empty()
        with col2:
            training_metric = st.empty()
        with col3:
            nodes_metric = st.empty()
        ingestion_header = st.empty()
        ingestion_progress_bar = st.empty()

        training_header = st.empty()
        training_progress_bar = st.empty()

        st.write("### Resource Usage by Node")
        resource_container = st.empty()

        while processed_training_counts < total_counts:
            (
                is_ingestion_done,
                processed_ingestion_counts,
                processed_training_counts,
            ) = self._get_processed_counts(
                is_ingestion_done,
                processed_ingestion_counts,
                processed_training_counts,
                total_counts,
            )

            # Update metrics
            ingestion_metric.metric(
                "Data Ingestion Complete",
                f"{processed_ingestion_counts}/{total_counts}",
            )
            training_metric.metric(
                "Training Complete", f"{processed_training_counts}/{total_counts}"
            )
            alive_nodes = len([n for n in ray.nodes() if n["Alive"]])
            nodes_metric.metric("Nodes", alive_nodes)

            ingestion_progress = processed_ingestion_counts / total_counts
            training_progress = processed_training_counts / total_counts
            ingestion_header.write(
                f"### Data Ingestion Progress: {ingestion_progress * 100:.1f}%"
            )
            ingestion_progress_bar.progress(ingestion_progress)
            training_header.write(f"### Progress: {training_progress * 100:.1f}%")
            training_progress_bar.progress(training_progress)
            resource_container.dataframe(get_ray_resource_metrics())

            if processed_training_counts >= total_counts:
                break

            # Check if run was cancelled
            if self.status == RunStatus.CANCELLED:
                break

            # Sleep for a while before checking again
            time.sleep(check_interval)
        if self.status == RunStatus.SUCCESS:
            st.success("Distributed partition function completed", icon="✅")
        else:
            st.error(
                "DPF failed! Please check the logs via dpf_run.get_progress() for more details.",
                icon="❌",
            )

    def cancel(self) -> None:
        """
        Cancels the ongoing distributed execution.

        Note:
            - Partitions that have already completed may not be affected.
            - Partial results, logs, or other artifacts might remain after cancellation.
        """
        assert (
            self._orchestrator_ref is not None
        ), "DPF instance should invoke run method first"
        ray.get(self._orchestrator_ref.cancel.remote())


class _ReadOnlyDPFRun(DPFRun):
    """
    An internal, read-only handle to a COMPLETED DPF run, restored from its
    persisted state file.
    """

    def __init__(self, run_id: str, *, states: Dict[str, Any]):
        super().__init__(run_id=run_id, orchestrator_ref=None, run_object_ref=None)
        self._states = states

    @classmethod
    def restore_from_stage(cls, run_id: str, stage_name: str) -> "_ReadOnlyDPFRun":
        fully_qualified_stage_name = convert_to_fully_qualified_stage(stage_name)
        try:
            states = download_and_deserialize_from_stage(
                run_id=run_id,
                stage_name=fully_qualified_stage_name,
                subpath=[MMT_STATE_PICKLE_FILENAME],
            )
            return cls(run_id=run_id, states=states)
        except Exception as e:
            raise ValueError(f"Failed to restore state for run_id='{run_id}': {e}")

    @property
    def status(self) -> RunStatus:
        return self._states.get("status")

    @property
    def partition_details(self) -> Dict[str, SinglePartitionDetails]:
        return self._states.get("partition_details", {})

    def wait(self, show_progress: bool = True) -> RunStatus:
        raise NotImplementedError(
            f"Run {self.run_id} was restored from a completed state. Cannot be re-run"
        )

    def cancel(self) -> None:
        raise NotImplementedError(
            "Cannot cancel a run that was restored from a completed state."
        )
