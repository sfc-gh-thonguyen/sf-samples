from unittest.mock import MagicMock, patch, call
from ray.data.datasource.datasource import ReadTask

from snowflake.ml.ray.datasource.datasource_utils import (
    extract_extension,
    create_stage_filesystem,
    update_metrics,
    write_to_local_path,
)


class TestDataSourceUtils:
    def test_extract_extension_single_wildcard_pattern(self):
        assert extract_extension("*.csv") == ["csv"]
        assert extract_extension("csv") == ["csv"]

        assert extract_extension(["*.csv", "*.json", "*.parquet"]) == [
            "csv",
            "json",
            "parquet",
        ]

        assert extract_extension([]) is None
        assert extract_extension(None) is None

    @patch("snowflake.ml.ray.datasource.datasource_utils.get_session")
    @patch("snowflake.ml.ray.datasource.datasource_utils.SFStageFileSystem")
    def test_create_named_stage_filesystem(self, mock_sf_stage_fs, mock_get_session):
        mock_session = MagicMock()
        mock_session.get_current_database.return_value = "TEST_DB"
        mock_session.get_current_schema.return_value = "TEST_SCHEMA"
        mock_get_session.return_value = mock_session

        mock_fs = MagicMock()
        mock_sf_stage_fs.return_value = mock_fs

        result = create_stage_filesystem("@mystage/path/to/files")

        mock_sf_stage_fs.assert_called_once_with(
            db="TEST_DB", schema="TEST_SCHEMA", stage="mystage"
        )
        assert result == mock_fs

    @patch("snowflake.ml.ray.datasource.datasource_utils.get_session")
    @patch("snowflake.ml.ray.datasource.datasource_utils.SFUserStageFileSystem")
    def test_create_user_stage_name(self, mock_sf_user_stage_fs, mock_get_session):
        mock_session = MagicMock()
        mock_session.get_current_database.return_value = "DEFAULT_DB"
        mock_session.get_current_schema.return_value = "DEFAULT_SCHEMA"
        mock_get_session.return_value = mock_session

        mock_fs = MagicMock()
        mock_sf_user_stage_fs.return_value = mock_fs

        result = create_stage_filesystem("@~")
        mock_sf_user_stage_fs.assert_called_once_with(
            db="DEFAULT_DB", schema="DEFAULT_SCHEMA", stage="~"
        )
        assert result == mock_fs

    @patch("snowflake.ml.ray.datasource.datasource_utils.MLRSPrometheusMetrics")
    @patch("snowflake.ml.ray.datasource.datasource_utils.os.makedirs")
    @patch("snowflake.ml.ray.datasource.datasource_utils.os.path.join")
    def test_write_to_local_path_success(self, mock_join, mock_makedirs, mock_metrics):
        """Test successful write to local path."""
        mock_fs = MagicMock()
        mock_write_metric = MagicMock()
        mock_metrics.DATASOURCE_WRITE_TO_LOCAL.value.labels.return_value = (
            mock_write_metric
        )

        mock_join.side_effect = lambda base, file: f"{base}/{file}"

        task1 = MagicMock(spec=ReadTask)
        task1.metadata.input_files = ["file1.csv", "file2.csv"]
        task2 = MagicMock(spec=ReadTask)
        task2.metadata.input_files = ["file3.csv"]

        tasks = [task1, task2]

        write_to_local_path(mock_fs, tasks, "/local/path", "CSV")
        assert mock_makedirs.call_count == 4

        expected_calls = [
            call("file1.csv", "/local/path/file1.csv"),
            call("file2.csv", "/local/path/file2.csv"),
            call("file3.csv", "/local/path/file3.csv"),
        ]
        mock_fs.get_file.assert_has_calls(expected_calls)

        assert mock_write_metric.inc.call_count == 3  # One for each file
        mock_metrics.DATASOURCE_WRITE_TO_LOCAL.value.labels.assert_called_with(
            datasource_type="CSV"
        )

    @patch("snowflake.ml.ray.datasource.datasource_utils.MLRSPrometheusMetrics")
    def test_update_metrics_with_complete_metadata(self, mock_metrics):
        mock_tasks_metric = MagicMock()
        mock_files_metric = MagicMock()
        mock_rows_metric = MagicMock()

        mock_metrics.DATASOURCE_READ_TASKS.value.labels.return_value = mock_tasks_metric
        mock_metrics.DATASOURCE_READ_FILES.value.labels.return_value = mock_files_metric
        mock_metrics.DATASOURCE_ROWS_READ.value.labels.return_value = mock_rows_metric

        task1 = MagicMock(spec=ReadTask)
        task1.metadata.input_files = ["file1.csv", "file2.csv"]
        task1.metadata.num_rows = 100
        task1.metadata.size_bytes = 1024

        task2 = MagicMock(spec=ReadTask)
        task2.metadata.input_files = ["file3.csv"]
        task2.metadata.num_rows = 50
        task2.metadata.size_bytes = 512

        tasks = [task1, task2]

        update_metrics(tasks, "CSV")

        # Verify metrics were called with correct values
        mock_tasks_metric.inc.assert_called_once_with(2)  # 2 tasks
        mock_files_metric.inc.assert_called_once_with(3)  # 3 files total
        mock_rows_metric.inc.assert_called_once_with(150)  # 100 + 50 rows

        # Verify labels were called correctly
        mock_metrics.DATASOURCE_READ_TASKS.value.labels.assert_called_with(
            datasource_type="CSV"
        )
        mock_metrics.DATASOURCE_READ_FILES.value.labels.assert_called_with(
            datasource_type="CSV"
        )
        mock_metrics.DATASOURCE_ROWS_READ.value.labels.assert_called_with(
            datasource_type="CSV"
        )
