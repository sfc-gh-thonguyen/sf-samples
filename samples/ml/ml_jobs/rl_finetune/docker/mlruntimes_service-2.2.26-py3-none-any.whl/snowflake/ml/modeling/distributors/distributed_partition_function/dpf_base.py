from typing import Callable, Any, Dict, Protocol, Optional, List
from snowflake import snowpark
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    SinglePartitionDetails,
    ExecutionOptions,
    RunStatus,
)


class DPF(Protocol):
    """
    Defines the interface for a Distributed Partition Function (DPF) designed to
    execute a user-defined-function across multiple data partitions in parallel.
    """

    def __init__(
        self,
        func: Callable[[Any], Any],
    ) -> None:
        """
        Initializes the DPF with the user-defined function to be executed on each partition.

        Args:
            func: The function to be applied to each data partition.
        """
        ...

    @property
    def partition_details(self) -> Dict[str, SinglePartitionDetails]:
        """
        Provides details for each partition.

        Returns:
            A dictionary mapping partition IDs to their respective details.
        """
        raise NotImplementedError

    @property
    def status(self) -> RunStatus:
        """
        Retrieves the overall status of the distributed execution.

        This property aggregates the status across all partitions to provide a summary
        of the entire run.

        Returns:
            The current status of the execution, which can be:
            - IN_PROGRESS: The run is ongoing.
            - SUCCESS: All partitions processed successfully.
            - PARTIAL_FAILURE: Some, but not all, partitions failed.
            - FAILURE: All partitions failed.
            - CANCELLED: The run was cancelled.
        """
        raise NotImplementedError

    def get_progress(self) -> Dict[str, List[SinglePartitionDetails]]:
        """
        Returns the current progress of the distributed run.

        Returns:
            A dictionary grouping partition details by their current status.
        """
        raise NotImplementedError

    def show_progress(self) -> None:
        """
        Displays a visualization of the execution progress
        """
        raise NotImplementedError

    def cancel(self) -> None:
        """
        Cancels the ongoing distributed execution.

        Note:
        - Partitions that have already completed may not be affected.
        - Partial results, logs, or other artifacts might remain after cancellation.
        """
        raise NotImplementedError

    def run(
        self,
        *,
        partition_by: str,
        snowpark_dataframe: snowpark.DataFrame,
        session: Optional[snowpark.Session] = None,
        execution_options: Optional[ExecutionOptions] = None,
    ) -> None:
        """
        Executes the user-defined function on partitions of the provided Snowpark DataFrame.

        Args:
            partition_by: The column name in the Snowpark DataFrame to partition the data by.
            snowpark_dataframe: The Snowpark DataFrame to be partitioned and processed.
            session: An optional Snowpark session to use.
            execution_options: Optional settings to configure the execution environment.
        """
        raise NotImplementedError
