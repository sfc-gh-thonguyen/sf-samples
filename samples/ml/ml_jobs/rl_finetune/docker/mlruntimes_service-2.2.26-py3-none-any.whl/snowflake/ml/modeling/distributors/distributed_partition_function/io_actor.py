import io
import os
import tempfile
import time
from typing import List
import cloudpickle
import ray

from snowflake.runtime.utils.session_utils import get_session
from snowflake.runtime.utils.logger import get_logger, print_user_log_info

logger = get_logger()

# Maximum number of IO actors (bounded to avoid Snowflake session limits)
MAX_IO_POOL_SIZE = 100


@ray.remote(num_cpus=0)
class IOActor:
    """
    A Ray actor that holds a persistent Snowflake session for stage I/O operations.

    This actor is part of a bounded pool to avoid overwhelming Snowflake with
    too many concurrent sessions when thousands of actors need to read/write data.
    """

    def __init__(self, id: int):
        self.id = id
        self.session = get_session()

    def ping(self) -> str:
        """Health check to ensure actor is initialized."""
        return "pong"

    def _refresh_session(self) -> None:
        """Refresh the session if it becomes stale."""
        self.session = get_session()

    def upload_to_stage(
        self,
        *,
        data: bytes,
        stage_path: str,
        filename: str,
        max_retries: int = 3,
    ) -> None:
        """
        Upload serialized data to a Snowflake stage with retry logic.

        Args:
            data: Pre-serialized bytes to upload.
            stage_path: The stage path (e.g., "@db.schema.stage/run_id/partition_id").
            filename: The destination filename.
            max_retries: Maximum number of retry attempts.
        """
        delay = 1
        stage_file_path = f"{stage_path}/{filename}"
        for attempt in range(max_retries):
            try:
                input_stream = io.BytesIO(data)
                self.session.file.put_stream(
                    input_stream,
                    stage_file_path,
                    auto_compress=False,
                    overwrite=True,
                )
                return
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                print_user_log_info(
                    logger,
                    f"IOActor {self.id}: upload failed (attempt {attempt + 1}), "
                    f"retrying in {delay}s. Error: {e}",
                )
                time.sleep(delay)
                delay *= 2
                # Refresh the session just in case it has become stale; if session hasnt expired, this will be a no-op.
                self._refresh_session()

    def download_from_stage(
        self,
        *,
        stage_path: str,
        filename: str,
        max_retries: int = 3,
    ) -> bytes:
        """
        Download a file from a Snowflake stage with retry logic.

        Uses session.file.get() with a unique temporary directory instead of
        get_stream() to avoid file corruption when multiple concurrent downloads
        on the same node have files with the same filename.

        Args:
            stage_path: The stage path (e.g., "@db.schema.stage/run_id/partition_id").
            filename: The filename to download.
            max_retries: Maximum number of retry attempts.

        Returns:
            The file contents as bytes.
        """
        delay = 1
        stage_file_path = f"{stage_path}/{filename}"
        for attempt in range(max_retries):
            # Use a unique temporary directory for this download to avoid
            # file corruption from concurrent downloads with the same filename.
            # get_stream() uses a shared temp directory which causes race conditions.
            try:
                with tempfile.TemporaryDirectory(
                    prefix=f"io_actor_{self.id}_"
                ) as tmp_dir:
                    self.session.file.get(stage_file_path, tmp_dir)
                    local_file_path = os.path.join(tmp_dir, filename)
                    with open(local_file_path, "rb") as f:
                        return f.read()
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                print_user_log_info(
                    logger,
                    f"IOActor {self.id}: download failed (attempt {attempt + 1}), "
                    f"retrying in {delay}s. Error: {e}",
                )
                time.sleep(delay)
                delay *= 2
                # Refresh the session just in case it has become stale
                self._refresh_session()
        # This should never be reached due to the raise in the loop
        raise RuntimeError(
            "Unexpected: download_from_stage completed without returning"
        )

    def execute_with_session(
        self,
        *,
        serialized_func: bytes,
        max_retries: int = 3,
    ) -> bytes:
        """
        Execute a user-provided function with this actor's Snowflake session.

        The function is received as cloudpickle-serialized bytes to handle closures
        and complex objects. The result is also returned as serialized bytes.

        Args:
            serialized_func: Cloudpickle-serialized function that takes a Session argument.
            max_retries: Maximum number of retry attempts.

        Returns:
            Cloudpickle-serialized result from the function.
        """
        delay = 1
        for attempt in range(max_retries):
            try:
                func = cloudpickle.loads(serialized_func)
                result = func(self.session)
                return cloudpickle.dumps(result)
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                print_user_log_info(
                    logger,
                    f"IOActor {self.id}: execute_with_session failed (attempt {attempt + 1}), "
                    f"retrying in {delay}s. Error: {e}",
                )
                time.sleep(delay)
                delay *= 2
                self._refresh_session()
        # This should never be reached due to the raise in the loop
        raise RuntimeError(
            "Unexpected: execute_with_session completed without returning"
        )

    def __repr__(self):
        return f"IOActor(id={self.id})"


class IOActorPool:
    """
    A dynamically growing pool of IOActor instances for distributing stage I/O operations.

    Grows on-demand up to max_size, then round-robins among existing actors.
    This bounds the number of concurrent Snowflake sessions to avoid hitting session limits.
    """

    def __init__(self, max_size: int = MAX_IO_POOL_SIZE):
        self._actors: List[ray.actor.ActorHandle] = []
        self._max_size = max_size
        self._next_index = 0

    def get_next_actor(self) -> ray.actor.ActorHandle:
        """
        Get an I/O actor - creates new one if under limit, otherwise round-robins.

        Actors are created with SPREAD scheduling strategy to distribute them
        across different nodes, balancing the session load.
        """
        current_size = len(self._actors)

        # If under limit, create a new actor with SPREAD scheduling
        if current_size < self._max_size:
            actor = IOActor.options(  # type: ignore[attr-defined]
                scheduling_strategy="SPREAD"
            ).remote(id=current_size)
            ray.get(actor.ping.remote())
            self._actors.append(actor)
            return actor

        # At capacity - round-robin among existing actors
        actor = self._actors[self._next_index]
        self._next_index = (self._next_index + 1) % self._max_size
        return actor

    def shutdown(self) -> None:
        """Kill all I/O actors."""
        for actor in self._actors:
            try:
                ray.kill(actor)
            except Exception:
                pass
        self._actors = []
