import os
import tempfile
import pickle
from typing import Any, List, Callable, Optional


# TODO: we should consolidate with "StageArtifactManager" from torch eventually.
class StageArtifactsManager:
    """
    Provides a user-friendly interface to list, download, and load artifacts
    that were saved to a specific stage path for a given partition.

    This class handles the common workflow of retrieving artifacts from Snowflake stages,
    with automatic deserialization for Python objects and flexible handling of different file types.

    Example:
        Basic usage after a DPF run completes:

        >>> # Get the stage artifacts manager for a specific partition
        >>> manager = run.partition_details["North"].stage_artifacts_manager

        >>> # List all available artifacts
        >>> files = manager.list()
        >>> print(files)  # ['model.pkl', 'metrics.json', 'predictions.csv']

        >>> # Download and deserialize a pickle file (default behavior)
        >>> model = manager.get("model.pkl")

        >>> # Download and load JSON with custom deserializer
        >>> import json
        >>> metrics = manager.get("metrics.json", read_function=lambda path: json.load(open(path, 'r')))

        >>> # Download raw file to specific local directory
        >>> import tempfile
        >>> local_dir = tempfile.mkdtemp()
        >>> csv_path = manager.download("predictions.csv", local_dir)
        >>> print(f"Downloaded to: {csv_path}")

        >>> # Load text files with custom deserializers
        >>> with open('config.txt', 'w') as f: f.write("setting=value")
        >>> config = manager.get("config.txt", read_function=lambda path: open(path, 'r').read())
    """

    def __init__(self, session, stage_path_prefix: str):
        self._session = session
        self._stage_path_prefix = stage_path_prefix.rstrip("/")

    def list(self) -> List[str]:
        """Lists the filenames of all artifacts in the partition's stage directory."""
        try:
            rows = self._session.sql(f"LS '@{self._stage_path_prefix}'").collect()
            return [os.path.basename(row["name"]) for row in rows]
        except Exception as e:
            raise RuntimeError(
                f"Could not list files at '{self._stage_path_prefix}': {e}"
            )

    def download(self, remote_filename: str, local_destination_dir: str) -> str:
        """
        Downloads a single raw artifact file to a specified local directory.

        Args:
            remote_filename: The name of the file to download (e.g., "model.pkl").
            local_destination_dir: The local directory to save the file in.

        Returns:
            The full local path to the downloaded file.
        """
        full_stage_path = f"{self._stage_path_prefix}/{remote_filename}"
        print(f"Downloading {full_stage_path} to {local_destination_dir}...")
        self._session.file.get(full_stage_path, local_destination_dir)
        return os.path.join(local_destination_dir, remote_filename)

    def get(
        self, filename: str, *, read_function: Optional[Callable[[str], Any]] = None
    ) -> Any:
        """
        Downloads an artifact to a temporary location and deserializes it into a Python object.

        How it works:

        - If 'read_function' is NOT provided (default):
          The file is assumed to be a pickle file and will be loaded with `pickle.load`.

        - If 'read_function' IS provided:
          That function will be called to load the object from the downloaded file path.

        Args:
            filename: The name of the artifact to get (e.g., "model.pkl").
            read_function: Optional. A function that takes one argument (the local file path)
                           and returns the deserialized Python object.
                           Example: `lambda path: json.load(open(path, 'r'))`

        Returns:
            The deserialized Python object.
        """

        def _default_load_logic(p):
            with open(p, "rb") as f:
                return pickle.load(f)

        load_logic = read_function or _default_load_logic

        with tempfile.TemporaryDirectory() as temp_dir:
            local_file_path = self.download(filename, temp_dir)
            return load_logic(local_file_path)
