import subprocess
import sys
import tempfile
import traceback

from snowflake.snowpark import Session
from snowflake.runtime.utils.session_utils import get_session
import ray
from ray.util.scheduling_strategies import NodeAffinitySchedulingStrategy
import time
from snowflake.runtime.utils.metrics import (
    MLRSPrometheusMetrics,
)
from snowflake.runtime.utils.logger import get_logger, LogType
from datetime import datetime
from typing import Optional, Dict, Any, Tuple
import os
from runtime_env import python_env

DEFAULT_SCALE_UP_TIMEOUT_S = 120.0
DEFAULT_SCALE_DOWN_TIMEOUT_S = 120.0
DEFAULT_CLUSTER_CHECK_INTERVAL_S = 5.0
DEFAULT_ROLLBACK_AFTER_SECONDS = 720

logger = get_logger()


def _setup() -> Session:
    """
    Setup function to initialize session and Ray cluster.
    Ensures that the Snowpark session and Ray cluster are active before performing any operation.
    """
    session = get_session()
    if not ray.is_initialized():
        ray.init(
            address="auto",
            ignore_reinit_error=True,
            log_to_driver=False,
            logging_level="CRITICAL",
        )
    return session


def _emit_success_metric(latency: int, is_scaling_up: bool):
    MLRSPrometheusMetrics.MULTI_NODE_SCALING_SUCCESS.value.inc()
    if is_scaling_up:
        MLRSPrometheusMetrics.MULTI_NODE_SCALING_UP_LATENCY.value.observe(latency)
    else:
        MLRSPrometheusMetrics.MULTI_NODE_SCALING_DOWN_LATENCY.value.observe(latency)


def _validate_compute_pool_capacity(
    session: Session, notebook_name: str, estimated_new_nodes: int
) -> bool:
    """
    Validate if the compute pool has enough capacity for scaling up.

    Note: This function only works as a pre-check before scaling up. The actual available capacity
    of the compute pool may change after the scaling operation starts.

    Args:
        session: Active Snowpark session
        notebook_name: Name of the notebook to scale
        estimated_new_nodes: Number of new nodes that will be added

    Returns:
        bool: True if validation passes (enough capacity or validation skipped due to errors),
              False if validation fails (not enough capacity)
    """
    nb_query = f"DESC NOTEBOOK {notebook_name}"

    try:
        # Get notebook details to find compute pool
        nb_result = session.sql(nb_query).collect()
        if len(nb_result) != 1:
            logger.warning(
                f"Expected exactly one result for notebook details, got {len(nb_result)}. Skipping capacity validation."
            )
            return True

        compute_pool_name = nb_result[0]["compute_pool"]

        # Get compute pool details to check capacity
        pool_query = f'DESC COMPUTE POOL "{compute_pool_name}"'
        pool_result = session.sql(pool_query).collect()

        if len(pool_result) != 1:
            logger.warning(
                f"Expected exactly one result for compute pool '{compute_pool_name}', got {len(pool_result)}. "
                "Skipping capacity validation."
            )
            return True

        max_nodes = pool_result[0]["max_nodes"]
        active_nodes = pool_result[0]["active_nodes"]
        headroom = max_nodes - active_nodes

        logger.debug(
            f"Compute pool '{compute_pool_name}' capacity: max_nodes={max_nodes}, "
            f"active_nodes={active_nodes}, headroom={headroom}, required={estimated_new_nodes}"
        )

        # Check if there's enough capacity
        if estimated_new_nodes > headroom:
            logger.warning(
                f"Not enough capacity in compute pool '{compute_pool_name}' to scale up. "
                f"Requested {estimated_new_nodes} new nodes but only {headroom} available "
                f"(max: {max_nodes}, active: {active_nodes})."
            )
            return False

        return True
    except Exception as e:
        # Log warning but don't block the scaling operation
        logger.warning(
            f"Failed to check compute pool capacity: {e}. Proceeding with scaling operation."
        )
        return True


def _validate_scaling_parameters(
    expected_cluster_size: int, is_async: bool, options: Dict[str, Any]
) -> Tuple[Optional[int], Optional[int]]:
    """
    Validate scaling parameters and extract option values.

    Args:
        expected_cluster_size: Desired cluster size
        is_async: Whether to run asynchronously
        options: Dictionary of scaling options

    Returns:
        Tuple containing rollback_after_seconds and block_until_min_cluster_size

    Raises:
        ValueError: If any parameter validation fails
    """
    if expected_cluster_size < 1:
        raise ValueError("Expected cluster size must be at least 1.")

    # Extract parameters from options
    rollback_after_seconds = options.get("rollback_after_seconds")
    block_until_min_cluster_size = options.get("block_until_min_cluster_size")

    # Handle async operation, which will override block_until_min_cluster_size to 1
    if is_async:
        block_until_min_cluster_size = 1

    # Validate optional parameters
    if rollback_after_seconds is not None and rollback_after_seconds <= 0:
        raise ValueError("rollback_after_seconds must be a positive integer.")

    if block_until_min_cluster_size is not None:
        if block_until_min_cluster_size <= 0:
            raise ValueError("block_until_min_cluster_size must be a positive integer.")
        if block_until_min_cluster_size > expected_cluster_size:
            raise ValueError(
                "block_until_min_cluster_size cannot be greater than expected_cluster_size."
            )

    # If block_until_min_cluster_size is provided but rollback_after_seconds is not, use default value
    if block_until_min_cluster_size is not None:
        rollback_after_seconds = (
            rollback_after_seconds or DEFAULT_ROLLBACK_AFTER_SECONDS
        )

    return rollback_after_seconds, block_until_min_cluster_size


def _check_scaling_capacity(
    session: Session,
    notebook_name: str,
    current_cluster_size: int,
    expected_cluster_size: int,
) -> None:
    """
    Check if there's enough capacity for scaling up.

    Args:
        session: Snowpark session
        notebook_name: Name of the notebook
        current_cluster_size: Current size of the cluster
        expected_cluster_size: Target size of the cluster

    Raises:
        Exception: If there's not enough capacity for scaling up
    """
    is_scaling_up = expected_cluster_size > current_cluster_size

    if is_scaling_up:
        estimated_new_nodes = expected_cluster_size - current_cluster_size
        has_capacity = _validate_compute_pool_capacity(
            session, notebook_name, estimated_new_nodes
        )

        if not has_capacity:
            MLRSPrometheusMetrics.MULTI_NODE_SCALING_FAILURE.value.inc()
            raise Exception(
                f"Not enough capacity to scale up. Requested {estimated_new_nodes} new nodes. "
                "Please try again with a smaller cluster size or contact your administrator "
                "to increase the compute pool capacity."
            )
    else:
        # Skip capacity validation for scale-down operations
        logger.debug(
            "Skipping capacity validation for scale-down operation"
            f" (from {current_cluster_size} to {expected_cluster_size} nodes)"
        )


def _build_scaling_query(
    notebook_name: str,
    target_worker_count: int,
    rollback_after_seconds: Optional[int] = None,
    block_until_min_cluster_size: Optional[int] = None,
) -> str:
    """
    Build the SQL query for scaling the cluster.

    Args:
        notebook_name: Name of the notebook
        target_worker_count: Target number of worker nodes
        rollback_after_seconds: Optional rollback time in seconds
        block_until_min_cluster_size: Optional minimum cluster size

    Returns:
        str: The constructed SQL query
    """
    query = f"CALL SYSTEM$SCALE_ST_SERVICE_WORKERS('NOTEBOOK', '{notebook_name}', {target_worker_count}"

    if rollback_after_seconds is not None:
        query += f", {rollback_after_seconds}"

        if block_until_min_cluster_size is not None:
            query += f", {block_until_min_cluster_size}"

    query += ");"

    return query


def _build_vnext_scaling_query(
    target_worker_count: int,
    rollback_after_seconds: Optional[int] = None,
    block_until_min_cluster_size: Optional[int] = None,
) -> str:
    """
    Build the SQL query for vnext scaling the cluster.

    Args:
        target_worker_count: Target number of worker nodes
        rollback_after_seconds: Optional rollback time in seconds
        block_until_min_cluster_size: Optional minimum cluster size

    Returns:
        str: The constructed SQL query
    """
    query = f"CALL SYSTEM$SCALE_SERVICE_WORKERS({target_worker_count}"

    if rollback_after_seconds is not None:
        query += f", {rollback_after_seconds}"

        if block_until_min_cluster_size is not None:
            query += f", {block_until_min_cluster_size}"

    query += ");"

    return query


def _execute_scaling_operation(
    session: Session,
    query: str,
    notebook_name: str,
    expected_cluster_size: int,
    timeout: float,
    block_until_min_cluster_size: Optional[int] = None,
) -> bool:
    """
    Execute the scaling operation and verify results.

    Args:
        session: Snowpark session
        query: SQL query to execute
        notebook_name: Name of the notebook
        expected_cluster_size: Target cluster size
        timeout: Timeout for verification
        block_until_min_cluster_size: Optional minimum cluster size

    Returns:
        bool: True if scaling succeeded

    Raises:
        Exception: If scaling fails
    """
    try:
        # Execute scaling operation
        # TODO: make this query asynchronous and logs some frequent update about progress
        result = session.sql(query).collect()

        # The system function returns a boolean indicating success.
        # This is a client-side guardrail to ensure we either return true or raise an error.
        if not result[0][0]:
            MLRSPrometheusMetrics.MULTI_NODE_SCALING_FAILURE.value.inc()
            raise Exception(f"Failed to scale cluster for notebook '{notebook_name}'")

        # Verify cluster scaling operation
        _verify_cluster_size(
            expected_cluster_size, timeout, block_until_min_cluster_size
        )
        return True
    except Exception as e:
        MLRSPrometheusMetrics.MULTI_NODE_SCALING_FAILURE.value.inc()
        raise Exception(f"Failed to scale cluster for notebook '{notebook_name}': {e}")


def _execute_vnext_scaling_operation(
    session: Session,
    query: str,
    expected_cluster_size: int,
    timeout: float,
    block_until_min_cluster_size: Optional[int] = None,
) -> bool:
    """
    Execute the scaling operation and verify results.

    Args:
        session: Snowpark session
        query: SQL query to execute
        expected_cluster_size: Target cluster size
        timeout: Timeout for verification
        block_until_min_cluster_size: Optional minimum cluster size

    Returns:
        bool: True if scaling succeeded

    Raises:
        Exception: If scaling fails
    """
    try:
        # Execute scaling operation
        # TODO: make this query asynchronous and logs some frequent update about progress
        result = session.sql(query).collect()

        # The system function returns a boolean indicating success.
        # This is a client-side guardrail to ensure we either return true or raise an error.
        if not result[0][0]:
            # TODO: Add vnext scaling metrics
            # MLRSPrometheusMetrics.MULTI_NODE_SCALING_FAILURE.value.inc()
            raise Exception("Failed to scale cluster")

        # Verify cluster scaling operation
        _verify_cluster_size(
            expected_cluster_size, timeout, block_until_min_cluster_size
        )
        return True
    except Exception as e:
        # TODO: Add vnext scaling metrics
        # MLRSPrometheusMetrics.MULTI_NODE_SCALING_FAILURE.value.inc()
        raise Exception(f"Failed to scale cluster: {e}")


def scale_cluster(
    expected_cluster_size: int,
    *,
    notebook_name: Optional[str] = None,
    is_async: bool = False,
    options: Optional[Dict[str, Any]] = None,
) -> bool:
    """
    Scale the Ray cluster associated with a notebook to the desired size.

    This function sends a request to scale the cluster, then waits until the scaling
    operation completes or meets minimum size requirements.

    Args:
        expected_cluster_size (int): Desired cluster size (number of total nodes including the head node).
            For example, a value of 3 means 1 head node + 2 worker nodes.
        notebook_name (str, optional): The name of the notebook to scale. If not provided,
            it will be retrieved from the OBJECT_NAME environment variable.
        is_async (bool, optional): Controls whether the function blocks waiting for scaling:

            - If False (default): The function blocks until either the cluster is fully ready or
              the operation times out. If scaling doesn't complete in time, the cluster will
              automatically roll back to its previous state.
            - If True: The function returns immediately after confirming the scaling request
              has been accepted, without waiting for the full cluster to be ready. This is
              useful for non-blocking operations.

        options (Dict[str, Any], optional): Advanced low-level configuration options for cluster scaling.
            These options are primarily for advanced use cases and debugging:

            - rollback_after_seconds (int): Maximum time in seconds before the scaling operation
              is automatically rolled back if not completed. Defaults to 720 seconds.
            - block_until_min_cluster_size (int): Number of nodes in the cluster that must be fully running
              before returning. If this threshold is reached before the timeout, the function returns,
              leaving any remaining nodes to come up (or fail) in the background. Note that if 'is_async'
              is set to True, this value will be overridden to 1 regardless of what is specified here.

    Returns:
        bool: True if scaling succeeded and the expected cluster size (or minimum required size) is reached.
    """
    # Initialize default options
    options = options or {}

    # Validate and prepare parameters
    object_name = os.getenv("OBJECT_NAME")

    result = None
    if object_name is None:
        (
            rollback_after_seconds,
            block_until_min_cluster_size,
        ) = _validate_scaling_parameters(expected_cluster_size, is_async, options)

        # Calculate target worker count
        target_worker_count = expected_cluster_size - 1

        # Setup and initialize
        session = _setup()
        current_cluster_size = get_cluster_size()
        is_scaling_up = expected_cluster_size > current_cluster_size
        timeout = (
            DEFAULT_SCALE_UP_TIMEOUT_S
            if is_scaling_up
            else DEFAULT_SCALE_DOWN_TIMEOUT_S
        )

        # Build scaling query
        query = _build_vnext_scaling_query(
            target_worker_count,
            rollback_after_seconds,
            block_until_min_cluster_size,
        )

        # Execute scaling operation
        result = _execute_vnext_scaling_operation(
            session,
            query,
            expected_cluster_size,
            timeout,
            block_until_min_cluster_size,
        )
    else:
        formatted_notebook_name = notebook_name if notebook_name else object_name
        (
            rollback_after_seconds,
            block_until_min_cluster_size,
        ) = _validate_scaling_parameters(expected_cluster_size, is_async, options)

        # Calculate target worker count
        target_worker_count = expected_cluster_size - 1

        # Setup and initialize
        start_time = datetime.now()
        session = _setup()
        current_cluster_size = get_cluster_size()
        is_scaling_up = expected_cluster_size > current_cluster_size
        timeout = (
            DEFAULT_SCALE_UP_TIMEOUT_S
            if is_scaling_up
            else DEFAULT_SCALE_DOWN_TIMEOUT_S
        )

        # Check capacity for scaling up
        _check_scaling_capacity(
            session,
            formatted_notebook_name,
            current_cluster_size,
            expected_cluster_size,
        )

        # Build scaling query
        query = _build_scaling_query(
            formatted_notebook_name,
            target_worker_count,
            rollback_after_seconds,
            block_until_min_cluster_size,
        )

        # Execute scaling operation
        result = _execute_scaling_operation(
            session,
            query,
            formatted_notebook_name,
            expected_cluster_size,
            timeout,
            block_until_min_cluster_size,
        )

        if not is_async:
            try:
                python_env.sync_env()
            except Exception as e:
                ex_info = "".join(
                    traceback.format_exception(type(e), e, e.__traceback__)
                )
                logger.error(
                    f"Error while updating python environment: {ex_info}",
                    extra={"log_types": [LogType.SYSTEM]},
                )

        # Emit metrics on success
        _emit_success_metric(
            int((datetime.now() - start_time).total_seconds()), is_scaling_up
        )

    return result


def get_nodes() -> list:
    """
    Get the current active nodes in the Ray cluster.

    Returns:
        list: A list of active node details. Only the node name, number of
        CPUs and GPUs are returned.
    """
    _setup()
    try:
        cluster_info = ray.nodes()
        active_nodes = [
            {
                "name": node["NodeName"],
                "cpus": node.get("Resources", {}).get("CPU", 0),
                "gpus": node.get("Resources", {}).get("GPU", 0),
            }
            for node in cluster_info
            if node["Alive"]
        ]
        return active_nodes
    except Exception as e:
        raise Exception(f"Failed to fetch active nodes: {e}")


def get_ray_dashboard_url(
    notebook_name: Optional[str] = None,
) -> str:
    """
    Get the public Ray dashboard url for the given notebook.

    Returns:
        str: The Ray dashboard url.
    """
    with open("/proc/meminfo", "r") as f:
        for line in f:
            if line.startswith("MemTotal"):
                mem_mb = int(line.split()[1]) // 1024
                if mem_mb < 8192:
                    raise Exception(
                        "Ray dashboard is not supported on XS compute pools. Please use a larger "
                        "compute pool if you want to use Ray dashboard."
                    )
                break

    session = _setup()
    get_services_query = "CALL SYSTEM$GET_ML_ENDPOINT_URL('ray-dashboard-endpoint')"
    get_services_result = session.sql(get_services_query).collect()

    if len(get_services_result) != 1:
        raise Exception(
            f"Expected exactly one 'ray-dashboard-endpoint' found, got {len(get_services_result)}.\
                To debug, run `CALL SYSTEM$GET_ML_ENDPOINT_URL('ray-dashboard-endpoint')` and check\
                     the result."
        )

    return get_services_result[0]["SYSTEM$GET_ML_ENDPOINT_URL"]


def get_grafana_dashboard_url() -> str:
    """
    Get the public Grafana dashboard url for the current notebook.

    Returns:
        str: The Grafana dashboard url.
    """
    session = _setup()
    get_services_query = "CALL SYSTEM$GET_ML_ENDPOINT_URL('grafana-endpoint')"
    get_services_result = session.sql(get_services_query).collect()

    if len(get_services_result) == 0:
        raise Exception(
            "No grafana endpoint found. Please ensure account parameter ENABLE_GRAFANA_ENDPOINT is set to true"
        )
    if len(get_services_result) != 1:
        raise Exception(
            f"Expected exactly one 'grafana-endpoint' found, got {len(get_services_result)}.\
                To debug, run `CALL SYSTEM$GET_ML_ENDPOINT_URL('grafana-endpoint')` and check\
                    the result."
        )

    return get_services_result[0]["SYSTEM$GET_ML_ENDPOINT_URL"]


def get_cluster_size() -> int:
    """
    Get the current number of alive nodes in the Ray cluster.

    Returns:
        int: The number of alive nodes (including the head node).
    """
    return len(get_nodes())


def _verify_cluster_size(
    expected_cluster_size: int, timeout: float, min_cluster_size: Optional[int] = None
) -> None:
    """
    Verify that the cluster size meets the requirements within a timeout.

    Args:
        expected_cluster_size (int): Expected cluster size (target size).
        timeout (float): Timeout in seconds for the verification.
        min_cluster_size (int, optional): Minimum acceptable cluster size. When provided,
            verification succeeds if the cluster has at least this many nodes, even if it
            doesn't reach expected_cluster_size yet.

    Raises:
        Exception: If the cluster size doesn't meet requirements within the timeout.
    """
    _setup()
    start_time = time.time()
    while time.time() - start_time < timeout:
        current_cluster_size = get_cluster_size()

        # If min_cluster_size is specified, check if we've reached at least that many nodes
        if min_cluster_size is not None and current_cluster_size >= min_cluster_size:
            return

        # Otherwise, check for exact match with expected size
        if current_cluster_size == expected_cluster_size:
            return

        time.sleep(DEFAULT_CLUSTER_CHECK_INTERVAL_S)

    MLRSPrometheusMetrics.MULTI_NODE_SCALING_TIMEOUT.value.inc()

    # Customize error message based on which verification failed
    if min_cluster_size is not None:
        raise Exception(
            f"Cluster size verification failed: expected at least {min_cluster_size}, "
            f"but got {current_cluster_size} after {timeout} seconds."
        )
    else:
        raise Exception(
            f"Cluster size verification failed: expected {expected_cluster_size}, "
            f"but got {current_cluster_size} after {timeout} seconds."
        )


def get_available_cpu() -> int:
    """
    Get the number of available CPUs for current ray cluster.

    Returns:
        int: number of available CPUs.
    """
    _setup()
    return ray.available_resources().get("CPU", 0)


def get_available_gpu() -> int:
    """
    Get the number of available GPUs for current ray cluster.

    Returns:
        int: number of available GPUs.
    """
    _setup()
    return ray.available_resources().get("GPU", 0)


def get_num_cpus_per_node() -> int:
    """
    Get the number of CPUs per node for current ray cluster.

    Returns:
        int: number of CPUs per node.
    """
    _setup()
    # Since we always use a homogeneous cluster, we can just randomly pick a node
    random_node = ray.nodes()[0]
    return random_node.get("Resources", {}).get("CPU", 0)


def _install_wheel_from_stage(wheel_stage_path: str, node_id: str = "current") -> None:
    """
    Common helper function to download and install a wheel from Snowflake stage.

    Args:
        wheel_stage_path: The stage path of the wheel to install.
        node_id: Identifier for the node (used in error messages).

    Raises:
        RuntimeError: If wheel installation fails.
    """
    session = _setup()

    # Download wheel from Snowflake stage
    with tempfile.TemporaryDirectory(prefix="ml_runtime_wheels_") as tmpdir:
        # Example stage path: '@"SNOWPUBLIC"."NOTEBOOKS"."KUNLE_WHEELS"/mlruntimes_service-1.7.2-py3-none-any.whl'
        session.file.get(wheel_stage_path, tmpdir)
        print(f"Successfully downloaded the wheel from stage {wheel_stage_path}")

        basename = os.path.basename(wheel_stage_path)
        wheel_local_path = os.path.join(tmpdir, basename)

        # Install the wheel into the current interpreter env and overwrite the existing one
        args = [
            sys.executable,
            "-m",
            "pip",
            "install",
            wheel_local_path,
            "--force-reinstall",
            "--no-deps",  # There is a versioning bug. Without no-deps,
            # pip tries to download all versions that satisfy the package condition instead of
            # just one.
        ]

        proc = subprocess.run(
            args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"pip install failed on node {node_id}: \nSTDOUT: \n{proc.stdout}\nSTDERR: \n{proc.stderr}"
            )


@ray.remote
def _per_node_runner(
    wheel_stage_path: str,
    node_id: str,
) -> Any:
    """
    Runs on a specific Ray node (pinned via NodeAffinity) and installs a wheel from Snowflake stage.
    """
    _install_wheel_from_stage(wheel_stage_path, node_id)


def _install_mlruntimes_wheel(
    wheel_stage_path: str,
):
    """
    Install the mlruntimes wheel across all nodes in the cluster. This function is meant to be
    called by the developers, NOT the customers.

    Args:
        wheel_stage_path: The stage path of the wheel to install.

    Raises:
        Exception: If wheel installation fails on any node.
    """
    print("Warning: This function should only be called by developers.")
    _setup()
    all_nodes = [n for n in ray.nodes() if n.get("Alive")]
    print(f"Found {len(all_nodes)} node(s) in the cluster")

    if len(all_nodes) == 1:
        # Single node cluster - install directly without Ray tasks
        try:
            _install_wheel_from_stage(wheel_stage_path)
            print("Successfully installed mlruntimes wheel on the head node.")
            print("Please restart the notebook kernel to use the new wheel.")
        except Exception as e:
            raise Exception(f"Wheel installation failed on head node: {e}")
        return

    # Multi-node cluster - use Ray tasks for distributed installation
    obj_refs = []
    for node in all_nodes:
        node_id = node["NodeID"]
        scheduling = NodeAffinitySchedulingStrategy(node_id=node_id, soft=False)
        ref = _per_node_runner.options(scheduling_strategy=scheduling).remote(
            wheel_stage_path, node_id
        )
        obj_refs.append((node_id, ref))

    # Wait for all tasks to complete and collect results/errors
    failed_nodes = []
    for node_id, ref in obj_refs:
        try:
            ray.get(ref)
        except Exception as e:
            failed_nodes.append((node_id, str(e)))

    # If any nodes failed, raise an exception with details
    if failed_nodes:
        error_details = "\n".join(
            [f"Node {node_id}: {error}" for node_id, error in failed_nodes]
        )
        raise Exception(
            f"Wheel installation failed on {len(failed_nodes)} node(s): {error_details}"
        )
    print("Successfully installed mlruntimes wheel on all nodes.")
    print("Please restart the notebook kernel to use the new wheel.")
