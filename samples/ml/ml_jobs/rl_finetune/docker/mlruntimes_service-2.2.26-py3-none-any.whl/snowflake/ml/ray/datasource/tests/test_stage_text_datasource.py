from snowflake.ml.ray.datasource.stage_text_datasource import SFStageTextDataSource
from unittest.mock import patch, MagicMock
from ray.data import ReadTask
from pyarrow.fs import FSSpecHandler, PyFileSystem


@patch("snowflake.ml.ray.datasource.stage_text_datasource.create_stage_filesystem")
@patch("snowflake.ml.ray.datasource.stage_text_datasource.update_metrics")
def test_init_with_all_args(mock_update_metrics, mock_create_fs):
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs

    with patch(
        "ray.data._internal.datasource.text_datasource.TextDatasource.__init__"
    ) as mock_parent_init:
        mock_parent_init.return_value = None

        datasource = SFStageTextDataSource(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
            file_pattern="*.txt",
            local_path="/local/path",
            encoding="utf-8",
            drop_empty_lines=True,
        )

        mock_create_fs.assert_called_once_with(
            stage_location="@mystage/path/to/files",
            database="test_db",
            schema="test_schema",
        )

        assert datasource._local_path == "/local/path"
        assert datasource._DATASOURCE_TYPE == "TextFile"
        mock_parent_init.assert_called_once()
        # update_metrics is not called during initialization
        mock_update_metrics.assert_not_called()


@patch("snowflake.ml.ray.datasource.stage_text_datasource.update_metrics")
def test_get_read_tasks_success(mock_update_metrics):
    with patch(
        "ray.data._internal.datasource.text_datasource.TextDatasource.__init__"
    ), patch(
        "snowflake.ml.ray.datasource.stage_text_datasource.create_stage_filesystem"
    ):
        mock_read_task = MagicMock(spec=ReadTask)
        datasource = SFStageTextDataSource(stage_location="@mystage/path")

        with patch(
            "ray.data._internal.datasource.text_datasource.TextDatasource.get_read_tasks"
        ) as mock_get_read_tasks:
            mock_get_read_tasks.return_value = [mock_read_task]

            result = datasource.get_read_tasks(parallelism=2)

            assert len(result) == 1
            assert result[0] is mock_read_task

            # Verify update_metrics was called with correct arguments
            mock_update_metrics.assert_called_once_with([mock_read_task], "TextFile")


@patch("ray.data._internal.datasource.text_datasource.TextDatasource.__init__")
@patch("snowflake.ml.ray.datasource.stage_text_datasource.update_metrics")
@patch("snowflake.ml.ray.datasource.stage_text_datasource.extract_extension")
@patch("snowflake.ml.ray.datasource.stage_text_datasource.create_stage_filesystem")
def test_parent_class_initialization(
    mock_create_fs, mock_extract_ext, mock_update_metrics, mock_parent_init
):
    mock_extract_ext.return_value = ["txt"]
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs
    mock_parent_init.return_value = None

    SFStageTextDataSource(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
        file_pattern="*.txt",
        encoding="utf-8",
        drop_empty_lines=False,
    )
    mock_parent_init.assert_called_once()

    # Check the arguments passed to parent constructor
    mock_parent_init.assert_called_with(
        paths=["//path/to/files"],
        filesystem=PyFileSystem(FSSpecHandler(mock_fs)),
        encoding="utf-8",
        drop_empty_lines=False,
        file_extensions=["txt"],
    )

    # Verify utility functions were called correctly
    mock_create_fs.assert_called_once_with(
        stage_location="@mystage/path/to/files",
        database="test_db",
        schema="test_schema",
    )
    mock_extract_ext.assert_called_once_with("*.txt")

    # update_metrics should not be called during initialization
    mock_update_metrics.assert_not_called()
