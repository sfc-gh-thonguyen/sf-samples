from typing import Protocol, List, Dict, Optional, Type, Any
import importlib

from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.modeling.distributors.pytorch.artifact_manager import ArtifactManager


class MetricsReporter(Protocol):
    """
    Only metrics reported by rank 0 are returned by the trainer.run() method.
    This object is accessible via the get_metrics_reporter() method on the Context object.
    All metrics reported by non-zero ranks are ignored. To report metrics from non-zero ranks,
    aggregate them to rank 0 and report them from there.
    """

    def log_metrics(self, metrics: Dict[str, Any]) -> None:
        pass


class Context(Protocol):
    """Context for setting up the PyTorch distributed environment for training scripts.

    Context defines the necessary methods to manage and retrieve information
    about the distributed training environment, including worker and node ranks,
    world size, and backend configurations.

    Definitions:
        Node: A physical instance or a container.

        Worker: A worker process in the context of distributed training.

        WorkerGroup: The set of workers that execute the same function (e.g., trainers).

        LocalWorkerGroup: A subset of the workers in the worker group running on the same node.

        RANK: The rank of the worker within a worker group.

        WORLD_SIZE: The total number of workers in a worker group.

        LOCAL_RANK: The rank of the worker within a local worker group.

        LOCAL_WORLD_SIZE: The size of the local worker group.

        rdzv_id: An ID that uniquely identifies the worker group for a job. This ID is used by each node to join as
            a member of a particular worker group.

        rdzv_backend: The backend of the rendezvous (e.g., c10d). This is typically a strongly consistent
            key-value store.

        rdzv_endpoint: The rendezvous backend endpoint; usually in the form <host>:<port>.
    """

    def get_world_size(self) -> int:
        """Return the number of workers(or processes) participating in the job.

        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then the world size is 8 (2 nodes * 4 GPUs per node). Usually, each GPU corresponds
        to a training process.

        Returns:
            int: The total number of workers in the job.
        """
        raise NotImplementedError()

    def get_rank(self) -> int:
        """Return the rank of the current process across all processes.

        Rank is the unique ID given to a process to identify it uniquely across the world.
        It should be a number between 0 and world_size - 1.
        Some frameworks aslo call it world_rank, to distinguish it from local_rank.
        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then the ranks will be [0, 1, 2, 3, 4, 5, 6, 7], i.e., from 0 to world_size - 1.

        Returns:
            int: The rank of the current process.
        """
        raise NotImplementedError()

    def get_local_rank(self) -> int:
        """Return the local rank for the current worker.

        Local rank is a unique local ID for a worker (or process) running on the current node.

        For example, if training is running on 2 nodes (servers) each with 4 GPUs, then
        local rank for workers(or processes) running on node 0 will be [0, 1, 2, 3] and
        similarly four workers(or processes) running on node 1 will have local_rank [0, 1, 2, 3].

        Returns:
            int: The local rank of the current process.
        """
        raise NotImplementedError()

    def get_local_world_size(self) -> int:
        """Return the number of workers running in the current node.

        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then local_world_size will be 4 for all processes on both nodes.

        Returns:
            int: The number of workers in the current node.
        """
        raise NotImplementedError()

    def get_node_rank(self) -> int:
        """Return the rank of the current node across all nodes.

        Node rank is a unique ID given to each node to identify it uniquely across all nodes
        in the world.

        For example, if training is running on 2 nodes (servers) each with 4 GPUs,
        then node ranks will be [0, 1] respectively.

        Returns:
            int: The rank of the current node.
        """
        raise NotImplementedError()

    def get_master_addr(self) -> str:
        """Return IP address of the master node.

        This is typically the address of the node with node_rank 0.

        Returns:
            str: The IP address of the master node.
        """
        raise NotImplementedError()

    def get_master_port(self) -> int:
        """Return port on master_addr that hosts the rendezvous server.

        Returns:
            int: The port number for rendezvous communication.
        """
        raise NotImplementedError()

    def get_default_backend(self) -> str:
        """Return default backend selected by MCE.

        Returns:
            str: The default backend being used for distributed training.
        """
        raise NotImplementedError()

    def get_supported_backends(self) -> List[str]:
        """Return list of supported backends by MCE.

        Returns:
            List[str]: A list containing names of supported backends.
        """
        raise NotImplementedError()

    def get_hyper_params(self) -> Optional[Dict[str, str]]:
        """Return hyperparameter map provided to trainer.run(...) method.

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping hyperparameter names to their values.
        """
        raise NotImplementedError()

    def get_dataset_map(self) -> Optional[Dict[str, Type[DataConnector]]]:
        """Return dataset map provided to trainer.run(...) method.

        Returns:
            Optional[Dict[str, Type[DataConnector]]]: A dictionary mapping dataset names to their DataConnector types.
        """
        raise NotImplementedError()

    def get_model_dir(self) -> str:
        """Return the path to a directory where the model should be saved.
        All the model artifacts written to this directory will be preserved after the training job.

        Returns:
            str: The path to the model directory.
        """
        raise NotImplementedError()

    def get_metrics_reporter(self) -> "MetricsReporter":
        """Return the metric reporter object for logging training metrics.
        Only metrics reported by rank 0 are returned by the trainer.run() method.

        Returns:
            MetricReporter: An instance of the MetricReporter interface.
        """
        raise NotImplementedError()

    def get_artifact_manager(self) -> ArtifactManager:
        """Return artifact manager object to help sync checkpoint files to shared persistence storage.
        A stage needs to be specified as input argument to PyTorchDistributor.run() method.

        Returns:
            ArtifactManager: An instance of the ArtifactManager.

        Raises:
            RuntimeError: If artifact_stage_location was not provided to PyTorchDistributor.run().
        """
        raise NotImplementedError()


def get_context() -> Context:
    """Fetches the context object that contains the worker specific runtime information.

    Returns:
        Context: An instance of the Context interface that provides methods for
        managing the distributed training environment.

    Raises:
        RuntimeError: If the PyTorch context is not available.
    """
    pytorch_context_module_name = "implementations.pytorch.torch_train_context"
    get_context_func_name = "get_torch_train_context"
    # Running in a job
    module = importlib.import_module(pytorch_context_module_name)
    getter_func = getattr(module, get_context_func_name)
    return getter_func()
