import pytest
from unittest.mock import patch, MagicMock, call
from snowflake.ml.ray.datasink.table_datasink import SnowflakeTableDatasink


@pytest.fixture
def mock_session():
    with patch(
        "snowflake.ml.ray.datasink.table_datasink.get_session"
    ) as mock_get_session:
        mock_session = MagicMock()
        mock_get_session.return_value = mock_session

        yield mock_session


@pytest.fixture
def mock_logger():
    with patch(
        "snowflake.ml.ray.datasink.table_datasink.get_logger"
    ) as mock_get_logger:
        mock_logger = MagicMock()
        mock_get_logger.return_value = mock_logger
        yield mock_logger


def test_snowflake_table_datasink_init(mock_logger, mock_session):
    mock_session.get_current_database.return_value = '"test_db"'
    mock_session.get_current_schema.return_value = '"test_schema"'

    datasink = SnowflakeTableDatasink(table_name="test_table")

    assert datasink._table_name == "test_table"
    assert datasink._database == '"test_db"'
    assert datasink._schema == '"test_schema"'
    assert datasink._override is False
    assert datasink._auto_create_table is False


@pytest.mark.parametrize("override", [True, False])
def test_on_write_start_table_not_exists_auto_create_false(
    mock_logger, mock_session, override
):
    mock_session.sql.return_value.collect.return_value = []

    datasink = SnowflakeTableDatasink(
        table_name="test_table", auto_create_table=False, override=override
    )

    with pytest.raises(ValueError, match=r".*does not exist.*"):
        datasink.on_write_start()


@pytest.mark.parametrize("auto_create_table", [True, False])
def test_on_write_start_override_true_should_drop_table(
    mock_logger, mock_session, auto_create_table
):
    mock_session.sql.return_value.collect.return_value = ["test_table"]
    mock_session.get_current_database.return_value = '"test_db"'
    mock_session.get_current_schema.return_value = '"test_schema"'

    datasink = SnowflakeTableDatasink(
        table_name="test_table", auto_create_table=auto_create_table, override=True
    )
    datasink.on_write_start()
    mock_session.sql.assert_called_with(
        'DROP TABLE IF EXISTS "test_db"."test_schema".test_table'
    )


@pytest.mark.parametrize("auto_create_table", [True, False])
def test_on_write_start_override_false_should_not_drop_table(
    mock_logger, mock_session, auto_create_table
):
    mock_session.sql.return_value.collect.return_value = ["test_table"]
    mock_session.get_current_database.return_value = '"test_db"'
    mock_session.get_current_schema.return_value = '"test_schema"'

    datasink = SnowflakeTableDatasink(
        table_name="test_table", auto_create_table=auto_create_table, override=False
    )
    datasink.on_write_start()
    assert (
        call('DROP TABLE IF EXISTS "test_db"."test_schema".test_table')
        not in mock_session.sql.call_args_list
    )


def test_write(mock_logger, mock_session):
    """Test normal write with block merging (no errors)"""
    mock_block_accessor = MagicMock()
    mock_pandas_df = MagicMock()
    mock_pandas_df.empty = False
    mock_pandas_df.__len__ = MagicMock(return_value=50)  # Mock len() for row count
    mock_memory_usage = MagicMock()
    mock_memory_usage.sum.return_value = 512  # Mock memory usage
    mock_pandas_df.memory_usage.return_value = mock_memory_usage
    mock_block_accessor.for_block.return_value.to_pandas.return_value = mock_pandas_df

    test_table_name = "test_table"

    mock_builder = MagicMock()
    mock_merged_block = MagicMock()
    mock_builder.build.return_value = mock_merged_block

    with patch(
        "snowflake.ml.ray.datasink.table_datasink.BlockAccessor", mock_block_accessor
    ), patch(
        "snowflake.ml.ray.datasink.table_datasink.DelegatingBlockBuilder"
    ) as mock_builder_class:
        mock_builder_class.return_value = mock_builder

        datasink = SnowflakeTableDatasink(table_name=test_table_name)
        mock_block1 = MagicMock()
        mock_block2 = MagicMock()
        mock_block3 = MagicMock()
        mock_ctx = MagicMock()

        datasink.write([mock_block1, mock_block2, mock_block3], mock_ctx)

        # Verify DelegatingBlockBuilder was used correctly
        mock_builder_class.assert_called_once()
        mock_builder.add_block.assert_has_calls(
            [call(mock_block1), call(mock_block2), call(mock_block3)]
        )
        mock_builder.build.assert_called_once()
        mock_block_accessor.for_block.assert_called_once_with(mock_merged_block)

        mock_session.write_pandas.assert_called_once_with(
            df=mock_pandas_df,
            table_name=test_table_name,
            database=mock_session.get_current_database.return_value,
            schema=mock_session.get_current_schema.return_value,
            auto_create_table=False,
            overwrite=False,
            quote_identifiers=False,
        )


def test_write_with_retry(mock_logger, mock_session):
    mock_block_accessor = MagicMock()
    mock_pandas_df = MagicMock()
    mock_pandas_df.empty = False
    mock_pandas_df.__len__ = MagicMock(return_value=50)  # Mock len() for row count
    mock_memory_usage = MagicMock()
    mock_memory_usage.sum.return_value = 512  # Mock memory usage
    mock_pandas_df.memory_usage.return_value = mock_memory_usage
    mock_block_accessor.for_block.return_value.to_pandas.return_value = mock_pandas_df

    test_table_name = "test_table"

    # Mock the lock limit error on first call, success on second
    from snowflake.connector.errors import ProgrammingError

    lock_error = ProgrammingError(
        "number of waiters for this lock exceeds the 20 statements limit"
    )
    mock_session.write_pandas.side_effect = [lock_error, None]

    # Mock the DelegatingBlockBuilder
    mock_builder = MagicMock()
    mock_merged_block = MagicMock()
    mock_builder.build.return_value = mock_merged_block

    with patch(
        "snowflake.ml.ray.datasink.table_datasink.BlockAccessor", mock_block_accessor
    ), patch(
        "snowflake.ml.ray.datasink.table_datasink.time.sleep"
    ) as mock_sleep, patch(
        "snowflake.ml.ray.datasink.table_datasink.DelegatingBlockBuilder"
    ) as mock_builder_class:
        mock_builder_class.return_value = mock_builder

        datasink = SnowflakeTableDatasink(table_name=test_table_name)
        mock_block1 = MagicMock()
        mock_block2 = MagicMock()
        mock_ctx = MagicMock()

        datasink.write([mock_block1, mock_block2], mock_ctx)

        # Verify DelegatingBlockBuilder was used correctly
        mock_builder_class.assert_called_once()
        mock_builder.add_block.assert_has_calls([call(mock_block1), call(mock_block2)])
        mock_builder.build.assert_called_once()

        # Verify BlockAccessor was called with the merged block
        mock_block_accessor.for_block.assert_called_once_with(mock_merged_block)

        # Called twice (first failed, second succeeded)
        assert mock_session.write_pandas.call_count == 2
        # Slept once for retry
        mock_sleep.assert_called_once()


def test_write_empty_merged_block(mock_logger, mock_session):
    """Test write when merged block is empty"""
    mock_block_accessor = MagicMock()
    mock_pandas_df = MagicMock()
    mock_pandas_df.empty = True  # Empty merged block
    mock_block_accessor.for_block.return_value.to_pandas.return_value = mock_pandas_df

    test_table_name = "test_table"

    mock_builder = MagicMock()
    mock_merged_block = MagicMock()
    mock_builder.build.return_value = mock_merged_block

    with patch(
        "snowflake.ml.ray.datasink.table_datasink.BlockAccessor", mock_block_accessor
    ), patch(
        "snowflake.ml.ray.datasink.table_datasink.DelegatingBlockBuilder"
    ) as mock_builder_class:
        mock_builder_class.return_value = mock_builder

        datasink = SnowflakeTableDatasink(table_name=test_table_name)
        mock_block1 = MagicMock()
        mock_ctx = MagicMock()

        datasink.write([mock_block1], mock_ctx)

        # Verify DelegatingBlockBuilder was used
        mock_builder_class.assert_called_once()
        mock_builder.add_block.assert_called_once_with(mock_block1)
        mock_builder.build.assert_called_once()

        mock_block_accessor.for_block.assert_called_once_with(mock_merged_block)

        # Should NOT have called write_pandas since block is empty
        mock_session.write_pandas.assert_not_called()
