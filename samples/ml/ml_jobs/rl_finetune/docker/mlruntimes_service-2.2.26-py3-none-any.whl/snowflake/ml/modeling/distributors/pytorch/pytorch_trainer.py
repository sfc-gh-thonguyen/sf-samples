from typing import Callable, Optional, Dict, Any

from snowflake.ml.data.data_connector import DataConnector

from snowflake.ml.modeling.distributors.base_runnable import (
    BaseRunnable,
)
from snowflake.ml.modeling.distributors.pytorch.scaling_config import (
    PyTorchScalingConfig,
)
import importlib


class PyTorchDistributorResult:
    def __init__(
        self,
        model_dir: str,
        metrics: Optional[Dict[str, Any]] = None,
        checkpoint_location: Optional[str] = None,
    ):
        self._model_dir = model_dir
        self._metrics = metrics
        self._checkpoint_location = checkpoint_location

    def get_model_dir(self) -> str:
        """Returns the location of the model. If this is a stage, this returns the fully qualified name."""
        return self._model_dir

    def get_metrics(self) -> Optional[Dict[str, Any]]:
        """
        Only metrics reported by rank 0 are returned by the trainer.run() method.
        """
        return self._metrics

    def get_checkpoint_location(self) -> Optional[str]:
        """Returns the location of the checkpoints. If this is a stage, this returns the fully qualified name."""
        return self._checkpoint_location


class PyTorchDistributor(BaseRunnable):
    """
    PyTorchDistributor enables users to run distributed training with PyTorch on ContainerRuntime cluster.

    PyTorchDistributor is responsible for setting up the environment, scheduling the training processes,
    managing the communication between the processes, and collecting the results.
    """

    def __init__(
        self,
        train_func: Callable,
        scaling_config: Optional[PyTorchScalingConfig] = None,
    ) -> None:
        """Initialize the PyTorchDistributor.

        Args:
            train_func (Callable): A callable object that defines the training logic
                to be executed.
            scaling_config (PyTorchScalingConfig): Configuration for scaling and other
                settings related to the training job.
            use_ray_job (bool): Whether to use Ray job submission (True) or direct Ray actor execution (False).
                Defaults to True for compatibility.
        """
        super().__init__(func=train_func, scaling_config=scaling_config)

    def run(
        self,
        *,
        dataset_map: Optional[Dict[str, DataConnector]] = None,
        hyper_params: Optional[Dict[str, str]] = None,
        artifact_stage_location: Optional[str] = None,
        use_ray_job: bool = True,
    ) -> PyTorchDistributorResult:
        """Runs the distributed training job.

        Args:
            dataset_map (Optional[Dict[str, DataConnector]], optional):
                A mapping of dataset names to their corresponding DataConnector instances. Defaults to None.
            hyper_params (Optional[Dict[str, str]], optional):
                A dictionary of hyperparameters to be used during training. Defaults to None.
            artifact_stage_location: The stage to use for checkpoints. Multi-node training requires a stage to store
                checkpoint and model information. Your Snowflake user stage will be used by default, under SF_PYTORCH.

        Returns:
            PyTorchDistributorResult: The result of the training process, which may include the trained model or
                other outputs.

        Raises:
            RuntimeError: If there is an error during the execution of the training process.
        """
        trainer_module = importlib.import_module("web.ml_runtime_trainer")
        trainer_klass = getattr(trainer_module, "MLRuntimeTrainer")

        trainer = trainer_klass()
        return trainer.trainV2(
            train_func=self.func,
            scaling_config=self.scaling_config,
            dataset_map=dataset_map,
            hyper_params=hyper_params,
            artifact_stage_location=artifact_stage_location,
            use_ray_job=use_ray_job,
        )
