"""Partition sources for DPF - abstracts partition discovery and task creation.

Architecture Overview
---------------------
DPF uses a producer-consumer pattern where PartitionSource produces tasks
and ActorPool consumes them:

    PartitionSource.discover_partitions() → List of partition IDs (for progress tracking)
    PartitionSource.start(on_task_ready)  → Calls on_task_ready(task) for each partition
                                            Orchestrator submits task to ActorPool

The two-phase approach (discover → start) allows the orchestrator to:
1. Know total partition count upfront for progress reporting
2. Initialize partition_details tracking before any work begins

Implementations
---------------
- SQLPartitionSource: Async data loading via background thread. Calls on_task_ready
  as each partition's data is prefetched.
- StagePartitionSource: Sync task creation. Immediately calls on_task_ready for each file.
  Actors load data on-demand (no prefetching needed).

Adding New Sources
------------------
1. Subclass PartitionSource
2. Implement discover_partitions() to return partition IDs
3. Implement start() to call on_task_ready(PartitionTask) for each partition
4. PartitionTask.partition_input (SQLPartitionInput or StagePartitionInput) is passed to TrainActor.run()
"""

import fnmatch
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
    PartitionInput,
    SQLPartitionInput,
    StagePartitionInput,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    get_partition_query,
)
from snowflake.runtime.utils.session_utils import get_session
from snowflake.runtime.utils.logger import get_logger, print_user_log_info
from snowflake.ml.modeling.distributors.distributed_partition_function.resultset_data_loader import (
    ResultSetDataLoader,
)

logger = get_logger()


@dataclass
class PartitionTask:
    """Encapsulates everything needed to run a partition task."""

    partition_id: str
    partition_input: PartitionInput  # Typed input passed to actor.run()


class PartitionSource(ABC):
    """Abstract base for partition sources."""

    @abstractmethod
    def discover_partitions(self) -> List[str]:
        """Return list of partition IDs."""
        pass

    @abstractmethod
    def start(self, on_task_ready: Callable[[PartitionTask], None]) -> None:
        """Start producing tasks. Call on_task_ready when each task is ready."""
        pass

    @abstractmethod
    def stop(self) -> None:
        """Cleanup any background processes."""
        pass


class SQLPartitionSource(PartitionSource):
    """SQL-based partitioning from Snowpark DataFrame."""

    def __init__(
        self,
        partition_by: str,
        query: str,
        execution_options: ExecutionOptions,
    ):
        self._partition_by = partition_by
        self._query = query
        self._execution_options = execution_options
        self._partition_id_and_query: Dict[str, str] = {}
        self._data_loader = None
        self._on_task_ready: Optional[Callable[[PartitionTask], None]] = None

    def discover_partitions(self) -> List[str]:
        session = get_session()
        snowpark_df = session.sql(self._query)
        self._partition_id_and_query = get_partition_query(
            partition_by=self._partition_by,
            snowpark_dataframe=snowpark_df,
        )
        print_user_log_info(
            logger,
            f"Discovered {len(self._partition_id_and_query)} partitions from SQL",
        )
        return list(self._partition_id_and_query.keys())

    def _on_partition_ready(self, partition_id, result_batches, dataframe_info):
        if self._on_task_ready:
            task = PartitionTask(
                partition_id=partition_id,
                partition_input=SQLPartitionInput(
                    partition_id=partition_id,
                    result_batches=result_batches,
                    dataframe_info=dataframe_info,
                ),
            )
            self._on_task_ready(task)

    def start(self, on_task_ready: Callable[[PartitionTask], None]) -> None:
        self._on_task_ready = on_task_ready
        data_loader = ResultSetDataLoader(
            partition_id_and_query=self._partition_id_and_query,
            execution_options=self._execution_options,
            on_partition_ready=self._on_partition_ready,
        )
        self._data_loader = data_loader
        data_loader.start()

    def stop(self) -> None:
        if self._data_loader:
            self._data_loader.stop()


class StagePartitionSource(PartitionSource):
    """File-based partitioning from Snowflake stage.

    Each file becomes one partition. Actors pull partitions from a queue,
    ensuring predictable memory usage (one file loaded at a time per actor).
    """

    def __init__(
        self,
        stage_location: str,
        file_pattern: str,
        execution_options: ExecutionOptions,
    ):
        self._stage_location = stage_location
        self._file_pattern = file_pattern
        self._execution_options = execution_options
        self._partition_files: Dict[str, List[str]] = {}

    def discover_partitions(self) -> List[str]:
        session = get_session()

        # Ensure trailing slash to avoid prefix matching issues with LIST
        # e.g., LIST '@stage/my_dir' would also match '@stage/my_directory/'
        stage_path = self._stage_location.rstrip("/") + "/"
        print_user_log_info(logger, f"Listing files from {stage_path}...")
        result = session.sql(f"LIST '{stage_path}'").collect()

        if not result:
            raise ValueError(
                f"No files found at stage location '{self._stage_location}'. "
                "Please verify the stage path exists and contains files."
            )

        # Filter by pattern using fnmatch for proper glob support
        # Supports patterns like "*.parquet", "data_*.csv", "*.csv.gz", etc.
        files = [
            row["name"]
            for row in result
            if fnmatch.fnmatch(row["name"].split("/")[-1], self._file_pattern)
        ]

        if not files:
            raise ValueError(
                f"No files found matching pattern '{self._file_pattern}' at '{self._stage_location}'. "
                f"Found {len(result)} files but none matched the pattern."
            )

        # LIST returns paths like "stage_name/subpath/file.parquet"
        # We need paths relative to stage root: "subpath/file.parquet"
        # Strip the first path component (stage name) for each file individually.
        # 1 file per partition: use relative path as partition_id to avoid collisions
        # (e.g., "dir1/data.parquet" and "dir2/data.parquet" are distinct partitions)
        for file_path in files:
            # Compute path relative to stage root by removing the first component
            parts = file_path.split("/", 1)
            relative_path = parts[1] if len(parts) > 1 else file_path
            self._partition_files[relative_path] = [relative_path]

        print_user_log_info(
            logger,
            f"Found {len(files)} files, creating {len(self._partition_files)} partitions",
        )

        return list(self._partition_files.keys())

    def start(self, on_task_ready: Callable[[PartitionTask], None]) -> None:
        for partition_id, file_paths in self._partition_files.items():
            task = PartitionTask(
                partition_id=partition_id,
                partition_input=StagePartitionInput(
                    partition_id=partition_id,
                    file_paths=file_paths,
                    stage_location=self._stage_location,
                ),
            )
            on_task_ready(task)

    def stop(self) -> None:
        pass
