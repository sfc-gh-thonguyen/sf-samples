from unittest.mock import patch

import pytest

from snowflake.ml.modeling.distributors.pytorch.scaling_config import (
    DefaultScalingConfig,
)


@patch("snowflake.ml.modeling.distributors.pytorch.scaling_config.get_num_ray_nodes")
@patch(
    "snowflake.ml.modeling.distributors.pytorch.scaling_config.get_total_node_resources"
)
def test_default_scaling_config_with_gpu(
    mock_get_total_node_resources,
    mock_get_num_ray_nodes,
):
    # Setup mocks
    mock_get_num_ray_nodes.return_value = 2
    mock_get_total_node_resources.return_value = {"GPU": 4}

    default_scaling_config = DefaultScalingConfig()

    assert default_scaling_config.num_node == 2
    assert default_scaling_config.num_workers_per_node == 4


@patch("snowflake.ml.modeling.distributors.pytorch.scaling_config.get_num_ray_nodes")
@patch(
    "snowflake.ml.modeling.distributors.pytorch.scaling_config.get_total_node_resources"
)
def test_default_scaling_config_with_cpu(
    mock_get_total_node_resources,
    mock_get_num_ray_nodes,
):
    # Setup mocks
    mock_get_num_ray_nodes.return_value = 2
    mock_get_total_node_resources.return_value = {"CPU": 8}

    default_scaling_config = DefaultScalingConfig()

    assert default_scaling_config.num_node == 2
    assert default_scaling_config.num_workers_per_node == 1


if __name__ == "__main__":
    pytest.main()
