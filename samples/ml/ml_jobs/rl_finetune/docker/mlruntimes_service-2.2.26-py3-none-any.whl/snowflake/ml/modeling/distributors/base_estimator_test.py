from unittest import mock

import pandas as pd
import pytest
from snowflake.ml.data.data_connector import DataConnector

from snowflake.ml.modeling.distributors.base_estimator import BaseEstimator


class FakeBaseEstimator(BaseEstimator):
    ...


def test_validate_fit_input():
    pandas_df = pd.DataFrame({"a": [1, 2, 3, 4, 5], "b": [1, 2, 3, 4, 5]})

    y = pd.DataFrame({"label": [1, 0, 1, 0, 1]})

    dataset_connector = mock.Mock(spec=DataConnector)
    y_data_connector = mock.Mock(spec=DataConnector)

    print(isinstance(y_data_connector, DataConnector))

    estimator = FakeBaseEstimator()

    # Error should be raised if only passed in in-memory datatype without labels
    with pytest.raises(ValueError):
        estimator._validate_fit_input(pandas_df)

    # Error should be raised if both in memory data are passed but also with input_col and label_col
    with pytest.raises(ValueError):
        estimator._validate_fit_input(
            pandas_df, y, input_cols=["a", "b"], label_col="label"
        )

    # Error when dataset connector is provided, y shouldn't be provided
    with pytest.raises(ValueError):
        estimator._validate_fit_input(dataset_connector, y, input_cols=["a", "b"])

    # Error when dataset connector is provided, input_cols and label_col should be provided
    with pytest.raises(ValueError):
        estimator._validate_fit_input(dataset_connector)

    # Label columns must be a string.
    with pytest.raises(ValueError):
        estimator._validate_fit_input(
            dataset_connector, input_cols=["a", "b"], label_col=["c", "d"]
        )
