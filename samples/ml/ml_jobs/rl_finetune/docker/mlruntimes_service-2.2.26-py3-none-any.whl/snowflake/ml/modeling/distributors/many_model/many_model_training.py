from typing import Callable, Optional, Any
import functools
from snowflake.ml.data import DataConnector

from snowflake.ml.modeling.distributors.many_model.many_model_run import ManyModelRun
from snowflake.ml.modeling.distributors.distributed_partition_function.dpf import DPF
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.partition_context import (
    PartitionContext,
)
from snowflake.ml.modeling.distributors.many_model.utils import (
    ModelSerde,
    PickleSerde,
)
from snowflake import snowpark


class ManyModelTraining(DPF):
    """
    Specialized distributed model training across data partitions.

    ``ManyModelTraining`` extends DPF specifically for machine learning scenarios where you need to
    train separate models on different data partitions. It automatically handles model serialization,
    artifact management, and provides framework-specific serialization options.

    Key features:
        * Automatic model serialization and saving to Snowflake stages
        * Built-in serializers for popular frameworks (XGBoost, scikit-learn, PyTorch, TensorFlow)
          or implement ``ModelSerde`` for custom formats
        * Consistent artifact naming and organization
        * Progress monitoring
        * Seamless integration with model inference workflows

    The user-provided training function should return a trained model object. The class automatically
    handles saving the model using the specified serialization method.

    Typical workflow:
        1. **Train** models across data partitions using ``ManyModelTraining``
        2. **Monitor** training progress and wait for completion
        3. **Run inference** on new data using ``ManyModelInference`` with the training run ID
        4. **Access results** from both training artifacts and inference outputs
        5. **Optional**: Restore previous DPF run (useful for retrieving previous results)

    Example:
        Complete end-to-end many model workflow:

        **1. Define Training Function**

        >>> def train_xgboost_model(data_connector, context):
        ...     df = data_connector.to_pandas()
        ...     X = df[['feature1', 'feature2', 'feature3']]
        ...     y = df['target']
        ...
        ...     model = XGBRegressor()
        ...     model.fit(X, y)
        ...     return model  # Automatically saved as model.pkl

        **2. Train Models Across Partitions**

        >>> trainer = ManyModelTraining(train_xgboost_model, "model_stage")
        >>> training_run = trainer.run(
        ...     partition_by="region",
        ...     snowpark_dataframe=sales_data,
        ...     run_id="regional_models_v1"
        ... )
        >>> training_run.wait()

        **3. Run Inference with Trained Models**

        >>> def predict_sales(data_connector, model, context):
        ...     df = data_connector.to_pandas()
        ...     X = df[['feature1', 'feature2', 'feature3']]
        ...     predictions = model.predict(X)
        ...
        ...     results = df.copy()
        ...     results['predictions'] = predictions
        ...     results['region'] = context.partition_id
        ...
        ...     # Two persistence strategies (choose one or both based on your needs):
        ...
        ...     # Strategy 1: Stage artifacts - for framework management and debugging
        ...     context.upload_to_stage(results, "predictions.csv",
        ...         write_function=lambda df, path: df.to_csv(path, index=False))
        ...
        ...     # Strategy 2: Snowflake table - uses bounded session pool to avoid session limits
        ...     context.with_session(lambda session:
        ...         session.create_dataframe(results)
        ...             .write.mode("append")
        ...             .save_as_table("sales_predictions")
        ...     )
        ...
        ...     return predictions

        >>> from snowflake.ml.modeling.distributors.many_model import ManyModelInference
        >>> inference = ManyModelInference(predict_sales, "model_stage", "regional_models_v1")
        >>> inference_run = inference.run(
        ...     partition_by="region",
        ...     snowpark_dataframe=new_sales_data,
        ...     run_id="predictions_2024"
        ... )
        >>> inference_run.wait()

        **4. Access Results (Two Different Approaches)**

        >>> # Approach 1: Access stage artifacts (for detailed analysis and debugging)
        >>> for partition_id in training_run.partition_details:
        ...     trained_model = training_run.get_model(partition_id)
        ...     predictions_csv = inference_run.partition_details[partition_id].stage_artifacts_manager.get(
        ...         "predictions.csv")

        >>> # Approach 2: Query Snowflake table (for analytics and aggregations)
        >>> from snowflake.runtime.utils.session_utils import get_session
        >>> session = get_session()
        >>> all_predictions = session.table("sales_predictions")
        >>> summary_stats = all_predictions.group_by("region").agg(
        ...     {"predictions": "avg", "predictions": "count"}).collect()

    See Also:
        :class:`ManyModelInference`: For running inference with trained models
        :class:`DPF`: Base class for general distributed processing
    """

    def __init__(
        self,
        train_func: Callable[[DataConnector, PartitionContext], Any],
        stage_name: str,
        serde: Optional[ModelSerde] = None,
    ) -> None:
        """
        Initialize ManyModelTraining.

        Args:
            train_func (Callable[[DataConnector, PartitionContext], Any]): User function that takes
                       (DataConnector, PartitionContext) and returns a trained model.
                       Both parameters are automatically provided by the framework.
                       Follows the same signature pattern as regular DPF functions for consistency.
            stage_name (str): Stage name for storing artifacts
            serde (Optional[ModelSerde]): ModelSerde instance for handling model serialization and deserialization.
                   Built-in options: PickleSerde (XGBoost, scikit-learn), TorchSerde, TensorFlowSerde,
                   or implement ModelSerde for custom formats. Defaults to PickleSerde.

        Examples:
            Default pickle serialization:

            >>> def train_xgb_model(data_connector, context):
            ...     df = data_connector.to_pandas()
            ...     X = df[['feature1', 'feature2']]
            ...     y = df['target']
            ...
            ...     from xgboost import XGBRegressor
            ...     model = XGBRegressor()
            ...     model.fit(X, y)
            ...     return model  # Automatically saved as model.pkl
            ...
            >>> trainer = ManyModelTraining(train_xgb_model, "models_stage")

            PyTorch model training:

            >>> def train_pytorch_model(data_connector, context):
            ...     import torch
            ...     import torch.nn as nn
            ...
            ...     df = data_connector.to_pandas()
            ...     # ... prepare data for PyTorch ...
            ...
            ...     model = nn.Sequential(nn.Linear(10, 1))
            ...     # ... training logic ...
            ...     return model  # Automatically saved as model.pth
            ...
            >>> from snowflake.ml.modeling.distributors.many_model import TorchSerde
            >>> trainer = ManyModelTraining(train_pytorch_model, "models_stage", serde=TorchSerde())

            TensorFlow model training:

            >>> def train_tf_model(data_connector, context):
            ...     import tensorflow as tf
            ...
            ...     df = data_connector.to_pandas()
            ...     # ... prepare data for TensorFlow ...
            ...
            ...     model = tf.keras.Sequential([tf.keras.layers.Dense(1)])
            ...     # ... training logic ...
            ...     return model  # Automatically saved as model.h5
            ...
            >>> from snowflake.ml.modeling.distributors.many_model import TensorFlowSerde
            >>> trainer = ManyModelTraining(train_tf_model, "models_stage", serde=TensorFlowSerde())

            Custom serialization for specialized model formats:

            >>> from snowflake.ml.modeling.distributors.many_model import ModelSerde
            >>> import json
            >>>
            >>> class ScikitLearnSerde(ModelSerde):
            ...     '''Custom serializer for scikit-learn models with metadata'''
            ...
            ...     @property
            ...     def filename(self) -> str:
            ...         return "sklearn_model.joblib"
            ...
            ...     def write(self, model, file_path: str) -> None:
            ...         import joblib
            ...         # Save model with metadata
            ...         model_data = {
            ...             'model': model,
            ...             'feature_names': getattr(model, 'feature_names_in_', None),
            ...             'model_type': type(model).__name__
            ...         }
            ...         joblib.dump(model_data, file_path)
            ...
            ...     def read(self, file_path: str):
            ...         import joblib
            ...         return joblib.load(file_path)
            >>>
            >>> def train_sklearn_model(data_connector, context):
            ...     from sklearn.ensemble import RandomForestRegressor
            ...     df = data_connector.to_pandas()
            ...     X, y = df[['feature1', 'feature2']], df['target']
            ...
            ...     model = RandomForestRegressor()
            ...     model.fit(X, y)
            ...     return model  # Automatically saved with metadata
            ...
            >>> trainer = ManyModelTraining(train_sklearn_model, "models_stage", serde=ScikitLearnSerde())
        """
        self._train_func = train_func
        self._serde = serde if serde is not None else PickleSerde()

        # Create wrapped function that handles model saving
        wrapped_func = self._create_wrapped_training_function()

        # Initialize parent DPF with the wrapped function
        super().__init__(func=wrapped_func, stage_name=stage_name)

    def _create_wrapped_training_function(
        self,
    ) -> Callable[[DataConnector, PartitionContext], None]:
        """Create a wrapped function that handles automatic model saving."""

        @functools.wraps(self._train_func)
        def wrapped_training_func(
            data_connector: DataConnector, context: PartitionContext
        ) -> None:
            # Call the user's training function
            result = self._train_func(data_connector, context)

            # Use the serde to save the model
            context.upload_to_stage(
                result, self._serde.filename, write_function=self._serde.write
            )

        return wrapped_training_func

    def run(
        self,
        *,
        partition_by: str,
        snowpark_dataframe: snowpark.DataFrame,
        run_id: str,
        on_existing_artifacts: str = "error",
        execution_options: Optional[ExecutionOptions] = None,
    ) -> ManyModelRun:
        """
        Execute distributed model training across data partitions.

        Trains separate models on each partition of the data and automatically saves them
        to the specified Snowflake stage using the configured serialization method.

        Args:
            partition_by (str): Column name to partition the DataFrame by. Each unique value
                creates a separate partition with its own trained model.
            snowpark_dataframe (snowpark.DataFrame): DataFrame containing training data.
            run_id (str): Unique identifier for this training run. Used to organize model
                artifacts and enable future inference runs.
            on_existing_artifacts (str, optional): Action for existing artifacts. Defaults to "error".

                * ``"error"``: Raises error if training artifacts already exist
                * ``"overwrite"``: Replaces existing training artifacts

            execution_options (ExecutionOptions, optional): Configuration for distributed execution.

        Returns:
            ManyModelRun: Enhanced run handle with model-specific capabilities for accessing
            trained models and monitoring training progress.

        Example:
            >>> trainer = ManyModelTraining(my_train_func, "models_stage")
            >>> run = trainer.run(
            ...     partition_by="store_id",
            ...     snowpark_dataframe=sales_data,
            ...     run_id="store_models_2024"
            ... )
            >>> run.wait()
            >>> # Models are now saved and can be used for inference
        """
        print(f"Starting many model training with run_id: {run_id}")
        print(f"Model will be saved as: {self._serde.filename}")
        print(f"Serde: {self._serde.__class__.__name__}")

        dpf_run = super().run(
            partition_by=partition_by,
            snowpark_dataframe=snowpark_dataframe,
            run_id=run_id,
            on_existing_artifacts=on_existing_artifacts,
            execution_options=execution_options,
        )

        return ManyModelRun(dpf_run, serde=self._serde)
