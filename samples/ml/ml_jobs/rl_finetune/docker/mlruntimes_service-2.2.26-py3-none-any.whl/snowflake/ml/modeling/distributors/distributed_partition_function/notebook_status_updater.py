import threading
import json
import os
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_warn,
)

from snowflake.runtime.utils.session_utils import get_session

logger = get_logger()


class NotebookStatusUpdater:
    """
    This class is responsible for firing a UPDATE_ST_SERVICE_STATUS sql query to prevent notebook from getting
    disconnected due to idle timeout when background thread is still running.

    We play defensive here by wrapping things into two try/catch blocks, and will log out warning message but
    not failing the overall workflow when exception occurred.

    reference source:
    https://github.com/snowflakedb/snowbooks/blob/main/snowbook/status_updater/status_thread.py#L79-L82
    """

    def __init__(self):
        self._stop_event = threading.Event()
        self._thread = None

    def start(self):
        try:
            from snowbook.notebook_sql_utils import get_fully_qualified_object_name
            from snowbook.web.env_vars import OBJECT_NAME
        except ImportError:
            return  # Not in a notebook environment

        try:
            session = get_session()
            object_name = os.environ.get(OBJECT_NAME)
            formatted_object_name = get_fully_qualified_object_name(
                object_name, no_double_quotes=True
            )
            status_as_json = json.dumps({"is_running": True})
            ping_interval_sec = 60 * 5  # 5 minutes

            def _update_status():
                while not self._stop_event.is_set():
                    try:
                        session.sql(
                            "CALL SYSTEM$UPDATE_ST_SERVICE_STATUS(?, ?, ?)",
                            ("NOTEBOOK", formatted_object_name, status_as_json),
                        ).collect()
                    except Exception as e:
                        print_user_log_warn(
                            logger,
                            f"Error updating notebook status. Please ensure the notebook cell is running to "
                            f"prevent notebook from being shutdown unintentionally due to idle timeout: {e}",
                        )
                        break
                    self._stop_event.wait(ping_interval_sec)

            self._thread = threading.Thread(target=_update_status, daemon=True)
            self._thread.start()
        except Exception as e:
            print_user_log_warn(
                logger,
                f"Error updating notebook status. Please ensure the notebook cell is running to "
                f"prevent notebook from being shutdown unintentionally due to idle timeout: {e}",
            )

    def stop(self):
        if self._thread:
            self._stop_event.set()
            self._thread.join()
