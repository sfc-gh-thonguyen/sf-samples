import os
import ray


def in_container_runtime():
    return os.getenv("IN_SPCS_ML_RUNTIME", None) is not None


def in_ray_task_or_actor() -> bool:
    """
    This function returns True when current environment is either within a Ray actor or task context.
    """
    try:
        ctx = ray.get_runtime_context()
        actor_id = ctx.get_actor_id()
        task_id = ctx.get_task_id()
        return bool(actor_id or task_id)
    except Exception:
        return False
