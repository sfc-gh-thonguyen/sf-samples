import os
import tempfile
from functools import cached_property
from typing import Any, List, Optional, Callable, Tuple, Union
from snowflake.runtime.utils.session_utils import get_session
from enum import Enum
from snowflake import snowpark
from dataclasses import dataclass
from snowflake.connector import result_batch
from snowflake.ml.data.data_source import DataFrameInfo

from snowflake.ml.modeling.distributors.distributed_partition_function.stage_artifacts_manager import (
    StageArtifactsManager,
)

PartitionFunction = Callable[[], Tuple[str, snowpark.DataFrame]]


@dataclass
class SQLPartitionInput:
    """Input for SQL-based partitions (result batches from Snowflake queries)."""

    partition_id: str
    result_batches: List[result_batch.ResultBatch]
    dataframe_info: DataFrameInfo


@dataclass
class StagePartitionInput:
    """Input for stage-based partitions (files from Snowflake stages)."""

    partition_id: str
    file_paths: List[str]
    stage_location: str


PartitionInput = Union[SQLPartitionInput, StagePartitionInput]


class PartitionStatus(str, Enum):
    """
    Enum representing the possible status of a partition execution.

    Attributes:
        PENDING (str): The partition is waiting to be processed.
        RUNNING (str): The partition is currently being processed.
        FAILED (str): The partition has failed.
        DONE (str): The partition has successfully completed.
        CANCELLED(str): The partition has been cancelled, this happens when user explicitly invokes the cancel call.
        INTERNAL_ERROR (str): The partition encountered an internal error during processing.
    """

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    DONE = "DONE"
    CANCELLED = "CANCELLED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class SinglePartitionDetails:
    """
    A class that encapsulates the details of a single model training job, including its status, model,
    and associated logs. It manages the loading of the model and training logs from a specified stage path,
    and provides safeguards in case of errors during these operations.

    Attributes:
       partition_id (str): The unique identifier for the partition of the job.
       stage_path (str): The path where the model and logs are stored in the system.
               status (PartitionStatus): The current status of the partition (default is PENDING).

    Raises:
       RuntimeError: If loading the model or logs from the stage path fails due to system errors.
    """

    def __init__(
        self,
        *,
        partition_id: str,
        status: PartitionStatus = PartitionStatus.PENDING,
        stage_path: Optional[str] = None,
    ):
        self._partition_id = partition_id
        self._status = status
        self._stage_path = stage_path
        self._session = get_session()
        self._logs: Optional[str] = None

    @property
    def partition_id(self) -> str:
        return self._partition_id

    @property
    def status(self) -> PartitionStatus:
        return self._status

    @cached_property
    def stage_artifacts_manager(self) -> StageArtifactsManager:
        """
        Returns an StageArtifactsManager instance for interacting with this partition's saved artifacts.
        """
        if self._stage_path is None:
            raise RuntimeError(
                f"Cannot access artifacts for partition {self.partition_id} due to empty stage path"
            )
        return StageArtifactsManager(
            session=self._session, stage_path_prefix=self._stage_path
        )

    @cached_property
    def logs(self) -> str:
        if self._logs is not None:
            return self._logs

        stage_log_path = (
            os.path.join(self._stage_path, "train.log") if self._stage_path else None
        )

        try:
            tmp_dir = tempfile.gettempdir()
            local_model_path = os.path.join(tmp_dir, "train.log")
            self._session.file.get(stage_log_path, tmp_dir)
            with open(local_model_path, "r") as f:
                return f.read()
        except Exception as e:
            # Fallback in case logs are not set due to unforeseen systematic errors. This is more of a safeguard.
            msg = f"Failed to load logs {f' from {stage_log_path}' if stage_log_path else ''}"
            if self.status != PartitionStatus.DONE:
                msg += " . Logs may not be available due to job failure"
            raise RuntimeError(f"{msg}: {e}") from e

    def set_logs(self, value: str) -> None:
        self._logs = value

    def set_model(self, model: Any) -> None:
        self._model = model

    def set_status(self, status: PartitionStatus) -> None:
        self._status = status

    def __getstate__(self):
        """
        Customize object serialization to non-serializable objects and model/logs, as they can be dynamically
        loaded.
        """
        state = self.__dict__.copy()
        state.pop("_session", None)
        state.pop("model", None)
        state.pop("logs", None)
        return state

    def __setstate__(self, state):
        """
        Customize object deserialization.
        """
        self.__dict__.update(state)
        self._session = get_session()

    def __eq__(self, other):
        """
        Compare SinglePartitionDetails objects based on their content.
        """
        if not isinstance(other, SinglePartitionDetails):
            return False

        return (
            self._partition_id == other._partition_id
            and self._status == other._status
            and self._stage_path == other._stage_path
            and self._logs == other._logs
        )

    def __hash__(self):
        """
        Make the object hashable for use in sets and as dict keys.
        """
        return hash((self._partition_id, self._status, self._stage_path, self._logs))


class DPFUncaughtException(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.__dict__.update(kwargs)


class RunStatus(Enum):
    """
    Enum representing the status of an overall distributed run.

    Attributes:
        SUCCESS (str): The run completed successfully.
        IN_PROGRESS (str): The run is actively executing.
        PARTIAL_FAILURE (str): The run completed, but some partitions failed.
        FAILURE (str): The run failed completely.
        CANCELLED (str): The run was cancelled.

    """

    SUCCESS = "success"
    IN_PROGRESS = "in_progress"
    PARTIAL_FAILURE = "partial_failure"
    FAILURE = "failure"
    CANCELLED = "cancelled"


@dataclass
class ExecutionOptions:
    """
    Configuration options for workload execution.

    Attributes:
        use_head_node (bool):
            This option controls whether the head node participates in the workload execution
            or solely acts as a coordinator.
            If True, the Ray head node will execute user-provided functions alongside worker nodes.
            If False, only worker nodes will execute user-provided functions.
        loading_wh:
            A dedicated warehouse used for loading data from Snowflake tables into the snowflake stage. This is
            typically a larger warehouse to accelerate the data loading process. Once data loading is complete, session
            will switch back to use the original warehouse.
        num_cpus_per_worker (Optional[int]):
            Number of CPUs to allocate per worker actor. If None (default),
            the behavior depends on GPU availability:
            - With GPUs: CPUs are divided evenly among workers based on GPU count
            - Without GPUs: Each worker uses all available CPUs (1 worker per node)

            Examples:
                - Node with 16 CPUs, 4 GPUs, num_cpus_per_worker=None:
                  → 4 workers created (1 GPU each), each gets 4 CPUs (16/4)
                - Node with 16 CPUs, 0 GPUs, num_cpus_per_worker=None:
                  → 1 worker created, gets all 16 CPUs
                - Node with 16 CPUs, 4 GPUs, num_cpus_per_worker=4:
                  → 4 workers created (limited by GPUs), each gets 4 CPUs
                - Node with 16 CPUs, 0 GPUs, num_cpus_per_worker=4:
                  → 4 workers created (16/4), each gets 4 CPUs

        num_gpus_per_worker (Optional[int]):
            Number of GPUs to allocate per worker actor. If None (default),
            allocates 1 GPU per worker when GPUs are available, 0 otherwise.
            The actual number of workers per node is constrained by both CPU and GPU availability.

            Examples:
                - Node with 16 CPUs, 4 GPUs, num_gpus_per_worker=None:
                  → 4 workers created (1 GPU each), each gets 4 CPUs (16/4)
                - Node with 16 CPUs, 4 GPUs, num_gpus_per_worker=2:
                  → 2 workers created (4/2), each gets 2 GPUs and 8 CPUs (16/2)
                - Node with 8 CPUs, 4 GPUs, num_gpus_per_worker=1, num_cpus_per_worker=4:
                  → 2 workers created (min of 8/4=2 CPUs, 4/1=4 GPUs), each gets 1 GPU and 4 CPUs

        max_retries (int):
            Maximum number of retry attempts for a failed partition task.
            Defaults to 1.

        fail_fast (bool):
            If True, terminate on first partition failure and cancel remaining partitions.
            If False (default), continue processing all partitions despite failures.
    """

    use_head_node: bool = True
    loading_wh: Optional[str] = None
    num_cpus_per_worker: Optional[int] = None
    num_gpus_per_worker: Optional[int] = None
    max_retries: int = 1
    fail_fast: bool = False
