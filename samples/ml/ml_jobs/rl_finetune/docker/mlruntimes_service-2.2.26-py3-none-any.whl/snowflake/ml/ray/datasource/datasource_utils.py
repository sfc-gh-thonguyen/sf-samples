import os
from typing import List, Optional, Union

from snowflake.runtime.utils.stage_fs import SFStageFileSystem
from snowflake.runtime.utils.session_utils import get_session
from shared_storage.sf_user_stage_fs import SFUserStageFileSystem
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
from ray.data.datasource.datasource import ReadTask


def extract_extension(
    file_pattern: Optional[Union[str, List[str]]]
) -> Optional[List[str]]:
    """
    Extract file extension from a file pattern for Ray's file_extensions parameter.

    Args:
        file_pattern: File pattern with wildcards (e.g., "*.csv", "*.txt")

    Returns:
        List of extensions without dots (e.g., ["csv"]) or None if no pattern

    Examples:
        >>> extract_extension("*.csv")
        ["csv"]
        >>> extract_extension("json")
        ["json"]
        >>> extract_extension(None)
        None
    """

    result = []

    if not file_pattern:
        return None

    # Support wildcard matchings, as Ray format is different
    if isinstance(file_pattern, list):
        for pattern in file_pattern:
            ext = pattern.lstrip("*").lstrip(".")
            result.append(ext)
    else:
        ext = file_pattern.lstrip("*").lstrip(".")
        result.append(ext)
    return result


def create_stage_filesystem(
    stage_location: str,
    database: Optional[str] = None,
    schema: Optional[str] = None,
    stage_name: Optional[str] = None,
) -> SFStageFileSystem:
    """
    Create a PyArrow filesystem for a Snowflake stage.

    Args:
        stage_location: Stage location like "@mystage/path/to/files"
        database: Database name (defaults to session current)
        schema: Schema name (defaults to session current)
        stage_name: Pre-parsed stage name (if provided, skips parsing stage_location)

    Returns:
        PyFileSystem wrapping SFStageFileSystem
    """
    if stage_name is None:
        stage_name = stage_location.lstrip("@").split("/")[0]
    database = database or get_session().get_current_database()
    schema = schema or get_session().get_current_schema()

    if stage_location.startswith("@~"):
        fs = SFUserStageFileSystem(
            db=database,
            schema=schema,
            stage=stage_name,
        )
    else:
        fs = SFStageFileSystem(
            db=database,
            schema=schema,
            stage=stage_name,
        )

    return fs


def update_metrics(tasks: List[ReadTask], datasource_type: str):
    total_tasks = len(tasks)
    total_files = 0
    total_estimated_rows = 0

    for task in tasks:
        if task.metadata.input_files is not None:
            total_files += len(task.metadata.input_files)
        if task.metadata.num_rows:
            total_estimated_rows += task.metadata.num_rows

    MLRSPrometheusMetrics.DATASOURCE_READ_TASKS.value.labels(
        datasource_type=datasource_type
    ).inc(total_tasks)
    MLRSPrometheusMetrics.DATASOURCE_READ_FILES.value.labels(
        datasource_type=datasource_type
    ).inc(total_files)
    MLRSPrometheusMetrics.DATASOURCE_ROWS_READ.value.labels(
        datasource_type=datasource_type
    ).inc(total_estimated_rows)


def write_to_local_path(fs, read_tasks, local_path, datasource_type):
    files = []
    for task in read_tasks:
        if task.metadata.input_files is not None:
            files.extend(task.metadata.input_files)
    os.makedirs(local_path, exist_ok=True)

    for file_name in files:
        local_file_path = os.path.join(local_path, file_name)
        os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
        fs.get_file(file_name, local_file_path)
        MLRSPrometheusMetrics.DATASOURCE_WRITE_TO_LOCAL.value.labels(
            datasource_type=datasource_type
        ).inc()
