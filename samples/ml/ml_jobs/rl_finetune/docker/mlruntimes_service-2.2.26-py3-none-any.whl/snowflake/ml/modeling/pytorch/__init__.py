from snowflake.ml.modeling.distributors.pytorch import (
    PyTorchDistributor as PyTorchTrainer,
    WorkerResourceConfig,
    PyTorchScalingConfig as ScalingConfig,
    Context,
    get_context as getContext,
)

# For backwards compatibility. We need to delete this after removing all the references old names.
__all__ = [
    "PyTorchTrainer",
    "WorkerResourceConfig",
    "ScalingConfig",
    "Context",
    "getContext",
]
