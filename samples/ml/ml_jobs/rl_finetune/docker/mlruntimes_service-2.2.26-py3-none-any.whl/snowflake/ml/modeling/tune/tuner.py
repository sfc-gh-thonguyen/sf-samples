from typing import Callable, Optional, Dict
from snowflake.ml.data.data_connector import DataConnector
from entities.search_space import SearchSpace, SearchSpaceValue
from entities.tuner_config import TunerConfig
from entities.tuner_results import TunerResults
from entities.search_algorithm import GridSearch
from snowflake.ml.runtime_cluster.cluster_manager import get_num_cpus_per_node
from web.ml_runtime_trainer import MLRuntimeTrainer
from common_utils.shared_storage_fs_util import get_py_filesystem_for_stage
import cloudpickle as cp


class Tuner:
    """
    Hyperparameter tuning interface for machine learning models.

    Example:
        Basic usage pattern:

        >>> def train_func():
        ...     context = get_tuner_context()
        ...     params = context.get_hyper_params()
        ...     # Train your model with params
        ...     # Evaluate and report metrics
        ...     context.report(metrics={"accuracy": accuracy}, model=model)
        >>>
        >>> from snowflake.ml.modeling.tune import uniform, randint, TunerConfig
        >>>
        >>> search_space = {
        ...     "learning_rate": uniform(0.01, 0.1),
        ...     "n_estimators": randint(50, 200)
        ... }
        >>> config = TunerConfig(metric="accuracy", mode="max", num_trials=10)
        >>> tuner = Tuner(train_func, search_space, config)
        >>> results = tuner.run(dataset_map=dataset_map)
    """

    def __init__(
        self,
        train_func: Callable[[], None],
        search_space: Dict[str, SearchSpaceValue],
        tuner_config: TunerConfig,
    ) -> None:
        """
        Initialize the Tuner.

        Args:
            train_func: The training function to optimize. Should use :func:`~entities.tuner_context.get_tuner_context`
                to access hyperparameters and datasets, then call :meth:`~entities.tuner_context.TunerContext.report` to
                report metrics. Must take no parameters and return None.
            search_space: Dictionary mapping parameter names to their search definitions.

                :data:`~entities.search_space.SearchSpaceValue` = Union
                    [:class:`~entities.sampling_function.SamplingFunction`, float, int, str, bool,
                    List[Union[float, int, str, bool]]]

                Each value can be one of:

                - **Sampling functions**: See :class:`~entities.sampling_function.SamplingFunction`
                  for available functions.
                - **Lists for grid search**: [0.01, 0.1, 0.2] or ['relu', 'tanh', 'sigmoid']
                - **Single values**: 0.1, 42, 'adam', True (fixed parameters)

                Example::

                    from snowflake.ml.modeling.tune import uniform, choice

                    search_space = {
                        "learning_rate": uniform(0.01, 0.3),
                        "optimizer": choice(['adam', 'sgd']),
                        "epochs": [10, 20, 50]
                    }

            tuner_config (:class:`~entities.tuner_config.TunerConfig`): Configuration specifying
                the optimization settings including metric, search algorithm, and number of trials.
        """
        self._validate(search_space=search_space, tuner_config=tuner_config)
        self.train_func = train_func
        self.search_space = search_space
        self.tuner_config = tuner_config
        self.trainer = MLRuntimeTrainer()

    def run(
        self, dataset_map: Optional[Dict[str, DataConnector]] = None
    ) -> TunerResults:
        """
        Execute the hyperparameter tuning process.

        Runs the optimization process using the configured search algorithm to find
        the best hyperparameter configuration based on the specified metric.

        Args:
            dataset_map
                (Optional[Dict[str, :class:`~snowflake.ml.data.data_connector.DataConnector`]]):
                Optional mapping of dataset names to DataConnector objects. These datasets will be
                made available to the training function through the
                :class:`~entities.tuner_context.TunerContext`.

        Returns:
            TunerResults: Results container with trial data, best configuration, and trained model.
                See :class:`~entities.tuner_results.TunerResults` for detailed field descriptions.
        """
        tune_results = self.trainer.tune(
            train_func=self.train_func,
            search_space=SearchSpace(self.search_space),
            tuner_config=self.tuner_config,
            dataset_map=dataset_map,
        )
        best_model_path = tune_results.best_model_path
        shared_storage_stage_path = tune_results.shared_storage_stage_path

        if shared_storage_stage_path:
            custom_fs = get_py_filesystem_for_stage(shared_storage_stage_path)
            with custom_fs.open_input_file(best_model_path) as read_stage_file:
                model = cp.load(read_stage_file)
        else:
            with open(best_model_path, "r+b") as f:
                # TODO[SNOW-1633909]: Support Torch(non-classical) models with HPO
                model = cp.load(f)

        return TunerResults(
            results=tune_results.results,
            best_result=tune_results.best_result,
            best_model=model,
        )

    def _validate(
        self, search_space: Dict[str, SearchSpaceValue], tuner_config: TunerConfig
    ) -> None:
        """
        Validates that only uniform sampling functions are used with BayesOpt.
        Raises an exception if non-uniform sampling functions are detected.
        """

        # HyperParameter tuning must be run on a machine that has at least 2 CPUs.
        if get_num_cpus_per_node() < 2:
            raise RuntimeError(
                "HyperParameter tuning must be run on a machine that has at least "
                "2 CPUs. Please use a machine with at least 2 CPUs."
            )

        if isinstance(tuner_config.search_alg, GridSearch):
            # Ensure that each search space is of a list type for grid search case.
            if not all(
                isinstance(value, list) and len(value) > 0
                for value in search_space.values()
            ):
                raise ValueError(
                    "Invalid search space configuration: Please use Python list to specify search space "
                    "when using :class:`~entities.search_algorithm.GridSearch`. Empty lists are not allowed."
                )
