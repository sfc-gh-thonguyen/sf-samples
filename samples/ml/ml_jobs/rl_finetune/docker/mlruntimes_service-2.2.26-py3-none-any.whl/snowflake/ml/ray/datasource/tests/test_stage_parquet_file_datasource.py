from unittest.mock import MagicMock, patch
from ray.data import ReadTask
from snowflake.ml.ray.datasource import SFStageParquetDataSource


@patch(
    "snowflake.ml.ray.datasource.stage_parquet_file_datasource.create_stage_filesystem"
)
def test_parquet_datasource_init(mock_create_fs):
    """Test initialization with all parameters."""
    with patch(
        "snowflake.ml.ray.datasource.stage_parquet_file_datasource.PyFileSystem"
    ), patch(
        "ray.data._internal.datasource.parquet_datasource.ParquetDatasource.__init__"
    ) as mock_parent_init:
        mock_parent_init.return_value = None

        datasource = SFStageParquetDataSource(
            stage_location="@mystage/path/to/files",
            database="mydb",
            schema="public",
            file_pattern=".parquet",
        )

        mock_parent_init.assert_called_once()
        assert datasource._DATASOURCE_TYPE == "ParquetFile"
        assert datasource._fs is not None


@patch(
    "snowflake.ml.ray.datasource.stage_parquet_file_datasource.create_stage_filesystem"
)
@patch("snowflake.ml.ray.datasource.stage_parquet_file_datasource.update_metrics")
def test_get_read_tasks_success(mock_create_fs, mock_update_metrics):
    with patch(
        "ray.data._internal.datasource.parquet_datasource.ParquetDatasource.__init__"
    ):
        # Mock successful read tasks from parent
        mock_read_task = MagicMock(spec=ReadTask)
        datasource = SFStageParquetDataSource(stage_location="@mystage/path")

        with patch(
            "ray.data._internal.datasource.parquet_datasource.ParquetDatasource.get_read_tasks"
        ) as mock_get_read_tasks:
            mock_get_read_tasks.return_value = [mock_read_task]

            result = datasource.get_read_tasks(parallelism=2)

            assert len(result) == 1
            assert result[0] is mock_read_task

            mock_update_metrics.assert_called_once()


@patch(
    "snowflake.ml.ray.datasource.stage_parquet_file_datasource.create_stage_filesystem"
)
@patch("snowflake.runtime.utils.session_utils.get_session")
@patch("ray.data._internal.datasource.parquet_datasource.ParquetDatasource.__init__")
def test_parent_class_initialization(
    mock_parent_init, mock_sf_stage_fs, mock_create_fs
):
    mock_fs = MagicMock()
    mock_create_fs.return_value = mock_fs

    # Set up parent constructor to succeed
    mock_parent_init.return_value = None

    # Initialize the data source
    SFStageParquetDataSource(
        stage_location="@mock_stage/path/to/files",
        file_pattern=".parquet",
    )

    # Assert parent class was initialized with correct parameters
    mock_parent_init.assert_called_once()
    _, kwargs = mock_parent_init.call_args

    # Check key arguments
    assert kwargs["paths"] == ["//path/to/files"]
    assert kwargs["file_extensions"] == ["parquet"]
