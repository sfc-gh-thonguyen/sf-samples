import pytest
from unittest import mock
from snowflake.ml.modeling.distributors.scaling_config_validator import (
    validate_ray_scaling_config,
)


@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_gpu",
    return_value=0,
)
@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_cpu",
    return_value=10,
)
def test_insufficient_cpu_resources(mock_total_cpu, mock_total_gpu):
    num_workers = 3
    num_cpu_per_worker = 4
    num_gpu_per_worker = 0

    expected_error_message = (
        "Insufficient CPU resources. Required: 12, Available: 10.\n"
        "To resolve this, you can try:\n"
        "• Reduce num_workers (3).\n"
        "• Reduce num_cpu_per_worker (4).\n"
        "• Increase the number of available CPUs by upgrading the compute pool.\n\n"
        "Current configuration: num_workers=3, num_cpu_per_worker=4, max_concurrent_trials=1"
    )

    with pytest.raises(ValueError) as excinfo:
        validate_ray_scaling_config(
            num_workers=num_workers,
            num_cpu_per_worker=num_cpu_per_worker,
            num_gpu_per_worker=num_gpu_per_worker,
        )

    assert str(excinfo.value) == expected_error_message
    mock_total_cpu.assert_called_once()
    mock_total_gpu.assert_called_once()


@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_gpu",
    return_value=0,
)
@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_cpu",
    return_value=14,
)
def test_insufficient_cpu_resources_with_max_concurrent_trials(
    mock_total_cpu, mock_total_gpu
):
    num_workers = 3
    num_cpu_per_worker = 4
    num_gpu_per_worker = 0

    expected_error_message = (
        "Insufficient CPU resources. Required: 24, Available: 14.\n"
        "To resolve this, you can try:\n"
        "• Reduce num_workers (3).\n"
        "• Reduce num_cpu_per_worker (4).\n"
        "• Lower max_concurrent_trials (2).\n"
        "• Increase the number of available CPUs by upgrading the compute pool.\n\n"
        "Current configuration: num_workers=3, num_cpu_per_worker=4, max_concurrent_trials=2"
    )

    with pytest.raises(ValueError) as excinfo:
        validate_ray_scaling_config(
            num_workers=num_workers,
            num_cpu_per_worker=num_cpu_per_worker,
            num_gpu_per_worker=num_gpu_per_worker,
            max_concurrent_trials=2,
        )
    assert str(excinfo.value) == expected_error_message
    mock_total_cpu.assert_called_once()
    mock_total_gpu.assert_called_once()


@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_gpu",
    return_value=2,
)
@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_cpu",
    return_value=16,
)
def test_insufficient_gpu_resources(mock_total_cpu, mock_total_gpu):
    num_workers = 3
    num_cpu_per_worker = 4
    num_gpu_per_worker = 1

    expected_error_message = (
        "Insufficient GPU resources. Required: 3, Available: 2.\n"
        "To resolve this, you can try:\n"
        "• Reduce num_workers (3).\n"
        "• Reduce num_gpu_per_worker (1).\n"
        "• Increase the number of available GPUs by upgrading the compute pool.\n\n"
        "Current configuration: num_workers=3, num_gpu_per_worker=1, max_concurrent_trials=1"
    )

    with pytest.raises(ValueError) as excinfo:
        validate_ray_scaling_config(
            num_workers=num_workers,
            num_cpu_per_worker=num_cpu_per_worker,
            num_gpu_per_worker=num_gpu_per_worker,
        )
    assert str(excinfo.value) == expected_error_message
    mock_total_cpu.assert_called_once()
    mock_total_gpu.assert_called_once()


@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_gpu",
    return_value=4,
)
@mock.patch(
    "snowflake.ml.modeling.distributors.scaling_config_validator.get_available_cpu",
    return_value=16,
)
def test_insufficient_gpu_resources_with_max_concurrent_trials(
    mock_total_cpu, mock_total_gpu
):
    num_workers = 3
    num_cpu_per_worker = 1
    num_gpu_per_worker = 1

    expected_error_message = (
        "Insufficient GPU resources. Required: 6, Available: 4.\n"
        "To resolve this, you can try:\n"
        "• Reduce num_workers (3).\n"
        "• Reduce num_gpu_per_worker (1).\n"
        "• Lower max_concurrent_trials (2).\n"
        "• Increase the number of available GPUs by upgrading the compute pool.\n\n"
        "Current configuration: num_workers=3, num_gpu_per_worker=1, max_concurrent_trials=2"
    )

    with pytest.raises(ValueError) as excinfo:
        validate_ray_scaling_config(
            num_workers=num_workers,
            num_cpu_per_worker=num_cpu_per_worker,
            num_gpu_per_worker=num_gpu_per_worker,
            max_concurrent_trials=2,
        )

    assert str(excinfo.value) == expected_error_message
    mock_total_cpu.assert_called_once()
    mock_total_gpu.assert_called_once()


if __name__ == "__main__":
    pytest.main()
