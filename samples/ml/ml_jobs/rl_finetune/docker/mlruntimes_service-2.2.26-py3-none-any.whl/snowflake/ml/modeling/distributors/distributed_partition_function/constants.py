MMT_STATE_PICKLE_FILENAME = "mmt_trainer_state.pkl"
