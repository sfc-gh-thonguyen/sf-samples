import threading
from typing import Dict, Any, List
from snowflake.ml.runtime_cluster.cluster_manager import (
    get_cluster_size,
)
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_info,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.train_actor import (
    TrainActor,
)
from ray.util.actor_pool import ActorPool
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
)

from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    get_actor_resources,
    get_actors_per_node,
)
from ray.actor import ActorHandle


logger = get_logger()


class ActorPoolScaler:
    """
    This class is responsible for ensuring notebook scales up worker actors to the total number of alive nodes in the
    compute pool. It runs the check every `scale_interval_seconds`(defaulted to 10) seconds.
    """

    def __init__(
        self,
        actor_pool: ActorPool,
        actor_arguments: Dict[str, Any],
        io_pool: Any,
        execution_options: ExecutionOptions,
        scale_interval_seconds: int = 10,
    ):
        self._actor_pool = actor_pool
        self._io_pool = io_pool
        self._actor_arguments = actor_arguments
        self._scale_interval_seconds = scale_interval_seconds
        self._stop_event = threading.Event()
        self._thread = None
        self._execution_options = execution_options
        self._actor_references: List[ActorHandle] = []  # Keep references to prevent GC

        # Monotonic counter to generate unique actor IDs and avoid duplicates
        # Start from number of actors already created on head node
        num_head_actors = (
            get_actors_per_node(execution_options)
            if execution_options.use_head_node
            else 0
        )
        self._next_actor_index: int = num_head_actors

    def start(self):
        """Starts the background thread for scaling the actor pool."""
        self._thread = threading.Thread(target=self._scale_actors, daemon=True)
        self._thread.start()

    def _scale_actors(self):
        """
        Checks for new nodes and scales the actor pool dynamically, every `scale_interval_seconds` seconds.

        # TODO: Figure out if there is a way to infer the compute pool info, such that we can rely on compute pool
        # max node info to exit the loop early. Such background thread is not intensive and trivial, hence okay
        # for now.
        """
        while not self._stop_event.is_set():
            # Calculate how many actors needed per node
            actors_per_node = get_actors_per_node(self._execution_options)

            # Worker nodes are always cluster_size - 1 (head node is always node 0)
            # The scaler only creates worker actors, never head actors
            worker_nodes = get_cluster_size() - 1

            # Target = actors_per_node * worker_nodes
            target_workers = actors_per_node * worker_nodes
            workers_created = len(self._actor_references)

            if workers_created < target_workers:
                missing = target_workers - workers_created
                actor_options = get_actor_resources(
                    is_head_node=False,
                    execution_options=self._execution_options,
                )

                for _ in range(missing):
                    actor_id = f"actor_{self._next_actor_index}"
                    self._next_actor_index += 1
                    # Get an IO actor from the pool (round-robin)
                    io_actor = self._io_pool.get_next_actor()
                    actor_instance = TrainActor.options(**actor_options).remote(
                        **self._actor_arguments, io_actor=io_actor, id=actor_id
                    )
                    self._actor_references.append(actor_instance)
                    self._actor_pool.push(actor_instance)

                # Calculate total actors including head node
                num_head_actors = (
                    get_actors_per_node(self._execution_options)
                    if self._execution_options.use_head_node
                    else 0
                )
                total_actors = target_workers + num_head_actors
                print_user_log_info(
                    logger, f"Scaling complete. Running {total_actors} actors."
                )
            self._stop_event.wait(self._scale_interval_seconds)

    def stop(self):
        """Stops the background scaling thread."""
        if self._thread:
            self._stop_event.set()
            self._thread.join()
