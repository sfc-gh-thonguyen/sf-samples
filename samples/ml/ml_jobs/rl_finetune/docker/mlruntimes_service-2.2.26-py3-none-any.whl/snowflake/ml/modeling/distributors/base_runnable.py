from dataclasses import dataclass
from typing import Optional, Callable


@dataclass
class BaseScalingConfig:
    """Base class for scaling config."""

    pass


class BaseRunnable:
    """
    Base class that support a run method that has a support running a custom function with a scaling config.
    """

    def __init__(
        self,
        func: Optional[Callable] = None,
        scaling_config: Optional[BaseScalingConfig] = None,
    ) -> None:
        self.func = func
        self.scaling_config = scaling_config

    def run(self, *args, **kwargs):
        raise NotImplementedError()
