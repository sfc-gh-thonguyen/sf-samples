from snowflake.ml.runtime_cluster.cluster_manager import (
    get_available_cpu,
    get_available_gpu,
)


def validate_ray_scaling_config(
    num_workers: int,
    num_cpu_per_worker: int,
    num_gpu_per_worker: int,
    max_concurrent_trials: int = 1,
) -> None:
    """
    Validate the scaling config for distributed training with/without HPO.

    Args:
        num_workers (int): Number of workers.
        num_cpu_per_worker (int): Number of CPUs per worker.
        num_gpu_per_worker (int): Number of GPUs per worker.

    Raises:
        ValueError: If there are insufficient CPU or GPU resources.
    """
    for name, value in [
        ("num_workers", num_workers),
        ("num_cpu_per_worker", num_cpu_per_worker),
        ("num_gpu_per_worker", num_gpu_per_worker),
    ]:
        assert value >= 0, f"{name} must be non-negative, but got {value}"

    max_concurrent_trials_suggestion = ""
    max_concurrent_trials_info = f", max_concurrent_trials={max_concurrent_trials}"
    if max_concurrent_trials > 1:
        max_concurrent_trials_suggestion = (
            f"• Lower max_concurrent_trials ({max_concurrent_trials}).\n"
        )

    available_cpu = get_available_cpu()
    available_gpu = get_available_gpu()
    required_cpu = num_workers * num_cpu_per_worker * max_concurrent_trials
    required_gpu = num_workers * num_gpu_per_worker * max_concurrent_trials
    if required_cpu > available_cpu:
        raise ValueError(
            f"Insufficient CPU resources. Required: {required_cpu}, Available: {available_cpu}.\n"
            f"To resolve this, you can try:\n"
            f"• Reduce num_workers ({num_workers}).\n"
            f"• Reduce num_cpu_per_worker ({num_cpu_per_worker}).\n"
            f"{max_concurrent_trials_suggestion}"
            f"• Increase the number of available CPUs by upgrading the compute pool.\n\n"
            f"Current configuration: num_workers={num_workers}, num_cpu_per_worker={num_cpu_per_worker}"
            f"{max_concurrent_trials_info}"
        )
    if required_gpu > available_gpu:
        raise ValueError(
            f"Insufficient GPU resources. Required: {required_gpu}, Available: {available_gpu}.\n"
            f"To resolve this, you can try:\n"
            f"• Reduce num_workers ({num_workers}).\n"
            f"• Reduce num_gpu_per_worker ({num_gpu_per_worker}).\n"
            f"{max_concurrent_trials_suggestion}"
            f"• Increase the number of available GPUs by upgrading the compute pool.\n\n"
            f"Current configuration: num_workers={num_workers}, num_gpu_per_worker={num_gpu_per_worker}"
            f"{max_concurrent_trials_info}"
        )
