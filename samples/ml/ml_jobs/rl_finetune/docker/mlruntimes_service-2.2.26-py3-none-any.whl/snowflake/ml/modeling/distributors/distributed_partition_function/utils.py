import os
import pickle
import tempfile
from typing import Dict, Union, Optional, List, Any
from snowflake.runtime.utils.session_utils import get_session
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    PartitionFunction,
    ExecutionOptions,
)
from snowflake import snowpark
from snowflake.snowpark import Session
from snowflake.snowpark import functions as F
from snowflake.runtime.utils.logger import get_logger
from common_utils.common_util import get_total_node_resources

logger = get_logger()


def _get_partition_query_from_column(
    partition_column: str, snowpark_dataframe: snowpark.DataFrame
) -> Dict[str, str]:
    """
    Return list of tuples, where each tuple contains partition_id and the associated SQL.
    """
    internal_session = get_session()
    query = snowpark_dataframe.queries["queries"][0]

    snowpark_df = internal_session.sql(query)
    partition_id_and_query = {}
    groups = snowpark_df.select(F.col(partition_column)).distinct().to_pandas()
    for group in groups[partition_column]:
        partition_id = str(group)
        partitioned_df = snowpark_df.filter(F.col(partition_column) == partition_id)
        partition_id_and_query[partition_id] = partitioned_df.queries["queries"][0]

    return partition_id_and_query


def _get_partition_query_from_function(
    partition_function: PartitionFunction,
) -> Dict[str, str]:
    """
    Return list of tuples, where each tuple contains partition_id and the associated SQL.
    """
    partition_id_and_df: Dict[str, snowpark.DataFrame] = partition_function()
    partition_id_and_query = {}
    for partition_id, df in partition_id_and_df.items():
        partition_id_and_query[partition_id] = df.queries["queries"][0]
    return partition_id_and_query


def get_partition_query(
    partition_by: Union[str, PartitionFunction],
    snowpark_dataframe: Optional[snowpark.DataFrame] = None,
) -> Dict[str, str]:
    if isinstance(partition_by, str):
        assert (
            snowpark_dataframe is not None
        ), "Please provide snowpark_dataframe to `run` method when partition_by is set to string"

        return _get_partition_query_from_column(
            partition_column=partition_by, snowpark_dataframe=snowpark_dataframe
        )
    elif callable(partition_by):
        return _get_partition_query_from_function(
            partition_function=partition_by,
        )
    else:
        raise RuntimeError(f"unsupported partition type: {partition_by}")


def construct_stage_path(
    *,
    run_id: str,
    stage_name: str,
    subpath: Union[str, List[str]] = [],
) -> str:
    if isinstance(subpath, list):
        return os.path.join(stage_name, run_id, *subpath)
    else:
        return os.path.join(stage_name, run_id, subpath)


def serialize_and_upload_to_stage(
    *,
    stage_path: str,
    object_to_upload: Any,
    filename: str,
    session: Optional[Session] = None,
) -> None:
    """
    Uploads either a pickle file (for models) or a text-based file (e.g., logs) to a Snowflake stage.

    Args:
      stage_path: Stage path for the partition.
      object_to_upload (Any): The object to upload. Must be picklable if `is_pickle=True`,
        or a string if `is_pickle=False`.
      filename: file_name of the object to be uploaded to stage.
      session (Session): Snowflake session to interact with the stage.

    Raises:
      AssertionError: If `is_pickle=True` and destination path does not end with .pkl.
      AssertionError: If `is_pickle=False` and `object_to_upload` is not a string.
    """
    session = session or get_session()

    local_file_path = os.path.join(tempfile.gettempdir(), filename)
    is_pickle = filename.endswith(".pkl")

    if is_pickle:
        with open(local_file_path, "wb") as f:
            pickle.dump(object_to_upload, f)
    else:
        # Assume it's a text-based file (e.g., log file)
        assert isinstance(
            object_to_upload, str
        ), "Only string data is supported for non-pickle files"
        with open(local_file_path, "w") as f:
            f.write(object_to_upload)

    session.file.put(local_file_path, stage_path, auto_compress=False, overwrite=True)


def download_and_deserialize_from_stage(
    *,
    run_id: str,
    stage_name: str,
    subpath: Union[str, List[str]],
    session: Optional[Session] = None,
) -> Any:
    """
    Downloads a file from a Snowflake stage, either as a pickle object (e.g. for models) or as a string (e.g. for logs).

    Args:
        run_id (str): Unique run identifier.
        stage_name (str): Name of the Snowflake stage.
        subpath (Union[str, List[str]]): Path relative to the stage, can be a string or list of path components.
        session (Session): Snowflake session to interact with the stage.

    Returns:
        Any: The deserialized object

    """
    session = session or get_session()
    stage_path = construct_stage_path(
        run_id=run_id,
        stage_name=stage_name,
        subpath=subpath,
    )

    tmp_dir = tempfile.gettempdir()
    session.file.get(stage_path, tmp_dir)

    filename = os.path.basename(stage_path)
    local_file_path = os.path.join(tmp_dir, filename)

    is_pickle = filename.endswith(".pkl")

    if is_pickle:
        with open(local_file_path, "rb") as f:
            return pickle.load(f)
    else:
        with open(local_file_path, "rt", encoding="utf-8") as f:
            return f.read()


def get_actors_per_node(execution_options: Optional[ExecutionOptions] = None) -> int:
    """
    Calculate how many actors should run on a single node based on CPU/GPU constraints.

    Args:
        execution_options: Execution options containing custom resource allocation.

    Returns:
        int: Number of actors that should run on one node.
    """
    if not execution_options:
        return 1

    node_resources = get_total_node_resources()
    total_gpus = int(node_resources.get("GPU", 0))
    total_cpus = node_resources["CPU"]

    # Determine GPU allocation per worker
    if execution_options and execution_options.num_gpus_per_worker is not None:
        gpus_per_worker = execution_options.num_gpus_per_worker
    else:
        # Default: 1 GPU per worker if GPUs available
        gpus_per_worker = 1 if total_gpus > 0 else 0

    # Determine CPU allocation per worker
    if execution_options and execution_options.num_cpus_per_worker is not None:
        cpus_per_worker = execution_options.num_cpus_per_worker
    else:
        # Default: If GPUs available, divide CPUs by number of GPUs for balanced allocation
        # Otherwise, allocate all CPUs (1 actor per node)
        if total_gpus > 0:
            cpus_per_worker = total_cpus / total_gpus
        else:
            cpus_per_worker = total_cpus

    # Calculate max actors based on constraints
    actors_from_cpu = int(total_cpus / cpus_per_worker)

    if total_gpus > 0 and gpus_per_worker > 0:
        actors_from_gpu = int(total_gpus / gpus_per_worker)
        max_actors = min(actors_from_cpu, actors_from_gpu)
    else:
        max_actors = actors_from_cpu

    return max(max_actors, 1)  # At least 1 actor per node


def get_actor_resources(
    is_head_node: bool = False,
    execution_options: Optional[ExecutionOptions] = None,
) -> Dict[str, Any]:
    """
    Returns Ray actor resource options for a worker or head node.

    Args:
        is_head_node (bool): If True, resources for head node; otherwise, worker node.
        execution_options (Optional[ExecutionOptions]): Execution options containing custom resource allocation.
            - num_cpus_per_worker (Optional[int]): Number of CPUs to allocate per worker actor. If None (default),
                the behavior depends on GPU availability:
                * With GPUs: CPUs are divided evenly among workers based on GPU count
                * Without GPUs: Each worker uses all available CPUs (1 worker per node)
                Examples:
                  - Node: 16 CPUs, 4 GPUs, None → 4 workers, 4 CPUs each
                  - Node: 16 CPUs, 0 GPUs, None → 1 worker, 16 CPUs
                  - Node: 16 CPUs, any GPUs, 4 → 4 workers per node
            - num_gpus_per_worker (Optional[int]): Number of GPUs to allocate per worker actor. If None (default),
                allocates 1 GPU per worker when GPUs are available, 0 otherwise.
                Examples:
                  - Node: 16 CPUs, 4 GPUs, None → 4 workers, 1 GPU each
                  - Node: 16 CPUs, 4 GPUs, 2 → 2 workers, 2 GPUs each

    Returns:
        dict: Ray actor options containing num_cpus, num_gpus (if > 0), and resources (node tags).
    """

    node_resources = get_total_node_resources()
    total_gpus = int(node_resources.get("GPU", 0))
    total_cpus = node_resources["CPU"]

    options: Dict[str, Any] = {}

    # Set node tag (always 0.001 - CPU allocation controls placement)
    if not is_head_node:
        options["resources"] = {"node_tag:worker": 0.001}
    else:
        options["resources"] = {"node_tag:head": 0.001}

    # Determine resources per worker to match get_actors_per_node logic
    actors_per_node = get_actors_per_node(execution_options)

    # CPU allocation: divide total CPUs by number of actors per node
    if execution_options and execution_options.num_cpus_per_worker is not None:
        allocated_cpus = execution_options.num_cpus_per_worker
    else:
        # Default: divide CPUs evenly across actors
        allocated_cpus = total_cpus / actors_per_node

    # GPU allocation: divide total GPUs by number of actors per node
    if execution_options and execution_options.num_gpus_per_worker is not None:
        allocated_gpus = execution_options.num_gpus_per_worker
    else:
        # Default: 1 GPU per worker if GPUs available, 0 otherwise
        allocated_gpus = 1 if total_gpus > 0 else 0

    # Set actor options
    if allocated_gpus > 0:
        options["num_gpus"] = allocated_gpus
    options["num_cpus"] = allocated_cpus

    return options
