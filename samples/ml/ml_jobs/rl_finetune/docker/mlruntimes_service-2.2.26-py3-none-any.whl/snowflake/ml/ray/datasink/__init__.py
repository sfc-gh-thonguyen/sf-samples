from .table_datasink import SnowflakeTableDatasink
from .stage_datasink import SnowflakeStageDatasink

__all__ = ["SnowflakeTableDatasink", "SnowflakeStageDatasink"]
