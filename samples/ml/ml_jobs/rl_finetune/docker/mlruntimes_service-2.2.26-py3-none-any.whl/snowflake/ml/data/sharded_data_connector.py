from snowflake.ml.data.internal_data_connector import InternalDataConnector
from snowflake.ml.data import data_ingestor
from typing import Any, Optional, TypeVar
import ray


DataConnectorType = TypeVar(
    "DataConnectorType", bound="ShardedDataConnector", covariant=True
)


class ShardedDataConnector(InternalDataConnector):
    """Subclass of a data connector that is used to shard data for distributed training.

    Data will be sharded automatically into the number of partitions that matches the `world_size` of the distributed
    trainer. Call `get_shard` within a Snowflake training context to retrieve the shard associated with
    that worker process.

    Example usage:
    ```
    # Load from Snowpark Dataframe
    df = session.table("TRAIN_DATA_TABLE")
    train_data = ShardedDataConnector.from_dataframe(df)

    # Pass to pytorch trainer to retrieve shard in training function.
    def train_func():
        dataset_map = context.get_dataset_map()

        # Get the data connector for the shard.
        training_data_shard = dataset_map["train"].get_shard()

        # Convert this shard into a torch dataset
        torch_data_shard = training_data_shard.to_torch_dataset()

    pytorch_trainer = PyTorchTrainer(
        train_func=train_func,
    )

    pytorch_trainer.run(
        dataset_map=dict(
            train=train_data
        )
    )
    ```
    """

    def __init__(
        self, ingestor: data_ingestor.DataIngestor, equal: bool = True, **kwargs: Any
    ) -> None:
        super().__init__(ingestor, **kwargs)
        self.equal = equal

    @classmethod
    def from_ray_dataset(
        cls: type[DataConnectorType],
        ray_ds: ray.data.Dataset,
        ingestor_class: Optional[type[data_ingestor.DataIngestor]] = None,
        equal: bool = True,
        **kwargs: Any,
    ) -> DataConnectorType:
        return super().from_ray_dataset(ray_ds, ingestor_class, equal=equal, **kwargs)

    def get_shard(self) -> "ShardedDataConnector":
        """Retrieves the shard of data associated with the `rank` of the process."""
        raise NotImplementedError(
            "`get_shard` must be called from within the Snowflake training context."
        )
