from typing import Optional, List, Union
import ray.data._internal.datasource.text_datasource as ray_text
from pyarrow.fs import FSSpecHandler, PyFileSystem
from ray.data.datasource.datasource import ReadTask

from snowflake.ml.ray.datasource.datasource_utils import (
    extract_extension,
    create_stage_filesystem,
    update_metrics,
    write_to_local_path,
)


class SFStageTextDataSource(ray_text.TextDatasource):
    _DATASOURCE_TYPE = "TextFile"

    def __init__(
        self,
        *,
        stage_location: str,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        file_pattern: Optional[Union[str, List[str]]] = None,
        local_path: Optional[str] = None,
        encoding: str = "utf-8",
        drop_empty_lines: bool = True,
        **file_based_datasource_kwargs,
    ):
        """
        Snowflake stage text data source for reading text files from a Snowflake stage.

        Args:
            stage_location (str): The location of the files in a stage.
                Example: "@mystage/path/to/files"
            database (str, optional): The database name. Defaults to session's current database.
            schema (str, optional): The schema name. Defaults to session's current database.
            file_pattern (str | List[str], optional): File patterns to filter in stage. Defaults to None.
            local_path (str, optional): The local path to save the files. Defaults to None. None means the file
                will not be saved to local disk.
            encoding (str, optional): The encoding to read the text files. Defaults to "utf-8".
            drop_empty_lines (bool, optional): Whether to drop empty lines in the text files. Defaults to True.
            **file_based_datasource_kwargs: Additional arguments for FileBasedDatasource
        """
        # Parse stage location
        stage_path = "//" + "/".join(stage_location.lstrip("@").split("/")[1:])
        self._local_path = local_path

        self._fs = create_stage_filesystem(
            stage_location=stage_location, database=database, schema=schema
        )
        py_fs = PyFileSystem(FSSpecHandler(self._fs))

        file_extensions = extract_extension(file_pattern)

        # Initialize parent with stage path and custom filesystem
        super().__init__(
            paths=[stage_path],
            filesystem=py_fs,
            encoding=encoding,
            drop_empty_lines=drop_empty_lines,
            file_extensions=file_extensions,
            **file_based_datasource_kwargs,
        )

    def get_read_tasks(
        self, parallelism: int, per_task_row_limit: Optional[int] = None
    ) -> List[ReadTask]:
        read_tasks = super().get_read_tasks(parallelism, per_task_row_limit)
        update_metrics(read_tasks, self._DATASOURCE_TYPE)

        if self._local_path:
            write_to_local_path(
                self._fs, read_tasks, self._local_path, self._DATASOURCE_TYPE
            )

        return read_tasks
