import random
from ray.data import Datasink
from ray.data.block import Block, BlockAccessor
from ray.data._internal.execution.interfaces import TaskContext
from typing import Optional, Iterable
import time
import pyarrow as pa
from snowflake.runtime.utils.logger import get_logger
from snowflake.runtime.utils.session_utils import get_session
from snowflake.connector.errors import ProgrammingError
from ray.data._internal.delegating_block_builder import DelegatingBlockBuilder
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics

logger = get_logger()


class SnowflakeTableDatasink(Datasink):
    _MAX_RETRIES = 5
    _BASE_DELAY = 1.0  # seconds
    _JITTER_MIN = 0.5  # seconds
    _JITTER_MAX = 1.0  # seconds

    def __init__(
        self,
        *,
        table_name: str,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        auto_create_table: bool = False,
        override: bool = False,
    ):
        """
        Snowflake Ray Datasink for writing Ray data blocks to a Snowflake table.

        Example::
            >>> import pandas as pd
            >>> import ray

            >>> pandas_df = pd.DataFrame([(1, "Steve"), (2, "Bob")], columns=["id", "name"])
            >>> ray_ds = ray.data.from_pandas(pandas_df)
            >>> datasink = SnowflakeTableDatasink(table_name="TABLE", database="DB", schema="SCHEMA")
            >>> ray_ds.write_datasink(datasink)

        Args:
            table_name (str): The name of the table.
            database (str, optional): The database name. Defaults to session's current database.
            schema (str, optional): The schema name. Defaults to session's current database.
            auto_create_table (bool, optional): Whether to automatically create the table if it does not exist.
                Defaults to False. If auto_create_table is False, the table must already exist in the database.
            override (bool, optional): Whether to override the table if it already exists. Defaults to False.
                When override is set to False, it will append to the existing table if it exist
        """
        self._table_name = table_name
        self._database = database or get_session().get_current_database()
        self._schema = schema or get_session().get_current_schema()
        self._override = override
        self._auto_create_table = auto_create_table

    def on_write_start(self, schema: Optional[pa.Schema] = None) -> None:
        # Check if the table exists and take action based on the auto_create_table and override flag
        # ACTION TABLE:
        # overwrite | auto_create_table | action
        # False     | False             | If the table exists, append to the table. if table not exist, stop the process # noqa
        # False     | True              | If the table exists, append to the table. If table not exist, create the table and append to the table. # noqa
        # True      | False             | If the table exists, drop the table first. If table not exist, stop the process # noqa
        # True      | True              | If the table exists, drop the table first. If table not exist, append to the table. # noqa
        if not self._auto_create_table:
            # table should already exist
            session = get_session()
            tables = session.sql(
                f"SHOW TABLES LIKE '{self._table_name}' IN {self._database}.{self._schema}"
            ).collect()
            if not tables:
                raise ValueError(
                    f"Table {self._database}.{self._schema}.{self._table_name} does not exist."
                )

        if self._override:
            logger.warning(
                f"Overriding table {self._database}.{self._schema}.{self._table_name}"
            )
            session = get_session()
            session.sql(
                f"DROP TABLE IF EXISTS {self._database}.{self._schema}.{self._table_name}"
            ).collect()

    def write(self, blocks: Iterable[Block], ctx: TaskContext) -> None:
        session = get_session()
        start_time = time.perf_counter()
        MLRSPrometheusMetrics.DATASINK_WRITE_TASKS.value.labels(
            datasink_type="table"
        ).inc()

        # Convert blocks to list to handle multiple iterations if needed
        builder = DelegatingBlockBuilder()
        for block in blocks:
            builder.add_block(block)
        merged_block = builder.build()

        pandas_block = BlockAccessor.for_block(merged_block).to_pandas()
        if pandas_block.empty:
            MLRSPrometheusMetrics.DATASINK_EMPTY_WRITE_BLOCKS.value.labels(
                datasink_type="table"
            ).inc()
            return

        row_count = len(pandas_block)

        for attempt in range(1, self._MAX_RETRIES + 1):
            try:
                session.write_pandas(
                    df=pandas_block,
                    table_name=self._table_name,
                    database=self._database,
                    schema=self._schema,
                    auto_create_table=self._auto_create_table,
                    overwrite=False,
                    quote_identifiers=False,
                )
                break
            except Exception as e:
                error_msg = str(e)

                # If write failed due to Snowflake DB Lock limit, then retry
                lock_limit_msg = (
                    "number of waiters for this lock exceeds the 20 statements limit"
                )
                if type(e) is ProgrammingError and lock_limit_msg in error_msg:
                    if attempt == self._MAX_RETRIES:
                        MLRSPrometheusMetrics.DATASINK_WRITE_RESULT.value.labels(
                            datasink_type="table", status="failure_max_retries"
                        ).inc()
                        raise e  # Give up after max_retries

                    # Exponential backoff with jitter
                    wait_time = self._BASE_DELAY * (
                        2 ** (attempt - 1)
                    ) + random.uniform(self._JITTER_MIN, self._JITTER_MAX)
                    MLRSPrometheusMetrics.DATASINK_RETRY_ATTEMPTS.value.labels(
                        datasink_type="table"
                    ).inc()

                    # Sleep for the calculated wait time
                    time.sleep(wait_time)
                else:
                    MLRSPrometheusMetrics.DATASINK_WRITE_RESULT.value.labels(
                        datasink_type="table", status="failure_error"
                    ).inc()
                    raise e

        MLRSPrometheusMetrics.DATASINK_WRITE_RESULT.value.labels(
            datasink_type="table", status="success"
        ).inc()
        MLRSPrometheusMetrics.DATASINK_ROWS_WRITTEN.value.labels(
            datasink_type="table"
        ).inc(row_count)
        # Write duration will include both wait-time and write-times
        MLRSPrometheusMetrics.DATASINK_WRITE_DURATION.value.labels(
            datasink_type="table"
        ).observe(time.perf_counter() - start_time)
