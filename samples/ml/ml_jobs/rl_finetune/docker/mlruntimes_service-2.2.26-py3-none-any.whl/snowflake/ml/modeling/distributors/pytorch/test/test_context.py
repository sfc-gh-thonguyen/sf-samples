import pytest
from snowflake.ml.modeling.distributors.pytorch import context


class TestMetricsReporter:
    @property
    def sut(self):
        class MockMetricsReporter(context.MetricsReporter):
            pass

        return MockMetricsReporter()

    def test_protocol_instantiation(self):
        with pytest.raises(TypeError, match="Protocols cannot be instantiated"):
            _ = context.MetricsReporter()

    def test_log_metrics(self):
        # Call should succeed
        _ = self.sut.log_metrics({"metric": 0.0})


class TestContext:
    @property
    def sut(self):
        class MockContext(context.Context):
            pass

        return MockContext()

    def test_protocol_instantiation(self):
        with pytest.raises(TypeError, match="Protocols cannot be instantiated"):
            _ = context.Context()

    def test_get_world_size(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_world_size()

    def test_get_rank(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_rank()

    def test_get_local_rank(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_local_rank()

    def test_get_local_world_size(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_local_world_size()

    def test_get_node_rank(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_node_rank()

    def test_get_master_addr(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_master_addr()

    def test_get_master_port(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_master_port()

    def test_get_default_backend(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_default_backend()

    def test_get_supported_backends(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_supported_backends()

    def test_get_hyper_params(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_hyper_params()

    def test_get_dataset_map(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_dataset_map()

    def test_get_model_dir(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_model_dir()

    def test_get_metrics_reporter(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_metrics_reporter()

    def test_get_artifact_manager(self):
        with pytest.raises(NotImplementedError):
            self.sut.get_artifact_manager()
