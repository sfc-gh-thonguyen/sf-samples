from scipy.sparse import csr_matrix
from xgboost import XGBClassifier, XGBRegressor, XGBRanker

from snowflake.ml.modeling.distributors.xgboost import XGBEstimator
import pandas as pd
import numpy as np
from unittest import mock
import pytest
from snowflake.ml.data.data_connector import DataConnector


def test_xgboost_estimator_override_estimator_in_param():
    params = {
        "n_estimators": 100,
        "objective": "binary:logistic",
    }
    estimator = XGBEstimator(n_estimators=10, objective="reg:squredloss", params=params)

    assert estimator.get_params()["n_estimators"] == 100
    assert estimator.get_params()["objective"] == "binary:logistic"


@mock.patch("web.request_handler.XGBTrainingHandler")
def test_xgboost_estimator_fit_raise_error_when_input_combination_is_not_allowed(
    mock_xgb_training_handler,
):
    pandas_df = pd.DataFrame({"a": [1, 2, 3, 4, 5], "b": [1, 2, 3, 4, 5]})

    y = pd.DataFrame({"label": [1, 0, 1, 0, 1]})

    dataset_connector = mock.Mock(spec=DataConnector)
    y_data_connector = mock.Mock(spec=DataConnector)

    print(isinstance(y_data_connector, DataConnector))

    estimator = XGBEstimator(n_estimators=10, objective="binary:logistic")

    # Error should be raised if only passed in in-memory datatype without labels
    with pytest.raises(ValueError):
        estimator.fit(pandas_df)

    # Error should be raised if both in memory data are passed but also with input_col and label_col
    with pytest.raises(ValueError):
        estimator.fit(pandas_df, y, input_cols=["a", "b"], label_col="label")

    # Error when dataset connector is provided, y shouldn't be provided
    with pytest.raises(ValueError):
        estimator.fit(dataset_connector, y, input_cols=["a", "b"])

    # Error when dataset connector is provided, input_cols and label_col should be provided
    with pytest.raises(ValueError):
        estimator.fit(dataset_connector)

    # Error when verbose_eval is not None eval_set cannot be None
    with pytest.raises(ValueError):
        estimator.fit(pandas_df, y, input_cols=["a", "b"], verbose_eval=True)


@mock.patch("web.request_handler.XGBTrainingHandler")
def test_xgb_estimator_will_not_predict_when_not_trained(mock_xgb_training_handler):
    estimator = XGBEstimator(n_estimators=10, objective="binary:logistic")

    dataset_connector = mock.Mock(spec=DataConnector)

    with pytest.raises(ValueError):
        estimator.predict(dataset_connector)


@pytest.mark.parametrize(
    "y",
    [
        np.array([0, 1, 0, 2, 1]),
        pd.Series([2, 1, 0, 0, 1]),
        csr_matrix(
            (np.array([1, 0, 2]), (np.array([0, 0, 1]), np.array([0, 1, 0]))),
            shape=(2, 3),
        ),
    ],
)
def test_sklearn_classifier(y):
    # Initialize the estimator
    estimator = XGBEstimator(n_estimators=10, objective="binary:logistic")

    # Mock the trained booster and parameters
    estimator._trained_booster = mock.MagicMock()
    # estimator._params = {"objective": "binary:logistic"}

    # Call the function
    sklearn_estimator = estimator._to_sklearn_estimator(y)

    # Assertions
    assert sklearn_estimator is not None
    assert isinstance(sklearn_estimator, XGBClassifier)
    assert sklearn_estimator._Booster is estimator._trained_booster
    assert sklearn_estimator.n_classes_ == 3


@pytest.mark.parametrize(
    "reg", [("reg:squarederror", XGBRegressor), ("rank:map", XGBRanker)]
)
@pytest.mark.parametrize(
    "y",
    [
        np.array([0, 1, 0, 2, 1]),
        pd.Series([2, 1, 0, 0, 1]),
        csr_matrix(
            (np.array([1, 0, 2]), (np.array([0, 0, 1]), np.array([0, 1, 0]))),
            shape=(2, 3),
        ),
    ],
)
def test_sklearn_regressor(y, reg):
    objective, estimator_cls = reg
    # Initialize the estimator
    estimator = XGBEstimator(n_estimators=10, objective=objective)

    # Mock the trained booster and parameters
    estimator._trained_booster = mock.MagicMock()
    # estimator._params = {"objective": "binary:logistic"}

    # Call the function
    sklearn_estimator = estimator._to_sklearn_estimator(y)

    # Assertions
    assert isinstance(sklearn_estimator, estimator_cls)
    assert sklearn_estimator._Booster is estimator._trained_booster


@mock.patch(
    "snowflake.ml.modeling.distributors.xgboost.xgboost_estimator.safe_run_awaitable"
)
@mock.patch(
    "snowflake.ml.modeling.distributors.xgboost.xgboost_estimator.MLRSPrometheusMetrics"
)
def test_fit_increments_metrics(mock_metrics, mock_awaitable) -> None:
    # Initialize the estimator
    estimator = XGBEstimator(n_estimators=10)

    dataset_mock = mock.Mock(spec=DataConnector)
    estimator.fit(dataset_mock, input_cols=["test"], label_col="test")

    mock_awaitable.assert_called_once()
    mock_metrics.TRAIN_ATTEMPTS.value.inc.assert_called_once()
    mock_metrics.TRAIN_XGB.value.inc.assert_called_once()
