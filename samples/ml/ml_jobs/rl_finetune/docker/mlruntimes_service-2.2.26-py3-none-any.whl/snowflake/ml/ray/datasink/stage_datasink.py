from io import BytesIO
from typing import Literal, Optional, Iterable
import time
from ray.data import Datasink, DataContext
from ray.data.block import Block, BlockAccessor
from ray.data._internal.execution.interfaces import TaskContext
from ray.data._internal.delegating_block_builder import DelegatingBlockBuilder
from snowflake.runtime.utils.logger import get_logger
from snowflake.runtime.utils.session_utils import get_session
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.csv as csv

logger = get_logger()

# Configure Ray's data context
context = DataContext.get_current()
context.execution_options.verbose_progress = False
context.enable_operator_progress_bars = False


class SnowflakeStageDatasink(Datasink):
    SUPPORTED_FORMATS = {"parquet", "csv"}

    def __init__(
        self,
        *,
        stage_location: str,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        file_prefix: str = "data",
        file_format: Literal["parquet", "csv"] = "parquet",  # Type hint enforces values
        auto_compress: bool = True,
        overwrite: bool = False,
        source_compression: str = "AUTO_DETECT",
    ):
        """
        Snowflake Ray Datasink for writing Ray data blocks to a Snowflake stage.
        Each task writes to exactly one file with a predetermined name.

        Args:
            stage_location: The stage location (e.g., "@my_stage/path/")
            database: Optional database name
            schema: Optional schema name
            file_prefix: Prefix for generated filenames (default: "data")
            file_format: File format - "parquet" or "csv" (default: "parquet")
            auto_compress: Whether to compress files (default: True)
            overwrite: Whether to overwrite existing files (default: False)
            source_compression: Compression type of source files if already compressed
                                 (e.g., "GZIP", "BROTLI", etc.)
        """
        self._stage_location = stage_location.lstrip("@").rstrip("/")
        self._database = database or get_session().get_current_database()
        self._schema = schema or get_session().get_current_schema()
        self._file_prefix = file_prefix
        self._file_format = file_format.lower()
        self._auto_compress = auto_compress
        self._overwrite = overwrite
        self._source_compression = source_compression

        if self._file_format not in self.SUPPORTED_FORMATS:
            raise ValueError("Only 'parquet' or 'csv' file formats are supported.")

    def _generate_file_name(self, task_idx: int) -> str:
        return f"{self._file_prefix}_{task_idx}.{self._file_format}"

    def on_write_start(self, schema: Optional[pa.Schema] = None) -> None:
        """Called once before write tasks begin.

        Args:
            schema: The PyArrow schema of the data being written (Ray 2.53+).
        """
        # Verify stage exists
        session = get_session()
        try:
            stage_location = self._stage_location.lstrip("@").split("/")[0]
            session.sql(
                f"CREATE STAGE IF NOT EXISTS {self._database}.{self._schema}.{stage_location}"
            ).collect()
        except Exception as e:
            logger.error(
                f"Cannot create and access stage: {self._stage_location}. Error: {e}"
            )
            raise e

    def write(self, blocks: Iterable[Block], ctx: TaskContext) -> None:
        """
        Write blocks to a single file in the stage.
        Each task writes to exactly one file with a unique name.
        """
        # Track write task initiation
        datasink_type = f"stage_{self._file_format}"
        MLRSPrometheusMetrics.DATASINK_WRITE_TASKS.value.labels(
            datasink_type=datasink_type
        ).inc()

        start_time = time.perf_counter()
        session = get_session()
        task_idx = ctx.task_idx
        # Generate the unique filename for this task
        filename = self._generate_file_name(task_idx)

        # Merge all blocks into a single block
        builder = DelegatingBlockBuilder()
        for block in blocks:
            builder.add_block(block)
        merged_block = builder.build()

        if BlockAccessor.for_block(merged_block).num_rows() == 0:
            MLRSPrometheusMetrics.DATASINK_EMPTY_WRITE_BLOCKS.value.labels(
                datasink_type=datasink_type
            ).inc()
            return

        arrow_table = BlockAccessor.for_block(merged_block).to_arrow()
        buffer = BytesIO()

        if self._file_format == "parquet":
            pq.write_table(arrow_table, buffer)
        else:
            csv.write_csv(arrow_table, buffer)

        buffer.seek(0)

        stage_path = f"{self._stage_location}/{filename}"
        result = session.file.put_stream(
            input_stream=buffer,
            stage_location=f"{self._database}.{self._schema}.{stage_path}",
            auto_compress=self._auto_compress,
            overwrite=self._overwrite,
            source_compression=self._source_compression,
        )

        if result.status != "UPLOADED":
            MLRSPrometheusMetrics.DATASINK_WRITE_RESULT.value.labels(
                datasink_type=datasink_type, status="upload_fail"
            ).inc()
            raise RuntimeError(f"Failed to upload {task_idx}: {result.message}")

        MLRSPrometheusMetrics.DATASINK_WRITE_RESULT.value.labels(
            datasink_type=datasink_type, status="success"
        ).inc()
        MLRSPrometheusMetrics.DATASINK_ROWS_WRITTEN.value.labels(
            datasink_type=datasink_type
        ).inc(arrow_table.num_rows)
        # Write duration will include both wait-time and write-times
        MLRSPrometheusMetrics.DATASINK_WRITE_DURATION.value.labels(
            datasink_type=datasink_type
        ).observe(time.perf_counter() - start_time)

    def on_write_failed(self, error: Exception) -> None:
        """Called if any write task fails."""
        logger.error(f"Write operation failed: {error}")
        raise error
