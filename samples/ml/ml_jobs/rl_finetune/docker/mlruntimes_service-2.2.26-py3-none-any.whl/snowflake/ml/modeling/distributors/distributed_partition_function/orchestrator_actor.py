import time
from typing import Dict, Callable, Any, Iterable, Union, List, Tuple, Optional
import ray
from ray.actor import ActorHandle
from ray.exceptions import RayActorError
from ray.types import ObjectRef
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    SinglePartitionDetails,
    PartitionStatus,
    DPFUncaughtException,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
    RunStatus,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.actor_pool import (
    ActorPool,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.actor_pool_scaler import (
    ActorPoolScaler,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.constants import (
    MMT_STATE_PICKLE_FILENAME,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.notebook_status_updater import (
    NotebookStatusUpdater,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.partition_source import (
    PartitionSource,
    PartitionTask,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.train_actor import (
    TrainActor,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.io_actor import (
    IOActorPool,
)

from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_info,
    print_user_log_warn,
)

from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    serialize_and_upload_to_stage,
    construct_stage_path,
    get_actor_resources,
    get_actors_per_node,
)


from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
from datetime import datetime

from snowflake.ml.runtime_cluster.cluster_manager import (
    get_cluster_size,
)

logger = get_logger()


# 0.001 to allow workload to be placed in the head node if use_head_node is set to True.
@ray.remote(resources={"node_tag:head": 0.001}, num_cpus=0)
class DPFOrchestrator:
    """
    This Distributed Partition Function(DPF) orchestrator is responsible for dispatching workloads to various workers
    and collect the results.
    """

    def __init__(
        self,
        func: Callable[[Any], Any],
        run_id: str,
        fully_qualified_stage_name: str,
        execution_options: ExecutionOptions,
        partition_source: PartitionSource,
    ):
        """
        :param func: user-provided func
        :param run_id: unique run id associated with the DPF run.
        :param fully_qualified_stage_name: user-provided stage to persist models and metadata
        :param execution_options: ray specific execution options.
        :param partition_source: source for partition discovery and task creation.
        """
        self._fully_qualified_stage_name = fully_qualified_stage_name
        self.run_id = run_id
        self._partition_source = partition_source
        partition_ids = partition_source.discover_partitions()
        self._partition_details: Dict[str, SinglePartitionDetails] = {
            partition_id: SinglePartitionDetails(partition_id=partition_id)
            for partition_id in partition_ids
        }

        # Initialize IO actor pool for bounded session management
        self._io_pool = IOActorPool()

        self._actor_pool, self._actors, self._actor_pool_scaler = self._init_actor_pool(
            func=func,
            fully_qualified_stage_name=fully_qualified_stage_name,
            execution_options=execution_options,
        )
        self._is_cancelled: bool = False
        self._fail_fast: bool = execution_options.fail_fast
        self._total_processed = 0  # number of total processed model training runs
        self._notebook_status_updater = NotebookStatusUpdater()
        self._object_ref_to_partition_id: Dict[ObjectRef, str] = {}
        self._tasks_submitted = (
            0  # track number of tasks submitted for progress reporting
        )

    def _init_actor_pool(
        self,
        *,
        func: Callable[[Any], Any],
        fully_qualified_stage_name: str,
        execution_options: ExecutionOptions,
    ) -> Tuple[ActorPool, List[ActorHandle], ActorPoolScaler]:
        """
        Initializes a Ray actor pool for distributed training across available compute nodes.

        This method creates a pool of `TrainActor` instances on available Ray nodes. Each actor is initialized with
        a unique ID and common arguments necessary for running the UDF. The method blocks until the head node
        actor is successfully started (if use_head_node=True) before proceeding with scaler initialization.

        Returns:
            Tuple[ActorPool, List[ActorHandle], ActorPoolScaler]:
                - `ActorPool`: A Ray actor pool managing the set of training actors.
                - `List[ActorHandle]`: The list of initialized actor handles.
                - `ActorPoolScaler`: A utility for monitoring and scaling the actor pool during training.
        """
        actor_arguments = {
            "func": func,
            "fully_qualified_stage_name": fully_qualified_stage_name,
            "run_id": self.run_id,
            "max_retries": execution_options.max_retries,
        }

        if not ray.is_initialized():
            ray.init(
                address="auto",
                ignore_reinit_error=True,
                log_to_driver=False,
                logging_level="CRITICAL",
            )

        ray_nodes_count = get_cluster_size()
        is_single_node = ray_nodes_count == 1
        if is_single_node and not execution_options.use_head_node:
            raise RuntimeError(
                "use_head_node option must set to True when running on a single node environment"
            )

        # Create head node actors (if required)
        actors = []

        if execution_options.use_head_node:
            num_head_actors = get_actors_per_node(execution_options)
            actor_options = get_actor_resources(
                is_head_node=True,
                execution_options=execution_options,
            )

            print_user_log_info(
                logger,
                f"Creating {num_head_actors} training actor(s) on head node to participate in running workloads...",
            )

            for i in range(num_head_actors):
                actor_id = f"actor_{i}"
                io_actor = self._io_pool.get_next_actor()
                head_instance = TrainActor.options(**actor_options).remote(
                    **actor_arguments, io_actor=io_actor, id=actor_id
                )
                actors.append(head_instance)

        print_user_log_info(
            logger,
            f"Actor pool initialized with {len(actors)} training actors. "
            f"Worker training actors will be added automatically as compute pool scales.",
        )

        actor_pool = ActorPool(actors)
        actor_pool_scaler = ActorPoolScaler(
            actor_pool=actor_pool,
            actor_arguments=actor_arguments,
            io_pool=self._io_pool,
            scale_interval_seconds=10,
            execution_options=execution_options,
        )

        return (actor_pool, actors, actor_pool_scaler)

    def get_status(self) -> RunStatus:
        """
        Retrieves the overall status of the distributed execution.

        This property aggregates the status across all partitions to provide a summary
        of the entire run.

        Returns:
            RunStatus: The current status of the training process, which can be one of:
                - `IN_PROGRESS`: If the number of completed trainings doesn't match the number of partitions.
                - `SUCCESS`: If all model trainings are complete with the status "DONE".
                - `PARTIAL_FAILURE`: If some model trainings are complete, but not all.
                - `FAILURE`: If none of the model trainings has "DONE" status.
                - `CANCELLED`: If cancel api was already invoked.
        """
        if self._is_cancelled:
            return RunStatus.CANCELLED

        if self._total_processed != len(self._partition_details):
            return RunStatus.IN_PROGRESS

        if all(
            single_partition_detail.status == PartitionStatus.DONE
            for single_partition_detail in self._partition_details.values()
        ):
            return RunStatus.SUCCESS
        if any(
            single_partition_detail.status == PartitionStatus.DONE
            for single_partition_detail in self._partition_details.values()
        ):
            return RunStatus.PARTIAL_FAILURE

        return RunStatus.FAILURE

    def get_partition_details(self) -> Dict[str, SinglePartitionDetails]:
        if self._is_cancelled:
            # mark all pending/running items as cancelled for clarity
            for partition_id, mt_detail in self._partition_details.items():
                if mt_detail.status in [
                    PartitionStatus.PENDING,
                    PartitionStatus.RUNNING,
                ]:
                    mt_detail.set_status(PartitionStatus.CANCELLED)
                    mt_detail.set_logs("DPF cancelled.")
        return self._partition_details

    def get_processed_training_counts(self) -> int:
        return self._total_processed

    def get_total_counts(self) -> int:
        return len(self._partition_details)

    def get_processed_ingestion_counts(self) -> int:
        return self._tasks_submitted

    def _handle_actor_exception(
        self,
        e: Union[DPFUncaughtException, RayActorError, Exception],
        partition_id: str,
    ) -> Optional[SinglePartitionDetails]:
        """
        Handles unexpected errors from the Ray actor itself.

        TODO: We'll need to handle non-OOM exceptions, most of them due to node failures.
        """
        details_obj = SinglePartitionDetails(
            status=PartitionStatus.INTERNAL_ERROR,
            partition_id=partition_id,
        )
        logs = (
            "Detected OOM error. " + str(e)
            if isinstance(e, ray.exceptions.OutOfMemoryError)
            else f"Uncaught exception. {str(e)}"
        )
        details_obj.set_logs(logs)
        return details_obj

    def _on_task_ready(self, task: PartitionTask) -> None:
        """Callback invoked by PartitionSource when a task is ready to be submitted."""
        partition_id = task.partition_id
        if partition_id in self._partition_details:
            self._partition_details[partition_id].set_status(PartitionStatus.RUNNING)

        # Capture partition_id and object_ref_map in closure
        object_ref_map = self._object_ref_to_partition_id

        def wrapped_fn(actor, t):
            object_ref = actor.run.remote(t.partition_input)
            object_ref_map[object_ref] = t.partition_id
            return object_ref

        self._actor_pool.submit(wrapped_fn, task)
        self._tasks_submitted += 1

    def _serialize_states(self):
        """
        Serializes the trainer states to stage after trainer run finished.
        """
        states = {
            "partition_details": self._partition_details,
            "status": self.get_status(),
        }

        stage_path = construct_stage_path(
            run_id=self.run_id,
            stage_name=self._fully_qualified_stage_name,
        )

        serialize_and_upload_to_stage(
            stage_path=stage_path,
            filename=MMT_STATE_PICKLE_FILENAME,
            object_to_upload=states,
        )

    def _iter_results(self) -> Iterable[SinglePartitionDetails]:
        """Yields results from the actor pool while handling failures and retries."""
        completed_counter = 0  # this can be either success or failed train actor run
        total = len(self._partition_details)

        while completed_counter < total:
            if not self._actor_pool.has_next():
                # This could happen while waiting for background thread to ingest data.
                time.sleep(1)
                continue

            object_ref = self._actor_pool.get_next_unordered()
            partition_id = self._object_ref_to_partition_id[object_ref]
            try:
                result = ray.get(object_ref)
                completed_counter += 1
                yield result
            except (DPFUncaughtException, RayActorError, Exception) as e:
                processed_result = self._handle_actor_exception(e, partition_id)
                assert isinstance(processed_result, SinglePartitionDetails)
                completed_counter += 1
                yield processed_result
                result = processed_result

            if self._fail_fast and result.status in {
                PartitionStatus.FAILED,
                PartitionStatus.INTERNAL_ERROR,
            }:
                print_user_log_warn(
                    logger,
                    f"Partition '{partition_id}' failed. "
                    f"Terminating remaining partitions due to fail_fast=True.",
                )
                self.cancel()
                break

    def _handle_result(self, result: SinglePartitionDetails) -> None:
        partition_id = result.partition_id
        self._total_processed += 1

        if not partition_id:
            # Skip updating partition_details mapping when partition_id is not set, this could happen when non-user
            # exception is thrown (e.g. ray actor error)
            return

        self._partition_details[partition_id] = result

    def run(self):
        try:
            start_time = datetime.now()
            self._notebook_status_updater.start()
            self._actor_pool_scaler.start()

            print_user_log_info(
                logger,
                f"Starting DPF execution with {len(self._partition_details)} partitions...",
            )
            self._partition_source.start(on_task_ready=self._on_task_ready)

            for result in self._iter_results():
                assert isinstance(result, SinglePartitionDetails)
                self._handle_result(result)

        finally:
            try:
                self._serialize_states()
            except Exception as e:
                print_user_log_warn(
                    logger,
                    f"Error occurred during state serialization: {e}",
                )

            try:
                self._actor_pool_scaler.stop()
            except Exception as e:
                print_user_log_warn(
                    logger,
                    f"Error occurred while stopping actor pool scaler: {e}",
                )

            try:
                self._notebook_status_updater.stop()
            except Exception as e:
                print_user_log_warn(
                    logger,
                    f"Error occurred while stopping notebook status updater: {e}",
                )

            try:
                self._partition_source.stop()
            except Exception as e:
                print_user_log_warn(
                    logger,
                    f"Error occurred while stopping partition source: {e}",
                )

            try:
                self._io_pool.shutdown()
            except Exception as e:
                print_user_log_warn(
                    logger,
                    f"Error occurred while shutting down IO pool: {e}",
                )

            mmt_trainer_status = self.get_status()
            MLRSPrometheusMetrics.MMT_REQUESTS.value.labels(
                status=mmt_trainer_status.value
            ).inc()
            duration_in_seconds = (datetime.now() - start_time).total_seconds()
            MLRSPrometheusMetrics.MMT_DURATION.value.labels(
                status=mmt_trainer_status.value
            ).observe(duration_in_seconds)

            print_user_log_info(
                logger,
                f"Distributed partition function(DPF) execution took {duration_in_seconds} seconds to "
                f"process {len(self._partition_details)} partitions",
            )

    def cancel(self) -> None:
        try:
            for actor in self._actors:
                # Force killing of every ray actor. ray.cancel won't work for normal actor in this case.
                # https://docs.ray.io/en/latest/ray-core/actors/terminating-actors.html
                ray.kill(actor)
        except Exception as e:
            raise RuntimeError(f"Failed to cancel DPF run: {str(e)}")
        finally:
            self._is_cancelled = True
            self._notebook_status_updater.stop()
            self._actor_pool_scaler.stop()
            self._partition_source.stop()
            self._io_pool.shutdown()
