from typing import Callable, Optional, Any
import functools
import os
from snowflake.ml.data import DataConnector
from snowflake.ml.modeling.distributors.many_model.many_model_run import ManyModelRun
from snowflake.ml.modeling.distributors.distributed_partition_function.dpf import DPF
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.partition_context import (
    PartitionContext,
)
from snowflake.ml.modeling.distributors.many_model.utils import (
    ModelSerde,
    PickleSerde,
)
from snowflake import snowpark


class ManyModelInference(DPF):
    """
    Specialized distributed model inference across data partitions.

    ``ManyModelInference`` extends DPF for machine learning scenarios where you need to run inference
    using previously trained models on different data partitions. It automatically handles model loading,
    artifact retrieval, and provides framework-specific deserialization.

    Key features:
        * Automatic model loading from previous training runs
        * Built-in deserializers for popular frameworks (XGBoost, scikit-learn, PyTorch, TensorFlow)
          or use the same ``ModelSerde`` from training
        * Seamless integration with ``ManyModelTraining`` workflows
        * Built-in error handling for model loading
        * Consistent artifact naming and retrieval

    The user-provided inference function receives a pre-loaded model object along with the data.
    The class automatically handles loading the correct model for each partition.

    Note:
        Your inference function signature should be ``(data_connector, model, context)`` - all three
        parameters are automatically provided by the framework. You don't pass these values yourself.

    Note:
        This class is typically used as step 3 in the many model workflow after training models
        with ``ManyModelTraining``. See ``ManyModelTraining`` for the complete workflow.

    Example:
        Basic inference function where each partition gets only its own data subset and the system
        automatically loads the corresponding trained model for that partition:

        >>> def predict_with_model(data_connector, model, context):
        ...     df = data_connector.to_pandas()
        ...     X = df[['feature1', 'feature2', 'feature3']]
        ...
        ...     predictions = model.predict(X)
        ...     results = df.copy()
        ...     results['predictions'] = predictions
        ...
        ...     context.upload_to_stage(results, "predictions.csv")
        ...     return results
        ...
        >>> inference = ManyModelInference(
        ...     predict_with_model,
        ...     "model_stage",
        ...     training_run_id="regional_models_v1"
        ... )
        >>> run = inference.run(
        ...     partition_by="region",
        ...     snowpark_dataframe=new_data,
        ...     run_id="predictions_2024"
        ... )
        >>> run.wait()
    """

    def __init__(
        self,
        inference_func: Callable[[DataConnector, Any, PartitionContext], Any],
        stage_name: str,
        training_run_id: str,
        serde: Optional[ModelSerde] = None,
    ) -> None:
        """
        Initialize ManyModelInference.

        Args:
            inference_func (Callable[[DataConnector, Any, PartitionContext], Any]): User function that takes
                           (DataConnector, model, PartitionContext) and returns results.
                           All three parameters are automatically provided by the framework.
                           Follows the same signature pattern as regular DPF functions for consistency.
            stage_name (str): Stage name where training artifacts are stored
            training_run_id (str): Run ID from the training phase to load models from
            serde (Optional[ModelSerde]): ModelSerde instance for handling model deserialization.
                   Built-in options: PickleSerde (XGBoost, scikit-learn), TorchSerde, TensorFlowSerde,
                   or use the same ModelSerde implementation from training. Defaults to PickleSerde.

        Examples:
            Default pickle deserialization for XGBoost models:

            >>> def predict_with_xgb(data_connector, model, context):
            ...     df = data_connector.to_pandas()
            ...     X = df[['feature1', 'feature2']]
            ...
            ...     predictions = model.predict(X)
            ...     results = df.copy()
            ...     results['predictions'] = predictions
            ...     results['partition_id'] = context.partition_id
            ...
            ...     # Two persistence strategies (choose based on your use case):
            ...
            ...     # Strategy 1: Stage artifacts - for framework management and retrieval
            ...     context.upload_to_stage(results, "predictions.csv",
            ...         write_function=lambda df, path: df.to_csv(path, index=False))
            ...
            ...     # Strategy 2: Snowflake table - uses bounded session pool to avoid session limits
            ...     context.with_session(lambda session:
            ...         session.create_dataframe(results)
            ...             .write.mode("append")
            ...             .save_as_table("my_predictions_table")
            ...     )
            ...
            ...     return predictions
            ...
            >>> inference = ManyModelInference(predict_with_xgb, "models_stage", "training_run_v1")

            PyTorch model inference:

            >>> def predict_with_pytorch(data_connector, model, context):
            ...     import torch
            ...
            ...     df = data_connector.to_pandas()
            ...     # ... prepare data for PyTorch ...
            ...
            ...     model.eval()
            ...     with torch.no_grad():
            ...         predictions = model(torch.tensor(X_test, dtype=torch.float32))
            ...
            ...     context.upload_to_stage(predictions.numpy(), "predictions.pkl")
            ...     return predictions
            ...
            >>> from snowflake.ml.modeling.distributors.many_model import TorchSerde
            >>> inference = ManyModelInference(
            ...     predict_with_pytorch, "models_stage", "training_run_v1", serde=TorchSerde())

            TensorFlow model inference:

            >>> def predict_with_tf(data_connector, model, context):
            ...     import tensorflow as tf
            ...
            ...     df = data_connector.to_pandas()
            ...     # ... prepare data for TensorFlow ...
            ...
            ...     predictions = model.predict(X_test)
            ...     context.upload_to_stage(predictions, "predictions.pkl")
            ...     return predictions
            ...
            >>> from snowflake.ml.modeling.distributors.many_model import TensorFlowSerde
            >>> inference = ManyModelInference(
            ...     predict_with_tf, "models_stage", "training_run_v1", serde=TensorFlowSerde())

            Custom deserialization for specialized model formats:

            >>> # Using the same ScikitLearnSerde from training
            >>> class ScikitLearnSerde(ModelSerde):
            ...     @property
            ...     def filename(self) -> str:
            ...         return "sklearn_model.joblib"
            ...
            ...     def write(self, model, file_path: str) -> None:
            ...         import joblib
            ...         model_data = {
            ...             'model': model,
            ...             'feature_names': getattr(model, 'feature_names_in_', None),
            ...             'model_type': type(model).__name__
            ...         }
            ...         joblib.dump(model_data, file_path)
            ...
            ...     def read(self, file_path: str):
            ...         import joblib
            ...         return joblib.load(file_path)
            >>>
            >>> def predict_with_sklearn(data_connector, model_data, context):
            ...     df = data_connector.to_pandas()
            ...     X = df[['feature1', 'feature2']]
            ...
            ...     # Access model and metadata
            ...     model = model_data['model']
            ...     model_type = model_data['model_type']
            ...
            ...     predictions = model.predict(X)
            ...
            ...     # Create results with model metadata
            ...     results_df = df.copy()
            ...     results_df['predictions'] = predictions
            ...     results_df['model_type'] = model_type
            ...     results_df['partition_id'] = context.partition_id
            ...
            ...     # Hybrid persistence strategy - different data types to different locations:
            ...
            ...     # Detailed metadata to stage (for debugging and audit)
            ...     metadata = {'model_type': model_type, 'feature_count': len(X.columns)}
            ...     context.upload_to_stage(metadata, "model_metadata.json",
            ...         write_function=lambda obj, path: json.dump(obj, open(path, 'w')))
            ...
            ...     # Predictions with basic metadata to table (uses bounded session pool)
            ...     context.with_session(lambda session:
            ...         session.create_dataframe(results_df)
            ...             .write.mode("append")
            ...             .save_as_table("sklearn_predictions")
            ...     )
            ...
            ...     return predictions
            ...
            >>> inference = ManyModelInference(
            ...     predict_with_sklearn, "models_stage", "training_run_v1", serde=ScikitLearnSerde())
        """
        self._inference_func = inference_func
        self._training_run_id = training_run_id
        self._serde = serde if serde is not None else PickleSerde()

        # Create wrapped function that handles model loading
        wrapped_func = self._create_wrapped_inference_function()

        # Initialize parent DPF with the wrapped function
        super().__init__(func=wrapped_func, stage_name=stage_name)

    def _create_wrapped_inference_function(
        self,
    ) -> Callable[[DataConnector, PartitionContext], Any]:
        """Create a wrapped function that handles automatic model loading."""

        @functools.wraps(self._inference_func)
        def wrapped_inference_func(
            data_connector: DataConnector, context: PartitionContext
        ) -> Any:
            # Construct the stage path for the training run
            training_stage_path = os.path.join(
                self._fully_qualified_stage_name,
                self._training_run_id,
                context.partition_id,
            )

            # Load the model from the training run using bounded IO actor pool
            try:
                model = context.download_from_stage(
                    self._serde.filename,
                    stage_path=training_stage_path,
                    read_function=self._serde.read,
                )
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load model '{self._serde.filename}' for partition '{context.partition_id}' "
                    f"from training run '{self._training_run_id}': {e}"
                )

            return self._inference_func(data_connector, model, context)

        return wrapped_inference_func

    def run(
        self,
        *,
        partition_by: str,
        snowpark_dataframe: snowpark.DataFrame,
        run_id: str,
        on_existing_artifacts: str = "error",
        execution_options: Optional[ExecutionOptions] = None,
    ) -> ManyModelRun:
        """
        Execute distributed model inference across data partitions.

        Loads previously trained models from the specified training run and runs inference
        on each partition of the new data. Models are automatically loaded and passed to
        the user-provided inference function.

        Args:
            partition_by (str): Column name to partition the DataFrame by. Must match the
                partitioning used during training to ensure correct model loading.
            snowpark_dataframe (snowpark.DataFrame): DataFrame containing data for inference.
            run_id (str): Unique identifier for this inference run. Each inference run should
                have a unique ID to avoid confusion and enable proper tracking.
            on_existing_artifacts (str, optional): Action for existing artifacts. Defaults to "error".

                * ``"error"``: Raises error if inference artifacts already exist
                * ``"overwrite"``: Replaces existing inference artifacts

            execution_options (ExecutionOptions, optional): Configuration for distributed execution.

        Returns:
            ManyModelRun: Enhanced run handle with model-specific capabilities for accessing
            inference results and monitoring execution progress.

        Note:
            While inference loads existing models (read-only operation), it still creates
            execution logs and result artifacts. Using unique ``run_id`` values helps
            prevent accidental overwrites and improves traceability.

        Example:
            >>> inference = ManyModelInference(my_predict_func, "models_stage", "training_run_v1")
            >>> run = inference.run(
            ...     partition_by="store_id",
            ...     snowpark_dataframe=new_sales_data,
            ...     run_id="predictions_2024"
            ... )
            >>> run.wait()
        """
        print(f"Starting many model inference with run_id: {run_id}")
        print(f"Loading models from training run: {self._training_run_id}")
        print(f"Model file: {self._serde.filename}")
        print(f"Serde: {self._serde.__class__.__name__}")

        dpf_run = super().run(
            partition_by=partition_by,
            snowpark_dataframe=snowpark_dataframe,
            run_id=run_id,
            on_existing_artifacts=on_existing_artifacts,
            execution_options=execution_options,
        )

        return ManyModelRun(dpf_run, serde=self._serde)
