from unittest import mock
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    get_actors_per_node,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
)


class TestGetActorsPerNode:
    """Test suite for get_actors_per_node function"""

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_no_execution_options(self, mock_get_resources):
        """Test that function returns 1 when no execution_options provided"""
        result = get_actors_per_node(execution_options=None)
        assert result == 1
        # Should not call get_total_node_resources when execution_options is None
        mock_get_resources.assert_not_called()

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_default_with_no_gpus(self, mock_get_resources):
        """Test default behavior with CPU-only node"""
        mock_get_resources.return_value = {"CPU": 8, "GPU": 0}
        execution_options = ExecutionOptions()

        result = get_actors_per_node(execution_options)

        # With no GPUs, should return 1 (all CPUs for one actor)
        assert result == 1

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_default_with_gpus(self, mock_get_resources):
        """Test default behavior with GPU node"""
        mock_get_resources.return_value = {"CPU": 16, "GPU": 4}
        execution_options = ExecutionOptions()

        result = get_actors_per_node(execution_options)

        # With 4 GPUs, default should be 1 GPU per worker = 4 actors
        # CPUs: 16/4 = 4 actors
        # Take minimum (both are 4) = 4 actors
        assert result == 4

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_custom_cpus_per_worker(self, mock_get_resources):
        """Test with custom num_cpus_per_worker"""
        mock_get_resources.return_value = {"CPU": 16, "GPU": 0}
        execution_options = ExecutionOptions(num_cpus_per_worker=4)

        result = get_actors_per_node(execution_options)

        # 16 CPUs / 4 CPUs per worker = 4 actors
        assert result == 4

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_custom_cpus_and_gpus_per_worker(self, mock_get_resources):
        """Test with both custom CPU and GPU allocation"""
        mock_get_resources.return_value = {"CPU": 16, "GPU": 4}
        execution_options = ExecutionOptions(
            num_cpus_per_worker=2, num_gpus_per_worker=1
        )

        result = get_actors_per_node(execution_options)

        # 16 CPUs / 2 CPUs per worker = 8 actors
        # 4 GPUs / 1 GPU per worker = 4 actors
        # Take minimum = 4 actors
        assert result == 4

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_minimum_one_actor(self, mock_get_resources):
        """Test that function always returns at least 1 actor"""
        mock_get_resources.return_value = {"CPU": 1, "GPU": 0}
        execution_options = ExecutionOptions(num_cpus_per_worker=8)

        result = get_actors_per_node(execution_options)

        # Even if calculation gives 0, should return at least 1
        assert result == 1

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_zero_gpus_per_worker_with_gpus_available(self, mock_get_resources):
        """Test explicitly setting num_gpus_per_worker to 0"""
        mock_get_resources.return_value = {"CPU": 8, "GPU": 4}
        execution_options = ExecutionOptions(
            num_cpus_per_worker=2, num_gpus_per_worker=0
        )

        result = get_actors_per_node(execution_options)

        # 8 CPUs / 2 CPUs per worker = 4 actors
        # GPUs per worker is 0, so no GPU constraint
        assert result == 4

    @mock.patch(
        "snowflake.ml.modeling.distributors.distributed_partition_function.utils.get_total_node_resources"
    )
    def test_large_node_configuration(self, mock_get_resources):
        """Test with large node (e.g., A100 GPU node)"""
        mock_get_resources.return_value = {"CPU": 96, "GPU": 8}
        execution_options = ExecutionOptions(
            num_cpus_per_worker=12, num_gpus_per_worker=1
        )

        result = get_actors_per_node(execution_options)

        # 96 CPUs / 12 CPUs per worker = 8 actors
        # 8 GPUs / 1 GPU per worker = 8 actors
        # Take minimum = 8 actors
        assert result == 8
