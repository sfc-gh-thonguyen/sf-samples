import os
from typing import Any, Callable, Dict, Optional, Union, List
import uuid
from datetime import datetime
import asyncio
import queue

import lightgbm as lgb
import pandas as pd
import numpy as np
import cloudpickle as cp
from lightgbm import LGBMClassifier, LGBMRegressor
from scipy.sparse import csr_matrix
from dataclasses import dataclass
import traceback

from sklearn.preprocessing import LabelEncoder
from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.modeling.distributors.base_estimator import (
    BaseScalingConfig,
    BaseEstimator,
)

from snowflake.runtime.utils.async_utils import safe_run_awaitable, aio_queue_reader
from snowflake.runtime.utils.data_connector_utils import (
    replace_data_connector_ingestor_with_ray_ingestor,
)
from snowflake.runtime.utils.logger import get_logger
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df
from web.request_handler import LGBMTrainingHandler

logger = get_logger()

REGRESSION_OBJECTIVES = [
    "regression",
    "regression_l1",
    "huber",
    "fair",
    "poisson",
    "quantile",
    "mape",
    "gamma",
    "tweedie",
    "regression_l2",
    "l2",
    "mean_squared_error",
    "mse",
    "l2_root",
    "root_mean_squared_error",
    "rmse",
    "l1",
    "mean_absolute_error",
    "mae",
    "mean_absolute_percentage_error",
]
CLASSIFIER_OBJECTIVES = [
    "binary",
    "multiclass",
    "softmax",
    "multiclassova",
    "multiclass_ova",
    "ova",
    "ovr",
    "cross_entropy",
    "xentropy",
    "cross_entropy_lambda",
    "xentlambda",
]


@dataclass
class LightGBMScalingConfig(BaseScalingConfig):
    """Scaling config for LightGBM Estimator.

    Attributes:
        num_workers (int): The number of worker processes to use. Default is -1, which utilizes all available resources.
        num_cpu_per_worker (int): Number of CPUs allocated per worker. Default is -1, which means all available
            resources.
        use_gpu (Optional[bool]): Whether to use GPU for training. Default is None, allowing the estimator to choose
            automatically based on the environment.
    """

    num_workers: int = -1
    num_cpu_per_worker: int = -1
    use_gpu: Optional[bool] = None


class LightGBMEstimator(BaseEstimator):
    """LightGBM Estimator for distributed training and inference.

    Args:
        n_estimators (int): Number of estimators. Default is 100.
        objective (str): The objective function used for training. 'regression'[Default] for regression,
            'binary' for binary classification, 'multiclass' for multi-class classification.
        params (Optional[Dict[str, Any]], optional):
            Additional parameters for LightGBM. Defaults to None.
            Some key params are:

            * boosting: The type of boosting to use. Use "gbdt"[Default] for Gradient Boosting Decision Tree.
            * num_leaves: The maximum number of leaves in one tree. Default is 31.
            * max_depth: The maximum depth of the tree. Default is -1, which means no limit.
            * early_stopping_rounds: Activates early stopping. Default is 0, means no early stopping.

            Full list of supported parameter can be found at https://lightgbm.readthedocs.io/en/latest/Parameters.html.
        scaling_config (Optional[LightGBMScalingConfig], optional):
            Configuration for scaling. Defaults to None. If None, the estimator will use all available resources.
        callbacks (Optional[List[Callable[..., Any]]]): List of callbacks to be applied during training.
            For more information, refer to https://lightgbm.readthedocs.io/en/stable/Python-API.html#callbacks.
    """

    def __init__(
        self,
        n_estimators: int = 100,
        objective: str = "regression",
        params: Optional[Dict[str, Any]] = None,
        scaling_config: Optional[LightGBMScalingConfig] = None,
        callbacks: Optional[List[Callable[..., Any]]] = None,
    ) -> None:
        self.params = {"n_estimators": n_estimators, "objective": objective}
        for key, value in (params or {}).items():
            self.params[key] = value

        self.scaling_config = scaling_config or LightGBMScalingConfig(
            num_workers=-1, num_cpu_per_worker=-1, use_gpu=None
        )
        self.callbacks = callbacks

        self._trained_booster: lgb.Booster = None
        self._eval_results: Optional[Dict[str, Any]] = None
        self._sklearn_estimator: Optional[Union[LGBMRegressor, LGBMClassifier]] = None
        self._input_cols: Optional[List[str]] = None
        self._label_col: Optional[str] = None

    def _get_estimator(
        self, params: dict
    ) -> Optional[Union[LGBMClassifier, LGBMRegressor]]:
        objective = self.params["objective"]
        if objective in REGRESSION_OBJECTIVES:
            return LGBMRegressor(**params)
        elif objective in CLASSIFIER_OBJECTIVES:
            return LGBMClassifier(**params)

        return None

    def _to_sklearn_estimator(
        self,
        y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
    ) -> Optional[Union[LGBMClassifier, LGBMRegressor]]:
        """This method converts the distributed LGBM trainer into an sklearn compatible LGBM object.

        Only Regressors and Classifiers are supported in sklearn. This is used exclusively to facilitate logging
        LGBM estimators that are part of an sklearn Pipeline into the Snowflake model registry.
        """
        bst = self.get_booster()
        clf = self._get_estimator(bst.params)

        if clf:
            clf._Booster = bst
            clf.fitted_ = True

            if self.params["objective"] in CLASSIFIER_OBJECTIVES:
                if isinstance(y, csr_matrix):
                    unique_values = np.unique(y.data)
                    num_classes = len(unique_values)
                else:
                    # For classifiers, the sklearn API requires that the number of classes is specified. This is not
                    # available on the booster. This is how LGBM extracts that metadata in their sklearn API:
                    # https://github.com/microsoft/LightGBM/blob/master/python-package/lightgbm/sklearn.py#L1376
                    num_classes = len(LabelEncoder().fit(y).classes_)

                clf._n_classes = num_classes

            clf._n_features = bst.num_feature()
            return clf
        return None

    def get_booster(self) -> lgb.Booster:
        """Returns the trained LightGBM Booster.

        Returns:
            lgb.Booster: The trained booster model.

        Raises:
            ValueError: If the model has not been trained yet.
        """
        if self._trained_booster is None:
            raise ValueError("Model is not trained yet. Please call fit first.")
        return self._trained_booster

    def fit(
        self,
        dataset: Union[DataConnector, pd.DataFrame, pd.Series, np.ndarray, csr_matrix],
        y: Optional[Union[pd.DataFrame, pd.Series, np.ndarray, csr_matrix]] = None,
        input_cols: Optional[List[str]] = None,
        label_col: Optional[str] = None,
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
    ):
        """Train the LightGBM model.

        This method trains the LightGBM model using the provided dataset and labels.
        It can accept various data formats and supports validation datasets for monitoring
        training performance. The model can also be initialized from a pre-trained model
        for warm starts.

        Args:
            dataset (Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray]):
                the dataset to train the model. If DataConnector is provided, input_cols and label_col are required.
                if in-memory data is provided (pd.DataFrame, pd.Series, csr_matrix, np.ndarray), y should be provided
                as well.
            y (Optional[Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray]]):
                If dataset is one of the in-memory data type, y should be provided.
                If dataset is DataConnector, y should not be provided. Instead, dataset should contain both input_cols
                and label_col.
            input_cols (Optional[List[str]]):
                the input columns to train the model. Required when `dataset` is DataConnector.
            label_col (Optional[str]):
                the label column to train the model. Required when DataConnector is provided.
            eval_set (Optional[DataConnector], optional):
                An optional evaluation dataset to monitor performance during training. Defaults to None.
            init_model (Optional[lgb.Booster], optional):
                An optional pre-trained LightGBM model for warm starting the training process. Defaults to None.

        Returns:
            The trained LightGBM model.

        Raises:
            ValueError: If input validation fails or if the model cannot be trained.
        """
        self._validate_fit_input(dataset, y, input_cols, label_col)

        MLRSPrometheusMetrics.TRAIN_ATTEMPTS.value.inc()
        MLRSPrometheusMetrics.TRAIN_LGBM.value.inc()

        request_id = uuid.uuid4().hex

        if isinstance(dataset, DataConnector):
            # _validate_fit_input already validated input_cols and label_col, but mypy doesn't know that
            assert input_cols is not None and label_col is not None
            self._input_cols = input_cols
            self._label_col = label_col
            return safe_run_awaitable(
                self._fit(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    eval_set=eval_set,
                    init_model=init_model,
                    request_id=request_id,
                )
            )
        else:
            return self._fit_in_memory_data(
                X=dataset,
                y=y,
                request_id=request_id,
                eval_set=eval_set,
                init_model=init_model,
            )

    async def _fit(
        self,
        dataset: DataConnector,
        input_cols: List[str],
        label_col: str,
        request_id: str,
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
    ):
        start_time = datetime.now()
        comm_queue: queue.Queue = queue.Queue()

        training_handler = LGBMTrainingHandler(
            request_id=request_id,
            num_workers=self.scaling_config.num_workers,
            num_cpu_per_worker=self.scaling_config.num_cpu_per_worker,
            use_gpu=self.scaling_config.use_gpu,
        )

        dataset = replace_data_connector_ingestor_with_ray_ingestor(dataset)
        eval_set = (
            replace_data_connector_ingestor_with_ray_ingestor(eval_set)
            if eval_set is not None
            else None
        )

        process_completed = False
        model_obj = None
        eval_results = None
        train_task = None
        try:
            loop = asyncio.get_event_loop()
            train_task = loop.create_task(
                training_handler.train(
                    comm_queue=comm_queue,
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=self.params,
                    eval_set=eval_set,
                    init_model=init_model,
                    callbacks=self.callbacks,
                )
            )
            # Read the message from the comm queue without blocking
            async for message in aio_queue_reader(comm_queue):
                if "done" in message and message["done"]:
                    if "trained_model" in message:
                        model_ref = message["trained_model"]
                        eval_results_ref = message.get("eval_results")
                        # There are two cases where this estimator is running from
                        # 1. Stand alone Ray task
                        # 2. Running in another Ray task
                        if isinstance(model_ref, str):
                            model_obj = lgb.Booster(model_file=model_ref)
                        else:
                            model_obj = model_ref

                        if isinstance(eval_results_ref, str):
                            if os.path.exists(eval_results_ref):
                                with open(eval_results_ref, "rb") as f:
                                    eval_results = cp.load(f)
                        elif eval_results_ref is not None:
                            eval_results = eval_results_ref

                        MLRSPrometheusMetrics.TRAIN_SUCCESS.value.inc()
                        MLRSPrometheusMetrics.TRAIN_DURATION_SUCCESS.value.observe(
                            (datetime.now() - start_time).total_seconds()
                        )
                    elif "exception" in message:
                        print(f"Training failed: {repr(message['exception'])}")
                        MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
                else:
                    log_lines = message.get("log_lines")
                    if log_lines:
                        print(log_lines)

            process_completed = True
        except Exception as e:
            logger.error(f"Error while training: {repr(e)}")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_time).total_seconds()
            )
            if not process_completed:
                logger.info(f"{request_id}: train request abandoned")
                MLRSPrometheusMetrics.TRAIN_DURATION_ABANDONED.value.observe(
                    (datetime.now() - start_time).total_seconds()
                )
                training_handler.close()
                if train_task is not None:
                    train_task.cancel()

            if model_obj is not None:
                self._trained_booster = model_obj
                self._eval_results = eval_results
                return model_obj
            raise RuntimeError(
                "Training failed, please check the log above for more information"
            )

    def _fit_in_memory_data(
        self,
        X: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        request_id: str,
        eval_set: Optional[DataConnector] = None,
        init_model: Optional[lgb.Booster] = None,
    ):
        start_time = datetime.now()

        training_handler = LGBMTrainingHandler(
            request_id=request_id,
            num_workers=self.scaling_config.num_workers,
            num_cpu_per_worker=self.scaling_config.num_cpu_per_worker,
            use_gpu=self.scaling_config.use_gpu,
        )

        process_completed = False
        train_result = None
        try:
            train_result = training_handler.train_with_in_memory_data(
                X=X,
                y=y,
                params=self.params,
                eval_set=eval_set,
                init_model=init_model,
                callbacks=self.callbacks,
            )
            process_completed = True
            if train_result and train_result.trained_model is not None:
                self._trained_booster = train_result.trained_model
                try:
                    # Create sklearn estimator for interoperability with sklearn pipelines in the model registry.
                    self._sklearn_estimator = self._to_sklearn_estimator(y=y)
                except Exception as e:
                    logger.warning(
                        f"Unable to convert to sklearn API. This will not be compatible with sklearn "
                        f"pipelines in the model registry. Failed with error {e}"
                    )

                return train_result.trained_model
        except KeyboardInterrupt as e:
            logger.info(f"Training interrupted: {repr(e)}")
            raise e
        except Exception:
            logger.exception("Error while training")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
            # why using traceback.print_exc() instead of using chained exception?
            # becuase notebook does not support chaining
            # see snowflake notebook bug report at
            # https://snowflakecomputing.atlassian.net/browse/SNOW-1874911
            traceback.print_exc()
            raise RuntimeError("Training failed, please see log above for details")
        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_time).total_seconds()
            )
            if not process_completed:
                logger.info(f"{request_id}: train request abandoned")
                MLRSPrometheusMetrics.TRAIN_DURATION_ABANDONED.value.observe(
                    (datetime.now() - start_time).total_seconds()
                )
                training_handler.close()

    # This is a simple in memory predict to unblock sklearn pipeline.
    # We should have a more optimized predict function with bulk inference.
    def predict(
        self,
        X: Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        raw_score: bool = False,
        start_iteration: int = 0,
        num_iteration: Optional[int] = None,
        pred_leaf: bool = False,
        pred_contrib: bool = False,
        validate_features: bool = True,
        output_col_name: Optional[str] = "PREDICTIONS",
    ) -> Union[np.ndarray, pd.DataFrame]:
        """Make predictions using the trained LightGBM model.

        This function utilizes the trained model to generate predictions on the provided dataset.
        It supports various options for prediction behavior, such as returning raw scores,
        predicting leaf indices, and validating features.

        Args:
            X (Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray]):
                The input data for which predictions are to be made.
            raw_score (bool, optional):
                If True, returns the raw scores from the model. Defaults to False.
            start_iteration (int, optional): The index of the iteration to start predictions from. If <= 0, starts from
                the first iteration. Defaults to 0.
            num_iteration (Optional[int], optional):
                The total number of iterations to use for predictions. If None and if the best iteration exists while
                start_iteration <= 0, the best iteration is used; otherwise, all iterations from start_iteration are
                used. If <= 0, all iterations from start_iteration are used. Defaults to None.
            pred_leaf (bool, optional):
                If True, predicts the leaf index instead of the actual prediction. Defaults to False.
            pred_contrib (bool, optional):
                If True, predicts feature contributions instead of the actual prediction. Defaults to False.
            validate_features (bool, optional):
                If True, validates that the features in X match those used during training. Defaults to True.
            output_col_name (Optional: str): Only required for DataConnector input. Defaults to "PREDICTIONS". This is
                necessary because DataConnector row order is not deterministic, so predictions must be co-located with
                their input features.

        Returns:
            (Union[np.ndarray, pd.DataFrame]):
            The prediction result. Will be a numpy array if an in memory dataset was passed. If a DataConnector is
            passed, the full dataframe is returned with predictions specified in "PREDICTIONS" column

        Raises:
            ValueError: If the model has not been trained yet.
        """
        booster = self.get_booster()

        is_data_connector = isinstance(X, DataConnector)

        if is_data_connector:
            # Make sure that only input columns are used for inference, data connector could contain label column.
            X = replace_data_connector_ingestor_with_ray_ingestor(X).to_pandas()[
                self._input_cols
            ]

        X = convert_to_pandas_df(X)

        results = booster.predict(
            data=X,
            start_iteration=start_iteration,
            num_iteration=num_iteration,
            raw_score=raw_score,
            pred_leaf=pred_leaf,
            pred_contrib=pred_contrib,
            validate_features=validate_features,
        )

        X[output_col_name] = results

        return results if not is_data_connector else X

    def get_params(self, deep=True) -> Dict[str, Any]:
        """
        Get parameters for this estimator.

        This is needed by sklearn when using CR estimator in a pipeline. This method is used to get the parameters

        Args:
            deep (bool): If True, will return the parameters for this estimator and
                contained subobjects that are estimators.
                However, since we don't have any subobjects in our class, this parameter is not used.
        """
        return self.params
