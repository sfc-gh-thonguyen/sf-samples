# Estimator
from xgboost import XGBClassifier, XGBRegressor, XGBRanker

from web.request_handler import XGBTrainingHandler
from snowflake.runtime.utils.async_utils import safe_run_awaitable, aio_queue_reader
from snowflake.runtime.utils.logger import get_logger
from snowflake.runtime.utils.data_connector_utils import (
    replace_data_connector_ingestor_with_ray_ingestor,
)
from snowflake.ml.modeling.distributors.base_estimator import (
    BaseEstimator,
    BaseScalingConfig,
)
from snowflake.ml.data.data_connector import DataConnector
import os
import uuid
import asyncio
import xgboost as xgb
import queue
from datetime import datetime
from typing import Optional, List, Dict, Union, Any, Tuple
from dataclasses import dataclass
import traceback

import pandas as pd
from scipy.sparse import csr_matrix
import numpy as np
from snowflake.runtime.utils.metrics import MLRSPrometheusMetrics
import cloudpickle as cp
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df

logger = get_logger()


@dataclass
class XGBScalingConfig(BaseScalingConfig):
    """
    Scaling config for XGBoost Estimator

    Attributes:
        num_workers (int): Number of workers to use for distributed training. Default is -1, meaning the estimator will
            use all available workers.
        num_cpu_per_worker (int): Number of CPU cores to use per worker. Default is -1, meaning the estimator will use
            all available CPU cores.
        use_gpu (Optional[bool]): Whether to use GPU for training. If None, the estimator will choose to use GPU or not
            based on the environment.
    """

    num_workers: int = -1
    num_cpu_per_worker: int = -1
    use_gpu: Optional[bool] = None


class XGBEstimator(BaseEstimator):
    def __init__(
        self,
        n_estimators: Optional[int] = 100,
        objective: Optional[str] = "reg:squarederror",
        params: Optional[Dict] = None,
        scaling_config: Optional[XGBScalingConfig] = None,
        callbacks: Optional[List[xgb.callback.TrainingCallback]] = None,
    ) -> None:
        """
        Xgboost Estimator that supports distributed training.

        Args:
            n_estimators (int): Number of estimators. Default is 100.
            objective (str): The objective function used for training. 'reg:squarederror'[Default] for regression,
                'binary:logistic' for binary classification, 'multi:softmax' for multi-class classification.
            params (Optional[dict]): Additional parameters for the XGBoost Estimator.
                Some key parameters are:

                * booster: Specify which booster to use: gbtree[Default], gblinear or dart.
                * max_depth: Maximum depth of a tree. Default is 6.
                * max_leaves: Maximum number of nodes to be added. Default is 0.
                * max_bin: Maximum number of bins that continuous feature values will be bucketed in. Default is 256
                * eval_metric: Evaluation metrics for validation data.

                Full list of supported parameter can be found at https://xgboost.readthedocs.io/en/stable/parameter.html
                Note: If params dict contains keys 'n_estimators' or 'objective', they will override the value provided
                by n_estimators and objective arguments.
            scaling_config (Optional[XGBScalingConfig]): Scaling config for XGBoost Estimator.  Defaults to None.
                If None, the estimator will use all available resources.
            callbacks (Optional[List[xgboost.callback.TrainingCallback]]): List of callbacks to be applied during
                training. For more information, refer to https://xgboost.readthedocs.io/en/stable/python/callbacks.html.
        """

        self.params = {
            "n_estimators": n_estimators,
            "objective": objective,
        }
        for k, v in (params or {}).items():
            self.params[k] = v

        self.scaling_config = scaling_config or XGBScalingConfig(
            num_workers=-1, num_cpu_per_worker=-1, use_gpu=None
        )
        self.callbacks = callbacks

        self._trained_booster: Optional[xgb.Booster] = None
        self._eval_results: Optional[Dict[str, Any]] = None
        self._sklearn_estimator: Optional[
            Union[XGBClassifier, XGBRegressor, XGBRanker]
        ] = None
        self._input_cols: Optional[List[str]] = None
        self._label_col: Optional[str] = None

    def _get_estimator(
        self, y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray], params: dict
    ) -> Optional[Union[XGBClassifier, XGBRegressor, XGBRanker]]:
        # TODO: Add support for `rank` regressors, which require accepting qid parameter at time of fit.
        objective = self.params["objective"]
        if not isinstance(objective, str):
            raise ValueError(
                f"Unexpected objective {objective}. Objective must be a string"
            )

        if "reg" in objective:
            return XGBRegressor(**params)
        elif "multi" in objective or "binary" in objective:
            clf = XGBClassifier(**params)
            # n_classes_ is not contained in the booster. This is calculated by xgboost inside their sklearn estimator
            # here: https://github.com/dmlc/xgboost/blob/master/python-package/xgboost/sklearn.py#L1525
            if isinstance(y, csr_matrix):
                unique_values = np.unique(y.data)
                num_unique_values = len(unique_values)
            else:
                num_unique_values = len(np.unique(np.asarray(y)))
            clf.n_classes_ = num_unique_values
            return clf
        elif "rank" in objective:
            return XGBRanker(**params)

        return None

    def _to_sklearn_estimator(
        self, y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray]
    ) -> Optional[Union[XGBClassifier, XGBRegressor, XGBRanker]]:
        """
        This method converts the distributed XGBoost trainer into an sklearn compatible XGBoost object.

        Only Regressors and Classifiers are supported in sklearn. This is used exclusively to facilitate logging
        XGBoost estimators that are part of an sklearn Pipeline into the Snowflake model registry.
        """
        bst = self.get_booster()
        clf = self._get_estimator(y, self.get_params())
        if clf:
            clf._Booster = bst
            clf._old_predict = clf.predict
            clf.predict = lambda X, *args, **kwargs: clf._old_predict(
                pd.DataFrame.sparse.from_spmatrix(
                    X, columns=[str(i) for i in range(X.shape[1])]
                )
                if isinstance(X, csr_matrix)
                else X,
                *args,
                **kwargs,
            )
            return clf
        return None

    def get_booster(self) -> xgb.Booster:
        """
        Get the trained booster.

        Returns:
            xgb.Booster: The trained booster.

        Raises:
            ValueError: If the model is not trained yet.
        """

        if self._trained_booster is None:
            raise ValueError("Model is not trained yet. Please call fit first.")
        return self._trained_booster

    def fit(
        self,
        dataset: Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Optional[Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray]] = None,
        input_cols: Optional[List[str]] = None,
        label_col: Optional[str] = None,
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        xgb_model: Optional[xgb.Booster] = None,
    ) -> xgb.Booster:
        """
        There are two ways to train a XGBoost model:

            1) Train with Snowflake DataConnector
                The DataConnector should contains a single source with both input data and label data. DataConnector
                can be created via `DataConnector.from_dataframe` for snowpark dataframe or `DataConnector.from_dataset`

            2) Train with in-memory data
                The input data should be provided as one of the in-memory data type:(pd.DataFrame, pd.Series,
                csr_matrix, np.ndarray). When training with in-memory data, y should be provided as well

        Args:
            dataset (Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray]): The dataset to train the
                model. If DataConnector is provided, input_cols and label_col are required. Otherwise, y is required.
            y (Optional[Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray]]): If dataset is one of the in-memory
                data types y is required. If dataset is DataConnector, y should not be provided.
            input_cols (Optional[List[str]]): The input columns to train the model. Required when `dataset` is
                DataConnector.
            label_col (Optional[str]): The label column to train the model. Required when DataConnector is provided.
            eval_set (Optional[DataConnector]): The evaluation dataset.
            verbose_eval (Optional[Union[bool, int]]): Whether to print the evaluation result. For detailed
                documentation, please refer to xgboost.train documentation.
            xgb_model (Optional[xgb.Booster]): The initial model to start with.

        Returns:
            xgb.Booster: The trained model.
        """

        self._validate_fit_input(dataset, y, input_cols, label_col)
        if verbose_eval is not None and eval_set is None:
            raise ValueError("verbose_eval is only valid when eval_set is provided")

        MLRSPrometheusMetrics.TRAIN_ATTEMPTS.value.inc()
        MLRSPrometheusMetrics.TRAIN_XGB.value.inc()

        request_id = uuid.uuid4().hex

        if isinstance(dataset, DataConnector):
            # _validate_fit_input already checked but mypy doesn't know that
            assert input_cols is not None and label_col is not None
            self._input_cols = input_cols
            self._label_col = label_col
            trained_model = safe_run_awaitable(
                self._fit(
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    request_id=request_id,
                    eval_set=eval_set,
                    verbose_eval=verbose_eval,
                    xgb_model=xgb_model,
                )
            )
        else:
            trained_model = self._fit_in_memory_data(
                X=dataset,
                y=y,
                request_id=request_id,
                eval_set=eval_set,
                verbose_eval=verbose_eval,
                xgb_model=xgb_model,
            )

        return trained_model

    async def _fit(
        self,
        dataset: DataConnector,
        input_cols: List[str],
        label_col: str,
        request_id: str,
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        xgb_model: Optional[xgb.Booster] = None,
    ) -> xgb.Booster:
        start_time = datetime.now()
        try:
            import ray.tune

            # Use official Ray Tune context detection
            context = ray.tune.get_context()
            if context:
                bundles = context.get_trial_resources().bundles
                if bundles and any(bundle.get("GPU", 0) > 0 for bundle in bundles):
                    ray.tune.utils.wait_for_gpu()
        except Exception as e:
            logger.error(f"Error while waiting for GPU: {e}")
            pass
        training_handler = XGBTrainingHandler(
            request_id=request_id,
            num_workers=self.scaling_config.num_workers,
            num_cpu_per_worker=self.scaling_config.num_cpu_per_worker,
            use_gpu=self.scaling_config.use_gpu,
        )
        comm_queue: queue.Queue = queue.Queue()
        dataset = replace_data_connector_ingestor_with_ray_ingestor(dataset)
        eval_set = (
            replace_data_connector_ingestor_with_ray_ingestor(eval_set)
            if eval_set
            else None
        )

        process_completed = False
        model_obj = None
        eval_results = None
        train_task = None
        error_msg: Optional[str] = None
        try:
            loop = asyncio.get_event_loop()
            train_task = loop.create_task(
                training_handler.train(
                    comm_queue=comm_queue,
                    dataset=dataset,
                    input_cols=input_cols,
                    label_col=label_col,
                    params=self.params,
                    eval_set=eval_set,
                    verbose_eval=verbose_eval,
                    xgb_model=xgb_model,
                    callbacks=self.callbacks,
                )
            )
            # Read the message from the comm queue without blocking
            async for message in aio_queue_reader(comm_queue):
                if "done" in message and message["done"]:
                    if "trained_model" in message:
                        model_ref = message["trained_model"]
                        eval_results_ref = message.get("eval_results")
                        # There are two cases where this estimator is running from
                        # 1. Stand alone Ray task
                        # 2. Running in another Ray task
                        if isinstance(model_ref, str):
                            model_obj = xgb.Booster()
                            model_obj.load_model(model_ref)
                        else:
                            model_obj = model_ref

                        if isinstance(eval_results_ref, str):
                            if os.path.exists(eval_results_ref):
                                with open(eval_results_ref, "rb") as f:
                                    eval_results = cp.load(f)
                        elif eval_results_ref is not None:
                            eval_results = eval_results_ref
                        MLRSPrometheusMetrics.TRAIN_SUCCESS.value.inc()
                        MLRSPrometheusMetrics.TRAIN_DURATION_SUCCESS.value.observe(
                            (datetime.now() - start_time).total_seconds()
                        )
                    elif "exception" in message:
                        error_msg = repr(message["exception"])
                        MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
                else:
                    log_lines = message.get("log_lines")
                    if log_lines:
                        print(log_lines)

            process_completed = True
        except Exception as e:
            logger.error(f"Error while training: {repr(e)}")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_time).total_seconds()
            )
            if not process_completed:
                logger.info(f"{request_id}: train request abandoned")
                MLRSPrometheusMetrics.TRAIN_DURATION_ABANDONED.value.observe(
                    (datetime.now() - start_time).total_seconds()
                )
                training_handler.close()
                if train_task is not None:
                    train_task.cancel()

            if model_obj is not None:
                self._trained_booster = model_obj
                self._eval_results = eval_results
                return model_obj

            raise RuntimeError("Training failed", error_msg)

    def _fit_in_memory_data(
        self,
        X: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        y: Union[pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        request_id: str,
        eval_set: Optional[DataConnector] = None,
        verbose_eval: Optional[Union[bool, int]] = None,
        xgb_model: Optional[xgb.Booster] = None,
    ):
        start_time = datetime.now()

        training_handler = XGBTrainingHandler(
            request_id=request_id,
            num_workers=self.scaling_config.num_workers,
            num_cpu_per_worker=self.scaling_config.num_cpu_per_worker,
            use_gpu=self.scaling_config.use_gpu,
        )
        process_completed = False
        train_result = None
        try:
            train_result = training_handler.train_with_in_memory_data(
                X=X,
                y=y,
                params=self.params,
                eval_set=eval_set,
                verbose_eval=verbose_eval,
                xgb_model=xgb_model,
                callbacks=self.callbacks,
            )
            process_completed = True
            if train_result and train_result.trained_model is not None:
                self._trained_booster = train_result.trained_model
                try:
                    # Create sklearn estimator for interoperability with sklearn pipelines in the model registry.
                    self._sklearn_estimator = self._to_sklearn_estimator(y=y)
                except Exception as e:
                    logger.warning(
                        f"Unable to convert to sklearn API. This will not be compatible with sklearn "
                        f"pipelines in the model registry. Failed with error {e}"
                    )

                return train_result.trained_model
        except KeyboardInterrupt as e:
            logger.info(f"Training interrupted: {repr(e)}")
            raise e
        except Exception:
            logger.exception("Error while training")
            MLRSPrometheusMetrics.TRAIN_EXCEPTION.value.inc()
            # why using traceback.print_exc() instead of using chained exception?
            # because the notebook does not support chaining
            # see snowflake notebook bug report at
            # https://snowflakecomputing.atlassian.net/browse/SNOW-1874911
            traceback.print_exc()
            raise RuntimeError("Training failed, please see log above for details")
        finally:
            MLRSPrometheusMetrics.TRAIN_DURATION_UNFILTERED.value.observe(
                (datetime.now() - start_time).total_seconds()
            )
            if not process_completed:
                logger.info(f"{request_id}: train request abandoned")
                MLRSPrometheusMetrics.TRAIN_DURATION_ABANDONED.value.observe(
                    (datetime.now() - start_time).total_seconds()
                )
                training_handler.close()

    def _get_iteration_range(
        self, iteration_range: Optional[Tuple[int, int]]
    ) -> Tuple[int, int]:
        """
        Get the iteration range.

        The following code is trying to follow how xgboost oss API handles iteration_range.

        Args:
            iteration_range (Optional[Tuple[int, int]]): The iteration range.

        Returns:
            Tuple[int, int]: The iteration range.
        """

        if iteration_range is None or iteration_range[1] == 0:
            # use the best_iteration if it is available
            try:
                iteration_range = (0, self.get_booster().best_iteration + 1)
            except AttributeError:
                iteration_range = (0, 0)
        if self.params.get("booster", "gbtree") == "gblinear":
            iteration_range = (0, 0)
        return iteration_range

    # This is a simple in memory predict to unblock sklearn pipeline.
    # We should have a more optimized predict function with bulk inference.
    def predict(
        self,
        X: Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray],
        output_margin: bool = False,
        validate_features: bool = False,
        base_margin: Optional[Any] = None,
        iteration_range: Optional[Tuple[int, int]] = None,
        output_col_name: Optional[str] = "PREDICTIONS",
    ) -> Union[np.ndarray, pd.DataFrame]:
        """
        Predict using the trained model. This is an in-memory implementation of predict.

        Args:
            X (Union[DataConnector, pd.DataFrame, pd.Series, csr_matrix, np.ndarray]):
                the input data to predict. If DataConnector is provided, input_cols are required.
                if in-memory data is provided (pd.DataFrame, pd.Series, csr_matrix, np.ndarray), y should be provided
                as well.
            output_margin (bool):
                Whether to output the raw untransformed margin value.
            validate_features (bool): When this is True, validate that the Booster's and data's feature_names are
                identical. Otherwise, it is assumed that the feature_names are the same.
            base_margin (Optional[Any]):
                Global bias for each instance. Please check xgboost official documentation for intercept.
            iteration_range (Optional[Tuple[int, int]]):
                Specifies which layer of trees are used in prediction.
            output_col_name (Optional: str): Only required for DataConnector input. Defaults to "PREDICTIONS". This is
                necessary because DataConnector row order is not deterministic, so predictions must be co-located with
                their input features.

        Returns:
            (Union[np.ndarray, pd.DataFrame]):
            The prediction result. Will be a numpy array if an in memory dataset was passed. If a DataConnector is
            passed, the full dataframe is returned with predictions specified in "PREDICTIONS" column

        Raises:
            ValueError: If the model is not trained yet.
        """

        iteration_range = self._get_iteration_range(iteration_range)

        is_data_connector = isinstance(X, DataConnector)

        if is_data_connector:
            # Make sure that only input columns are used for inference, data connector could contain label column.
            X = replace_data_connector_ingestor_with_ray_ingestor(X).to_pandas()[
                self._input_cols
            ]

        X = convert_to_pandas_df(X)

        data = xgb.DMatrix(
            X,
            base_margin=base_margin,
        )
        results = self.get_booster().predict(
            data,
            output_margin=output_margin,
            validate_features=validate_features,
            iteration_range=iteration_range,
        )

        X[output_col_name] = results

        return results if not is_data_connector else X

    def get_params(self, deep=True) -> Dict[str, Any]:
        """
        Get parameters for this estimator.

        This is needed by sklearn when using CR estimator in a pipeline. This method is used to get the parameters

        Args:
            deep (bool): If True, will return the parameters for this estimator and
                contained sub-objects that are estimators.
                However, since we don't have any sub-objects in our class, this parameter is not used.
        """

        return self.params
