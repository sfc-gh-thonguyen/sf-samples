import pytest
from unittest.mock import MagicMock, patch, call
from snowflake.ml.runtime_cluster import cluster_manager


@pytest.fixture
def mock_setup():
    """
    Fixture to mock the setup function for session and Ray initialization.
    """
    with patch(
        "snowflake.ml.runtime_cluster.cluster_manager._setup"
    ) as mock_setup_func:
        session = MagicMock()
        mock_setup_func.return_value = session
        yield mock_setup_func


@pytest.fixture
def mock_ray_nodes():
    """
    Fixture to mock Ray's `nodes` function.
    """
    with patch("ray.nodes") as mock_nodes:
        yield mock_nodes


@pytest.fixture
def mock_snowpark_sql(mock_setup):
    """
    Fixture to mock Snowpark SQL execution with default responses.
    Returns the mock_sql object and mock_setup for additional customization.
    """
    session = mock_setup.return_value
    mock_sql = session.sql.return_value
    # Default mock responses
    mock_sql.collect.side_effect = [
        # Mock response for DESC NOTEBOOK query
        [{"compute_pool": "TEST_COMPUTE_POOL"}],
        # Mock response for DESC COMPUTE POOL query
        [{"max_nodes": 20, "active_nodes": 2}],
        # Mock response for scaling operation
        [[True]],
    ]
    yield mock_sql, mock_setup


@pytest.fixture
def mock_python_env_sync():
    """
    Fixture to mock python_env.sync_env() function.
    """
    with patch("runtime_env.python_env.sync_env") as mock_sync_env:
        yield mock_sync_env


@pytest.fixture
def mock_object_name_env():
    """
    Fixture to mock OBJECT_NAME environment variable for scale_cluster tests.
    This is required by cluster_manager.scale_cluster() regardless of whether
    notebook_name is provided explicitly.
    """
    with patch.dict("os.environ", {"OBJECT_NAME": "TEST_NOTEBOOK"}):
        yield


def create_node_sequence(initial_count, target_count):
    """
    Helper to create a node sequence for scaling tests.

    Args:
        initial_count: Initial number of nodes
        target_count: Target number of nodes

    Returns:
        A list containing two node configurations
    """
    initial_nodes = [
        {"NodeName": f"192.168.1.{i+1}", "Alive": True} for i in range(initial_count)
    ]

    target_nodes = [
        {"NodeName": f"192.168.1.{i+1}", "Alive": True} for i in range(target_count)
    ]

    return [initial_nodes, target_nodes]


def setup_node_scaling_mock(mock_ray_nodes, initial_count, target_count):
    """
    Helper to set up the mock for node scaling.

    Args:
        mock_ray_nodes: The mock_ray_nodes fixture
        initial_count: Initial number of nodes
        target_count: Target number of nodes
    """
    node_sequence = create_node_sequence(initial_count, target_count)

    def side_effect():
        return node_sequence.pop(0)

    mock_ray_nodes.side_effect = side_effect


def verify_scale_sql_calls(
    mock_setup,
    notebook_name,
    worker_count,
    rollback=None,
    min_cluster_size=None,
    is_scale_down=False,
):
    """
    Helper to verify SQL calls for scaling operations.

    Args:
        mock_setup: The mock_setup fixture
        notebook_name: Name of the notebook
        worker_count: Target worker count
        rollback: Optional rollback time
        min_cluster_size: Optional min cluster size
        is_scale_down: Whether this is a scale-down operation (skips capacity checks)
    """
    if is_scale_down:
        # Scale down operations only have one SQL call
        expected_calls = []
    else:
        # Scale up operations have capacity validation calls first
        expected_calls = [
            call(f"DESC NOTEBOOK {notebook_name}"),
            call('DESC COMPUTE POOL "TEST_COMPUTE_POOL"'),
        ]

    # Build the expected scaling query
    query = f"CALL SYSTEM$SCALE_ST_SERVICE_WORKERS('NOTEBOOK', '{notebook_name}', {worker_count}"

    if rollback is not None:
        query += f", {rollback}"

        if min_cluster_size is not None:
            query += f", {min_cluster_size}"

    query += ");"

    expected_calls.append(call(query))

    assert mock_setup.return_value.sql.call_args_list == expected_calls


def test_scale_cluster_success(mock_snowpark_sql, mock_ray_nodes, mock_object_name_env):
    """
    Test scaling the cluster successfully.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Setup node scaling
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Execute test
    result = cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")
    assert result is True

    # Verify SQL calls
    verify_scale_sql_calls(mock_setup, "MY_NOTEBOOK", 2)


@patch("snowflake.ml.runtime_cluster.cluster_manager.DEFAULT_SCALE_UP_TIMEOUT_S", new=1)
def test_scale_cluster_failure(mock_snowpark_sql, mock_ray_nodes, mock_object_name_env):
    """
    Test scaling the cluster failure due to mismatched cluster size.
    """
    # Always return a single node to simulate scaling failure
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
    ]

    with pytest.raises(Exception, match="Cluster size verification failed"):
        cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")


def test_get_nodes(mock_setup, mock_ray_nodes):
    """
    Test retrieving active nodes from the Ray cluster.
    """
    # Mock Ray nodes
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True, "Resources": {"CPU": 3}},
        {"NodeName": "192.168.1.2", "Alive": True, "Resources": {"CPU": 4}},
        {
            "NodeName": "192.168.1.3",
            "Alive": False,
            "Resources": {"CPU": 4},
        },  # Not active
    ]

    active_nodes = cluster_manager.get_nodes()
    assert active_nodes == [
        {"name": "192.168.1.1", "cpus": 3, "gpus": 0},
        {"name": "192.168.1.2", "cpus": 4, "gpus": 0},
    ]


def test_verify_cluster_size_success(mock_setup, mock_ray_nodes):
    """
    Test verifying the cluster size with mocked Ray nodes.
    """
    # Set up node sequence
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    cluster_manager._verify_cluster_size(expected_cluster_size=3, timeout=10.0)


def test_verify_cluster_size_timeout(mock_setup, mock_ray_nodes):
    """
    Test cluster size verification timeout.
    """
    # Mock Ray nodes (simulate no scaling progress)
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
    ]

    with pytest.raises(Exception, match="Cluster size verification failed"):
        cluster_manager._verify_cluster_size(expected_cluster_size=3, timeout=5.0)


def test_verify_cluster_size_with_min_size(mock_setup, mock_ray_nodes):
    """
    Test verifying the cluster size with a minimum size requirement.
    """
    # Set up node sequence
    setup_node_scaling_mock(mock_ray_nodes, 1, 2)

    # Should succeed because min_cluster_size=2 is reached
    cluster_manager._verify_cluster_size(
        expected_cluster_size=5, timeout=10.0, min_cluster_size=2
    )


def test_verify_cluster_size_with_min_size_timeout(mock_setup, mock_ray_nodes):
    """
    Test timeout when min_cluster_size is not reached.
    """
    # Mock Ray nodes (simulate no scaling progress)
    mock_ray_nodes.return_value = [{"NodeName": "192.168.1.1", "Alive": True}]

    with pytest.raises(Exception, match="expected at least 2"):
        cluster_manager._verify_cluster_size(
            expected_cluster_size=3, timeout=5.0, min_cluster_size=2
        )


def test_scale_cluster_with_rollback_time(
    mock_snowpark_sql, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling the cluster with custom rollback_after_seconds parameter.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Setup node scaling
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Call with rollback_after_seconds in options
    cluster_manager.scale_cluster(
        3, notebook_name="MY_NOTEBOOK", options={"rollback_after_seconds": 600}
    )

    # Verify the SQL calls
    verify_scale_sql_calls(mock_setup, "MY_NOTEBOOK", 2, rollback=600)


def test_scale_cluster_with_min_cluster_size(
    mock_snowpark_sql, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling the cluster with block_until_min_cluster_size parameter.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Mock Ray nodes for verification (only reaching min size, not full expected size)
    setup_node_scaling_mock(mock_ray_nodes, 1, 2)

    # Call with block_until_min_cluster_size in options
    result = cluster_manager.scale_cluster(
        3, notebook_name="MY_NOTEBOOK", options={"block_until_min_cluster_size": 2}
    )

    # Verify it succeeded since min_cluster_size was reached
    assert result is True

    # Verify SQL calls with default rollback time and min cluster size
    verify_scale_sql_calls(
        mock_setup,
        "MY_NOTEBOOK",
        2,
        rollback=cluster_manager.DEFAULT_ROLLBACK_AFTER_SECONDS,
        min_cluster_size=2,
    )


def test_scale_cluster_with_both_optional_params(
    mock_snowpark_sql, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling with both rollback_after_seconds and block_until_min_cluster_size.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Setup node scaling
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Call with both optional parameters
    cluster_manager.scale_cluster(
        3,
        notebook_name="MY_NOTEBOOK",
        options={"rollback_after_seconds": 500, "block_until_min_cluster_size": 2},
    )

    # Verify SQL calls with both parameters
    verify_scale_sql_calls(
        mock_setup, "MY_NOTEBOOK", 2, rollback=500, min_cluster_size=2
    )


def test_scale_cluster_parameter_validation(mock_object_name_env):
    """
    Test parameter validation in scale_cluster function.
    """
    # Test invalid rollback_after_seconds
    with pytest.raises(
        ValueError, match="rollback_after_seconds must be a positive integer"
    ):
        cluster_manager.scale_cluster(
            3, notebook_name="MY_NOTEBOOK", options={"rollback_after_seconds": 0}
        )

    with pytest.raises(
        ValueError, match="rollback_after_seconds must be a positive integer"
    ):
        cluster_manager.scale_cluster(
            3, notebook_name="MY_NOTEBOOK", options={"rollback_after_seconds": -10}
        )

    # Test invalid block_until_min_cluster_size
    with pytest.raises(
        ValueError, match="block_until_min_cluster_size must be a positive integer"
    ):
        cluster_manager.scale_cluster(
            3, notebook_name="MY_NOTEBOOK", options={"block_until_min_cluster_size": 0}
        )

    with pytest.raises(
        ValueError, match="block_until_min_cluster_size must be a positive integer"
    ):
        cluster_manager.scale_cluster(
            3, notebook_name="MY_NOTEBOOK", options={"block_until_min_cluster_size": -1}
        )

    # Test block_until_min_cluster_size greater than expected_cluster_size
    with pytest.raises(
        ValueError,
        match="block_until_min_cluster_size cannot be greater than expected_cluster_size",
    ):
        cluster_manager.scale_cluster(
            3, notebook_name="MY_NOTEBOOK", options={"block_until_min_cluster_size": 4}
        )


def test_scale_cluster_async_mode(
    mock_snowpark_sql, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling the cluster in async mode.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Only one node available - enough for async mode
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
    ]

    # Call with is_async=True
    result = cluster_manager.scale_cluster(
        3,
        notebook_name="MY_NOTEBOOK",
        is_async=True,
        options={
            "rollback_after_seconds": 500,
            "block_until_min_cluster_size": 2,  # Should be ignored in async mode
        },
    )

    # Verify it succeeded since async mode only needs min_cluster_size=1
    assert result is True

    # Verify SQL calls - min_cluster_size should be 1 due to is_async=True
    verify_scale_sql_calls(
        mock_setup, "MY_NOTEBOOK", 2, rollback=500, min_cluster_size=1
    )


def test_scale_cluster_with_env_notebook_name(mock_snowpark_sql, mock_ray_nodes):
    """
    Test scaling the cluster with notebook_name from environment variable.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Mock environment variable
    with patch.dict("os.environ", {"OBJECT_NAME": "ENV_NOTEBOOK"}):
        # Setup node scaling
        setup_node_scaling_mock(mock_ray_nodes, 2, 3)

        # Call without notebook_name parameter
        result = cluster_manager.scale_cluster(3)
        assert result is True

        # Verify SQL calls with notebook name from environment
        verify_scale_sql_calls(mock_setup, "ENV_NOTEBOOK", 2)


def test_scale_cluster_not_enough_capacity(
    mock_setup, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling the cluster when there's not enough capacity in the compute pool.
    """
    # Mock Snowpark SQL execution
    mock_sql = mock_setup.return_value.sql.return_value
    mock_sql.collect.side_effect = [
        # Mock response for DESC NOTEBOOK query
        [{"compute_pool": "TEST_COMPUTE_POOL"}],
        # Mock response for DESC COMPUTE POOL query - only 1 node headroom
        [{"max_nodes": 5, "active_nodes": 4}],
    ]

    # Mock Ray nodes - only 1 node currently active
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
    ]

    # Try to scale to 3 nodes (need 2 more, but only have headroom for 1)
    with pytest.raises(Exception, match="Not enough capacity to scale up"):
        cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")


def test_scale_cluster_sql_error_proceeds(
    mock_setup, mock_ray_nodes, mock_object_name_env
):
    """
    Test that scaling proceeds even when SQL validation fails with an error.
    """
    # Mock Snowpark SQL execution
    mock_sql = mock_setup.return_value.sql.return_value

    # First SQL call (notebook desc) raises an exception
    mock_sql.collect.side_effect = [
        Exception("SQL permission error"),  # Permission error for notebook desc
        [[True]],  # Result for scaling operation
    ]

    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Should proceed with scaling despite SQL error
    with patch("logging.Logger.warning") as mock_warning:
        result = cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")
        assert result is True

        # Verify the warning was logged
        mock_warning.assert_any_call(
            "Failed to check compute pool capacity: SQL permission error. Proceeding with scaling operation."
        )

    # Verify the scaling operation was still called
    assert mock_setup.return_value.sql.call_count == 2


def test_validate_compute_pool_capacity(mock_setup):
    """
    Test the _validate_compute_pool_capacity function directly.
    """
    session = mock_setup.return_value

    # Case 1: Enough capacity
    session.sql.return_value.collect.side_effect = [
        [{"compute_pool": "TEST_POOL"}],
        [{"max_nodes": 10, "active_nodes": 5}],
    ]

    result = cluster_manager._validate_compute_pool_capacity(
        session, "test-notebook", 3
    )
    assert result is True

    # Case 2: Not enough capacity
    session.sql.return_value.collect.side_effect = [
        [{"compute_pool": "TEST_POOL"}],
        [{"max_nodes": 10, "active_nodes": 9}],
    ]

    with patch("logging.Logger.warning") as mock_warning:
        result = cluster_manager._validate_compute_pool_capacity(
            session, "test-notebook", 2
        )
        assert result is False
        mock_warning.assert_called_once()

    # Case 3: SQL error proceeds with warning
    session.sql.return_value.collect.side_effect = Exception("SQL error")

    with patch("logging.Logger.warning") as mock_warning:
        result = cluster_manager._validate_compute_pool_capacity(
            session, "test-notebook", 3
        )
        assert result is True
        mock_warning.assert_called_once()
        assert "SQL error" in mock_warning.call_args[0][0]


def test_scale_down_skips_capacity_check(
    mock_setup, mock_ray_nodes, mock_object_name_env
):
    """
    Test scaling down the cluster skips the capacity check.
    """
    # Mock Snowpark SQL execution - only need to mock the scaling operation
    mock_setup.return_value.sql.return_value.collect.return_value = [[True]]

    # Set up node sequence - starting with 3 nodes and after scaling should be 2 nodes
    setup_node_scaling_mock(mock_ray_nodes, 3, 2)

    # Scale down to 2 nodes
    result = cluster_manager.scale_cluster(2, notebook_name="MY_NOTEBOOK")
    assert result is True

    # Verify only one SQL call was made (no DESC queries for capacity check)
    assert mock_setup.return_value.sql.call_count == 1

    # Verify the scaling query using our helper
    verify_scale_sql_calls(mock_setup, "MY_NOTEBOOK", 1, is_scale_down=True)


# Tests for python_env.sync_env() usage in scale_cluster
def test_scale_cluster_calls_sync_env_in_sync_mode(
    mock_snowpark_sql, mock_ray_nodes, mock_python_env_sync, mock_object_name_env
):
    """
    Test that scale_cluster calls python_env.sync_env() in sync mode (is_async=False).
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Setup node scaling
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Execute test with is_async=False (default)
    result = cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")
    assert result is True

    # Verify sync_env was called once
    mock_python_env_sync.assert_called_once()


def test_scale_cluster_does_not_call_sync_env_in_async_mode(
    mock_snowpark_sql, mock_ray_nodes, mock_python_env_sync, mock_object_name_env
):
    """
    Test that scale_cluster does NOT call python_env.sync_env() in async mode (is_async=True).
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Only one node available - enough for async mode
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
    ]

    # Execute test with is_async=True
    result = cluster_manager.scale_cluster(
        3, notebook_name="MY_NOTEBOOK", is_async=True
    )
    assert result is True

    # Verify sync_env was NOT called in async mode
    mock_python_env_sync.assert_not_called()


def test_scale_cluster_handles_sync_env_exception(
    mock_snowpark_sql, mock_ray_nodes, mock_python_env_sync, mock_object_name_env
):
    """
    Test that scale_cluster handles exceptions from python_env.sync_env() gracefully.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Setup node scaling
    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Make sync_env raise an exception
    mock_python_env_sync.side_effect = RuntimeError("Python environment sync failed")

    # Execute test - should still succeed despite sync_env failure
    with patch("snowflake.ml.runtime_cluster.cluster_manager.logger") as mock_logger:
        result = cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")
        assert result is True

        # Verify sync_env was called
        mock_python_env_sync.assert_called_once()

        # Verify error was logged
        mock_logger.error.assert_called_once()
        error_call_args = mock_logger.error.call_args[0][0]
        assert "Error while updating python environment" in error_call_args
        assert "Python environment sync failed" in error_call_args


def test_scale_cluster_sync_env_called_after_successful_scaling(
    mock_snowpark_sql, mock_ray_nodes, mock_python_env_sync, mock_object_name_env
):
    """
    Test that sync_env is only called after successful scaling operation.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Make the scaling operation fail
    mock_setup.return_value.sql.return_value.collect.side_effect = [
        [{"compute_pool": "TEST_COMPUTE_POOL"}],
        [{"max_nodes": 20, "active_nodes": 2}],
        [[False]],  # Scaling operation returns False (failure)
    ]

    setup_node_scaling_mock(mock_ray_nodes, 2, 3)

    # Execute test - should fail due to scaling operation failure
    with pytest.raises(Exception, match="Failed to scale cluster"):
        cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")

    # Verify sync_env was NOT called since scaling failed
    mock_python_env_sync.assert_not_called()


def test_scale_cluster_sync_env_not_called_on_verification_timeout(
    mock_snowpark_sql, mock_ray_nodes, mock_python_env_sync, mock_object_name_env
):
    """
    Test that sync_env is not called when cluster size verification times out.
    """
    # Unpack the mock SQL and mock setup
    _, mock_setup = mock_snowpark_sql

    # Mock Ray nodes to never reach the target size (verification will timeout)
    mock_ray_nodes.return_value = [
        {"NodeName": "192.168.1.1", "Alive": True},
        {"NodeName": "192.168.1.2", "Alive": True},
    ]  # Always return 2 nodes, never 3

    # Execute test with short timeout - should fail due to verification timeout
    with patch(
        "snowflake.ml.runtime_cluster.cluster_manager.DEFAULT_SCALE_UP_TIMEOUT_S",
        new=0.1,
    ):
        with pytest.raises(Exception, match="Cluster size verification failed"):
            cluster_manager.scale_cluster(3, notebook_name="MY_NOTEBOOK")

    # Verify sync_env was NOT called since verification failed
    mock_python_env_sync.assert_not_called()


# Tests for get_ray_dashboard_url function
def test_get_ray_dashboard_url_success(mock_setup):
    """
    Test successful retrieval of Ray dashboard URL.
    """
    session = mock_setup.return_value
    expected_url = "https://ray-dashboard-12345.snowflakecomputing.com"

    # Mock SQL response
    session.sql.return_value.collect.return_value = [
        {"SYSTEM$GET_ML_ENDPOINT_URL": expected_url}
    ]

    result_url = cluster_manager.get_ray_dashboard_url()

    # Verify the correct query was made
    expected_query = "CALL SYSTEM$GET_ML_ENDPOINT_URL('ray-dashboard-endpoint')"
    session.sql.assert_called_once_with(expected_query)
    assert result_url == expected_url


def test_get_ray_dashboard_url_with_notebook_name(mock_setup):
    """
    Test retrieval with explicitly provided notebook name (parameter is ignored in current implementation).
    """
    session = mock_setup.return_value
    expected_url = "https://ray-dashboard-67890.snowflakecomputing.com"

    session.sql.return_value.collect.return_value = [
        {"SYSTEM$GET_ML_ENDPOINT_URL": expected_url}
    ]

    # notebook_name parameter exists but is not used in current implementation
    result_url = cluster_manager.get_ray_dashboard_url(
        notebook_name="EXPLICIT_NOTEBOOK"
    )

    expected_query = "CALL SYSTEM$GET_ML_ENDPOINT_URL('ray-dashboard-endpoint')"
    session.sql.assert_called_once_with(expected_query)
    assert result_url == expected_url


def test_get_ray_dashboard_url_no_endpoints_found(mock_setup):
    """
    Test error when no ray dashboard endpoints are found.
    """
    session = mock_setup.return_value
    session.sql.return_value.collect.return_value = []

    with pytest.raises(
        Exception, match="Expected exactly one 'ray-dashboard-endpoint' found, got 0"
    ):
        cluster_manager.get_ray_dashboard_url()


def test_get_ray_dashboard_url_multiple_endpoints_found(mock_setup):
    """
    Test error when multiple ray dashboard endpoints are found.
    """
    session = mock_setup.return_value
    session.sql.return_value.collect.return_value = [
        {
            "SYSTEM$GET_ML_ENDPOINT_URL": "https://ray-dashboard-1.snowflakecomputing.com"
        },
        {
            "SYSTEM$GET_ML_ENDPOINT_URL": "https://ray-dashboard-2.snowflakecomputing.com"
        },
    ]

    with pytest.raises(
        Exception, match="Expected exactly one 'ray-dashboard-endpoint' found, got 2"
    ):
        cluster_manager.get_ray_dashboard_url()
