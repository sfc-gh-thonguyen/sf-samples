from snowflake.ml.modeling.distributors.base_runnable import (
    BaseScalingConfig,
)
from common_utils.common_util import get_num_ray_nodes, get_total_node_resources


class WorkerResourceConfig:
    """Resources requirements per worker.

    This class defines the resource requirements for each worker in a distributed
    training job, specifying the number of CPU and GPU resources to allocate.

    Attributes:
        num_cpus (int): The number of CPU cores to reserve for each worker.
        num_gpus (int): The number of GPUs to reserve for each worker.
            Default is 0, indicating no GPUs are reserved.
    """

    def __init__(self, num_cpus: int = 1, num_gpus: int = 0) -> None:
        """Initialize the WorkerResourceConfig.

        Args:
            num_cpus (int): The number of CPU cores to reserve for each worker.
            num_gpus (int): The number of GPUs to reserve for each worker.
                Default is 0, indicating no GPUs are reserved.
        """
        self.num_cpus = num_cpus
        self.num_gpus = num_gpus


class PyTorchScalingConfig(BaseScalingConfig):
    """Scaling configuration for training PyTorch models.

    This class defines the scaling configuration for a PyTorch training job,
    including the number of nodes, the number of workers per node, and the
    resource requirements for each worker.

    Attributes:
        num_nodes (int): The number of nodes to use for training.
        num_workers_per_node (int): The number of workers to use per node.
        resource_requirements_per_worker (WorkerResourceConfig): The resource requirements
            for each worker, such as the number of CPUs and GPUs.
    """

    def __init__(
        self,
        num_nodes: int,
        num_workers_per_node: int,
        resource_requirements_per_worker: WorkerResourceConfig,
    ) -> None:
        """Initialize the PyTorchScalingConfig.

        Args:
            num_nodes (int): The number of nodes to use for training.
            num_workers_per_node (int): The number of workers to use per node.
            resource_requirements_per_worker (WorkerResourceConfig): The resource requirements
                for each worker, such as the number of CPUs and GPUs.
        """
        self.num_node = num_nodes
        self.num_workers_per_node = num_workers_per_node
        self.resource_requirements_per_worker = resource_requirements_per_worker


class DefaultScalingConfig(PyTorchScalingConfig):
    def __init__(self) -> None:
        num_nodes = int(get_num_ray_nodes())
        node_resources = get_total_node_resources()

        if node_resources.get("GPU"):
            num_gpus_per_worker = 1
            num_workers_per_node = int(node_resources["GPU"])
            num_cpus_per_worker = 0
        else:
            num_gpus_per_worker = 0
            num_workers_per_node = 1
            num_cpus_per_worker = -1

        super().__init__(
            num_nodes=num_nodes,
            num_workers_per_node=num_workers_per_node,
            resource_requirements_per_worker=WorkerResourceConfig(
                num_cpus=num_cpus_per_worker, num_gpus=num_gpus_per_worker
            ),
        )
