import io
import os
import pickle
import tempfile
from typing import Any, Optional, Callable, TypeVar

import cloudpickle
import ray
from ray.actor import ActorHandle
from snowflake.snowpark import Session

T = TypeVar("T")


class PartitionContext:
    """
    Provides context and utilities for partition-specific operations within DPF functions.

    This class is automatically passed as the second argument to user-defined DPF functions,
    providing access to partition metadata and artifact management capabilities.

    Key capabilities:
        * Access to partition identifier
        * Upload artifacts to the partition's dedicated stage directory
        * Automatic handling of temporary files and serialization

    Note:
        Users don't create ``PartitionContext`` instances directly. They are provided
        automatically by the DPF execution framework.

    Example:
        >>> def my_dpf_function(data_connector, context):
        ...     # Access partition information
        ...     print(f"Processing partition: {context.partition_id}")
        ...
        ...     # Process data
        ...     df = data_connector.to_pandas()
        ...     results = perform_analysis(df)
        ...
        ...     # Save results to stage
        ...     context.upload_to_stage(results, "analysis_results.pkl")
    """

    def __init__(
        self, *, io_actor: ActorHandle, partition_id: str, stage_path_prefix: str
    ):
        self._partition_id = partition_id
        self._io_actor = io_actor
        self._stage_path_prefix = stage_path_prefix

    @property
    def partition_id(self) -> str:
        return self._partition_id

    @property
    def stage_path_prefix(self) -> str:
        return self._stage_path_prefix

    def upload_to_stage(
        self,
        obj: Any,
        filename: str,
        *,
        write_function: Optional[Callable[[Any, str], None]] = None,
    ):
        """
        Saves a Python object to a file and uploads it to the partition's stage directory.

        This method handles the complete workflow of serializing objects and uploading them
        to Snowflake stages, with automatic temporary file management.

        How it works:
            * If ``write_function`` is NOT provided (default): Uses Python's pickle module
            * If ``write_function`` IS provided: Uses your custom serialization logic

        Args:
            obj: The Python object to save.
            filename (str): The destination filename for the artifact (e.g., "model.pkl").
            write_function (Optional[Callable[[Any, str], None]]): Custom serialization function
                that takes the object and local file path as arguments.

        Example:
            Common usage patterns within a DPF function:

            >>> def my_analytics_function(data_connector, context):
            ...     df = data_connector.to_pandas()
            ...
            ...     # Save pickle objects (default behavior)
            ...     results = {'total': df['amount'].sum(), 'count': len(df)}
            ...     context.upload_to_stage(results, "summary.pkl")
            ...
            ...     # Save JSON data
            ...     import json
            ...     context.upload_to_stage(
            ...         results, "summary.json",
            ...         write_function=lambda obj, path: json.dump(obj, open(path, 'w'))
            ...     )
            ...
            ...     # Save CSV file
            ...     df_processed = df.groupby('category').sum()
            ...     context.upload_to_stage(
            ...         df_processed, "aggregated.csv",
            ...         write_function=lambda df, path: df.to_csv(path, index=False)
            ...     )

        Note:
            The method automatically handles temporary file creation and cleanup.
            Files are uploaded with ``auto_compress=False`` and ``overwrite=True``.
        """
        stage_path = self._stage_path_prefix
        stage_file_path = f"{stage_path}/{filename}"

        if write_function is None:
            # Default case: use pickle with streaming (more efficient)
            def _upload_stream(session):
                data = pickle.dumps(obj)
                input_stream = io.BytesIO(data)
                session.file.put_stream(
                    input_stream,
                    stage_file_path,
                    auto_compress=False,
                    overwrite=True,
                )

            self.with_session(_upload_stream)
        else:
            # Custom write function: needs file path, use temp file
            def _upload_file(session):
                with tempfile.TemporaryDirectory() as temp_dir:
                    local_file_path = os.path.join(temp_dir, filename)
                    write_function(obj, local_file_path)
                    session.file.put(
                        local_file_path,
                        stage_path,
                        auto_compress=False,
                        overwrite=True,
                    )

            self.with_session(_upload_file)

        print(f"Successfully uploaded to {stage_path}")

    def download_from_stage(
        self,
        filename: str,
        *,
        stage_path: Optional[str] = None,
        read_function: Optional[Callable[[str], Any]] = None,
    ) -> Any:
        """
        Downloads an artifact from a stage and deserializes it into a Python object.

        This method handles the complete workflow of downloading files from Snowflake stages
        and deserializing them, with automatic temporary file management.

        How it works:
            * If ``read_function`` is NOT provided (default): Uses Python's pickle module
            * If ``read_function`` IS provided: Uses your custom deserialization logic

        Args:
            filename (str): The filename to download (e.g., "model.pkl").
            stage_path (Optional[str]): The stage path to download from. If not provided,
                uses the current partition's stage path.
            read_function (Optional[Callable[[str], Any]]): Custom deserialization function
                that takes the local file path as argument and returns the deserialized object.

        Returns:
            The deserialized Python object.

        Example:
            Common usage patterns within a DPF function:

            >>> def my_inference_function(data_connector, context):
            ...     # Load pickle objects (default behavior)
            ...     model = context.download_from_stage("model.pkl")
            ...
            ...     # Load from a different stage path (e.g., training artifacts)
            ...     model = context.download_from_stage(
            ...         "model.pkl",
            ...         stage_path="@db.schema.stage/training_run/partition_0"
            ...     )
            ...
            ...     # Load JSON with custom deserializer
            ...     import json
            ...     config = context.download_from_stage(
            ...         "config.json",
            ...         read_function=lambda path: json.load(open(path, 'r'))
            ...     )
        """
        target_stage_path = stage_path or self._stage_path_prefix
        stage_file_path = f"{target_stage_path}/{filename}"

        if read_function is None:
            # Use get() with a unique temp directory instead of get_stream() to avoid
            # file corruption from concurrent downloads with the same filename.
            # get_stream() uses a shared temp directory which causes race conditions.
            def _download_file_pickle(session):
                with tempfile.TemporaryDirectory() as temp_dir:
                    session.file.get(stage_file_path, temp_dir)
                    local_file_path = os.path.join(temp_dir, filename)
                    with open(local_file_path, "rb") as f:
                        return pickle.load(f)

            return self.with_session(_download_file_pickle)
        else:
            # Custom read function: needs file path, use temp file
            def _download_file(session):
                with tempfile.TemporaryDirectory() as temp_dir:
                    session.file.get(stage_file_path, temp_dir)
                    local_file_path = os.path.join(temp_dir, filename)
                    return read_function(local_file_path)

            return self.with_session(_download_file)

    def with_session(self, func: Callable[[Session], T]) -> T:
        """
        Execute a function with a Snowflake session from the bounded IO actor pool.

        This method allows you to perform session-based operations (like writing to tables)
        without creating a new session in each worker, which could hit Snowflake's session
        limits with many concurrent partitions.

        The function is serialized and executed on an IO actor that maintains a persistent
        session. This bounds the total number of concurrent sessions regardless of how many
        partitions are running.

        Args:
            func (Callable[[Session], T]): A function that takes a Snowflake Session as its
                only argument and returns a result. The function must be serializable
                (closures with simple captured variables work fine).

        Returns:
            The return value from the function.

        Example:
            Writing results to a Snowflake table within a DPF function:

            >>> def my_inference_function(data_connector, model, context):
            ...     df = data_connector.to_pandas()
            ...     predictions = model.predict(df[['X1', 'X2']])
            ...
            ...     # Create results DataFrame
            ...     results = df.copy()
            ...     results['predictions'] = predictions
            ...     results['partition_id'] = context.partition_id
            ...
            ...     # Write to table using bounded session pool
            ...     context.with_session(lambda session:
            ...         session.create_dataframe(results)
            ...             .write.mode("append")
            ...             .save_as_table("predictions_table")
            ...     )
            ...
            ...     return predictions

            Reading from a table:

            >>> def my_function(data_connector, context):
            ...     # Query a lookup table
            ...     lookup_data = context.with_session(lambda session:
            ...         session.table("lookup_table").to_pandas()
            ...     )
            ...     # ... use lookup_data ...

        Note:
            The function is serialized using cloudpickle, which handles most closures well.
            However, avoid capturing large objects or non-serializable resources in the closure.
        """
        # Serialize the function with cloudpickle (handles closures better than pickle)
        serialized_func = cloudpickle.dumps(func)

        # Execute on IO actor and get serialized result
        serialized_result = ray.get(
            self._io_actor.execute_with_session.remote(
                serialized_func=serialized_func,
            )
        )

        # Deserialize and return result
        return cloudpickle.loads(serialized_result)
