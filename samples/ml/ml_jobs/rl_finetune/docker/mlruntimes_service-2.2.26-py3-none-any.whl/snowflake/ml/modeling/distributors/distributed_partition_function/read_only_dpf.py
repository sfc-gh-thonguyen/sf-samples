from typing import Any, Dict, Optional

from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    SinglePartitionDetails,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.dpf import (
    DPF,
)

from snowflake.ml.modeling.distributors.distributed_partition_function.entities import (
    ExecutionOptions,
    RunStatus,
)
from snowflake import snowpark
from snowflake.ml.modeling.distributors.distributed_partition_function.constants import (
    MMT_STATE_PICKLE_FILENAME,
)
from snowflake.ml.modeling.distributors.distributed_partition_function.utils import (
    download_and_deserialize_from_stage,
)
from common_utils.shared_storage_util import convert_to_fully_qualified_stage
from ray.types import ObjectRef


class ReadOnlyDPF(DPF):
    def __init__(self, states: Dict[str, Any]) -> None:
        self._states = states

    @classmethod
    def restore_from(
        cls, model_name: str, model_version: str, stage_name: str
    ) -> "ReadOnlyDPF":
        """
        Restore a ManyModelTrainer instance from previous run, making metadata access easier.
        Note that this instance is read-only, 'run' method is not permitted.

        Parameters:
            model_name (str): The name of the model to be trained.
            model_version (str): The version of the model to be trained.
            stage_name (str): The stage name (either fully qualified or not) used to store or retrieve training data.
                Examples:
                    - my_stage  # Unqualified stage name (uses the current session's database and schema)
                    - my_db.my_schema.my_stage  # Fully qualified stage name (specifies database, schema, and stage)
        """

        fully_qualified_stage_name = convert_to_fully_qualified_stage(
            stage_name=stage_name
        )

        try:
            states = download_and_deserialize_from_stage(
                model_name=model_name,
                model_version=model_version,
                stage_name=fully_qualified_stage_name,
                subpath=[MMT_STATE_PICKLE_FILENAME],
            )
            return cls(states=states)
        except Exception as e:
            raise ValueError(
                f"Failed to restore state for model {model_name}, version {model_version} "
                f"from stage {stage_name}: {e}"
            )

    @property
    def model_trainings(self) -> Dict[str, SinglePartitionDetails]:
        """
        Retrieve the dictionary of model trainings.

        Returns:
            Dict[str, SinglePartitionDetails]: A dictionary where the keys are model partition ids (str)
            and the values are ModelTraining instances representing the training details
            for each model.
        """
        return self._states["model_trainings"]

    @property
    def status(self) -> RunStatus:
        return self._states["status"]

    def cancel(self) -> None:
        raise NotImplementedError

    def run(
        self,
        *,
        partition_by: str,
        snowpark_dataframe: snowpark.DataFrame,
        session: Optional[snowpark.Session] = None,
        execution_options: Optional[ExecutionOptions] = None,
    ) -> ObjectRef:
        raise NotImplementedError
