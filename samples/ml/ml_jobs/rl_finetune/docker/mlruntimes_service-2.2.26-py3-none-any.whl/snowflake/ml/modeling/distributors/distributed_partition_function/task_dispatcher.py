import threading
from queue import Queue, Empty
from typing import Dict
import ray
from ray.types import ObjectRef
from snowflake.runtime.utils.logger import get_logger
from ray.util.actor_pool import ActorPool

logger = get_logger()


class TaskDispatcher:
    """
    Background thread for dispatching tasks from a queue to actors in an actor pool.
    """

    def __init__(
        self,
        pending_tasks: Queue,
        actor_pool: ActorPool,
        object_ref_to_partition_id: Dict[ObjectRef, str],
    ):
        self._pending_tasks = pending_tasks
        self._actor_pool = actor_pool
        self._object_ref_to_partition_id = object_ref_to_partition_id
        self._stop_event = threading.Event()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._dispatcher_loop, daemon=True)
        self._thread.start()

    def _dispatcher_loop(self):
        while not self._stop_event.is_set():
            try:
                task = self._pending_tasks.get(timeout=1)
            except Empty:
                continue

            partition_id, result_batches, dataframe_info = task

            # Check if we should stop before processing
            if self._stop_event.is_set():
                # Put task back if we're stopping
                self._pending_tasks.put(task)
                break

            try:

                def wrapped_fn(actor, values):
                    # Ensure actor is ready before assigning work; if this times out, the caller will requeue
                    ray.get(actor.ping.remote(), timeout=60)
                    partition_id, result_batches, dataframe_info = values
                    object_ref = actor.run.remote(
                        partition_id=partition_id,
                        result_batches=result_batches,
                        dataframe_info=dataframe_info,
                    )
                    self._object_ref_to_partition_id[object_ref] = partition_id
                    return object_ref

                # Submit directly - ActorPool will handle queueing if no actors available
                self._actor_pool.submit(wrapped_fn, task)
                self._pending_tasks.task_done()

            except Exception as e:
                # Log critical errors only
                logger.error(
                    f"TaskDispatcher failed to submit task for partition {partition_id}: {e}"
                )
                self._pending_tasks.put(task)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            if self._thread.is_alive():
                logger.warning("TaskDispatcher thread did not stop within timeout")

        remaining_tasks = self._pending_tasks.qsize()
        if remaining_tasks > 0:
            logger.warning(
                f"TaskDispatcher stopped with {remaining_tasks} pending tasks"
            )
