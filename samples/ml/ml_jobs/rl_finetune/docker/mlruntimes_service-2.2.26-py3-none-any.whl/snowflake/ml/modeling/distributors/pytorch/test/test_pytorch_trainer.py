from unittest import mock
from snowflake.ml.modeling.distributors.pytorch import pytorch_trainer, scaling_config
from web.ml_runtime_trainer import MLRuntimeTrainer


def train_func() -> None:
    pass


def get_scaling_config(
    num_nodes: int = 1, num_workers_per_node: int = 1
) -> scaling_config.PyTorchScalingConfig:
    resource_config = scaling_config.WorkerResourceConfig()
    return scaling_config.PyTorchScalingConfig(
        num_nodes=num_nodes,
        num_workers_per_node=num_workers_per_node,
        resource_requirements_per_worker=resource_config,
    )


def get_ml_runtime_trainer() -> MLRuntimeTrainer:
    mock_trainer = mock.MagicMock(spec=MLRuntimeTrainer)
    mock_trainer.trainV2.return_value = pytorch_trainer.PyTorchDistributorResult(
        "model_dir",
        {"metric": 0.0},
        "checkpoint_location",
    )
    return mock_trainer


class TestPyTorchDistributorResult:
    @property
    def sut(self):
        return pytorch_trainer.PyTorchDistributorResult(
            "model_dir",
            {"metric": 0.0},
            "checkpoint_location",
        )

    def test_get_model_dir(self):
        assert self.sut.get_model_dir() == "model_dir"

    def test_get_metrics(self):
        assert self.sut.get_metrics() == {"metric": 0.0}

    def test_get_checkpoint_location(self):
        assert self.sut.get_checkpoint_location() == "checkpoint_location"


class TestPyTorchDistributor:
    @property
    def sut(self):
        return pytorch_trainer.PyTorchDistributor(
            train_func=train_func,
            scaling_config=get_scaling_config(),
        )

    @mock.patch("web.ml_runtime_trainer.MLRuntimeTrainer", new=get_ml_runtime_trainer)
    def test_run_mce(self):
        rst = self.sut.run()
        assert isinstance(rst, pytorch_trainer.PyTorchDistributorResult)
