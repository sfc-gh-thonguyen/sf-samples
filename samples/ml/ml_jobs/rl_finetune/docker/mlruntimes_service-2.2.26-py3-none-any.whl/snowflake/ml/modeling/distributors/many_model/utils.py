import pickle
from abc import ABC, abstractmethod
from typing import Any


class ModelSerde(ABC):
    """
    Base class for model serialization and deserialization.

    This class defines the interface for saving and loading models. Implement this
    class only when you need to support a custom model format not covered by the
    built-in serializers. For common frameworks, use one of the provided
    serializers: :class:`PickleSerde`, :class:`TorchSerde`, or
    :class:`TensorFlowSerde`.
    """

    @property
    @abstractmethod
    def filename(self) -> str:
        """The filename to use for the serialized model."""
        pass

    @abstractmethod
    def write(self, model: Any, file_path: str) -> None:
        """
        Serialize a model to the given file path.

        Args:
            model: The model object to serialize
            file_path: Full path where the model should be saved
        """
        pass

    @abstractmethod
    def read(self, file_path: str) -> Any:
        """
        Deserialize a model from the given file path.

        Args:
            file_path: Full path to the serialized model

        Returns:
            The deserialized model object
        """
        pass


class PickleSerde(ModelSerde):
    """
    Serializer for scikit-learn, XGBoost, and other pickle-compatible models.

    Args:
        filename (str): The filename for the serialized model.
                        Defaults to "model.pkl".
    """

    def __init__(self, filename: str = "model.pkl"):
        self._filename = filename

    @property
    def filename(self) -> str:
        return self._filename

    def write(self, model: Any, file_path: str) -> None:
        with open(file_path, "wb") as f:
            pickle.dump(model, f)

    def read(self, file_path: str) -> Any:
        with open(file_path, "rb") as f:
            return pickle.load(f)


class TorchSerde(ModelSerde):
    """
    Serializer for PyTorch models.

    Args:
        filename (str): The filename for the serialized model.
                        Defaults to "model.pt".
        weights_only (bool): If True, saves only the model's weights.
                             Defaults to False.
    """

    def __init__(self, filename: str = "model.pt", weights_only: bool = False):
        self._filename = filename
        self._weights_only = weights_only

    @property
    def filename(self) -> str:
        return self._filename

    def write(self, model: Any, file_path: str) -> None:
        try:
            import torch

            if self._weights_only:
                torch.save(model.state_dict(), file_path)
            else:
                torch.save(model, file_path)
        except ImportError:
            raise ImportError("PyTorch is required for TorchSerde")

    def read(self, file_path: str) -> Any:
        try:
            import torch

            # If the model was saved with `weights_only=False` (the default),
            # we must pass `weights_only=False` to `torch.load` to allow it
            # to unpickle the full model object. This parameter is aligned
            # with how the model was saved.
            return torch.load(file_path, weights_only=self._weights_only)
        except ImportError:
            raise ImportError("PyTorch is required for TorchSerde")


class TensorFlowSerde(ModelSerde):
    """
    Serializer for TensorFlow/Keras models.

    Args:
        filename (str): The filename for the serialized model.
                        Defaults to "model.keras".
    """

    def __init__(self, filename: str = "model.keras"):
        self._filename = filename

    @property
    def filename(self) -> str:
        return self._filename

    def write(self, model: Any, file_path: str) -> None:
        try:
            # Support both TensorFlow and Keras models
            if hasattr(model, "save"):
                model.save(file_path)
            else:
                raise ValueError("Model does not have a save method")
        except ImportError:
            raise ImportError("TensorFlow is required for TensorFlowSerde")

    def read(self, file_path: str) -> Any:
        try:
            import tensorflow as tf

            return tf.keras.models.load_model(file_path)
        except ImportError:
            raise ImportError("TensorFlow is required for TensorFlowSerde")
