import os
import sys


def get_pkg_root():
    # Start from cwd and keep going up the dir path to look for
    # "mlruntimes" root folder
    path = os.getcwd()
    while os.path.basename(path) and os.path.basename(path) != "mlruntimes":
        path = os.path.dirname(path)
    if os.path.basename(path) != "mlruntimes":
        raise RuntimeError("Couldn't find pacakge root for mlruntimes pkg.")
    return path


def set_python_path_in_dev_env() -> None:
    """
    <pkg_root>/common should be added to python path in dev env to make common modules
    accessible for mlruntime server process and other sub processes created by ray.
    """
    if os.getenv("DEV_ENV", None):
        # Add <pkg_root>/common to python path.
        try:
            pkg_root = get_pkg_root()
            sys.path.append(f"{pkg_root}/common")
            sys.path.append(f"{pkg_root}")
        except RuntimeError:
            # Failed to find package root. May be running with installed wheel file.
            # Ignore the error.
            pass
