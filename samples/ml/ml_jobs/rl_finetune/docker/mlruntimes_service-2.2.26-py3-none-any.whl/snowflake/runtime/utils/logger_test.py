from snowflake.runtime.utils.logger import (
    LogType,
    get_logger,
    CustomLoggingHandler,
    set_mlrs_logger_level,
)
from unittest import TestCase
import logging
import os
import sys
from snowflake.runtime.utils.const import LOG_TEST_UUID, TEST_DIR, TEST_MAX_BYTES
import io
from contextlib import contextmanager
import glob

os.environ["DEV_ENV"] = "1"


@contextmanager
def custom_stdout():
    # ref: https://stackoverflow.com/questions/35779023/get-text-contents-of-what-has-been-printed-python
    old_stdout = sys.stdout  # default stdout
    buffer = io.StringIO()
    sys.stdout = buffer  # attach a new IO to sys.stdout
    try:
        yield buffer
    finally:
        sys.stdout = old_stdout  # reset stdout back to default


class LoggerTest(TestCase):
    logger: LogType

    @classmethod
    def setUpClass(cls) -> None:
        if not os.path.exists(TEST_DIR):
            os.makedirs(TEST_DIR)
        cls.logger = get_logger()

    def test_get_mlrs_logger_with_custom_handler(self):
        self.assertEqual(len(self.logger.handlers), 1)

        get_logger()
        self.assertEqual(len(self.logger.handlers), 1)

        self.assertEqual(type(self.logger.handlers[0]), CustomLoggingHandler)

    def check_log_file(
        self,
        log_type: LogType,
        expected_msg: str,
        expected_file_length: int,
        file_suffix: str = "",
    ):
        custom_handler = self.logger.handlers[0]
        expected_file_path = custom_handler.handlers[log_type].baseFilename
        if file_suffix:
            expected_file_path += file_suffix

        # Check if file exists
        self.assertTrue(os.path.exists(expected_file_path))

        # Check the content of the file
        with open(expected_file_path, "r") as f:
            lines = f.readlines()
            self.assertEqual(len(lines), expected_file_length)
            if expected_file_length > 0:
                self.assertTrue(expected_msg in lines[-1])  # check the last line
            f.close()

    def test_generate_file_name(self) -> None:
        custom_handler = self.logger.handlers[0]

        expected = f"{TEST_DIR}/user-logs-mlrs-{LOG_TEST_UUID}.log"
        actual = custom_handler._generate_file_path(LogType.USER)

        self.assertEqual(expected, actual)

    def test_has_correct_handlers(self) -> None:
        custom_handler = self.logger.handlers[0]

        expected_keys = LogType
        self.assertCountEqual(expected_keys, custom_handler.handlers.keys())

        for idx in custom_handler.handlers:
            handler: logging.FileHandler = custom_handler.handlers[idx]
            expected_file = custom_handler._generate_file_path(idx)
            self.assertEqual(handler.baseFilename, expected_file)

    def test_log_create_file_with_content(self) -> None:
        # Test setting logger level
        set_mlrs_logger_level(logging.WARN)
        msg = "Hello World"
        self.logger.info(msg=msg, extra={"log_types": [LogType.USER]})
        self.check_log_file(
            log_type=LogType.USER, expected_msg=msg, expected_file_length=0
        )

        # Log message to single log file
        set_mlrs_logger_level(logging.INFO)

        msg = "Hello World"
        self.logger.info(msg=msg, extra={"log_types": [LogType.USER]})
        self.check_log_file(
            log_type=LogType.USER, expected_msg=msg, expected_file_length=1
        )

        # Assert the other file is still empty
        self.check_log_file(
            log_type=LogType.SYSTEM, expected_msg=msg, expected_file_length=0
        )

        # Log message to two log files at once
        msg = "Hello World 2"
        self.logger.error(
            msg=msg,
            extra={
                "log_types": [LogType.USER, LogType.SYSTEM],
            },
        )
        self.check_log_file(
            log_type=LogType.USER, expected_msg=msg, expected_file_length=2
        )
        self.check_log_file(
            log_type=LogType.SYSTEM, expected_msg=msg, expected_file_length=1
        )

        # Log message with default setting (no extra)
        msg = "Hello World 3"
        self.logger.error(msg=msg)
        self.check_log_file(
            log_type=LogType.USER, expected_msg=msg, expected_file_length=3
        )
        self.check_log_file(
            log_type=LogType.SYSTEM, expected_msg=msg, expected_file_length=2
        )

    def test_rotating_log(self) -> None:
        msg = "Hello World"
        self.logger.error(msg=msg, extra={"log_types": [LogType.USER]})

        expected_file_path = f"{TEST_DIR}/user-logs-mlrs-{LOG_TEST_UUID}.log"

        # get the current file size after 1 log
        file_size = os.path.getsize(expected_file_path)

        # number of iteration that should fill up file to max limit
        log_number = TEST_MAX_BYTES // file_size

        # fill the file
        for i in range(log_number - 1):
            self.logger.error(msg=msg, extra={"log_types": [LogType.USER]})

        self.check_log_file(
            log_type=LogType.USER, expected_msg=msg, expected_file_length=log_number
        )
        og_file_size = os.path.getsize(expected_file_path)
        assert og_file_size < TEST_MAX_BYTES

        # log another message, should overflow and rotate
        new_msg = "World Hello"
        self.logger.error(msg=new_msg, extra={"log_types": [LogType.USER]})

        # log file should be rotated: new file with base name is created with new msg
        self.check_log_file(
            log_type=LogType.USER, expected_msg=new_msg, expected_file_length=1
        )

        # original log file is rotated to baseFilename + suffix (e.g ...log.1)
        assert os.path.getsize(expected_file_path + ".1") == og_file_size

        self.check_log_file(
            log_type=LogType.USER,
            expected_msg=msg,
            expected_file_length=log_number,
            file_suffix=".1",
        )

    def tearDown(self) -> None:
        # empty log files
        open(f"{TEST_DIR}/user-logs-mlrs-{LOG_TEST_UUID}.log", "w").close()
        open(f"{TEST_DIR}/system-logs-mlrs-{LOG_TEST_UUID}.log", "w").close()

    @classmethod
    def tearDownClass(cls) -> None:
        # Clean up all log files created by this test, including any rotated files
        # This allows other tests that may be using loggers to continue working
        try:
            # Use glob to find all files that start with our log file patterns
            user_log_pattern = f"{TEST_DIR}/user-logs-mlrs-{LOG_TEST_UUID}.log*"
            system_log_pattern = f"{TEST_DIR}/system-logs-mlrs-{LOG_TEST_UUID}.log*"

            # Remove all matching user log files
            for log_file in glob.glob(user_log_pattern):
                if os.path.exists(log_file):
                    os.remove(log_file)

            # Remove all matching system log files
            for log_file in glob.glob(system_log_pattern):
                if os.path.exists(log_file):
                    os.remove(log_file)

        except OSError:
            # If files don't exist or can't be removed, that's fine
            pass
