"""Retry utilities for system error handling."""

import time
from typing import Callable, Tuple, Type, TypeVar

from ray.exceptions import RayActorError
from snowflake.connector.errors import OperationalError

from implementations.ray_data_ingester import SnowflakeResultBatchReadError
from snowflake.runtime.utils.logger import get_logger, print_user_log_info

logger = get_logger()
T = TypeVar("T")


# Common system errors worth retrying
SYSTEM_ERRORS: Tuple[Type[Exception], ...] = (
    ConnectionError,
    TimeoutError,
    OSError,
    SnowflakeResultBatchReadError,
    OperationalError,
    RayActorError,
)


def with_retry(
    fn: Callable[[], T],
    *,
    max_attempts: int = 3,
    initial_delay: float = 1.0,
    backoff_factor: float = 2.0,
    retryable_errors: Tuple[Type[Exception], ...] = SYSTEM_ERRORS,
    description: str = "Operation",
) -> T:
    """
    Execute a function with retry on specified errors.

    Uses exponential backoff between retries.

    Args:
        fn: Zero-argument callable to execute
        max_attempts: Total attempts (including first try)
        initial_delay: Seconds to wait before first retry
        backoff_factor: Multiply delay by this after each retry
        retryable_errors: Tuple of exception types to retry on
        description: Human-readable name for logging

    Returns:
        The return value of fn()

    Raises:
        The last exception if all retries fail, or immediately
        if the exception is not in retryable_errors.

    Example:
        >>> result = with_retry(
        ...     lambda: requests.get("https://example.com"),
        ...     max_attempts=3,
        ...     retryable_errors=(ConnectionError, TimeoutError),
        ...     description="HTTP request",
        ... )
    """
    attempt = 0
    delay = initial_delay

    while True:
        try:
            return fn()
        except Exception as e:
            attempt += 1
            is_retryable = isinstance(e, retryable_errors)

            if is_retryable and attempt < max_attempts:
                print_user_log_info(
                    logger,
                    f"[{description}] Attempt {attempt} failed, "
                    f"retrying in {delay}s. Error: {e}",
                )
                time.sleep(delay)
                delay *= backoff_factor
                continue

            # Not retryable or max attempts reached
            raise
