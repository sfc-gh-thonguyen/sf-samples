from unittest.mock import patch, MagicMock
from snowflake.runtime.utils import get_instance_ip

# Sample test data
SAMPLE_SERVICE_NAME = "test-service"
SAMPLE_IP_ADDRESS = "10.0.0.1"
SAMPLE_INSTANCE_ID = "1"


class TestGETSPCSInstanceIp:
    @patch("snowflake.runtime.utils.session_utils.get_session")
    def test_get_first_instance(self, mock_get_active_session):
        # Set up mock session
        mock_session = MagicMock()
        mock_get_active_session.return_value = mock_session

        # Mock the SQL execution and result
        mock_df = MagicMock()
        mock_session.sql.return_value = mock_df

        # Create sample result data
        sample_results = [
            {
                "instance_id": "2",
                "ip_address": "10.0.0.2",
                "start_time": "2023-01-01 10:10:10",
                "status": "READY",
            },
            {
                "instance_id": "1",
                "ip_address": SAMPLE_IP_ADDRESS,
                "start_time": "2023-01-01 10:00:00",
                "status": "READY",
            },
            {
                "instance_id": "3",
                "ip_address": "10.0.0.3",
                "start_time": "2023-01-01 10:20:00",
                "status": "READY",
            },
        ]

        # Mock the collect method to return our sample data
        mock_df.select.return_value = mock_df
        mock_df.collect.return_value = sample_results

        # Call the function
        result = get_instance_ip.get_first_instance(SAMPLE_SERVICE_NAME)

        # Assertions
        assert result == (SAMPLE_INSTANCE_ID, SAMPLE_IP_ADDRESS)
        mock_session.sql.assert_called_once_with(
            f"show service instances in service {SAMPLE_SERVICE_NAME}"
        )
        mock_df.select.assert_called_once_with(
            '"instance_id"', '"ip_address"', '"start_time"'
        )

    @patch("snowflake.runtime.utils.session_utils.get_session")
    def test_get_first_instance_no_start_time(self, mock_get_active_session):
        # Set up mock session
        mock_session = MagicMock()
        mock_get_active_session.return_value = mock_session

        # Mock the SQL execution and result
        mock_df = MagicMock()
        mock_session.sql.return_value = mock_df

        # Create sample result data
        sample_results = [
            {
                "instance_id": "2",
                "ip_address": "10.0.0.2",
                "start_time": None,
                "status": "PENDING",
            },
            {
                "instance_id": "1",
                "ip_address": SAMPLE_IP_ADDRESS,
                "start_time": None,
                "status": "PENDING",
            },
            {
                "instance_id": "3",
                "ip_address": "10.0.0.3",
                "start_time": None,
                "status": "PENDING",
            },
        ]

        # Return empty results
        mock_df.select.return_value = mock_df
        mock_df.collect.return_value = sample_results

        # Call the function
        result = get_instance_ip.get_first_instance(SAMPLE_SERVICE_NAME)

        # Assertion
        assert result == (SAMPLE_INSTANCE_ID, SAMPLE_IP_ADDRESS)
