#!/usr/bin/env python3
import sys
import time
import socket
import argparse
from typing import Optional
from snowflake.runtime.utils import session_utils


def get_self_ip() -> Optional[str]:
    """Get the IP address of the current service instance.
    References:
    - https://docs.snowflake.com/en/developer-guide/snowpark-container-services/working-with-services#general-guidelines-related-to-service-to-service-communications # noqa
    """
    try:
        hostname = socket.gethostname()
        instance_ip = socket.gethostbyname(hostname)
        return instance_ip
    except socket.error as e:
        print(f"Error: Unable to get IP address via socket. {e}", file=sys.stderr)
        return None


def get_first_instance(service_name: str) -> Optional[tuple[str, str]]:
    """Get the first instance of a batch job based on start time and instance ID.

    Args:
        service_name (str): The name of the service to query.

    Returns:
        tuple[str, str]: A tuple containing (instance_id, ip_address) of the head instance.
    """
    session = session_utils.get_session()
    df = session.sql(f"show service instances in service {service_name}")
    result = df.select('"instance_id"', '"ip_address"', '"start_time"').collect()

    if not result:
        return None

    # Sort by start_time first, then by instance_id
    sorted_instances = sorted(
        result, key=lambda x: (x["start_time"], int(x["instance_id"]))
    )
    head_instance = sorted_instances[0]
    if not head_instance["instance_id"] or not head_instance["ip_address"]:
        return None
    return (head_instance["instance_id"], head_instance["ip_address"])


def main():
    """Retrieves the IP address of a specified service instance or the current service.
    Args:
        service_name (str,required) Name of the service to query
        --instance-index (int, optional) Index of the service instance to query. Default: -1
            Currently only supports -1 to get the IP address of the current service instance.
        --head (bool, optional) Get the head instance information using show services.
            If set, instance-index will be ignored, and the script will return the index and IP address of
              the head instance, split by a space. Default: False.
        --timeout (int, optional) Maximum time to wait for IP address retrieval in seconds. Default: 720 seconds
        --retry-interval (int, optional) Time to wait between retry attempts in seconds. Default: 10 seconds
    Usage Examples:
        python get_instance_ip.py myservice --instance-index=1 --retry-interval=5
    Returns:
        Prints the IP address to stdout if successful. Exits with status code 0 on success, 1 on failure
    """

    parser = argparse.ArgumentParser(description="Get IP address of a service instance")
    group = parser.add_mutually_exclusive_group()
    parser.add_argument("service_name", help="Name of the service")
    group.add_argument(
        "--instance-index",
        type=int,
        default=-1,
        help="Index of service instance (default: -1 for self instance)",
    )
    group.add_argument(
        "--head",
        action="store_true",
        help="Get head instance information using show services",
    )
    parser.add_argument(
        "--timeout", type=int, default=720, help="Timeout in seconds (default: 720)"
    )
    parser.add_argument(
        "--retry-interval",
        type=int,
        default=10,
        help="Retry interval in seconds (default: 10)",
    )

    args = parser.parse_args()
    start_time = time.time()

    if args.head:
        while time.time() - start_time < args.timeout:
            head_info = get_first_instance(args.service_name)
            if head_info:
                print(f"{head_info[0]} {head_info[1]}")
                sys.exit(0)
            time.sleep(args.retry_interval)
        # If we get here, we've timed out
        print("Error: Unable to retrieve head IP address", file=sys.stderr)
        sys.exit(1)

    # If the index is -1, use get_self_ip to get the IP address of the current service
    if args.instance_index == -1:
        ip_address = get_self_ip()
        if ip_address:
            print(ip_address)
            sys.exit(0)
        else:
            print("Error: Unable to retrieve self IP address", file=sys.stderr)
            sys.exit(1)
    else:
        # We don't support querying a specific instance index other than -1
        print(
            "Error: Invalid arguments. Only --instance-index=-1 is supported for now.",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
