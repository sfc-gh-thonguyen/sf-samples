import pytest
import pyarrow as pa
from snowflake.runtime.utils.data_type_utils import convert_doubles_to_float32_arrow
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from snowflake.runtime.utils.data_type_utils import convert_to_pandas_df


def test_convert_doubles_to_float32_arrow():
    # Create a sample Arrow table with various data types
    data = {
        "int_col": pa.array([1, 2, 3], type=pa.int32()),
        "float64_col": pa.array([1.1, 2.2, 3.3], type=pa.float64()),
        "str_col": pa.array(["a", "b", "c"], type=pa.string()),
        "float64_col2": pa.array([4.4, 5.5, 6.6], type=pa.float64()),
    }
    table = pa.Table.from_pydict(data)

    # Convert the table
    converted_table = convert_doubles_to_float32_arrow(table)

    # Check that the number of columns remains the same
    assert len(converted_table.columns) == len(table.columns)

    # Check that float64 columns were converted to float32
    assert pa.types.is_float32(converted_table.schema.field("float64_col").type)
    assert pa.types.is_float32(converted_table.schema.field("float64_col2").type)

    # Check that non-float64 columns remain unchanged
    assert pa.types.is_int32(converted_table.schema.field("int_col").type)
    assert pa.types.is_string(converted_table.schema.field("str_col").type)

    # Check that the values are approximately equal (considering potential float precision issues)
    assert converted_table["float64_col"].to_pylist() == pytest.approx(
        table["float64_col"].to_pylist()
    )
    assert converted_table["float64_col2"].to_pylist() == pytest.approx(
        table["float64_col2"].to_pylist()
    )

    # Check that non-converted columns have exactly the same values
    assert converted_table["int_col"].to_pylist() == table["int_col"].to_pylist()
    assert converted_table["str_col"].to_pylist() == table["str_col"].to_pylist()


def test_convert_doubles_to_float32_arrow_empty_table():
    # Test with an empty table
    empty_table = pa.Table.from_pydict({})
    converted_empty_table = convert_doubles_to_float32_arrow(empty_table)
    assert len(converted_empty_table.columns) == 0


def test_convert_doubles_to_float32_arrow_no_float64():
    # Test with a table that has no float64 columns
    data = {
        "int_col": pa.array([1, 2, 3], type=pa.int32()),
        "float32_col": pa.array([1.1, 2.2, 3.3], type=pa.float32()),
        "str_col": pa.array(["a", "b", "c"], type=pa.string()),
    }
    table = pa.Table.from_pydict(data)
    converted_table = convert_doubles_to_float32_arrow(table)

    # Check that all columns remain unchanged
    assert converted_table.schema == table.schema
    for col_name in table.column_names:
        assert converted_table[col_name].to_pylist() == table[col_name].to_pylist()


@pytest.mark.gpu
def test_dummy():
    pass


def test_convert_to_pandas_df_from_dataframe():
    data = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    result = convert_to_pandas_df(data)
    pd.testing.assert_frame_equal(result, data)


def test_convert_to_pandas_df_from_series():
    data = pd.Series([1, 2, 3], name="a")
    result = convert_to_pandas_df(data)
    expected = data.to_frame()
    pd.testing.assert_frame_equal(result, expected)


def test_convert_to_pandas_df_from_csr_matrix():
    data = csr_matrix([[1, 0, 2], [0, 3, 0], [4, 0, 5]])
    result = convert_to_pandas_df(data)
    expected = pd.DataFrame.sparse.from_spmatrix(data, columns=["0", "1", "2"])
    pd.testing.assert_frame_equal(result, expected)


def test_convert_to_pandas_df_from_1d_ndarray():
    data = np.array([1, 2, 3])
    result = convert_to_pandas_df(data)
    expected = pd.DataFrame(data, columns=["0"])
    pd.testing.assert_frame_equal(result, expected)


def test_convert_to_pandas_df_from_2d_ndarray():
    data = np.array([[1, 2, 3], [4, 5, 6]])
    result = convert_to_pandas_df(data)
    expected = pd.DataFrame(data, columns=["0", "1", "2"])
    pd.testing.assert_frame_equal(result, expected)


def test_convert_to_pandas_df_unsupported_type():
    data = "unsupported type"
    with pytest.raises(ValueError, match="Unsupported data type str"):
        convert_to_pandas_df(data)
