import uuid

TEST_DIR = "/tmp/mlrs-logs-dev"
LOG_TEST_UUID = str(uuid.uuid4())
MLRS_METRICS_PORT = 11501
DEFAULT_RAY_METRICS_PORT = 11502
DEFAULT_RAY_PORT = 7777
DEFAULT_RAY_DASHBOARD_PORT = 12003
DEFAULT_RAY_CLIENT_SERVER_PORT = 10001
DEFAULT_RAY_MIN_WORKER_PORT = 20002
DEFAULT_RAY_MAX_WORKER_PORT = 29999
LOG_MAX_BYTES = 512_000_000
TEST_MAX_BYTES = 500
NOTEBOOK_PORT = 9090

RAY_STATUS = "ray_status"
NOTEBOOK_STATUS = "notebook_status"

# timeout values for health check
HEALTH_CHECK_HTTP_TIMEOUT_10 = 10
HEALTH_CHECK_HTTP_RETRY_COUNT = 1
HEALTH_CHECK_FAILURE_COUNT = 3
HEALTH_CHECK_HTTP_TIMEOUT_5 = 5

HEALTH_CHECK_INITIAL_DELAY_SECS = 180
HEALTH_CHECK_REPEAT_SECS = 30
HEALTH_CHECK_FAILURE_DELAY_SECS = 5

# extracted from https://github.com/ray-project/ray/blob/c54dc5c5857bed5bedc865f07f8917c1a8f516de
# /python/ray/tests/test_metrics_agent.py#L41

EXPECTED_RAY_METRICS = [
    "ray_node_disk_usage",
    "ray_node_mem_used",
    "ray_node_mem_total",
    "ray_node_cpu_utilization",
    # Object store metrics do not show up immediately. Need to explicitly wait for them.
    "ray_object_store_available_memory",
    "ray_object_store_used_memory",
    "ray_object_store_num_local_objects",
    "ray_object_store_memory",
    "ray_object_manager_num_pull_requests",
    "ray_object_directory_subscriptions",
    "ray_object_directory_updates",
    "ray_object_directory_lookups",
    "ray_object_directory_added_locations",
    "ray_object_directory_removed_locations",
    "ray_internal_num_processes_started",
    "ray_internal_num_spilled_tasks",
    "ray_grpc_server_req_process_time_ms",
    "ray_grpc_server_req_new_total",
    "ray_grpc_server_req_handling_total",
    "ray_grpc_server_req_finished_total",
    "ray_object_manager_received_chunks",
    "ray_pull_manager_usage_bytes",
    "ray_pull_manager_requested_bundles",
    "ray_pull_manager_requests",
    "ray_pull_manager_active_bundles",
    "ray_pull_manager_retries_total",
    # Note: ray_push_manager_in_flight_pushes removed in Ray 2.52
    "ray_push_manager_chunks",
    "ray_scheduler_failed_worker_startup_total",
    "ray_scheduler_tasks",
    "ray_scheduler_unscheduleable_tasks",
    "ray_spill_manager_objects",
    "ray_spill_manager_objects_bytes",
    "ray_spill_manager_request_total",
    # "ray_gcs_placement_group_creation_latency_ms_sum", -- these two metrics do not exist in test
    # "ray_gcs_placement_group_scheduling_latency_ms_sum",
    "ray_gcs_placement_group_count",
    "ray_gcs_actors_count",
    # RAY NODE METRICS
    "ray_node_cpu_utilization",
    "ray_node_cpu_count",
    "ray_node_mem_used",
    "ray_node_mem_available",
    "ray_node_mem_total",
    "ray_node_disk_io_read",
    "ray_node_disk_io_write",
    "ray_node_disk_io_read_count",
    "ray_node_disk_io_write_count",
    "ray_node_disk_io_read_speed",
    "ray_node_disk_io_write_speed",
    "ray_node_disk_read_iops",
    "ray_node_disk_write_iops",
    "ray_node_disk_usage",
    "ray_node_disk_free",
    "ray_node_disk_utilization_percentage",
    "ray_node_network_sent",
    "ray_node_network_received",
    "ray_node_network_send_speed",
    "ray_node_network_receive_speed",
    # RAY NODE COMPONENT METRICS
    "ray_component_cpu_percentage",
    "ray_component_rss_mb",
    "ray_component_uss_mb",
    "ray_component_num_fds",
    # Additional metrics
    "ray_component_mem_shared_bytes",
    "ray_cluster_active_nodes",
]

# These metrics are conditionally available and may not always be present
# depending on Ray's internal state and timing
OPTIONAL_RAY_METRICS = [
    "ray_health_check_rpc_latency_ms_sum",  # Only available after Ray performs health check RPCs
]

# Note: The separation of EXPECTED_RAY_METRICS and OPTIONAL_RAY_METRICS addresses
# the intermittent availability of certain Ray metrics. Health check latency metrics
# are only generated when Ray's internal health checking system performs RPC calls
# between components, and the happening time is unpredictable.
