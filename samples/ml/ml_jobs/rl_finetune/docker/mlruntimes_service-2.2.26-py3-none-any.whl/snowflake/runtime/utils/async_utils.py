import asyncio
from collections.abc import Coroutine
import concurrent.futures
import queue


async def aio_queue_reader(comm_queue: queue.Queue):
    """multiprocessing.Queue is shareable between multiple processes
    using pipes, semaphores, etc., to simplify multiprocess communication.

    multiprocessing.Queue is not yet complatible with asyncio. get() and put()
    methods are blocking calls.

    his method provides asyncio style reader for multiprocessing.Queue by
    executing all the blocking calls in a separate thread.
    """
    executor = concurrent.futures.ThreadPoolExecutor()
    loop = asyncio.get_event_loop()

    done = False
    while not done:
        msg = await loop.run_in_executor(executor, comm_queue.get)
        if "done" in msg and msg["done"]:
            done = True
        yield msg


def safe_run_awaitable(awaitable: Coroutine) -> object:
    """
    Method to safely run an awaitable (Coroutine, Task, or Future) to completion.

    If this method is called from an event loop, it will create a new thread and block
    until the awaitable completes in that new thread. This is required because when
    running inside an event loop, blocking calls should be executed in a different
    thread to avoid blocking the event loop.

    Otherwise, this method will create a new event loop in the current thread and run
    the awaitable until completion.

    Note:
    https://snowflakecomputing.atlassian.net/browse/SNOW-1474726
    asyncio.run requires it first argument to be of the Coroutine type
    even if Coroutine is a subtype of Awaitable.
    More details: https://stackoverflow.com/q/76961919
    """
    running_in_event_loop: bool = False
    try:
        asyncio.get_running_loop()  # Triggers RuntimeError if no running event loop
        running_in_event_loop = True
    except RuntimeError:
        # Not running in a event loop
        running_in_event_loop = False

    if running_in_event_loop:
        # Create a separate thread so we can block before returning
        with concurrent.futures.ThreadPoolExecutor(1) as pool:
            return pool.submit(lambda: asyncio.run(awaitable)).result()
    else:
        return asyncio.run(awaitable)
