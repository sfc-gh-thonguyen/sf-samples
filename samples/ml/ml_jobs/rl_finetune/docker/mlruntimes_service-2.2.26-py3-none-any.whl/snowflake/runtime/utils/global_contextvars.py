import contextvars

request_id_contextvar = contextvars.ContextVar("request_id_contextvar", default="")
node_type_contextvar = contextvars.ContextVar("node_type_contextvar", default="")


def set_context_head(request_id: str):
    request_id_contextvar.set(request_id)
    node_type_contextvar.set("HEAD_NODE")


def set_context_worker(request_id: str):
    request_id_contextvar.set(request_id)
    node_type_contextvar.set("WORKER_NODE")
