import pandas as pd
from snowflake.snowpark import Session

from snowflake.snowpark._internal.utils import (
    random_name_for_temp_object,
    TempObjectType,
)


def get_resultset_queryid_from_df(df: pd.DataFrame, session: Session) -> str:
    """Create a temp table from a pandas df, use a resultset to point to this table, and
        return a query_id that corresponds to the resultset.

    Args:
        df: The pandas dataframe.

    Returns:
        a string query id.
    """

    temp_table_name = random_name_for_temp_object(TempObjectType.TABLE)

    session.write_pandas(
        df=df,
        auto_create_table=True,
        table_name=temp_table_name,
        table_type="temporary",
    )

    query_str = f"""
        DECLARE
            res RESULTSET;
        BEGIN
            res := (SELECT * from {temp_table_name});
            RETURN TABLE(res);
        END
        """

    res_df = session.sql(query_str)
    async_job = res_df.collect_nowait()
    query_id = async_job.query_id
    # Wait for execution to complete.
    # TODO: This call ends up running "select * from table(result_scan(sfqid))" query.
    # Find a cheaper way to wait for async query to complete.
    async_job.result(result_type="count")
    return query_id
