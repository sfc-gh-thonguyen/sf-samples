from snowflake.snowpark import Row
from snowflake.runtime.utils.stage_fs import SFStageFileSystem
import pickle


def test_stage_fs_can_be_pickled():
    sffs = SFStageFileSystem(
        db="test_db",
        schema="test_schema",
        stage="MY_STAGE",
    )
    # Should pickle without any errors
    pickled_obj = pickle.dumps(sffs)
    # Unpickle and verify the object type and attribute
    unpickled_obj = pickle.loads(pickled_obj)
    assert isinstance(unpickled_obj, SFStageFileSystem)
    assert unpickled_obj._stage == "MY_STAGE"
    assert unpickled_obj._db == "test_db"
    assert unpickled_obj._schema == "test_schema"


def test_parse_list_result():
    # Mock the necessary dependencies
    sffs = SFStageFileSystem(
        db="test_db",
        schema="test_schema",
        stage="MY_STAGE",
    )
    StageRow = Row(name=str, size=int, md5=str, last_modified=str)
    # Test cases
    test_cases = [
        {
            "name": "internal stage",
            "list_result": [
                StageRow(
                    name="my_stage/file1.txt",
                    size=100,
                    md5="abc123",
                    last_modified="2024-01-01",
                ),
                StageRow(
                    name="my_stage/file2.txt",
                    size=200,
                    md5="def456",
                    last_modified="2024-01-02",
                ),
                StageRow(
                    name="my_stage/other.txt",
                    size=300,
                    md5="ghi789",
                    last_modified="2024-01-03",
                ),
                StageRow(name="my_stage/subdir/", size=0, md5=None, last_modified=None),
            ],
            "search_path": "/",
            "expected": [
                {
                    "name": "file1.txt",
                    "size": 100,
                    "type": "file",
                    "md5": "abc123",
                    "last_modified": "2024-01-01",
                },
                {
                    "name": "file2.txt",
                    "size": 200,
                    "type": "file",
                    "md5": "def456",
                    "last_modified": "2024-01-02",
                },
                {
                    "name": "other.txt",
                    "size": 300,
                    "type": "file",
                    "md5": "ghi789",
                    "last_modified": "2024-01-03",
                },
                {
                    "name": "subdir/",
                    "size": 0,
                    "type": "directory",
                    "md5": None,
                    "last_modified": None,
                },
            ],
        },
        {
            "name": "s3 nested directory case",
            "list_result": [
                StageRow(
                    name="s3://my_stage/subdir/file1.txt",
                    size=100,
                    md5="abc123",
                    last_modified="2024-01-01",
                ),
                StageRow(
                    name="s3://my_stage/file2.txt",
                    size=200,
                    md5="def456",
                    last_modified="2024-01-02",
                ),
            ],
            "search_path": "/",
            "expected": [
                {
                    "name": "file2.txt",
                    "size": 200,
                    "type": "file",
                    "md5": "def456",
                    "last_modified": "2024-01-02",
                },
                {
                    "name": "subdir/",
                    "size": 0,
                    "type": "directory",
                    "md5": None,
                    "last_modified": None,
                },
            ],
        },
        {
            "name": "azure nested directory case",
            "list_result": [
                StageRow(
                    name="azure://my_stage/subdir/file1.txt",
                    size=100,
                    md5="abc123",
                    last_modified="2024-01-01",
                ),
                StageRow(
                    name="azure://my_stage/file2.txt",
                    size=200,
                    md5="def456",
                    last_modified="2024-01-02",
                ),
            ],
            "search_path": "/",
            "expected": [
                {
                    "name": "file2.txt",
                    "size": 200,
                    "type": "file",
                    "md5": "def456",
                    "last_modified": "2024-01-02",
                },
                {
                    "name": "subdir/",
                    "size": 0,
                    "type": "directory",
                    "md5": None,
                    "last_modified": None,
                },
            ],
        },
    ]

    # Run tests
    for test_case in test_cases:
        result = sffs._parse_list_result(
            test_case["list_result"], test_case["search_path"]
        )
        assert sorted(result, key=lambda x: x["name"]) == sorted(
            test_case["expected"], key=lambda x: x["name"]
        ), f"Failed {test_case['name']}"
