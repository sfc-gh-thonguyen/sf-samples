from snowflake.runtime.utils.ray_utils import RuntimeRayTaskError
import pickle


def test_snowflake_result_batch_read_task_error_from_exception():
    try:
        raise ValueError("Test error message")
    except Exception as original_exception:
        error_instance = RuntimeRayTaskError.from_exception(original_exception)

        assert error_instance.original_type == "ValueError"
        assert error_instance.message == "Test error message"
        assert 'ValueError("Test error message")' in error_instance.traceback_str
        pickled_error_instance = pickle.loads(pickle.dumps(error_instance))
        assert pickled_error_instance.original_type == "ValueError"
        assert pickled_error_instance.message == "Test error message"
        assert (
            'ValueError("Test error message")' in pickled_error_instance.traceback_str
        )


def test_snowflake_result_batch_read_task_error_from_exception_with_custom_exception():
    class CustomException(Exception):
        pass

    try:
        original_exception = CustomException("Custom error message")
        error_instance = RuntimeRayTaskError.from_exception(original_exception)
    except Exception as original_exception:
        error_instance = RuntimeRayTaskError.from_exception(original_exception)

        assert error_instance.original_type == "CustomException"
        assert error_instance.message == "Custom error message"
        assert 'CustomException("Custom error message")' in error_instance.traceback_str

        pickled_error_instance = pickle.loads(pickle.dumps(error_instance))
        assert pickled_error_instance.original_type == "ValueError"
        assert pickled_error_instance.message == "Test error message"
        assert (
            'CustomException("Custom error message")'
            in pickled_error_instance.traceback_str
        )
