import os
from snowflake.snowpark import Session
from typing import Optional
import threading

# TODO: Remove `snowflake.ml.utils.connection_params` request once two versions past 1.8.5
try:
    from snowflake.ml._internal.utils.connection_params import SnowflakeLoginOptions
except ImportError:
    from snowflake.ml.utils.connection_params import SnowflakeLoginOptions


IS_DEV_ENV = os.getenv("DEV_ENV", None)
_global_session: Optional[Session] = None
_session_lock = threading.Lock()


def get_session() -> Session:
    global _global_session
    if _global_session is not None and not _global_session._conn._conn.expired:
        return _global_session

    with _session_lock:
        # Re-check inside the lock (double-checked locking)
        if _global_session is None or _global_session._conn._conn.expired:
            params = SnowflakeLoginOptions()
            params["client_session_keep_alive"] = True
            _global_session = Session.builder.configs(params).getOrCreate()
        return _global_session
