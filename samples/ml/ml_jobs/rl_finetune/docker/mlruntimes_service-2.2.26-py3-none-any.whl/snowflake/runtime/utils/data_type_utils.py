import pyarrow as pa
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from typing import Union


def convert_doubles_to_float32_arrow(table: pa.Table) -> pa.Table:
    """
    Snowflake returns all floating point numbers as float64 (double), but sometimes
    float64 is not necessary for ML models and also some frameworks will treat it as float32 anyway. E.g. xgboost_ray.

    This function converts all float64 columns to float32 in an Arrow table.
    """
    new_schema = pa.schema(
        [
            field.with_type(pa.float32()) if pa.types.is_float64(field.type) else field
            for field in table.schema
        ]
    )
    return table.cast(new_schema)


def convert_to_pandas_df(
    data: Union[pd.DataFrame, np.ndarray, pd.Series, csr_matrix]
) -> pd.DataFrame:
    """
    Convert all support in memory data type to pandas dataframe.

    This is for easier processing on columsn names and conversion to Ray Dataset.
    """
    if isinstance(data, pd.DataFrame):
        data = data.rename(columns=lambda x: str(x))
        return data
    if isinstance(data, pd.Series):
        return data.to_frame()
    if isinstance(data, csr_matrix):
        n_cols = data.shape[1]
        return pd.DataFrame.sparse.from_spmatrix(
            data, columns=[str(i) for i in range(n_cols)]
        )
    if isinstance(data, np.ndarray):
        if len(data.shape) == 1:
            # This is a 1D array, convert it to a DataFrame with a single column
            return pd.DataFrame(data, columns=["0"])
        n_cols = data.shape[1]
        return pd.DataFrame(data, columns=[str(i) for i in range(n_cols)])

    raise ValueError(f"Unsupported data type {type(data).__name__}")
