import logging
import os
import tempfile
import time
import shutil
from dataclasses import dataclass
from typing import Any, Dict, IO, List, Optional, Tuple, Union, cast

import fsspec
from fsspec.implementations import http as httpfs
from snowflake.snowpark import AsyncJob, Row
from snowflake.connector import errors
from snowflake.snowpark import exceptions as snowpark_exceptions
from snowflake.runtime.utils.session_utils import get_session


# The default length of how long a presigned url stays active in seconds.
# Presigned url here is used to fetch file objects from Snowflake when SFStageFileSystem.open() is called.
_PRESIGNED_URL_LIFETIME_SEC = 14400

# The threshold of when the presigned url should get refreshed before its expiration.
_PRESIGNED_URL_HEADROOM_SEC = 3600

# Snowpark error codes
ERRNO_FILE_EXIST_IN_STAGE = 1030
ERRNO_DOMAIN_NOT_EXIST = 2003
ERRNO_STAGE_NOT_EXIST = 391707


@dataclass(frozen=True)
class _PresignedUrl:
    """File system metadata for each stage file."""

    __slots__ = ["url", "expire_at"]
    url: str
    expire_at: float

    def is_expiring(self, headroom_sec: float = _PRESIGNED_URL_HEADROOM_SEC) -> bool:
        """Check if a token is going to expire in <headroom_sec> seconds."""
        return not self.expire_at or time.time() > self.expire_at - headroom_sec


class _TempFileWrapper:
    """
    Duck-typed file-like wrapper that cleans up the temporary directory on close.

    This class wraps a file handle and ensures that the temporary directory
    created for parallel-safe downloads is properly cleaned up after the file is read.

    Does not inherit from AbstractBufferedFile to avoid complex initialization requirements.
    Instead, implements the file-like interface through duck typing.
    """

    def __init__(self, file_handle: IO[bytes], temp_dir: str):
        """
        Args:
            file_handle: An open binary file handle to wrap
            temp_dir: Path to temporary directory to clean up on close
        """
        self._file: IO[bytes] = file_handle
        self._temp_dir: str = temp_dir
        self._closed: bool = False
        # Copy attributes from wrapped file for compatibility
        self.mode = getattr(file_handle, "mode", "rb")
        self.name = getattr(file_handle, "name", None)
        self.size = None
        try:
            # Try to get size if possible
            pos = file_handle.tell()
            file_handle.seek(0, 2)  # Seek to end
            self.size = file_handle.tell()
            file_handle.seek(pos)  # Restore position
        except (OSError, AttributeError):
            pass

    def read(self, size: int = -1) -> bytes:
        """Read bytes from the file."""
        return self._file.read(size)

    def readline(self, size: int = -1) -> bytes:
        """Read a line from the file."""
        return self._file.readline(size)

    def readlines(self, hint: int = -1) -> List[bytes]:
        """Read all lines from the file."""
        return self._file.readlines(hint)

    def seek(self, offset: int, whence: int = 0) -> int:
        """Seek to a position in the file."""
        return self._file.seek(offset, whence)

    def tell(self) -> int:
        """Get current file position."""
        return self._file.tell()

    def readable(self) -> bool:
        """Check if file is readable."""
        return self._file.readable()

    def writable(self) -> bool:
        """Check if file is writable."""
        return self._file.writable()

    def seekable(self) -> bool:
        """Check if file is seekable."""
        return self._file.seekable()

    def flush(self) -> None:
        """Flush file buffer."""
        if hasattr(self._file, "flush"):
            self._file.flush()

    @property
    def closed(self) -> bool:
        """Check if file is closed."""
        return self._closed or (hasattr(self._file, "closed") and self._file.closed)

    def close(self) -> None:
        """Close the file and clean up the temporary directory."""
        if not self._closed:
            self._closed = True
            try:
                if not self._file.closed:
                    self._file.close()
            finally:
                # Clean up temp directory
                if os.path.exists(self._temp_dir):
                    try:
                        shutil.rmtree(self._temp_dir)
                    except Exception as e:
                        logging.warning(
                            f"Failed to clean up temp directory {self._temp_dir}: {e}"
                        )

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, *args):
        """Context manager exit."""
        self.close()

    def __iter__(self):
        """Iterate over lines."""
        return iter(self._file)

    def __del__(self):
        """
        Cleanup on deletion - but be careful not to close if still in use.
        Only clean up temp directory, don't close the file handle.
        """
        # Just try to clean up temp directory if file was never properly closed
        if not self._closed and os.path.exists(self._temp_dir):
            try:
                shutil.rmtree(self._temp_dir, ignore_errors=True)
            except Exception:
                pass  # Silently ignore - we're in finalizer


def _get_httpfs_kwargs(**kwargs: Any) -> Dict[str, Any]:
    """Extract kwargs that are meaningful to HTTPFileSystem."""
    httpfs_related_keys = [
        "block_size",
        "cache_type",
        "cache_options",
    ]
    httpfs_related_kwargs = {}
    for key in httpfs_related_keys:
        v = kwargs.get(key, None)
        if v:
            httpfs_related_kwargs[key] = v
    return httpfs_related_kwargs


class SFStageFileSystem(fsspec.AbstractFileSystem):
    """ A Snowflake stage file system based on fsspec (https://filesystem-spec.readthedocs.io/).

    It grants user readonly access to Snowflake stage as if it were a file system. It exposes a
    filesystem-like API (ls, open) on top of Snowflake internal stage storage.

    Example: Create FS object and do file operation
    --------
    >>> conn = snowflake.connector.connect(**connection_parameters)
    >>> sffs = SFStageFileSystem(db="MYDB", schema="public", stage="FOO", sf_connection=conn)
    >>> sffs.ls("nytrain")
    ['nytrain/data_0_0_0.csv', 'nytrain/data_0_0_1.csv']
    >>> with sffs.open('nytrain/data_0_0_1.csv', mode='rb') as f:
    >>>     print(f.readline())
    b'2014-02-05 14:35:00.00000054,13,2014-02-05 14:35:00 UTC,\
        -74.00688,40.73049,-74.00563,40.70676,2\n'
    """

    # Default to use snowpark because we found pre-signed url path has a bug in file access
    _USE_FALLBACK_FILE_ACCESS = True

    def __init__(
        self,
        *,
        db: str,
        schema: str,
        stage: str,
        **kwargs: Any,
    ) -> None:
        """Initiate the file system with stage information and a snowflake connection.

        Args:
            db: The database name of the target internal stage.
            schema: The schema name of the target internal stage.
            stage: The name of the target stage.
            snowpark_session: A Snowpark session object. Mutually exclusive to `sf_connection`.
            sf_connection: A Snowflake python connection object. Mutually exclusive to `snowpark_session`.
            **kwargs : Optional. Other parameters that can be passed on to fsspec. Currently supports:
                - skip_instance_cache: Int. Controls reuse of instances.
                - cache_type, cache_options, block_size: Configure file buffering.
                See more information in https://filesystem-spec.readthedocs.io/en/latest/features.html

        Raises:
            ValueError: An error occurred when not exactly one of sf_connection and snowpark_session is given.
        """
        logging.debug(f"Creating new stage file system on @{db}.{schema}.{stage}")
        self._db = db
        self._schema = schema
        self._stage = stage
        self._url_cache: Dict[str, _PresignedUrl] = {}
        httpfs_kwargs = _get_httpfs_kwargs(**kwargs)
        self._fs = httpfs.HTTPFileSystem(**httpfs_kwargs)

        super().__init__(**kwargs)

    @property
    def stage_name(self) -> str:
        """Get the Snowflake path to this stage.

        Returns:
            String in the format of "@{database}.{schema}.{stage}".
                Example: @mydb.myschema.mystage
        """
        return f"@{self._db}.{self._schema}.{self._stage}"

    def ls(
        self, path: str, detail: bool = False
    ) -> Union[List[str], List[Dict[str, Any]]]:
        """Override fsspec `ls` method. List single "directory" with or without details.

        Args:
            path: Relative file paths in the stage.
                Example:
                    "": Empty string points to the stage root.
                    "mydir": Points to the "mydir" file/directory under the stage.
                    "dir1/dir2": Points to the "dir2" file/directory in the "dir1" directory.
            detail: Whether to present detailed information of results. If set to be False, a list of filenames will be
                returned. If set to be True, each list item in the result is a dict, whose keys are "name", "size",
                "type", "md5" and "last_modified".

        Returns:
            A list of filename if `detail` is false, or a list of dict if `detail` is true.

        Raises:
            SnowflakeMLException: An error occurred when the given path points to a stage that cannot be found.
            SnowflakeMLException: An error occurred when Snowflake cannot list files in the given stage path.
        """
        try:
            loc = self.stage_name
            path = path.lstrip("/")
            async_job: AsyncJob = (
                get_session().sql(f"LIST '{loc}/{path}'").collect(block=False)
            )
            objects: List[Row] = _resolve_async_job(async_job)
        except snowpark_exceptions.SnowparkSQLException as e:
            if e.sql_error_code == ERRNO_DOMAIN_NOT_EXIST:
                raise ValueError(
                    f"Stage {loc} does not exist or is not authorized."
                ) from e
            else:
                raise e

        files = self._parse_list_result(objects, path)
        if detail:
            return files
        else:
            return [f["name"] for f in files]

    def optimize_read(self, files: Optional[List[str]] = None) -> None:
        """Prefetch and cache the presigned urls for all the given files to speed up the read performance.

        All the files introduced here will have their urls cached. Further open() on any of cached urls will lead to a
        batch refreshment of all the cached urls if that url is inactive.

        Args:
            files: A list of file paths. If not given, all the files that have urls cached will refresh their url cache.
        """
        if not files:
            files = list(self._url_cache.keys())
        url_lifetime = _PRESIGNED_URL_LIFETIME_SEC
        start_time = time.time()
        logging.info(f"Start batch fetching presigned urls for {self.stage_name}.")
        presigned_urls = self._fetch_presigned_urls(files, url_lifetime)
        expire_at = start_time + url_lifetime

        for presigned_url in presigned_urls:
            file_path, url = presigned_url
            self._url_cache[file_path] = _PresignedUrl(url, expire_at)
            logging.debug(f"Retrieved presigned url for {file_path}.")
        logging.info(f"Finished batch fetching presigned urls for {self.stage_name}.")

    def _open(
        self, path: str, mode: str = "rb", **kwargs: Any
    ) -> fsspec.spec.AbstractBufferedFile:
        """Override fsspec `_open` method. Open a file for reading.

        The opened file will be readable for 4 hours. After that, you need to reopen the file.

        Args:
            path: Path of file in Snowflake stage.
            mode: One of 'r', 'rb'. These have the same meaning as they do for the built-in `open` function.
            **kwargs: Extra options that supported by fsspec. See more in
                https://filesystem-spec.readthedocs.io/en/latest/api.html#fsspec.open

        Returns:
            A fsspec file-like object.

        Raises:
            SnowflakeMLException: An error occurred when the given path points to a file that cannot be found.
            snowpark_exceptions.SnowparkClientException: File access failed with a Snowpark exception
        """
        path = path.lstrip("/")
        if self._USE_FALLBACK_FILE_ACCESS:
            return self._open_with_snowpark(path)
        cached_presigned_url = self._url_cache.get(path, None)
        try:
            if not cached_presigned_url:
                res = self._fetch_presigned_urls([path])
                url = res[0][1]
                expire_at = time.time() + _PRESIGNED_URL_LIFETIME_SEC
                cached_presigned_url = _PresignedUrl(url, expire_at)
                self._url_cache[path] = cached_presigned_url
                logging.debug(f"Retrieved presigned url for {path}.")
            elif cached_presigned_url.is_expiring():
                self.optimize_read()
                cached_presigned_url = self._url_cache[path]
        except snowpark_exceptions.SnowparkClientException as e:
            if not self._USE_FALLBACK_FILE_ACCESS:
                raise
            # This may be an intermittent failure, so don't set _USE_FALLBACK_FILE_ACCESS = True
            logging.warning(
                f"Pre-signed URL generation failed with {e.message}, trying fallback file access"
            )
            return self._open_with_snowpark(path)
        url = cached_presigned_url.url
        try:
            return self._fs._open(url, mode=mode, **kwargs)
        except FileNotFoundError:
            # Enable fallback if _USE_FALLBACK_FILE_ACCESS is True or None; set to False to disable
            if self._USE_FALLBACK_FILE_ACCESS != False:  # noqa: E712
                content = self._open_with_snowpark(path)
                self._USE_FALLBACK_FILE_ACCESS = True
                return content
            raise ValueError(f"Stage file {path} doesn't exist.")

    def _open_with_snowpark(self, path: str) -> fsspec.spec.AbstractBufferedFile:
        """Open a file for reading using snowflake.snowpark.file_operation

        Uses a unique temporary directory per file to avoid race conditions when
        multiple workers download files concurrently. get_stream() uses a shared
        temp directory which causes file corruption in parallel downloads.

        Args:
            path: Path of file in Snowflake stage.

        Returns:
            A fsspec file-like object.

        Raises:
            Exception: An error occurred when the given path points to a file that cannot be found.
        """
        temp_dir = None
        try:
            # Create unique temp directory for this download to avoid race conditions
            # in parallel processing. get_stream() uses shared temp directory which
            # causes corruption when multiple workers download same filename
            temp_dir = tempfile.mkdtemp(prefix=f"stage_fs_{os.getpid()}_")
            stage_file_path = f"{self.stage_name}/{path}"

            # Download file to unique temp directory
            session = get_session()
            session.file.get(stage_file_path, temp_dir)

            # Open the downloaded file
            filename = os.path.basename(path)
            local_file_path = os.path.join(temp_dir, filename)

            if not os.path.exists(local_file_path):
                raise ValueError(f"Stage file {path} doesn't exist.")

            # Open file in binary read mode and wrap with cleanup handler
            file_handle = open(local_file_path, "rb")
            return _TempFileWrapper(file_handle, temp_dir)
        except Exception:
            # Clean up temp directory if it was created before error occurred
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            raise

    def _parse_list_result(
        self, list_result: List[Row], search_path: str
    ) -> List[Dict[str, Any]]:
        """Convert the result from LIST query to the expected format of fsspec ls() method.

        Note that Snowflake LIST query has different behavior with ls(). LIST query will return all the stage files
        whose path starts with the given search_path. However, ls() should only return files that either exactly
        match the given search_path or are under the given search_path directory.

        For example, both "mydir/hello_world.txt" and "mydir1/hello_world.txt" will appear as a result of "LIST mydir",
        but only the former one is in "mydir" directory. As a result, only "mydir/hello_world.txt" should be returned by
        ls("mydir").

        Args:
            list_result: The result of LIST query, a list where each item is a Snowpark Row with four items:
                name, size, md5 and last_modified.
            search_path: The path that was used by the List query to get the list_result.

        Returns:
            A list of dict, where each dict contains key-value pairs as the properties of a file.
        """
        files: Dict[str, Dict[str, Any]] = {}
        search_path = search_path.strip("/")
        for row in list_result:
            name, size, md5, last_modified = (
                row["name"],
                row["size"],
                row["md5"],
                row["last_modified"],
            )
            obj_path = self._stage_path_to_relative_path(name)
            if obj_path == search_path:
                # If there is a exact match, then the matched object will always be a file object.
                self._add_file_info_helper(
                    files, obj_path, size, "file", md5, last_modified
                )
                continue
            elif search_path and not obj_path.startswith(search_path + "/"):
                # If the path doesn't start with "<search_path>/", the object is not under the <search_path> directory.
                continue

            # Now we want to distinguish whether the object is in a subdirecotry of the given search path.
            rel_file_path = obj_path[len(search_path) :].lstrip("/")
            slash_idx = rel_file_path.find("/")
            if slash_idx == -1:
                # There is no subdirectory.
                self._add_file_info_helper(
                    files, obj_path, size, "file", md5, last_modified
                )
            else:
                # There is a subdirectory. We will only add the top level subdirectory to the result of ls().
                dir_path = "" if not search_path else f"{search_path}/"
                dir_path += f"{rel_file_path[:slash_idx + 1]}"
                self._add_file_info_helper(files, dir_path, 0, "directory", None, None)
        return list(files.values())

    def _stage_path_to_relative_path(self, stage_path: str) -> str:
        """Convert a stage file path which comes from the LIST query to a relative file path in that stage.

        The file path returned by LIST query always has the format "<stage_name>/<relative_file_path>".
                Only <relative_file_path> will be returned.

        Args:
            stage_path: A string started with the name of the stage.

        Returns:
            A string of the relative stage path.
        """
        if stage_path.startswith(self._stage.lower()):
            return stage_path[len(self._stage) + 1 :]
        elif stage_path.startswith("s3://"):
            return stage_path.lstrip("s3://").split("/", 1)[1]
        elif stage_path.startswith("gcs://"):
            return stage_path.lstrip("gcs://").split("/", 1)[1]
        elif stage_path.startswith("azure://"):
            return stage_path.lstrip("azure://").split("/", 1)[1]

        raise ValueError(f"Invalid stage path: {stage_path}")

    def _add_file_info_helper(
        self,
        files: Dict[str, Dict[str, Any]],
        object_path: str,
        file_size: int,
        file_type: str,
        md5: Optional[str],
        last_modified: Optional[str],
    ) -> None:
        files.setdefault(
            object_path,
            {
                "name": object_path,
                "size": file_size,
                "type": file_type,
                "md5": md5,
                "last_modified": last_modified,
            },
        )

    def _fetch_presigned_urls(
        self, files: List[str], url_lifetime: float = _PRESIGNED_URL_LIFETIME_SEC
    ) -> List[Tuple[str, str]]:
        """Fetch presigned urls for the given files."""
        file_df = get_session().create_dataframe(files).to_df("name")
        try:
            presigned_urls: List[Tuple[str, str]] = file_df.select_expr(
                f"name, get_presigned_url('{self.stage_name}', name, {url_lifetime}) as url"
            ).collect()
        except snowpark_exceptions.SnowparkSQLException as e:
            if e.sql_error_code in {ERRNO_DOMAIN_NOT_EXIST, ERRNO_STAGE_NOT_EXIST}:
                raise ValueError(
                    f"Stage {self.stage_name} does not exist or is not authorized."
                ) from e
            else:
                raise e
        return presigned_urls


def _match_error_code(
    ex: snowpark_exceptions.SnowparkSQLException, error_code: int
) -> bool:
    # Snowpark writes error code to message instead of populating e.sql_error_code
    error_code_str = str(error_code)
    return ex.sql_error_code == error_code_str or error_code_str in ex.message


def _resolve_async_job(async_job: AsyncJob) -> List[Row]:
    # Make sure Snowpark exceptions are properly caught and converted by wrap_exception wrapper
    try:
        query_result = cast(List[Row], async_job.result("row"))
        return query_result
    except errors.DatabaseError as e:
        # HACK: Snowpark surfaces a generic exception if query doesn't complete immediately
        # assume it's due to FileNotFound
        if type(e) is errors.DatabaseError and "results are unavailable" in str(e):
            raise ValueError("Query failed.") from e
        assert e.msg is not None
        raise snowpark_exceptions.SnowparkSQLException(e.msg, conn_error=e) from e
