import os
import ray
from typing import Any, List, Optional
import time
import traceback
from snowflake.runtime.utils.logger import (
    get_logger,
    print_user_log_warn,
)

logger = get_logger()

NODE_SESSION_DIR = os.getenv("NODE_SESSION_DIR", "/tmp/ray/session_latest")
IN_RAY_TASK_ENV_VAR = "IN_RAY_TASK"


def get_head_node_ip_address():
    """Get head node IP address from any Ray node"""
    runtime_context = ray.get_runtime_context()
    gcs_address = runtime_context.gcs_address
    head_node_ip = gcs_address.split(":")[0]
    return head_node_ip


def get_ray_dashboard_address():
    """Get Ray dashboard address. This is called lazily after Ray is initialized."""
    dashboard_port = os.getenv("DASHBOARD_PORT", "12003")
    return f"http://{get_head_node_ip_address()}:{dashboard_port}"


def get_node_ip_address():
    # TODO: Get session directory from env variable.
    return ray._private.services.get_cached_node_ip_address(
        session_dir=NODE_SESSION_DIR
    )


def is_running_in_ray_task():
    import os

    return os.getenv(IN_RAY_TASK_ENV_VAR, None) is not None


def interruptible_ray_get(
    object_ref: ray.ObjectRef, check_interval: float = 0.1
) -> Any:
    """
    A wrapper around ray.get that can be interrupted.

    Why ray.get cannot be interrupted:
    Snowflake notebook has a architecture where the user code is executed in a thread instead of a process.
    As a result of this, all code that blocked on native execution cannot receive signals.
    The ray.get function is one such function that blocks on native execution.
    Hence, when user press "Cancel", the signal cannot interrupt the ray.get() call.

    Args:
        object_ref: Ray object reference to wait for
        check_interval: How frequently to check if the task is done (in seconds)

    Returns:
        The result from the ray task

    Raises:
        KeyboardInterrupt: If interrupted during execution
    """
    while True:
        # Use ray.wait with timeout=0 to check if the task is ready
        # This is non-blocking and returns immediately
        ready_refs, remaining_refs = ray.wait(
            [object_ref], timeout=0, num_returns=1  # Don't actually wait
        )

        if ready_refs:  # Task is complete
            return ray.get(
                object_ref
            )  # Safe to call ray.get now since we know it's ready

        # Add a short interval to avoid busy waiting
        # this sleep is also not interruptible since it's a native call
        # however, since it is a short sleep, it should not be a problem
        time.sleep(check_interval)


def find_actors(
    *, exact_name: Optional[str] = None, prefix: Optional[str] = None
) -> List[str]:
    """
    Find Ray actors by exact name or by prefix.

    Args:
        exact_name (str, optional): Exact actor name to match. If provided, only this name will be matched.
        prefix (str, optional): Actor name prefix to match.
            If provided, all actors starting with this prefix will be returned.

    Returns:
        List[str]: List of matching actor names.

    Raises:
        ValueError: If both exact_name and prefix are provided or both are None.
    """
    if (exact_name is None and prefix is None) or (
        exact_name is not None and prefix is not None
    ):
        raise ValueError("You must provide exactly one of 'exact_name' or 'prefix'.")

    all_actors = ray.util.list_named_actors()

    if exact_name is not None:
        return [actor_name for actor_name in all_actors if actor_name == exact_name]

    return [actor_name for actor_name in all_actors if actor_name.startswith(prefix)]


def kill_actors(actor_names: List[str]) -> bool:
    """
    Attempts to kill Ray actors by their names.

    For each actor name provided:
    - Tries to get the actor reference.
    - If the actor is not found, no-op.
    - If the actor is found, attempts to kill it without restart.
    - Logs a warning if killing the actor fails.

    Args:
        actor_names (List[str]): List of Ray actor names to kill.

    Returns:
        bool: True if all kill operations succeeded or actors not found,
              False if any kill operation failed.
    """
    all_success = True

    for actor_name in actor_names:
        try:
            actor = ray.get_actor(actor_name)
        except ValueError:
            # Actor not found, treat as success (nothing to kill)
            continue

        try:
            ray.kill(actor, no_restart=True)
        except Exception as exc:
            print_user_log_warn(logger, f"Failed to kill actor '{actor_name}': {exc}")
            all_success = False

    return all_success


class RuntimeRayTaskError(RuntimeError):
    """Error when there is a unpicklable error in a Ray task.

    For example, all session related error are not picleable.

    This class has to only contains pickable data.
    """

    def __init__(self, original_type, message, traceback_str):
        super().__init__(message)
        self.message: str = message
        self.original_type: str = original_type
        self.traceback_str: str = traceback_str

    def __reduce__(self):
        """
        Implement __reduce__ to help Ray with serialization
        """
        return (self.__class__, (self.original_type, self.message, self.traceback_str))

    @classmethod
    def from_exception(cls, exc: Exception) -> "RuntimeRayTaskError":
        """
        Create a picklable exception from any exception

        Args:
            exc: The original exception to wrap

        Returns:
            A new PicklableException instance containing the original exception info
        """
        return cls(
            original_type=exc.__class__.__name__,
            message=str(exc),
            traceback_str="".join(traceback.format_tb(exc.__traceback__)),
        )

    def __str__(self) -> str:
        """This is used to print the error message which will be called by ray"""
        return (
            f"Original exception type: {self.original_type}\n"
            f"Message: {self.message}\n"
            f"Traceback:\n{self.traceback_str}"
        )
