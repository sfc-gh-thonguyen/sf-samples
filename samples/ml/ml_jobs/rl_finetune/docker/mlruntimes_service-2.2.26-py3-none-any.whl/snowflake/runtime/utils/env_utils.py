from pathlib import Path


def get_mlruntimes_path() -> Path:
    cur_path = Path(__file__).resolve()
    root_path = cur_path
    while root_path.name != "mlruntimes" and root_path.parent != root_path:
        root_path = root_path.parent
    if root_path.name != "mlruntimes":
        raise ValueError(f"Path {cur_path} invalid.")
    return root_path.resolve()


def get_mlruntimes_service_path() -> Path:
    runtime_path = get_mlruntimes_path()
    service_path = runtime_path / "service"
    if not service_path.exists():
        raise RuntimeError("service path did not exist.")
    return service_path
