from prometheus_client import (
    Counter,
    Histogram,
    Summary,
    multiprocess,
    start_http_server,
    CollectorRegistry,
    disable_created_metrics,
)
from snowflake.runtime.utils.const import MLRS_METRICS_PORT
import enum

_MLRUNTIME_METRIC_PREFIX = "mlruntime"

TRAIN_BUCKET = (30, 120, 300, 600, 1200, 3600, 7200, float("inf"))
# Set the upper limit to 12min as the timeout for scale cluster is 12min
SCALE_BUCKET = (10, 30, 60, 90, 120, 180, 240, 480, 720, float("inf"))
# Set the upper limit to 24h
MMT_BUCKET = (
    30,
    120,
    300,
    600,
    1200,
    3600,
    7200,
    14400,
    28800,
    43200,
    57600,
    72000,
    86400,
    float("inf"),
)

# We need the registry to be shared across all the modules
# Otherwise integ test will fail
registry = CollectorRegistry()


# Ideally, we'd have an Enum class that enforces prefixes for all metrics, with MLRSPrometheusMetrics inheriting from
# it. However, Prometheus' register/unregister logic is problematic; /metrics endpoint returns both old and new metric
# names even after deregistration. Thus, we apply this helper function on metric creation and rely on unit tests to
# ensure proper prefixing for all metric enums.
def _prepend_metric_prefix(metric_name: str):
    return f"{_MLRUNTIME_METRIC_PREFIX}_{metric_name}"


class MLRSPrometheusMetrics(enum.Enum):
    # Service metrics
    SERVICE_START = Counter(
        _prepend_metric_prefix("service_start"),
        "Number of successful launches of the ML Runtime Service",
        registry=registry,
    )
    SERVICE_TERMINATE = Counter(
        _prepend_metric_prefix("service_terminate"),
        "Number of successful terminations of the ML Runtime Service",
        registry=registry,
    )

    # Configuration metrics
    CUDA_GPU_COUNT = Summary(
        _prepend_metric_prefix("cuda_gpu_count"),
        "Number of GPU accessible from pytorch.cuda",
        registry=registry,
    )

    # Progress Trackers
    PROGRESS_TRACKER_UPDATE = Counter(
        _prepend_metric_prefix("progress_tracker_update"),
        "Number of progress tracker messages sent to client",
        registry=registry,
    )

    PROGRESS_TRACKER_EXCEPTION = Counter(
        _prepend_metric_prefix("progress_tracker_exception"),
        "Number of progress tracker exceptions",
        registry=registry,
    )

    # Ray Jobs API
    RAY_JOB_ATTEMPT = Counter(
        _prepend_metric_prefix("ray_job_attempt"),
        "Number of job requests attempted on Ray",
        registry=registry,
    )
    RAY_JOB_SUCCESS = Counter(
        _prepend_metric_prefix("ray_job_success"),
        "Number of successful job requests attempted on Ray",
        registry=registry,
    )
    RAY_JOB_FAILURE = Counter(
        _prepend_metric_prefix("ray_job_failure"),
        "Number of failed job requests attempted on Ray",
        registry=registry,
    )

    # Train metrics
    TRAIN_ATTEMPTS = Counter(
        _prepend_metric_prefix("train_attempts"),
        "Number of received requests to train models",
        registry=registry,
    )
    TRAIN_LGBM = Counter(
        _prepend_metric_prefix("train_lgbm"),
        "Number of received requests to train using lgbm models",
        registry=registry,
    )
    TRAIN_XGB = Counter(
        _prepend_metric_prefix("train_xgb"),
        "Number of received requests to train using XGB models",
        registry=registry,
    )
    TRAIN_PYTORCH = Counter(
        _prepend_metric_prefix("train_pytorch"),
        "Number of received requests to train using PyTorch models",
        registry=registry,
    )
    TRAIN_PYTORCH_EXECUTION_MODE = Counter(
        _prepend_metric_prefix("train_pytorch_execution_mode"),
        "Number of PyTorch training requests by execution mode (ray_job vs non_rayjob)",
        ["mode"],
        registry=registry,
    )
    TRAIN_GPU_LGBM = Counter(
        _prepend_metric_prefix("train_gpu_lgbm"),
        "Number of received requests to train using LGBM models on GPU",
        registry=registry,
    )
    TRAIN_GPU_XGB = Counter(
        _prepend_metric_prefix("train_gpu_xgb"),
        "Number of received requests to train using XGBoost models on GPU",
        registry=registry,
    )
    TRAIN_GPU_UNEXPECTED_MODEL = Counter(
        _prepend_metric_prefix("train_gpu_unexpected_model"),
        "Number of received requests to train on GPU using an unexpected model architecture",
        registry=registry,
    )
    TRAIN_SUCCESS = Counter(
        _prepend_metric_prefix("train_success"),
        "Number of successful responses to train models",
        registry=registry,
    )
    TRAIN_EXCEPTION = Counter(
        _prepend_metric_prefix("train_exception"),
        "Number of exception responses to train models",
        registry=registry,
    )
    TRAIN_PARSE_ERROR = Counter(
        _prepend_metric_prefix("train_parse_error"),
        "Number of internal parse errors to train models",
        registry=registry,
    )
    TRAIN_DURATION_UNFILTERED = Histogram(
        _prepend_metric_prefix("train_seconds"),
        "Time spent processing train request (unfiltered)",
        buckets=TRAIN_BUCKET,
        registry=registry,
    )
    TRAIN_DURATION_SUCCESS = Histogram(
        _prepend_metric_prefix("train_success_seconds"),
        "Time spent processing train request filtered by successful response",
        buckets=TRAIN_BUCKET,
        registry=registry,
    )
    TRAIN_DURATION_ABANDONED = Histogram(
        _prepend_metric_prefix("train_abandoned_seconds"),
        "Time spent processing train request filtered by abandoned attempt",
        buckets=TRAIN_BUCKET,
        registry=registry,
    )
    TRAIN_DURATION_DISCONNECTED = Histogram(
        _prepend_metric_prefix("train_disconnected_seconds"),
        "Time spent processing train request filtered by disconnected attempt",
        buckets=TRAIN_BUCKET,
        registry=registry,
    )

    # Score metrics
    SCORE_ATTEMPTS = Counter(
        _prepend_metric_prefix("score_attempts"),
        "Number of received requests to score models",
        registry=registry,
    )
    SCORE_SUCCESS = Counter(
        _prepend_metric_prefix("score_success"),
        "Number of successful responses to score models",
        registry=registry,
    )
    SCORE_EXCEPTION = Counter(
        _prepend_metric_prefix("score_exception"),
        "Number of exception responses to score models",
        registry=registry,
    )
    SCORE_PARSE_ERROR = Counter(
        _prepend_metric_prefix("score_parse_error"),
        "Number of internal parse errors to score models",
        registry=registry,
    )
    SCORE_DURATION_UNFILTERED = Histogram(
        _prepend_metric_prefix("score_duration_seconds"),
        "Time spent processing score request (unfiltered)",
        registry=registry,
    )
    SCORE_DURATION_SUCCESS = Histogram(
        _prepend_metric_prefix("score_success_seconds"),
        "Time spent processing score request filtered by successful response",
        registry=registry,
    )
    SCORE_DURATION_ABANDONED = Histogram(
        _prepend_metric_prefix("score_abandoned_seconds"),
        "Time spent processing score request filtered by abandoned attempt",
        registry=registry,
    )
    SCORE_DURATION_DISCONNECTED = Histogram(
        _prepend_metric_prefix("score_disconnected_seconds"),
        "Time spent processing score request filtered by disconnected attempt",
        registry=registry,
    )

    # General errors metrics
    USER_CODE_ERROR = Counter(
        _prepend_metric_prefix("user_code_error"),
        "Error in python code passed in by a user",
        registry=registry,
    )

    TUNE_REQUESTS = Counter(
        _prepend_metric_prefix("tune_requests"),
        "Total number of tune requests",
        ["status"],
        registry=registry,
    )

    TUNE_DURATION = Histogram(
        _prepend_metric_prefix("tune_duration_seconds"),
        "Duration of tune requests in seconds",
        ["status"],
        registry=registry,
        buckets=MMT_BUCKET,
    )

    # Multi Node scaling metrics
    MULTI_NODE_SCALING_UP_LATENCY = Histogram(
        _prepend_metric_prefix("multi_node_scaling_up_latency_seconds"),
        "Time spent executing Multi Node Scaling up function",
        registry=registry,
        buckets=SCALE_BUCKET,
    )

    MULTI_NODE_SCALING_DOWN_LATENCY = Histogram(
        _prepend_metric_prefix("multi_node_scaling_down_latency_seconds"),
        "Time spent executing Multi Node Scaling down function",
        registry=registry,
        buckets=SCALE_BUCKET,
    )

    MULTI_NODE_SCALING_SUCCESS = Counter(
        _prepend_metric_prefix("multi_node_scaling_success"),
        "Multi Node scaling Operation Success",
        registry=registry,
    )

    MULTI_NODE_SCALING_FAILURE = Counter(
        _prepend_metric_prefix("multi_node_scaling_failure"),
        "Multi Node scaling Operation Failure",
        registry=registry,
    )

    MULTI_NODE_SCALING_TIMEOUT = Counter(
        _prepend_metric_prefix("multi_node_scaling_timeout"),
        "Multi Node scaling Operation Timeout",
        registry=registry,
    )

    MMT_REQUESTS = Counter(
        _prepend_metric_prefix("mmt_requests"),
        "Total number of many model training(MMT) run. Each MMT run parallelize multiple training jobs",
        ["status"],
        registry=registry,
    )

    MMT_DURATION = Histogram(
        _prepend_metric_prefix("mmt_duration_seconds"),
        "Duration of the total many model training(MMT) run in seconds",
        ["status"],
        registry=registry,
        buckets=MMT_BUCKET,
    )

    # Data Ingestion API metrics
    DATASINK_WRITE_TASKS = Counter(
        _prepend_metric_prefix("datasink_write_tasks"),
        "Number of Ray write tasks created",
        ["datasink_type"],
        registry=registry,
    )

    DATASINK_WRITE_RESULT = Counter(
        _prepend_metric_prefix("datasink_write_result"),
        "Status of datasink writes",
        ["datasink_type", "status"],
        registry=registry,
    )

    DATASINK_ROWS_WRITTEN = Counter(
        _prepend_metric_prefix("datasink_rows_written"),
        "Total number of rows written to Snowflake tables",
        ["datasink_type"],
        registry=registry,
    )

    DATASINK_WRITE_DURATION = Histogram(
        _prepend_metric_prefix("datasink_write_duration_seconds"),
        "Time spent writing data to Snowflake tables",
        ["datasink_type"],
        registry=registry,
    )

    DATASINK_RETRY_ATTEMPTS = Counter(
        _prepend_metric_prefix("datasink_retry_attempts"),
        "Number of retry attempts due to lock limits",
        ["datasink_type"],
        registry=registry,
    )

    DATASINK_EMPTY_WRITE_BLOCKS = Counter(
        _prepend_metric_prefix("datasink_empty_write_blocks"),
        "Number of write tasks with empty blocks",
        ["datasink_type"],
        registry=registry,
    )

    DATASOURCE_READ_TASKS = Counter(
        _prepend_metric_prefix("datasource_read_tasks"),
        "Number of Ray read tasks created",
        ["datasource_type"],
        registry=registry,
    )

    DATASOURCE_READ_FILES = Counter(
        _prepend_metric_prefix("datasource_read_files"),
        "Number of files read from the datasource",
        ["datasource_type"],
        registry=registry,
    )

    DATASOURCE_FAILED_READ_TASKS = Counter(
        _prepend_metric_prefix("datasource_failed_read_tasks"),
        "Number of Ray read tasks failed",
        ["datasource_type", "error_type"],
        registry=registry,
    )

    DATASOURCE_ROWS_READ = Counter(
        _prepend_metric_prefix("datasource_rows_read"),
        "Total number of rows read from Snowflake stages",
        ["datasource_type"],
        registry=registry,
    )

    DATASOURCE_WRITE_TO_LOCAL = Counter(
        _prepend_metric_prefix("datasource_write_to_local"),
        "Total bytes written to local storage",
        ["datasource_type"],
        registry=registry,
    )

    DATA_INGESTER_TOBATCH = Counter(
        _prepend_metric_prefix("data_ingester_tobatch"),
        "Number of data ingester to batch operations",
        ["batch_type"],
        registry=registry,
    )
    DATA_INGESTER_TABLE_ROWS_READ = Counter(
        _prepend_metric_prefix("data_ingester_table_rows_read"),
        "Total number of rows read from Snowflake tables by the data ingester",
        registry=registry,
    )

    DATA_INGESTER_READ_DURATION = Histogram(
        _prepend_metric_prefix("data_ingester_read_duration_seconds"),
        "Duration of the data ingester read job in seconds",
        ["data_type"],
        registry=registry,
    )

    DATA_INGESTER_READ_JOB = Counter(
        _prepend_metric_prefix("data_ingester_read_job"),
        "Number of read jobs executed by the data ingester",
        ["data_type", "status"],
        registry=registry,
    )


def start_prometheus_metrics_port():
    # ref: https://prometheus.github.io/client_python/instrumenting/#disabling-_created-metrics
    disable_created_metrics()
    multiprocess.MultiProcessCollector(registry)
    start_http_server(MLRS_METRICS_PORT, registry=registry)
