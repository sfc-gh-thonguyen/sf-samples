from snowflake.ml.data.data_connector import DataConnector
from snowflake.ml.data.data_source import DataFrameInfo, DatasetInfo
from snowflake.ml.data.internal_data_connector import InternalDataConnector
from snowflake.runtime.utils.session_utils import get_session
from implementations.ray_data_ingester import RayDataIngester


def replace_data_connector_ingestor_with_ray_ingestor(
    dataset: DataConnector,
) -> InternalDataConnector:
    sources = []
    session = get_session()

    if isinstance(dataset._ingestor, RayDataIngester):
        return dataset

    for source in dataset.data_sources:
        if isinstance(source, DataFrameInfo):
            if source.query_id is not None:
                sources.append(source)
                continue
            # Need to collect using the same session on the client side to avoid session error
            # Otherwise the session inside ray cluster will not be able to access the data
            qid = session.sql(source.sql).collect_nowait().query_id
            sources.append(
                DataFrameInfo(
                    sql=source.sql,
                    query_id=qid,
                )
            )
        elif isinstance(source, DatasetInfo):
            sources.append(source)
        else:
            raise RuntimeError(f"Unsupported source type: {type(source)}")

    ray_data_ingestor = RayDataIngester(sources)
    return InternalDataConnector(ingestor=ray_data_ingestor)
