import logging
import datetime
from logging.handlers import RotatingFileHandler
from enum import Enum
import os
from snowflake.runtime.utils.const import LOG_TEST_UUID, TEST_DIR, TEST_MAX_BYTES
from snowflake.runtime.utils.global_contextvars import (
    request_id_contextvar,
    node_type_contextvar,
)
from ray.data.context import DataContext

MLRS_LOGGER_NAME = "mlrs"
MLRS_LOGGING_FORMAT = (
    "%(asctime)s,%(msecs)03d - MLRS - %(node_type)s - %(levelname)s - %(message)s - "
    "REQUEST_ID - %(request_id)s"
)
MLRS_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"  # e.g 2024-03-25 23:11:02
MLRS_FILE_NAME = "/var/log/managedservices/{log_type_name}/mlrs/logs-mlrs.log"
LOG_MAX_BYTES = 512_000_000


def IS_DEV_ENV():
    return os.getenv("DEV_ENV", None)


def print_user_log_info(logger: logging.Logger, log_message: str, extra=None):
    """
    Print the logs to stdout which is sent back to Ray driver from the workers/tasks.
    Can be replaced with Ray Queue as named actors to pass events to driver and
    driver can append these logs to "mlrs" logger.
    """
    if extra is None:
        extra = {"log_types": [LogType.SYSTEM]}
    logger.info(log_message, extra=extra)
    print(f"Info - {datetime.datetime.now()} - {log_message}")


def print_user_log_warn(logger: logging.Logger, log_message: str, extra=None):
    if extra is None:
        extra = {"log_types": [LogType.SYSTEM]}
    logger.warning(log_message, extra=extra)
    print(f"Warning! - {datetime.datetime.now()} - {log_message}")


def get_logger() -> logging.Logger:
    logger = logging.getLogger(name=MLRS_LOGGER_NAME)
    logger.setLevel(logging.INFO)
    if (
        len(logger.handlers) == 0
    ):  # cannot use hasHandlers as the function searches up the hierarchy for handlers
        handler = CustomLoggingHandler()
        logger.addHandler(handler)

    if IS_DEV_ENV():
        # propagate logs to root streaming logger for dev env
        logger.propagate = True
    else:
        logger.propagate = False
    return logger


def set_mlrs_logger_level(log_level: int):
    logger = logging.getLogger(name=MLRS_LOGGER_NAME)
    logger.setLevel(log_level)


# Ray Data logger names to suppress
RAY_DATA_LOGGERS_TO_SUPPRESS = [
    "ray.data",
    "ray.data._internal.execution",
    "ray.data._internal.execution.streaming_executor",
    "ray.data._internal.progress",
    "ray.data._internal.logging",
]


def configure_ray_data_logging() -> None:
    """
    Configure Ray Data to suppress progress bars and verbose output.

    This function uses multiple approaches for defense-in-depth:
    1. DataContext API: Ray's native way to control progress bars and verbosity
    2. Python logging: Suppresses logs that may not be controlled by DataContext
    3. Environment variables (set elsewhere): Controls settings at Ray initialization

    All three approaches are needed because:
    - DataContext affects Ray Data's internal progress reporting
    - Python logging catches any logs not controlled by DataContext
    - Environment variables work globally across all Ray processes
    """
    # Configure Ray Data context (Ray-native way)
    try:
        context = DataContext.get_current()
        context.execution_options.verbose_progress = False
        context.enable_operator_progress_bars = False
        context.enable_progress_bars = False
    except (ImportError, AttributeError, RuntimeError):
        # Ray Data not available, context not initialized, or API changed
        pass

    # Suppress Ray Data logs via Python logging (fallback/defense-in-depth)
    for logger_name in RAY_DATA_LOGGERS_TO_SUPPRESS:
        logging.getLogger(logger_name).setLevel(logging.ERROR)


def configure_ray_logger() -> None:
    # Configure Ray logging
    ray_logger = logging.getLogger("ray")
    ray_logger.setLevel(logging.CRITICAL)

    data_logger = logging.getLogger("ray.data")
    data_logger.setLevel(logging.CRITICAL)

    # Configure root logger
    logger = logging.getLogger()
    logger.setLevel(logging.CRITICAL)

    context = DataContext.get_current()
    context.enable_operator_progress_bars = False


class LogType(Enum):
    USER = 0
    SYSTEM = 1


class CustomLoggingHandler(logging.Handler):
    """Custom Logging Handler as a wrapper for all the sub MLRS file handlers"""

    def __init__(self) -> None:
        super().__init__()
        self.handlers = {}
        # TODO: prob there's a way to patch; tried mock.patch but does not work due to module import
        maxBytes = LOG_MAX_BYTES if not IS_DEV_ENV() else TEST_MAX_BYTES
        for log_type in LogType:
            handler = RotatingFileHandler(
                filename=self._generate_file_path(log_type),
                mode="a",
                maxBytes=maxBytes,
                backupCount=1,
            )
            handler.setFormatter(
                logging.Formatter(
                    fmt=MLRS_LOGGING_FORMAT,
                    datefmt=MLRS_DATE_FORMAT,
                )
            )
            self.handlers[log_type] = handler

    def _generate_file_path(self, log_type: LogType) -> str:
        """Generate output file path for logs
        Args:
            log_type: type of logs, i.e system, user
            log_src: where the logs are from, i.e mlrs, ray-head, ray-worker...

        Returns:
            _description_
        """
        if IS_DEV_ENV():
            os.makedirs(TEST_DIR, exist_ok=True)
            log_file = (
                f"{TEST_DIR}/{log_type.name.lower()}-logs-mlrs-{LOG_TEST_UUID}.log"
            )
            return log_file
        return MLRS_FILE_NAME.format(log_type_name=log_type.name.lower())

    def emit(self, record: logging.LogRecord):
        """Emit is used whenever a logger with this CustomLoggingHandler logs a message. MLRS LogRecord should contain
        an extra field describing the log types. The log is recorded in various files depending on what
        log type it is.

        e.g logger.info(msg="Some info", extra={"log_types": [LogType.USER]})

        A log can be of multiple types, i.e both user and system logs, which will be recorded in both user and system
        log files. If log_types field is not specified, logging to both user and system files becomes the default
        behavior

        Args:
            record: LogRecord
        """
        record.request_id = request_id_contextvar.get()
        record.node_type = node_type_contextvar.get()
        if hasattr(record, "log_types"):
            for log_type in record.log_types:  # Record can be multiple types
                self.handlers[log_type].emit(record)
        else:
            # default, logging to both user and system files
            for handler in self.handlers:
                self.handlers[handler].emit(record)
